# Owner-scoped five-role improvement cycle — 2026-11-04

## Goal / authorization

Owner explicitly requested: (1) resume five logical ChatGPT agents in an indefinite recurring cycle, (2) verify historical Scheduler runs, (3) improve this multi-agent system, (4) monitor execution.

**Boundary:** This document authorizes scoped **test/dev work only in the isolated portable staging copy** `Tunnel-release-staging`. It does NOT grant host identity, P085, reviewer authority, Git merge/push, permission to modify the LIVE coordinator/SQLite/queues, or the right to resend ambiguous ChatGPT UI messages. No paid API calls, no use of extra accounts or bypassing provider limits.

The current plan allows at most five active Scheduler automations. Four development/review schedule cards represent five **logical roles** (developer-3 and developer-4 execute sequentially in the same card); a fifth unrelated certificate schedule remains. The former Chain2 monitor is consolidated into architect-reviewer. These are **hourly recurring launches**, not five guaranteed simultaneous LLM processes or infinite tokens.

## Shared operating agreement

1. `list_workspaces` -> alias `projects`; verify read/write/execute capability and inspect this work-order. Read existing `Local-Workspace-Extensions/AGENTS.md` and normative SDD for context only; never rewrite protected live code or bypass `host_actor_authenticated=false`.
2. Every execution: check actual SHA-256 of own targets; inspect latest revision and relevant tests. Preserve external edits via SHA compare-and-swap. No overwrite if file drift, concurrent edit, unrecognized path, symlink or unclear ownership.
3. Only touch files listed for the role under `Tunnel-release-staging`. No runtime states, credential files, local `config.json`, `bridge-config.json`, `.local-mcp-state`, `bridge-state`, operational databases, `agent-briefs`, `agent-reports`, website credentials or browser sessions.
4. Prefer a novel reproducible negative test before implementing a targeted fix. Rerun focused tests and `scripts/verify-portable-install.py --test-powershell` when relevant; don't modify published binaries or upload to GitHub automatically.
5. Record an outcome that distinguishes `CODE_CHANGED_TESTED`, `READ_ONLY_FINDING`, `BLOCKED` and `NO_NOVEL_WORK` with exact paths, source SHA before/after, job IDs, return code, observed tests and next steps. Do not claim success on incomplete/pending job, skip, own assertion or previous test report.
6. If no new source SHA or new failure, do not repeat previous tests or generate more variants merely to fill a clock. End with a truthful blocker and let next scheduled run check for changes.

## Four independent developer lanes

### D1 — Chain2 reconciliation (owner-scoped staging only)
- Files: `Tunnel-release-staging/scripts/chain2-triage.py`; `Tunnel-release-staging/scripts/test_chain2_triage.py`.
- Goal: stronger classification of 9 stuck ACTIVE (UNKNOWN/ambiguous browser send, invalid handoff, valid handoff without request); fail-closed invalid JSON/cross-parent/duplicate/out-of-order evidence. Do NOT replay sends, create synthetic ACK, change live Chain2 queues or mark DONE.
- Gate: test 8 existing cases + add one genuinely new negative property; real CLI against existing live data is **read-only**.

### D2 — Health/monitoring diagnostics
- Files: `Tunnel-release-staging/scripts/status-stack.py`; `Tunnel-release-staging/scripts/test_status_stack.py`.
- Goal: reliable single-command health status for MCP, bridge, browser extension, Chain2/Chain3 and concise remediation with no token leaks, falsified LIVE status or automatic startup. Avoid misclassifying failed tests and future timestamps.
- Gate: focused unittest + CLI in clean staging; no privileged calls.

### D3 — Browser recovery regression
- Files: `Tunnel-release-staging/chat-launch-smoke-desktop-test/web-companion/test_v066_ui_recovery.py` and `Tunnel-release-staging/chat-launch-smoke-desktop-test/web-companion/test_recovery.js`.
- Goal: new negative regression for new-chat URL changes, lost connection, repeated send, unexpected tab close and de-duplication; test-only modifications. No real browser tabs launched, no auto-retry of UNKNOWN or bypass of rate limits.
- Gate: relevant Python unittest and Node tests, with explicit SKIP if runtime missing.

### D4 — ZIP/portable install integrity
- Files: `Tunnel-release-staging/scripts/build-distribution.py`; `Tunnel-release-staging/scripts/test-distribution.py`.
- Goal: packaging fail-closed on private data, symlinks, ZIP path traversal, checksum drift, second installer run, and archive/source mismatch. Only publish packaging recommendations; do not rebuild public ZIP or commit/push without independent owner review.
- Gate: archive validation on known-good ZIP and focused negative tests with deterministic fixtures.

## Architect Reviewer / monitor
- Do independent read-only review of newly changed D1/D2/D3/D4 files and test evidence (SHA-fenced; do not self-approve code). Evaluate P085 on live environment via `p085_autonomous_guard.py --write-report`, but green offline tests do not grant protected host permission.
- In each scheduled run, invoke read-only `chain2_lineage_monitor.py`, `chain2_blocker_dossier.py`, `chain_campaign.py preview`, `chain3_continuous.py preview` and `p085_readiness_matrix.py`; require actual `job_status=completed`, `returncode=0`, JSON `ok=true` where applicable.
- Compare exact job IDs and blocker codes with prior run and report meaningful deltas. No duplicate notification when no changes; no owner grants, write operations, untrusted role-based acceptance, or guesses from ACTIVE about actual model execution.
- Reviewer records independent verdict `advisory-ready` / `changes-requested` only. Formal merge/accept requires actual trusted principal, protected host and separate authorized process.

## Exit gates (not yet met)

- P085 actual OS identity and real two-principal Windows E2E validated.
- Chain2 50 stages accepted or safely dispositioned, with no disputed browser sends.
- Chain3 successfully demonstrates `developer -> reviewer -> developer` in a user-approved sandbox with valid immutable receipts, SHA checks, no duplicate browser send and permitted rate limits.
- An end-to-end independent Windows account uses own API keys and custom MCP; no existing ChatGPT session/authorization shared.
