# Chain2 live-source Triage and Status Stack remediation — 2026-11-04

## Constraints
This work inspects and edits code/tests/README in workspace `projects` via Local Workspace MCP. No browser sends, automatic retries, original-role impersonation, ACK generation/backfill, job-state or queue mutation, privilege changes, credential reads, Windows broker activation or Chain3 startup. Monitoring files are agent-editable advisory evidence, **not** trusted owner authorization.

## Reproduced defects and fixes
1. **False zero ACTIVE:** before the fix, `python scripts/chain2-triage.py` executed in `Tunnel-release-staging` reported `done=0,active=0,not_started=50` (job `13316a2356a943909f0e8eacf65e0d67`, rc=0). Running with `--root ..` observed the real `done=19,active=9` (job `db05678f2d434069830e8640de12fe66`). The helper had defaulted to an empty *staged copy*, not the sibling project. New `default_project_root()` selects the live sibling only when a real sibling Chain2 controller exists; otherwise uses the self-contained bundle directory for the installed archive.
2. **Stale message evidence:** triage previously called `successor_message_saved` (historical occurrence) `browser_saved_confirmed`, ignoring the lineage monitor's `successor_latest_send_confirmed`. Now distinguishes `browser_ever_saved` from `browser_saved_confirmed` and requires the latter for latest delivery confirmation.
3. **Account dispute missed:** the standalone lineage lacks full telemetry for a seed/original active job; `l07-p148` was misclassified as worker evidence incomplete even though original dossier said `ACCOUNT_CONTEXT_DISPUTED`. Added a second read-only diagnostic `chain2_blocker_dossier.py`; the CLI cross-checks exact active job IDs, ticket and role, record counts, the status allowlist, and both no-mutation flags. Contradictory/missing outputs fail closed. The original blocker classification takes precedence over lineage-derived guesses. Only enum-like statuses and safe actions appear in results; untrusted report details/account paths are not echoed.
4. **Untrusted monitor JSON:** added strict bounded parsing for two subprocess results (<=100 KiB, reject repeated JSON keys at any depth, NaN/Infinity and malformed content). A missing or corrupt dossier cannot silently become a healthy 0-ACTIVE report.
5. **Overall status contradiction:** before correction, `scripts/status-stack.py` showed source staging Chain2 as `done=0,active=0,ready=10` yet Triage had `active=9` (job `62b79a9719ad4d2ea876b3d4b8339465`). `_runtime_root()` now targets the real sibling controller/MCP/bridge in source checkout but uses the bundle root in a portable installation. A remaining active-count disagreement is shown explicitly as `inconsistent_views` rather than trusted. General monitor recognizes `identity_disputed` and `report_ack_unverified` categories and emits manual reconciliation steps.
6. **Docs/packaging:** updated `Tunnel-release-staging/README.md` explaining both evidence sources, the three main categories, archive root selection and no-replay policy.

## Latest verified file digests (SHA-256)
- `Tunnel-release-staging/scripts/chain2-triage.py` — `547d5f91fa92b460028a3e9c30aa533c547ac3ec7149da9dabef934fd4c74021`
- `Tunnel-release-staging/scripts/test_chain2_triage.py` — `6bfe83ace1c184abbbfb23c8e436de96ce6d1b880e900a95907228da89053971`
- `Tunnel-release-staging/scripts/status-stack.py` — `ccd108fc10ac37655d01bd3cd45e84f4b31ffe1494ce7c810c623a6ea2e5e3b8`
- `Tunnel-release-staging/scripts/test_status_stack.py` — `1ad2612a9b96c8a22096239177d6412772bdf0981298050abc02a7d36cf7bb9b`
- `Tunnel-release-staging/README.md` — `47c15b2757ea28cc6c1aa53af815c9cd028d6f17fdcc66c365adad7bff32ac5d`

## Actual tests and status
- Triage negative/hermetic tests: `be635e507a304c978eddc33b22224c3f`, completed returncode=0, **23/23 PASS** (including concurrent independent negative tests protecting invalid/missing handoffs).
- Status Stack tests: `98d6f382e61d418fb22ee7b0c48d43c9`, completed returncode=0, **12/12 PASS**; an earlier run `a82b2c8e2f50498c8028febd47420121` exposed an older mocked category dictionary missing `identity_disputed`; handled compatibly through absent-category=0, without bypassing live active-count checks.
- Portable installation validation: `945df233bc414dd3b6e771152b08c52c`, completed returncode=0, `ok=true`, 166 source files scanned, `mcp_http_auth=authorized_200_unauthorized_401`, PowerShell installer twice idempotent, 28 MCP tools, smoke tests pass, no live browser calls, owner_armed=false.
- Real Triage post-fix: `cb08851734cd4906a27d472a6ecf477e` (completed rc=0) correctly reported active=9, done=19, 4 `report_ack_unverified`, 4 `browser_delivery_uncertain`, 1 `identity_disputed`.
- Final real general monitor: `0eb3e3b9f3e54551bdc86a7b6217fc88`, completed returncode=0. `chain2.status=blocked_active`, `done=19`, `active=9`, `ready=0`, Chain2 `owner_armed=true` (local campaign flag only, not P085 OS authority). Triage categories are 4/4/1 and `manual_browser_checks=5`. `chain3.effective_mode=blocked`, `chain3.owner_armed=false`, `full_autonomous_ready=false`.

## Nine original jobs and owner-scoped next steps
- **Account context dispute, do not replay:** `l07-p148`, job `661a7381-5009-5731-9900-7c747dbe40d2`: original account and tab/conversation binding need independent verification before touching the job.
- **Pre-send unconfirmed, no auto retry:** `m01-roadmap-integ` (`bc8227e5-d1dd-52c4-a038-cb81cfa1f438`), `m03-approval-e2e` (`23e6c4b5-052e-5e06-92b7-c81e3ceed441`), `m04-ledger-e2e` (`ac998294-128c-5492-88b7-b552c67e0408`), `m08-p111-resource` (`00dd5b44-91de-577b-a381-79094323ec83`): independently check original browser/provider thread before any retry, because absence of a saved event is not proof no send occurred.
- **Original report present but no ACK:** `l02-redaction` (`c6a6fb47-8f47-57f5-8a3e-fc90170ea7ed`), `l06-p108` (`0b9076f2-af00-5f5b-90b0-adabc96492fc`), `m09-p096-recover` (`956ddd13-9c31-514b-a2bf-9b3a377b727d`), `n05-runtime-qa` (`ac7a5168-08e6-5d3a-ae48-17b5e3f160d0`): original authenticated agent must reconcile exact report hash, immutable handoff request and original ACK; `l02` also has invalid handoff-path evidence requiring its original actor's repair, not automatic rewriting.

## Remaining limits
This report prepares a safe deterministic operator worklist; it cannot claim nine live GPT generations, verify trusted provider sends or independently provision the P085 protected Windows broker. No recovery action authorized by this checkpoint, and Chain3 must remain blocked until original actor confirmations and separately verified owner-controlled protected identities/2-SID OS E2E.
