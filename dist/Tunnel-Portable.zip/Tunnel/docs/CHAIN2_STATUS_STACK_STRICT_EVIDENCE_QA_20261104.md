# Chain2 / Chain3 Status Stack — strict evidence, accounting and heartbeat QA
Date: 2026-11-04. Workspace: `projects` (Local Workspace MCP).

## Changes (read-only monitoring; no live job mutation)

1. **Job-list consistency:** `scripts/status-stack.py` now refuses a Triage claim of `active=0` with nonempty `jobs`. It validates required read-only/no-replay flags, Chain2 campaign, exact job count, distinct canonical UUIDs, bounded ticket names, allowed developer/reviewer roles, each job's category, known category count totals, and no unexpected category keys.
2. **Campaign accounting:** validates `total_stages = done + active + queued + not_started`; all quantities must be nonnegative integers (not booleans), at most 100, and `done_with_verified_report_ack <= done`. Returns non-sensitive counts. General status compares **both** DONE and ACTIVE against Chain2's independent preview; disagreement is `inconsistent_views`.
3. **Ambiguous subprocess output:** `_strict_output_json` rejects duplicate JSON keys even when nested, NaN/Infinity, malformed and overlong JSON from Chain2/Chain3 previews and Chain2 Triage. A failed parser cannot silently assert `ok=true`, `owner_armed`, or an empty campaign.
4. **Extension heartbeat:** `_json_file` bounds actually read bytes (not just initial stat), rejects symlinks/junctions in the file/immediate parent and parses strict JSON. Duplicate `at` timestamps no longer forge a fresh heartbeat.
5. **Defensive status rendering:** missing optional category keys in a test or legacy/partial view no longer crash the status monitor. Actual Triage results still have their full schema validated before rendering.

## SHA-256 evidence

- `Tunnel-release-staging/scripts/status-stack.py` — `661ff342d606a8996bb0f921392320fed45d9828c039eb04aed19b7aba7ce8fc`.
- `Tunnel-release-staging/scripts/test_status_stack.py` — `38eabd12765b48615a526264449138d491faea4f0d8b854bf5cee93e4d375101`.
- Upstream read-only Triage `Tunnel-release-staging/scripts/chain2-triage.py` unchanged here — `547d5f91fa92b460028a3e9c30aa533c547ac3ec7149da9dabef934fd4c74021`.

## Reproduction and regression receipts

- Job `05d222dd6dd84cb5a37526285796a624`: intentionally failing test on old Triage aggregation — 3 failures from falsified/inconsistent job-list evidence, including `active=0` while a job is listed.
- Job `cab50e30c2b243bfa05e51d8dad51875`: intentionally failing old preview parsing — 5 failures for repeated keys / NaN / Infinity.
- Job `49164bbd3d444950a39390830446bd82`: intentionally failing old DONE cross-view comparison, `blocked_active` instead of required `inconsistent_views`.
- Job `2daacbc4689748599a82dca1c3ebd987`: intentionally failing old heartbeat parsing — duplicate `at` reported `recent`.
- Job `e7d45373e54148d1b6352fd17ceb41c7`: completed rc=0, final focused **18 PASS / 0 FAIL**; includes negative accounting, role, SHA-free job identity, JSON, future clock, heartbeat checks.
- Job `befd397c28bf4fed824f3253dab20641`: completed rc=0, full staging unittest discovery `-s scripts -p test_*.py`, **47 run / 46 PASS / 1 SKIP / 0 FAIL**.
- Job `5ef4aa6a9d9f46b7adac1d7017571345`: completed rc=0, real read-only `status-stack.py`: Chain2 `done=19, active=9, ready=0`, Triage `done=19, active=9, queued=0, not_started=22, total_stages=50, done_with_verified_report_ack=19`. Subgroups: 4 report-ACK-unverified, 4 browser-delivery-uncertain, 1 identity-disputed. `chain3.effective_mode=blocked`, `owner_armed=false`, `full_autonomous_ready=false`.
- Job `d1be28d02228432e9b1242415257b1b1`: completed rc=0, portable install verification `ok=true`, 175 files scanned, 28 MCP tools, PowerShell installer idempotence and auth checks passed, extension version 0.8.5 in that verification, `no_live_browser_calls=true`.

## Non-claims and remaining steps

These tests are hermetic/offline. They do not prove original actor identity, trusted browser delivery, authenticated host receipt, protected Windows ACL/OS principals or production readiness. Original 9 ACTIVE Chain2 records must be reconciled by their genuine actors: 4 uncertain browser sends (no auto replay), 4 reports without original verified ACK (no fabricated ACK), 1 disputed account/tab binding (quarantine). P085 still requires owner-controlled protected service, dedicated Windows principals and independent negative 2-SID OS E2E. Do not auto-arm Chain3 or infer that `ACTIVE` means an LLM is currently working.
