"""Install official MCP SDK into THIS project's .venv only; never global Python."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
uv = shutil.which("uv")
results = []
if uv is None:
    print(json.dumps({"ok":False, "error":"uv_not_found"}))
    sys.exit(1)
venv = root / ".venv"
py = venv / "Scripts" / "python.exe" if sys.platform.startswith("win") else venv / "bin" / "python"
steps = []
if not py.exists():
    steps.append(["uv","venv",str(venv),"--python",sys.executable])
steps.append(["uv","pip","install","--python",str(py),"mcp>=2,<3"])
for cmd in steps:
    executable = uv if cmd[0] == "uv" else cmd[0]
    try:
        cp = subprocess.run([executable,*cmd[1:]],cwd=str(root),stdin=subprocess.DEVNULL,
                            capture_output=True,encoding="utf-8",errors="replace",
                            text=True,timeout=160,check=False)
        results.append({"command":cmd[0:2],"returncode":cp.returncode,
                        "stderr":cp.stderr[-1000:],"stdout":cp.stdout[-300:]})
        if cp.returncode != 0:
            break
    except (subprocess.TimeoutExpired, OSError) as exc:
        results.append({"command":cmd[0:2],"error":type(exc).__name__})
        break
if py.exists():
    cp = subprocess.run([str(py),"-c",
        "import importlib.metadata; print(importlib.metadata.version('mcp'))"],
        cwd=str(root),capture_output=True,text=True,timeout=15)
    results.append({"mcp_version":cp.stdout.strip(),"returncode":cp.returncode})
print(json.dumps({"ok":bool(results) and "mcp_version" in results[-1] and
                  results[-1]["returncode"]==0,"results":results},ensure_ascii=True))
