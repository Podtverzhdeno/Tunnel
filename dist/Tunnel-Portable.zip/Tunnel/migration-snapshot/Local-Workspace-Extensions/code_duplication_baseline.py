"""Read-only baseline of substantial code clones already in canonical source.

Inventory is source-hashed and deterministic. It does not modify or
automatically refactor existing code. Exact normalized AST matches are
structural clone candidates, not automatically approved architectural debt.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from code_reuse_guard import _entries,_load_module,_similarity,MAX_MODULES,NAME,MIN_NEAR_NODES,NEAR_JACCARD,ReuseGuardError

ROOT=Path(__file__).resolve().parent

def baseline(root=ROOT):
    root=Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ReuseGuardError("UNSAFE_PROJECT_ROOT")
    hashes=[]
    grouped=defaultdict(list)
    modules=0
    funcs=0
    candidates=[]
    for path in sorted(root.glob("*.py")):
        if path.name.startswith("test_") or not NAME.fullmatch(path.name):
            continue
        modules+=1
        if modules>MAX_MODULES:raise ReuseGuardError("SOURCE_INDEX_CAP_EXCEEDED")
        raw=path.read_bytes() if path.is_file() and not path.is_symlink() else b""
        tree=_load_module(path)
        hashes.append(f"{path.name}:{hashlib.sha256(raw).hexdigest()}")
        for e in _entries(path.name,tree):
            funcs+=1
            if e["node_count"]>=MIN_NEAR_NODES:
                candidates.append(e)
            grouped[e["hash"]].append({
                "module":e["file"],"symbol":e["symbol"],"line":e["line"],
                "source_module_sha256":hashlib.sha256(raw).hexdigest(),
                "body_nodes":e["node_count"]
            })
    clones=[]
    for digest,positions in grouped.items():
        if len({e["module"] for e in positions})<2:continue
        clones.append({"structural_body_sha256":digest,
                       "implementations":sorted(positions,key=lambda x:(x["module"],x["symbol"]))})
    clones.sort(key=lambda x:(-len(x["implementations"]),x["implementations"][0]["module"]))
    near=[]
    for i,one in enumerate(candidates):
        for other in candidates[:i]:
            if (one["file"]==other["file"] or one["hash"]==other["hash"]):
                continue
            similarity=_similarity(one,other)
            if similarity>=NEAR_JACCARD:
                near.append({
                    "left":{"module":one["file"],"symbol":one["symbol"],"line":one["line"]},
                    "right":{"module":other["file"],"symbol":other["symbol"],"line":other["line"]},
                    "heuristic_token_jaccard":round(similarity,4),
                    "requires_manual_code_inspection":True,
                })
    near.sort(key=lambda x:(-x["heuristic_token_jaccard"],x["left"]["module"],x["right"]["module"]))
    return {
        "schema":"canonical-code-clone-baseline-v1",
        "canonical_snapshot_sha256":hashlib.sha256("\n".join(hashes).encode()).hexdigest(),
        "scanned_modules":modules,
        "eligible_substantial_functions":funcs,
        "cross_module_clone_groups":len(clones),
        "near_similarity_groups":len(near),
        "near_pairs":near[:30],
        "near_truncated":len(near)>30,
        "groups":clones[:50],
        "truncated":len(clones)>50,
        "no_source_mutations":True,
        "requires_human_architecture_review":True,
        "semantic_equivalence_proven":False,
    }

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--root",default=str(ROOT))
    args=parser.parse_args()
    try:
        print(json.dumps({"ok":True,"data":baseline(args.root)},ensure_ascii=True))
        return 0
    except (ReuseGuardError,OSError,UnicodeError,ValueError,RecursionError) as exc:
        print(json.dumps({"ok":False,"error":str(exc)[:200]}))
        return 2

if __name__=="__main__":
    raise SystemExit(main())
