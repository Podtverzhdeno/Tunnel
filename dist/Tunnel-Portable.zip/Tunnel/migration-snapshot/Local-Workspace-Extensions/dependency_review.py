"""Offline, read-only dependency manifest review.

Only explicitly named files at the authorized project root are opened. This
module neither performs vulnerability lookups nor installs dependencies.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tomllib
from typing import Any

REPARSE = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
FILES = ("pyproject.toml", "requirements.txt", "package-lock.json")
KNOWN_PY_LOCKS = ("uv.lock", "poetry.lock", "requirements.lock")
REQ_NAME = re.compile(r"^([a-zA-Z][a-zA-Z0-9._-]{0,119})(?:\[[a-zA-Z0-9.,_-]{1,200}\])?\s*(.*)$")
EXACT_PY = re.compile(r"^==\s*[0-9][A-Za-z0-9.!+_-]*$")
NPM_MAJOR = re.compile(r"^[~^]?([0-9]+)\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9.-]+)?$")
SAFE_NAME = re.compile(r"^(?:@?[A-Za-z0-9._-]{1,90}/)?[A-Za-z0-9._-]{1,90}$")


class DependencyReviewError(ValueError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def _unsafe(path: Path, st: os.stat_result) -> bool:
    return (stat.S_ISLNK(st.st_mode)
            or bool(getattr(st, "st_file_attributes", 0) & REPARSE)
            or bool(getattr(path, "is_junction", lambda: False)()))


def _read_file(root: Path, name: str, max_bytes: int) -> tuple[str, str, int] | None:
    path = root / name
    try:
        before = path.lstat()
    except FileNotFoundError:
        return None
    except OSError:
        raise DependencyReviewError("UNREADABLE_FILE") from None
    if _unsafe(path, before) or not stat.S_ISREG(before.st_mode):
        raise DependencyReviewError("UNSAFE_FILE")
    if before.st_size > max_bytes:
        raise DependencyReviewError("FILE_TOO_LARGE")
    fd = None
    try:
        if not path.resolve(strict=True).is_relative_to(root):
            raise DependencyReviewError("UNSAFE_FILE")
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_BINARY", 0) |
                     getattr(os, "O_NOFOLLOW", 0))
        opened = os.fstat(fd)
        if ((opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino)
                or before.st_ino == 0 or not stat.S_ISREG(opened.st_mode)
                or (opened.st_size, opened.st_mtime_ns) !=
                   (before.st_size, before.st_mtime_ns)):
            raise DependencyReviewError("FILE_CHANGED")
        chunks: list[bytes] = []
        remaining = before.st_size
        while remaining > 0:
            chunk = os.read(fd, min(64 * 1024, remaining))
            if not chunk:
                raise DependencyReviewError("FILE_CHANGED")
            chunks.append(chunk)
            remaining -= len(chunk)
        after_fd = os.fstat(fd)
        after_path = path.lstat()
        if (_unsafe(path, after_path)
                or (after_path.st_dev, after_path.st_ino) !=
                   (before.st_dev, before.st_ino)
                or (after_fd.st_dev, after_fd.st_ino) !=
                   (before.st_dev, before.st_ino)
                or (after_path.st_size, after_path.st_mtime_ns) !=
                   (before.st_size, before.st_mtime_ns)
                or (after_fd.st_size, after_fd.st_mtime_ns) !=
                   (before.st_size, before.st_mtime_ns)
                or not path.resolve(strict=True).is_relative_to(root)):
            raise DependencyReviewError("FILE_CHANGED")
        payload = b"".join(chunks)
        try:
            return payload.decode("utf-8-sig"), hashlib.sha256(payload).hexdigest(), len(payload)
        except UnicodeError:
            raise DependencyReviewError("INVALID_UTF8") from None
    except DependencyReviewError:
        raise
    except (OSError, ValueError, RuntimeError):
        raise DependencyReviewError("FILE_CHANGED") from None
    finally:
        if fd is not None:
            os.close(fd)


def _sanitized_name(name: Any) -> str:
    return name if isinstance(name, str) and SAFE_NAME.fullmatch(name) else "[redacted]"


def _finding(code: str, source: str, package: str | None = None,
             severity: str = "warning") -> dict[str, str]:
    return {"code": code, "severity": severity, "source": source,
            "package": _sanitized_name(package) if package else ""}


def _python_deps(values: Any, source: str, findings: list[dict[str, str]],
                 packages: list[dict[str, str]], max_deps: int) -> None:
    if not isinstance(values, list):
        findings.append(_finding("INVALID_DEPENDENCY_LIST", source))
        return
    if len(values) > max_deps:
        raise DependencyReviewError("DEPENDENCY_LIMIT")
    for raw in values:
        if not isinstance(raw, str) or len(raw) > 2048:
            findings.append(_finding("INVALID_DEPENDENCY", source))
            continue
        text = raw.strip()
        if not text or text.startswith("#"):
            continue
        if text.startswith(("-r ", "--", "-e ", ".")) or text.startswith(("git+", "https:", "http:", "file:")):
            findings.append(_finding("UNSAFE_SOURCE_OR_OPTION", source))
            continue
        match = REQ_NAME.match(text)
        if not match:
            findings.append(_finding("INVALID_DEPENDENCY", source))
            continue
        name, spec = match.groups()
        spec = spec.partition(";")[0].strip()
        direct = spec.startswith("@") or "://" in spec or "git+" in spec
        label = _sanitized_name(name)
        if direct:
            findings.append(_finding("DIRECT_URL", source, label))
            packages.append({"name": label, "source": source, "pin": "direct_url"})
        elif EXACT_PY.fullmatch(spec) and "*" not in spec:
            packages.append({"name": label, "source": source, "pin": "exact"})
        else:
            findings.append(_finding("UNPINNED", source, label))
            packages.append({"name": label, "source": source, "pin": "unbounded_or_range"})


def _parse_requirements(text: str, findings: list[dict[str, str]],
                        packages: list[dict[str, str]], max_deps: int) -> None:
    lines = text.splitlines()
    if len(lines) > max_deps * 10:
        raise DependencyReviewError("DEPENDENCY_LIMIT")
    values = []
    for line in lines:
        strip = line.strip()
        if strip and not strip.startswith("#"):
            if " --hash=" in strip:
                strip = strip.partition(" --hash=")[0].strip()
            strip = re.sub(r"\s+#.*$", "", strip).strip()
            values.append(strip)
    _python_deps(values, "requirements.txt", findings, packages, max_deps)


def _parse_pyproject(text: str, findings: list[dict[str, str]],
                     packages: list[dict[str, str]], max_deps: int) -> None:
    try:
        doc = tomllib.loads(text)
    except (tomllib.TOMLDecodeError, ValueError, RecursionError):
        findings.append(_finding("INVALID_TOML", "pyproject.toml", severity="error"))
        return
    project = doc.get("project", {})
    if project and not isinstance(project, dict):
        findings.append(_finding("INVALID_DEPENDENCY_LIST", "pyproject.toml"))
        return
    if isinstance(project, dict):
        _python_deps(project.get("dependencies", []), "pyproject.toml", findings, packages, max_deps)
        extras = project.get("optional-dependencies", {})
        if isinstance(extras, dict):
            if len(extras) > max_deps:
                raise DependencyReviewError("DEPENDENCY_LIMIT")
            for key in sorted(extras):
                _python_deps(extras[key], "pyproject.toml", findings, packages, max_deps)
        else:
            findings.append(_finding("INVALID_DEPENDENCY_LIST", "pyproject.toml"))
    build = doc.get("build-system", {})
    if isinstance(build, dict):
        _python_deps(build.get("requires", []), "pyproject.toml", findings, packages, max_deps)


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("Duplicate JSON key")
        out[key] = value
    return out


def _parse_package_lock(text: str, findings: list[dict[str, str]],
                        packages: list[dict[str, str]], max_deps: int) -> None:
    try:
        doc = json.loads(text, object_pairs_hook=_no_duplicate_keys)
    except (ValueError, TypeError, RecursionError):
        findings.append(_finding("INVALID_LOCK_JSON", "package-lock.json", severity="error"))
        return
    if not isinstance(doc, dict):
        findings.append(_finding("INVALID_LOCK_JSON", "package-lock.json", severity="error"))
        return
    lock_packages = doc.get("packages", {})
    if not isinstance(lock_packages, dict) or len(lock_packages) > max_deps * 10:
        findings.append(_finding("INVALID_LOCK_PACKAGES", "package-lock.json", severity="error"))
        return
    root = lock_packages.get("", {})
    if not isinstance(root, dict):
        findings.append(_finding("INVALID_LOCK_PACKAGES", "package-lock.json", severity="error"))
        return
    dependencies = {}
    for group in ("dependencies", "devDependencies", "optionalDependencies"):
        declared = root.get(group, {})
        if isinstance(declared, dict):
            dependencies.update(declared)
        else:
            findings.append(_finding("INVALID_LOCK_PACKAGES", "package-lock.json"))
    if len(dependencies) > max_deps:
        raise DependencyReviewError("DEPENDENCY_LIMIT")
    for name, expected in sorted(dependencies.items()):
        label = _sanitized_name(name)
        if not isinstance(expected, str) or len(expected) > 256:
            findings.append(_finding("INVALID_DEPENDENCY", "package-lock.json", label))
            continue
        if any(marker in expected.lower() for marker in ("://", "git+", "file:", "workspace:")):
            findings.append(_finding("DIRECT_URL", "package-lock.json", label))
            packages.append({"name": label, "source": "package-lock.json", "pin": "direct_url"})
            continue
        key = "node_modules/" + name
        entry = lock_packages.get(key, {})
        version = entry.get("version") if isinstance(entry, dict) else None
        if version is None:
            findings.append(_finding("MISSING_LOCK_ENTRY", "package-lock.json", label))
            continue
        if not isinstance(version, str):
            findings.append(_finding("INVALID_LOCK_VERSION", "package-lock.json", label))
            continue
        expected_match, locked_match = NPM_MAJOR.fullmatch(expected), NPM_MAJOR.fullmatch(version)
        if expected_match and locked_match and expected_match.group(1) != locked_match.group(1):
            findings.append(_finding("MAJOR_VERSION_MISMATCH", "package-lock.json", label))
        packages.append({"name": label, "source": "package-lock.json",
                         "pin": "locked", "version": version if NPM_MAJOR.fullmatch(version) else "unknown"})


def review_dependencies(
    root: str | os.PathLike[str], *, max_file_bytes: int = 256_000,
    max_total_bytes: int = 650_000, max_dependencies: int = 500,
) -> dict[str, Any]:
    """Return grounded local manifest findings, never a vulnerability verdict."""
    if (type(max_file_bytes) is not int or not 1024 <= max_file_bytes <= 2_000_000
            or type(max_total_bytes) is not int
            or not max_file_bytes <= max_total_bytes <= 6_000_000
            or type(max_dependencies) is not int or not 1 <= max_dependencies <= 5000):
        raise DependencyReviewError("INVALID_LIMIT")
    if not isinstance(root, (str, os.PathLike)):
        raise DependencyReviewError("INVALID_ROOT")
    candidate = Path(root)
    try:
        st = candidate.lstat()
        if _unsafe(candidate, st) or not stat.S_ISDIR(st.st_mode):
            raise DependencyReviewError("INVALID_ROOT")
        directory = candidate.resolve(strict=True)
    except DependencyReviewError:
        raise
    except (OSError, ValueError, RuntimeError):
        raise DependencyReviewError("INVALID_ROOT") from None
    texts = {}
    files = []
    total = 0
    for filename in FILES:
        file = _read_file(directory, filename, max_file_bytes)
        if file is None:
            continue
        text, digest, bytes_read = file
        total += bytes_read
        if total > max_total_bytes:
            raise DependencyReviewError("TOTAL_BYTE_LIMIT")
        texts[filename] = text
        files.append({"path": filename, "sha256": digest})
    findings: list[dict[str, str]] = []
    packages: list[dict[str, str]] = []
    if "pyproject.toml" in texts:
        _parse_pyproject(texts["pyproject.toml"], findings, packages, max_dependencies)
    if "requirements.txt" in texts:
        _parse_requirements(texts["requirements.txt"], findings, packages, max_dependencies)
    if "package-lock.json" in texts:
        _parse_package_lock(texts["package-lock.json"], findings, packages, max_dependencies)
    if ("pyproject.toml" in texts or "requirements.txt" in texts):
        # Existence only: NEVER open unapproved lockfile paths.
        if not any(not (directory / name).is_symlink() and
                   (directory / name).is_file() for name in KNOWN_PY_LOCKS):
            findings.append(_finding("NO_KNOWN_PYTHON_LOCK", "python"))
    if not files:
        findings.append(_finding("NO_SUPPORTED_MANIFEST", "project"))
    count_by_code = dict(sorted(Counter(f["code"] for f in findings).items()))
    return {
        "files": files, "packages": sorted(packages, key=lambda x: (x["source"], x["name"])),
        "findings": sorted(findings, key=lambda x: (x["code"], x["source"], x["package"])),
        "summary": {"files_read": len(files), "packages_examined": len(packages),
                    "bytes_read": total, "finding_counts": count_by_code},
        "vulnerability_status": "unknown_offline_no_advisories",
        "network_used": False, "installed_packages": False,
        "limitations": "No registry access, no CVE lookup, no lock diff against prior version.",
    }
