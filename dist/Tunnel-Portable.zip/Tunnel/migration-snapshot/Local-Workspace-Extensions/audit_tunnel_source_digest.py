import hashlib,zipfile,json
from pathlib import Path
r=Path(__file__).resolve().parent.parent/"Tunnel-release-staging"
files=["chat-launch-smoke-desktop-test/plugin.json","Local-Workspace-Extensions/mcp-host-source/manage.py","README.md","INSTALL_FROM_ARCHIVE.ps1"]
def sha(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\x00"+b).hexdigest()
with zipfile.ZipFile(r/"dist"/"Tunnel-Complete-Windows.zip") as z:
 for f in files:
  b=(r/f).read_bytes()
  a=z.read("Tunnel/"+f)
  print(json.dumps({"file":f,"stage_bytes":len(b),"zip_bytes":len(a),"same":b==a,
                    "stage_sha":sha(b),"zip_sha":sha(a),
                    "stage_tail":repr(b[-100:]),"zip_tail":repr(a[-100:])}))
