"""Transparent opportunity-cost KPIs for observed scheduled-agent workloads.

No claim that token estimates are provider receipts. Three distinct concepts:
 - gross counterfactual API spend for ONLY observed workload
 - marginal avoided API charge if ChatGPT Plus is already owned
 - net vs buying Plus ($20) if (and ONLY IF) the SAME workload's entire
   billing cycle is captured and the API would replace that subscription.

An incomplete month's runs are never treated as evidence of monthly net
savings. The fixed subscription cash spend cannot be inferred from pro-rata
minutes: subscription allocations do not enter this calculator.
"""
from __future__ import annotations

import json
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

USD=Decimal("0.01")
class EconomicsError(ValueError):
    pass


def _usd(value):
    return str(value.quantize(USD, rounding=ROUND_HALF_UP))


def _money(value,label):
    try:
        number=Decimal(str(value))
    except (ValueError, InvalidOperation) as exc:
        raise EconomicsError(label+"_INVALID") from exc
    if not number.is_finite() or number<0 or number>Decimal("10000000"):
        raise EconomicsError(label+"_INVALID")
    return number


def summarize_api_savings(api_report, *, model="gpt-6-sol",
                          subscription_monthly_usd="20",
                          billing_cycle_complete=False,
                          subscription_already_paid=True):
    if type(billing_cycle_complete) is not bool or type(subscription_already_paid) is not bool:
        raise EconomicsError("PROVENANCE_FLAG_INVALID")
    if not isinstance(api_report,dict) or api_report.get("schema")!="counterfactual-gpt6-api-cost-v1":
        raise EconomicsError("API_REPORT_SCHEMA_INVALID")
    if api_report.get("actual_api_usage_available") is not False or api_report.get("actual_api_invoice_usd") is not None:
        raise EconomicsError("API_PROVENANCE_INVALID")
    models=api_report.get("by_model")
    if not isinstance(models,dict) or model not in models or not isinstance(models[model],dict):
        raise EconomicsError("SELECTED_MODEL_MISSING")
    block=models[model]
    count=api_report.get("included_runs")
    if type(count) is not int or not 0<=count<=5000:
        raise EconomicsError("RUN_COUNT_INVALID")
    total=block.get("total")
    subscription=_money(subscription_monthly_usd,"SUBSCRIPTION_MONTHLY_USD")
    if count==0:
        if total is not None:
            raise EconomicsError("EMPTY_TOTAL_MISMATCH")
        return {
            "schema":"api-vs-subscription-economics-v1",
            "base_api_model":model,
            "history_coverage":"COMPLETE_CYCLE_OWNER_ATTESTED" if billing_cycle_complete else "PARTIAL_OR_UNKNOWN",
            "observed_runs":0,
            "hypothetical_avoided_api_spend_usd":None,
            "incremental_subscription_cash_spend_usd": "0.00" if subscription_already_paid else None,
            "monthly_subscription_cash_price_usd":_usd(subscription),
            "monthly_net_savings_usd":None,
            "break_even_runs_at_observed_mean":None,
            "truthful_note":"No observed runs is not proof of zero API usage.",
        }
    if not isinstance(total,dict):
        raise EconomicsError("API_TOTAL_INVALID")
    token_in=total.get("input_tokens")
    token_out=total.get("output_tokens")
    if (type(token_in) is not int or type(token_out) is not int or
        token_in<0 or token_out<0):
        raise EconomicsError("TOKEN_TOTAL_INVALID")
    summed=_money(total.get("total_usd"),"API_TOTAL_USD")
    cached=_money(total.get("cached_input_cost_usd"),"CACHED_INPUT_USD")
    raw_in=_money(total.get("uncached_input_cost_usd"),"UNCACHED_INPUT_USD")
    raw_out=_money(total.get("output_cost_usd"),"OUTPUT_USD")
    if abs((cached+raw_in+raw_out)-summed)>Decimal("0.000003"):
        raise EconomicsError("API_COST_SUM_MISMATCH")
    mean=summed/Decimal(count)
    # First integer count where the hypothetical mean API cost reaches
    # or exceeds the full monthly subscription price. This is NOT a hard
    # scheduler capacity or actual provider limit.
    if mean==0:
        threshold=None
    else:
        threshold=int((subscription/mean).to_integral_value(rounding="ROUND_CEILING"))
    result={
        "schema":"api-vs-subscription-economics-v1",
        "base_api_model":model,
        "reference_rate_source":api_report.get("official_rate_source"),
        "observed_runs":count,
        "input_tokens_scenario":token_in,
        "output_tokens_scenario":token_out,
        "hypothetical_avoided_api_spend_usd":_usd(summed),
        "gross_api_equivalent_usd":_usd(summed),
        "monthly_subscription_cash_price_usd":_usd(subscription),
        "subscription_allocation_cost_used":False,
        "subscription_already_paid":subscription_already_paid,
        "incremental_subscription_cash_spend_usd":("0.00" if subscription_already_paid else None),
        "net_if_only_observed_runs_usd":_usd(summed-subscription),
        "net_if_only_observed_runs_label":"COUNTERFACTUAL_NOT_MONTHLY_SAVINGS",
        "monthly_net_savings_usd":_usd(summed-subscription) if billing_cycle_complete else None,
        "history_coverage":"COMPLETE_CYCLE_OWNER_ATTESTED" if billing_cycle_complete else "PARTIAL_OR_UNKNOWN",
        "api_equivalent_per_observed_run_usd":str(mean.quantize(Decimal("0.000001"),rounding=ROUND_HALF_UP)),
        "break_even_runs_at_observed_mean":threshold,
        "is_reliable_accuracy_claim":False,
        "conditions":[
            "Plus subscription and API serve interchangeable tasks at comparable quality and access, which is not independently verified.",
            "API usage is inferred from an uncalibrated token heuristic, not provider receipts.",
            "The $20 subscription is a fixed monthly cash expense, never $0.05/minute incremental billing.",
            "An already paid subscription has zero incremental charge for eligible runs, subject to platform limits.",
            "Partial sampled history cannot establish monthly net savings; capture full billing cycle separately.",
            "The threshold extrapolates the observed sample mean and ignores model/usage mix and real limits.",
        ],
    }
    return result


def main(argv=None):
    import argparse
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--api-report",required=True)
    p.add_argument("--model",default="gpt-6-sol")
    p.add_argument("--subscription-usd",default="20")
    p.add_argument("--complete-billing-cycle",action="store_true",
                   help="Use ONLY if owner verified full billing-cycle coverage")
    p.add_argument("--subscription-not-already-paid",action="store_true")
    args=p.parse_args(argv)
    try:
        f=Path(args.api_report)
        if f.is_symlink() or not f.is_file() or f.stat().st_size>8*1024*1024:
            raise EconomicsError("API_INPUT_UNSAFE")
        x=json.loads(f.read_text(encoding="utf-8"))
        y=summarize_api_savings(x,model=args.model,
             subscription_monthly_usd=args.subscription_usd,
             billing_cycle_complete=args.complete_billing_cycle,
             subscription_already_paid=not args.subscription_not_already_paid)
        print(json.dumps(y,ensure_ascii=True,sort_keys=True))
        return 0
    except (ValueError,OSError,OverflowError) as exc:
        print(json.dumps({"ok":False,"error":str(exc)[:130]}))
        return 1


if __name__=="__main__":
    raise SystemExit(main())
