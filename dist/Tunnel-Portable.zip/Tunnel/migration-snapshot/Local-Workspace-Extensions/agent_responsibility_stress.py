"""Repeatable SQLite contention probe; NEVER touches the live agent queue.

Run: python agent_responsibility_stress.py --rounds 100 --workers 4
Each round races two conflicting owners plus independent nonconflicting owners.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import tempfile
import threading
import time
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import agent_team as team
from test_agent_responsibility_integration import POLICY, SPEC, task


def stress(rounds: int = 100, workers: int = 4) -> dict:
    if not 1 <= rounds <= 1000 or not 2 <= workers <= 12:
        raise ValueError("Expected 1..1000 rounds and 2..12 workers")
    begin = time.monotonic()
    successes = conflicts = 0
    with tempfile.TemporaryDirectory(prefix="responsibility-stress-") as temp:
        root = Path(temp)
        state = root / ".agent-team"
        spec = root / SPEC
        spec.parent.mkdir(parents=True)
        spec.write_text("### Requirement: Workspace inventory\nThe system SHALL work.\n",
                        encoding="utf-8")
        policy = root / POLICY
        policy.parent.mkdir(parents=True)
        policy.write_text("### Requirement: Unique responsibility ownership\n",
                          encoding="utf-8")
        with patch.object(team, "PROJECT", root), patch.object(team, "STATE", state):
            for round_id in range(rounds):
                db_path = state / f"stress-{round_id}.sqlite3"
                with closing(team.connect(db_path)):
                    pass
                barrier = threading.Barrier(workers)
                files = []
                for worker in range(workers):
                    # 0 and 1 must conflict; all others own independent components.
                    responsibility = "shared-work" if worker < 2 else f"separate-work-{worker}"
                    item = task(f"P{100+worker}", f"stress_{worker}", responsibility,
                                role_hint=f"developer-{worker % 4 + 1}")
                    filename = root / f"round-{round_id}-worker-{worker}.json"
                    filename.write_text(json.dumps([item]), encoding="utf-8")
                    files.append(filename)

                def attempt(manifest: Path):
                    barrier.wait(timeout=10)
                    try:
                        team.seed(manifest, db_path)
                        return "ok"
                    except team.TeamError as exc:
                        return exc.code

                with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                    outcomes = list(pool.map(attempt, files))
                wanted = ["ok"] * (workers-1) + ["RESPONSIBILITY_CONFLICT"]
                if sorted(outcomes) != sorted(wanted):
                    raise AssertionError(f"round {round_id}: {outcomes!r}, expected {wanted!r}")
                with closing(team.connect(db_path)) as check:
                    owners = check.execute(
                        "SELECT COUNT(*) FROM task_responsibilities"
                    ).fetchone()[0]
                    if owners != workers-1:
                        raise AssertionError(f"round {round_id}: {owners} owners")
                successes += workers-1
                conflicts += 1
                for filename in files:
                    filename.unlink()
    return {
        "schema": "responsibility-contention-stress-v1",
        "passed": True,
        "rounds": rounds,
        "parallel_contenders": workers,
        "accepted_distinct_owners": successes,
        "rejected_conflicting_owners": conflicts,
        "unexpected_results": 0,
        "duration_seconds": round(time.monotonic()-begin, 3),
        "live_queue_mutated": False,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rounds", type=int, default=100)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    try:
        print(json.dumps(stress(args.rounds, args.workers)))
    except (AssertionError, ValueError, OSError, TimeoutError) as exc:
        print(json.dumps({"passed": False, "error": type(exc).__name__,
                          "reason": str(exc)[:350]}))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
