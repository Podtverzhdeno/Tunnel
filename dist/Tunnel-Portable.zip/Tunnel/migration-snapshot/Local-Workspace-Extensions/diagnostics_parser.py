"""Bounded, read-only normalization of provided build and test diagnostics.

No commands, filesystem reads, network calls, or untrusted message echoing.
Only path/line/severity/code/source are exposed; messages are deliberately
omitted because arbitrary tool output may contain tokens or private data.
"""
from __future__ import annotations

import re
from pathlib import PurePosixPath

MAX_INPUT_BYTES = 256 * 1024
MAX_LINE_CHARS = 2048
MAX_ITEMS = 100
SOURCES = frozenset(("unittest", "pytest", "ruff", "mypy", "npm"))
_SECRET_PART = re.compile(r"(?i)(?:^\.|secret|credential|password|token|\.env|id_rsa|private|keyring)")
_CODE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,31}$")
# Patterns deliberately bounded by per-line truncation.
_COLON = re.compile(r"^(?P<path>.+?):(?P<line>\d{1,7})(?::(?P<col>\d{1,5}))?:\s*(?P<tail>.+)$")
_MYPY = re.compile(r"^(?P<severity>error|warning|note):\s*(?P<msg>.*)$", re.I)
_RUFF = re.compile(r"^(?P<code>[A-Z]{1,4}\d{3,5})\s+(?P<msg>.+)$")
_NPM = re.compile(r"^(?P<path>.+?)\((?P<line>\d{1,7}),(?P<col>\d{1,5})\):\s*(?P<severity>error|warning)\s+(?P<code>TS\d{3,6}):", re.I)
_UNIT = re.compile(r'^\s*File "(?P<path>[^"]{1,600})", line (?P<line>\d{1,7})(?:,|$)')
_RUFF_ARROW = re.compile(r"^\s*(?:-->|→)\s+(?P<path>.+?):(?P<line>\d{1,7}):(?P<col>\d{1,5})\s*$")
_PYTEST = re.compile(r"^(?P<path>.+?):(?P<line>\d{1,7}):\s*(?:in\s+\S+|(?:AssertionError|Error|Exception|Failed)\b.*)$")


def _path(raw):
    """Return project-relative path or basename, never a host absolute path."""
    if not isinstance(raw, str):
        return None
    value = raw.strip().strip('"').replace("\\", "/")
    if not value or "\x00" in value or len(value) > 600:
        return None
    absolute = value.startswith("/") or value.startswith("//") or bool(
        re.match(r"^[A-Za-z]:/", value)
    )
    parts = [p for p in value.split("/") if p and p != "."]
    if not parts:
        return None
    if ".." in parts or absolute:
        basename = parts[-1]
        if basename in (".", "..") or _SECRET_PART.search(basename):
            return None
        return basename
    if any(_SECRET_PART.search(p) for p in parts):
        return None
    return "/".join(parts)


def _line_number(value):
    try:
        number = int(value)
    except (ValueError, TypeError):
        return None
    return number if 1 <= number <= 1000000 else None


def _add(items, seen, *, path, line, severity, code, source, max_items):
    if len(items) >= max_items:
        return False
    safe = _path(path) if path is not None else None
    if path is not None and safe is None:
        return True  # private path: suppress whole finding
    number = _line_number(line)
    if line is not None and number is None:
        return True
    clean_code = code if isinstance(code, str) and _CODE.fullmatch(code) else None
    entry = {"file": safe, "line": number, "severity": severity,
             "code": clean_code, "source": source}
    identity = (safe, number, severity, clean_code, source)
    if identity not in seen:
        seen.add(identity)
        items.append(entry)
    return len(items) < max_items


def parse_diagnostics(text, source, *, max_input_bytes=MAX_INPUT_BYTES,
                      max_items=MAX_ITEMS):
    """Normalize diagnostics from *provided* stdout/stderr only.

    Input is str or bytes. Invalid UTF-8 is decoded with replacement. No raw
    diagnostic messages are returned. A bounded response signals truncation.
    """
    if source not in SOURCES:
        raise ValueError("Unsupported diagnostic source")
    if not isinstance(text, (str, bytes)):
        raise TypeError("Expected text or bytes")
    if not isinstance(max_input_bytes, int) or not 1 <= max_input_bytes <= MAX_INPUT_BYTES:
        raise ValueError("Invalid input budget")
    if not isinstance(max_items, int) or not 1 <= max_items <= MAX_ITEMS:
        raise ValueError("Invalid item budget")
    raw = text.encode("utf-8", "replace") if isinstance(text, str) else text
    truncated = len(raw) > max_input_bytes
    segment = raw[:max_input_bytes].decode("utf-8", "replace")
    invalid_utf8 = "\ufffd" in segment
    items = []
    seen = set()
    skipped_lines = 0
    pending_ruff = None
    for raw_line in segment.splitlines():
        if len(raw_line) > MAX_LINE_CHARS:
            skipped_lines += 1
            truncated = True
            pending_ruff = None
            continue
        line = raw_line.strip()
        if not line:
            continue
        if source == "unittest":
            m = _UNIT.match(raw_line)
            if m and not _add(items, seen, path=m["path"], line=m["line"],
                              severity="error", code="TRACEBACK", source=source,
                              max_items=max_items):
                truncated = True
                break
        elif source == "npm":
            m = _NPM.match(line)
            if m and not _add(items, seen, path=m["path"], line=m["line"],
                              severity=m["severity"].lower(), code=m["code"].upper(),
                              source=source, max_items=max_items):
                truncated = True
                break
            if line.startswith("npm ERR!") and not _add(
                    items, seen, path=None, line=None, severity="error",
                    code="NPM", source=source, max_items=max_items):
                truncated = True
                break
        elif source == "ruff":
            arrow = _RUFF_ARROW.match(line)
            if arrow and pending_ruff:
                if not _add(items, seen, path=arrow["path"], line=arrow["line"],
                            severity="error", code=pending_ruff, source=source,
                            max_items=max_items):
                    truncated = True
                    break
                pending_ruff = None
                continue
            match = _COLON.match(line)
            if match:
                code = _RUFF.match(match["tail"])
                if code and not _add(items, seen, path=match["path"],
                                     line=match["line"], severity="error",
                                     code=code["code"], source=source,
                                     max_items=max_items):
                    truncated = True
                    break
            else:
                code = _RUFF.match(line)
                if code:
                    pending_ruff = code["code"]
        elif source == "mypy":
            match = _COLON.match(line)
            if match:
                kind = _MYPY.match(match["tail"])
                if kind:
                    tail = kind["msg"]
                    code = re.search(r"\[([a-z][a-z0-9_-]{0,31})\]\s*$", tail)
                    if not _add(items, seen, path=match["path"], line=match["line"],
                                severity=kind["severity"].lower(),
                                code=code.group(1) if code else None,
                                source=source, max_items=max_items):
                        truncated = True
                        break
        elif source == "pytest":
            match = _PYTEST.match(line)
            if match and not _add(items, seen, path=match["path"],
                                  line=match["line"], severity="error",
                                  code="PYTEST", source=source, max_items=max_items):
                truncated = True
                break
    return {"source": source, "problems": items, "count": len(items),
            "truncated": truncated, "invalid_utf8": invalid_utf8,
            "skipped_oversize_lines": skipped_lines, "input_bytes": len(raw)}
