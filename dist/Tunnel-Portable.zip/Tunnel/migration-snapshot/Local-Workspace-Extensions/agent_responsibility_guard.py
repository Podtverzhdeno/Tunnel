"""Spec 004: deterministic ownership and import gates for new multi-agent tasks.

Read-only checks except for caller-owned SQLite writes. Existing tasks without a
contract are explicitly grandfathered; no forged approvals or actor identity.
"""
from __future__ import annotations

import ast
import json
import re
from pathlib import Path

MAX_SOURCE_BYTES = 2 * 1024 * 1024
MAX_MODULES = 350
IDENT = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z")
MODULE = re.compile(r"[a-z][a-z0-9_]*\Z")
API = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")
STATES_ACTIVE = frozenset({"available", "working", "review", "reviewing", "rework"})
MODES = frozenset({"owner", "consumer"})
REUSE = frozenset({"REUSE_EXISTING", "EXTEND_CANONICAL_OWNER", "PROPOSE_NEW_RESPONSIBILITY"})


class ResponsibilityError(ValueError):
    pass


def _check_text(text, kind, min_length=8, max_length=600):
    if type(text) is not str or not min_length <= len(text.strip()) <= max_length:
        raise ResponsibilityError("INVALID_" + kind)
    return text.strip()


def _check_id(value, name, pattern=IDENT):
    if type(value) is not str or not pattern.fullmatch(value):
        raise ResponsibilityError("INVALID_" + name)
    return value


def validate_contract(value, deliverables):
    """Validate explicit owner-ready task contract without auto-generating any ID."""
    expected = {"id", "module", "public_api", "role", "reuse_decision",
                "inputs", "outputs", "errors", "scaling", "depends_on", "allowed_extensions"}
    optional = {"handoff_from"}
    if type(value) is not dict or not expected.issubset(value) or set(value) - (expected | optional):
        raise ResponsibilityError("INVALID_RESPONSIBILITY_CONTRACT")
    rid = _check_id(value["id"], "RESPONSIBILITY_ID")
    module = _check_id(value["module"], "CANONICAL_MODULE", MODULE)
    api = _check_id(value["public_api"], "PUBLIC_API", API)
    role = value["role"]
    reuse = value["reuse_decision"]
    if type(role) is not str or role not in MODES:
        raise ResponsibilityError("INVALID_RESPONSIBILITY_ROLE")
    if type(reuse) is not str or reuse not in REUSE:
        raise ResponsibilityError("INVALID_REUSE_DISPOSITION")
    if role == "consumer" and reuse != "REUSE_EXISTING":
        raise ResponsibilityError("CONSUMER_MUST_REUSE")
    if role == "owner" and reuse == "REUSE_EXISTING":
        raise ResponsibilityError("OWNER_MUST_OWN")
    for field in ("inputs", "outputs", "errors", "scaling"):
        _check_text(value[field], field.upper())
    dependencies = value["depends_on"]
    extensions = value["allowed_extensions"]
    if (type(dependencies) is not list or len(dependencies) > 30 or
            type(extensions) is not list or not 1 <= len(extensions) <= 6):
        raise ResponsibilityError("INVALID_RESPONSIBILITY_SCOPE")
    if any(_check_id(x, "DEPENDENCY") == rid for x in dependencies):
        raise ResponsibilityError("SELF_DEPENDENCY")
    if len(set(dependencies)) != len(dependencies):
        raise ResponsibilityError("DUPLICATE_DEPENDENCY")
    if (any(type(x) is not str or not MODULE.fullmatch(x.removesuffix(".py"))
            or not x.endswith(".py") for x in extensions)
            or len(set(extensions)) != len(extensions)):
        raise ResponsibilityError("INVALID_EXTENSION_SCOPE")
    if not set(extensions).issubset(deliverables):
        raise ResponsibilityError("UNSCOPED_EXTENSION")
    canonical_file = module + ".py"
    if role == "owner" and canonical_file not in extensions:
        raise ResponsibilityError("CANONICAL_OWNER_NOT_IN_SCOPE")
    if role == "consumer" and canonical_file in extensions:
        raise ResponsibilityError("CONSUMER_MODIFIES_OWNER")
    handoff = value.get("handoff_from")
    if handoff is not None:
        if type(handoff) is not str or not re.fullmatch(r"P[0-9]{3,6}", handoff):
            raise ResponsibilityError("INVALID_HANDOFF")
        if role != "owner":
            raise ResponsibilityError("CONSUMER_CANNOT_HANDOFF")
    return {key: value[key] for key in sorted(expected | ({"handoff_from"} if handoff else set()))}


def _all_rows(db):
    try:
        return db.execute(
            "SELECT c.task_id,c.payload_json,t.status "
            "FROM task_responsibilities c INNER JOIN tasks t ON t.task_id=c.task_id"
        ).fetchall()
    except Exception as exc:
        raise ResponsibilityError("RESPONSIBILITY_REGISTRY_UNAVAILABLE") from exc


def check_ownership(db, task_id, contract):
    """Call under BEGIN IMMEDIATE to make duplicate ownership checks race-safe."""
    rid = contract["id"]
    owning_module = contract["module"]
    historical = []
    for row in _all_rows(db):
        if row["task_id"] == task_id:
            continue
        try:
            other = json.loads(row["payload_json"])
        except (TypeError, ValueError) as exc:
            raise ResponsibilityError("CORRUPT_RESPONSIBILITY_REGISTRY") from exc
        if other["id"] == rid and other["module"] != owning_module:
            raise ResponsibilityError("RESPONSIBILITY_MODULE_CONFLICT")
        if other["module"] == owning_module and other["id"] != rid:
            raise ResponsibilityError("CANONICAL_MODULE_CONFLICT")
        if other["id"] != rid or other["role"] != "owner":
            continue
        if row["status"] == "done":
            historical.append((row["task_id"],other.get("handoff_from")))
        elif row["status"] in STATES_ACTIVE and contract["role"] == "owner":
            raise ResponsibilityError("MULTIPLE_ACTIVE_OWNERS")
    if contract["role"] == "owner":
        handoff = contract.get("handoff_from")
        if historical:
            completed={task for task,_ in historical}
            predecessors=[prior for _,prior in historical if prior is not None]
            # Every accepted handoff forms one linear chain; no branch, loop
            # or invented predecessor can make one owner appear canonical.
            if (any(prior not in completed for prior in predecessors) or
                    len(predecessors)!=len(set(predecessors)) or
                    len(predecessors)!=len(completed)-1):
                raise ResponsibilityError("INVALID_HISTORICAL_OWNER_CHAIN")
            latest=completed-set(predecessors)
            if len(latest)!=1 or handoff not in latest:
                raise ResponsibilityError("UNVERIFIED_RESPONSIBILITY_HANDOFF")
            for completed_id in completed:
                receipt=db.execute(
                    "SELECT reviewer_role FROM acceptance_records WHERE task_id=?",
                    (completed_id,)
                ).fetchone()
                if receipt is None or receipt["reviewer_role"]!="architect-reviewer":
                    raise ResponsibilityError("UNVERIFIED_HANDOFF_EVIDENCE")
        elif handoff is not None:
            raise ResponsibilityError("UNKNOWN_RESPONSIBILITY_HANDOFF")


def _source_tree(path):
    if (path.is_symlink() or getattr(path, "is_junction", lambda: False)() or
            not path.is_file() or path.stat().st_size > MAX_SOURCE_BYTES):
        raise ResponsibilityError("UNSAFE_PYTHON_SOURCE")
    try:
        with path.open("rb") as file:
            data = file.read(MAX_SOURCE_BYTES + 1)
        if len(data) > MAX_SOURCE_BYTES:
            raise ResponsibilityError("OVERSIZED_PYTHON_SOURCE")
        return ast.parse(data.decode("utf-8", errors="strict"), filename=path.name)
    except (UnicodeError, SyntaxError, ValueError, RecursionError) as exc:
        raise ResponsibilityError("INVALID_PYTHON_SOURCE") from exc


def _imports(tree, known):
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for item in node.names:
                if item.name in known:
                    found.add(item.name)
        elif isinstance(node, ast.ImportFrom) and not node.level:
            if node.module in known:
                found.add(node.module)
    return found


def _cycle_involving(graph, origins):
    """Report cycles that actually reach back to one of the changed modules."""
    for origin in sorted(origins):
        route = [(origin, [origin])]
        visited = set()
        while route:
            node, chain = route.pop()
            if node in visited:
                continue
            visited.add(node)
            for target in sorted(graph[node], reverse=True):
                if target == origin:
                    return chain + [origin]
                if target not in visited:
                    route.append((target, chain + [target]))
    return None


def audit_candidate_imports(root, changes, contract, known_contracts):
    """Independent reviewer gate; checks candidate modules against current main.

    Root-level modules only. Dynamic imports aren't resolved and a PASS does not
    certify semantic correctness. No source is ever imported or executed.
    """
    root = Path(root)
    if root.is_symlink() or getattr(root, "is_junction", lambda: False)() or not root.is_dir():
        raise ResponsibilityError("UNSAFE_PROJECT_ROOT")
    candidates = dict(changes)
    if contract["role"] == "owner" and contract["module"] + ".py" not in candidates:
        raise ResponsibilityError("CANONICAL_OWNER_NOT_DELIVERED")
    paths = {}
    for path in root.glob("*.py"):
        if path.name.startswith("test_") or not MODULE.fullmatch(path.stem):
            continue
        if path.name not in candidates:
            paths[path.stem] = path
    for name, path in candidates.items():
        if name.startswith("test_"):
            continue
        if not name.endswith(".py") or not MODULE.fullmatch(name[:-3]):
            raise ResponsibilityError("INVALID_CANDIDATE_MODULE")
        paths[name[:-3]] = Path(path)
    if len(paths) > MAX_MODULES:
        raise ResponsibilityError("IMPORT_GRAPH_MODULE_LIMIT")
    known = set(paths)
    graphs, trees = {}, {}
    for name, path in sorted(paths.items()):
        tree = _source_tree(path)
        trees[name] = tree
        graphs[name] = _imports(tree, known)
    modified = {name[:-3] for name in candidates if not name.startswith("test_")}
    cycle = _cycle_involving(graphs, modified)
    if cycle:
        raise ResponsibilityError("SOURCE_IMPORT_CYCLE:" + "->".join(cycle[:16]))
    canonical_tree = trees.get(contract["module"])
    if canonical_tree is None:
        raise ResponsibilityError("CANONICAL_OWNER_MISSING")
    exports = {n.name for n in canonical_tree.body
               if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    if contract["public_api"] not in exports:
        raise ResponsibilityError("CANONICAL_API_MISSING")
    if contract["role"] == "consumer":
        if not modified:
            raise ResponsibilityError("CONSUMER_DELIVERABLE_MISSING")
        if contract["module"] in modified:
            raise ResponsibilityError("CONSUMER_MODIFIES_OWNER")
        for changed in sorted(modified):
            if contract["module"] not in graphs[changed]:
                raise ResponsibilityError("CONSUMER_MUST_IMPORT_CANONICAL_OWNER:" + changed)
    mapping = {}
    for item in known_contracts:
        key = item["module"]
        if key in mapping and mapping[key] != item["id"]:
            raise ResponsibilityError("MODULE_CONTRACT_AMBIGUOUS")
        mapping[key] = item["id"]
    for name in modified:
        for imported in graphs[name]:
            rid = mapping.get(imported)
            if rid is not None and rid != contract["id"] and rid not in contract["depends_on"]:
                raise ResponsibilityError("UNDECLARED_RESPONSIBILITY_IMPORT:" + imported)
    return {"decision":"PASS", "scanned_modules":len(paths),
            "verified_identity":False, "dynamic_imports_checked":False, "no_source_execution":True}
