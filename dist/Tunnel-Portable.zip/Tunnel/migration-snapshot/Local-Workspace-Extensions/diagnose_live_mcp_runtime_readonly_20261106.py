"""Read-only identify the active loopback MCP listener without reading process args or secrets."""
import json, urllib.request
try:
    with urllib.request.urlopen("http://127.0.0.1:8765/healthz",timeout=5) as r:
        data=json.load(r)
        print("health",{"http":r.status,"status":data.get("status"),"server":data.get("server"),
                        "tools":data.get("tools"),"workspaces":data.get("workspaces")})
except Exception as exc:
    print("health",{"error":type(exc).__name__})
try:
    import psutil
except ImportError:
    print("process","psutil_unavailable")
else:
    for conn in psutil.net_connections(kind="tcp"):
        if not conn.laddr or conn.laddr.port!=8765 or conn.status!="LISTEN":
            continue
        if not conn.pid:
            print("listener",{"state":"pid_unavailable"})
            continue
        try:
            p=psutil.Process(conn.pid)
            # Never inspect or print cmdline/environment, where bearer tokens may live.
            print("listener",{"pid":conn.pid,"exe_name":p.name(),
                              "cwd":p.cwd(),"state":p.status()})
        except (psutil.NoSuchProcess,psutil.AccessDenied) as exc:
            print("listener",{"state":type(exc).__name__})
