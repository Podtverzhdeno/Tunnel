

def register_approved_spec_tool(server, approval_store, authenticated_actor):
    """Register a mutating spec-creation tool ONLY behind a trusted host verifier.

    The real MCP host must provide authenticated_actor from its connection context
    and issue approval tokens via a separate trusted foreground UI. This function
    deliberately is NOT called from the default register_tools() path.
    """
    if not callable(authenticated_actor) or approval_store is None:
        raise ValueError("Authenticated server identity and approval store required")
    import spec_tools
    from spec_tools import SpecError
    from approval_broker import ApprovalError
    from mcp_adapter import checked

    @server.tool()
    def spec_change_create(manifest_path: str, expected_plan_sha256: str,
                           approval_token: str) -> dict:
        """Create a reviewed OpenSpec/SDD change after host-verified one-use approval."""
        def operation():
            brief = spec_tools.read_manifest(manifest_path)
            project, _, current_hash = spec_tools.plan(brief)
            if expected_plan_sha256 != current_hash:
                raise SpecError("PREVIEW_CHANGED", "Plan changed; request a new approval")
            identity = authenticated_actor()
            if not identity or not isinstance(identity, str):
                raise ApprovalError("IDENTITY_DENIED", "MCP caller identity is unavailable")
            approval_store.consume(
                token=approval_token, actor=identity,
                workspace=project.as_posix(), operation="spec_change_create",
                plan_hash=current_hash,
            )
            return spec_tools.create(brief, expected_plan_sha256)
        return checked(operation)
    return ["spec_change_create"]
