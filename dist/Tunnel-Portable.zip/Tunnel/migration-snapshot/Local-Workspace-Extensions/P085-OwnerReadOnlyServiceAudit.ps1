#requires -Version 5.1
<#
.SYNOPSIS
  P085 owner read-only SCM and protected stage audit.
.DESCRIPTION
  No UAC, OS write, service installation, ACL changes, account creation,
  key access, grants or approval. This is NOT independent trust attestation.
#>
[CmdletBinding()]
param(
  [ValidateSet('P085ProtectedReviewer')]
  [string]$ServiceName='P085ProtectedReviewer',
  [string]$ExpectedServiceSid='',
  [string]$ExpectedPythonPath='',
  [string]$ExpectedEntrypointSha256='',
  [string]$ExpectedPythonSha256='',
  [string]$ExpectedOverlappedSha256=''
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if ($ExpectedServiceSid -and $ExpectedServiceSid -notmatch '^S-1-5-21-(?:\d+-){3}\d+$') { throw 'EXPECTED_SERVICE_SID_INVALID' }
foreach ($pin in @($ExpectedEntrypointSha256,$ExpectedOverlappedSha256,$ExpectedPythonSha256)) {
  if ($pin -and $pin -notmatch '^[0-9a-fA-F]{64}$') { throw 'EXPECTED_SHA256_PIN_INVALID' }
}
$blockers=New-Object 'System.Collections.Generic.List[string]'
$checks=[ordered]@{
  service_present=$false
  service_running=$false
  service_own_process=$false
  service_process_owner_sid_matches_pin=$null
  service_registered_account_sid_matches_pin=$null
  live_process_executable_matches_pin=$null
  live_process_commandline_matches_registration=$null
  live_service_pid_stable=$null
  python_invocation_matches_protected_stage=$false
  python_path_matches_pin=$null
  python_hash_matches_pin=$null
  protected_stage_found=$false
  stage_path_not_reparse_point=$false
  entrypoint_hash_matches_pin=$null
  overlapped_hash_matches_pin=$null
  stage_receipt_present=$false
  private_state_directory_present=$false
  stage_acl_effectiveness_verified=$false
  independent_qa_and_two_sid_e2e_verified=$false
}
function Add-Blocker([string]$code) {
  if (-not $blockers.Contains($code)) { $blockers.Add($code) }
}
function Is-RegularFile([string]$path) {
  if (-not [IO.File]::Exists($path)) { return $false }
  $item=Get-Item -LiteralPath $path -ErrorAction Stop
  return (-not [bool]($item.Attributes -band [IO.FileAttributes]::ReparsePoint))
}
function Is-SafeDirectory([string]$path) {
  if (-not [IO.Directory]::Exists($path)) { return $false }
  $item=Get-Item -LiteralPath $path -ErrorAction Stop
  return (-not [bool]($item.Attributes -band [IO.FileAttributes]::ReparsePoint))
}
function Compare-HashIfPinned([string]$path,[string]$pin,[string]$label) {
  if (-not $pin) {
    Add-Blocker ("{0}_SHA_PIN_MISSING" -f $label)
    return $null
  }
  if (-not (Is-RegularFile $path)) {
    Add-Blocker ("{0}_SOURCE_MISSING_OR_LINKED" -f $label)
    return $false
  }
  try {
    $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash
    if ($actual -ine $pin) {
      Add-Blocker ("{0}_SOURCE_SHA_MISMATCH" -f $label)
      return $false
    }
    return $true
  } catch {
    Add-Blocker ("{0}_SOURCE_UNREADABLE" -f $label)
    return $null
  }
}
$programData=$env:ProgramData
if ([string]::IsNullOrWhiteSpace($programData)) {
  Add-Blocker 'PROGRAMDATA_UNAVAILABLE'
} else {
  $root=Join-Path $programData 'P085ProtectedReviewer'
  $code=Join-Path $root 'code'
  $pkg=Join-Path $code 'workspace_mcp'
  $entrypoint=Join-Path $code 'p085_reviewer_service.py'
  $overlapped=Join-Path $pkg 'win_pipe_overlapped.py'
  $receipt=Join-Path $root 'STAGE_RECEIPT.json'
  $private=Join-Path $root 'private_state'
  try {
    $checks.protected_stage_found=[bool](Test-Path -LiteralPath $root -PathType Container)
    $checks.stage_path_not_reparse_point=(
      (Is-SafeDirectory $root) -and
      (Is-SafeDirectory $code) -and
      (Is-SafeDirectory $pkg))
    if (-not $checks.protected_stage_found) { Add-Blocker 'P085_STAGE_NOT_INSTALLED' }
    if ($checks.protected_stage_found -and -not $checks.stage_path_not_reparse_point) {
      Add-Blocker 'P085_STAGE_LINK_OR_STRUCTURE_UNSAFE'
    }
    $checks.stage_receipt_present=Is-RegularFile $receipt
    if (-not $checks.stage_receipt_present) { Add-Blocker 'P085_STAGE_RECEIPT_MISSING' }
    $checks.private_state_directory_present=Is-SafeDirectory $private
    if (-not $checks.private_state_directory_present) {
      Add-Blocker 'P085_PRIVATE_STATE_MISSING_OR_UNSAFE'
    }
    $checks.entrypoint_hash_matches_pin=Compare-HashIfPinned $entrypoint $ExpectedEntrypointSha256 'ENTRYPOINT'
    $checks.overlapped_hash_matches_pin=Compare-HashIfPinned $overlapped $ExpectedOverlappedSha256 'OVERLAPPED'
  } catch {
    Add-Blocker 'P085_STAGE_READ_FAILED'
  }
}
try {
  # Exact service name; never accept caller-controlled WQL or remote host.
  $svc=Get-CimInstance -ClassName Win32_Service -Filter "Name='P085ProtectedReviewer'" -ErrorAction Stop
  if ($null -eq $svc) {
    Add-Blocker 'BROKER_SERVICE_UNPROVISIONED'
  } else {
    $checks.service_present=$true
    $checks.service_running=($svc.State -eq 'Running')
    $checks.service_own_process=($svc.ServiceType -eq 'Own Process')
    if (-not $checks.service_running) { Add-Blocker 'BROKER_SERVICE_NOT_RUNNING' }
    if (-not $checks.service_own_process) { Add-Blocker 'BROKER_SERVICE_NOT_OWN_PROCESS' }
    # Registry StartName alone cannot attest the live process token, but an
    # account mismatch here can silently change security on the NEXT start.
    if ($ExpectedServiceSid) {
      try {
        $savedAccountSid=([Security.Principal.NTAccount]::new(
            [string]$svc.StartName)).Translate(
                [Security.Principal.SecurityIdentifier]).Value
        $checks.service_registered_account_sid_matches_pin=(
            [string]::Equals($savedAccountSid,$ExpectedServiceSid,
                             [StringComparison]::OrdinalIgnoreCase))
        if (-not $checks.service_registered_account_sid_matches_pin) {
          Add-Blocker 'SCM_REGISTERED_ACCOUNT_SID_MISMATCH'
        }
      } catch {
        Add-Blocker 'SCM_REGISTERED_ACCOUNT_SID_UNVERIFIED'
      }
    }
    $commandLine=[string]$svc.PathName
    $pattern='^"(?<python>[^"]+)"\s+-E\s+-s\s+"(?<entry>[^"]+)"\s+--serve-service\s*$'
    if ($commandLine -match $pattern -and $programData) {
      $commandPython=[IO.Path]::GetFullPath($Matches['python'])
      $commandEntry=[IO.Path]::GetFullPath($Matches['entry'])
      $stageEntry=[IO.Path]::GetFullPath($entrypoint)
      $checks.python_invocation_matches_protected_stage=(
        [string]::Equals($commandEntry,$stageEntry,[StringComparison]::OrdinalIgnoreCase) -and
        (Is-RegularFile $commandPython))
      if ($ExpectedPythonPath) {
        $pinPath=[IO.Path]::GetFullPath($ExpectedPythonPath)
        $checks.python_path_matches_pin=[string]::Equals(
          $commandPython,$pinPath,[StringComparison]::OrdinalIgnoreCase)
        $checks.python_hash_matches_pin=Compare-HashIfPinned $commandPython $ExpectedPythonSha256 'PYTHON'
      } else {
        Add-Blocker 'EXPECTED_PYTHON_PATH_NOT_PINNED'
      }
    }
    if (-not $checks.python_invocation_matches_protected_stage) {
      Add-Blocker 'SCM_IMAGEPATH_NOT_PROTECTED_INVOCATION'
    }
    if ($checks.python_path_matches_pin -eq $false) { Add-Blocker 'SCM_PYTHON_PATH_MISMATCH' }
    # StartName is not sufficient; inspect the running process token SID.
    if ($checks.service_running -and [int]$svc.ProcessId -gt 0) {
      try {
        $proc=Get-CimInstance -ClassName Win32_Process -Filter ("ProcessId={0}" -f [uint32]$svc.ProcessId) -ErrorAction Stop
        if ($null -eq $proc) {
          Add-Blocker 'SCM_PROCESS_UNAVAILABLE'
        } else {
          # The SCM ImagePath is a registry configuration, not proof of the
          # actual executable or command line in a PID-reusable live process.
          # Collect each independent signal; fail closed on denied queries.
          if ($ExpectedPythonPath -and $proc.ExecutablePath) {
            try {
              $expectedExecutable=[IO.Path]::GetFullPath($ExpectedPythonPath)
              $observedExecutable=[IO.Path]::GetFullPath([string]$proc.ExecutablePath)
              $checks.live_process_executable_matches_pin=(
                [string]::Equals($expectedExecutable,$observedExecutable,
                                 [StringComparison]::OrdinalIgnoreCase))
              if (-not $checks.live_process_executable_matches_pin) {
                Add-Blocker 'SCM_LIVE_EXECUTABLE_MISMATCH'
              }
            } catch {
              Add-Blocker 'SCM_LIVE_EXECUTABLE_UNVERIFIED'
            }
          } else {
            Add-Blocker 'SCM_LIVE_EXECUTABLE_UNVERIFIED'
          }
          if ($proc.CommandLine) {
            $checks.live_process_commandline_matches_registration=(
              [string]::Equals([string]$proc.CommandLine,$commandLine,
                               [StringComparison]::OrdinalIgnoreCase))
            if (-not $checks.live_process_commandline_matches_registration) {
              Add-Blocker 'SCM_LIVE_COMMANDLINE_MISMATCH'
            }
          } else {
            Add-Blocker 'SCM_LIVE_COMMANDLINE_UNVERIFIED'
          }
          # Guard against PID reuse or SCM handoff during the observation.
          $after=Get-CimInstance -ClassName Win32_Service -Filter "Name='P085ProtectedReviewer'" -ErrorAction Stop
          $checks.live_service_pid_stable=($null -ne $after -and
            $after.State -eq 'Running' -and
            [uint32]$after.ProcessId -eq [uint32]$svc.ProcessId)
          if (-not $checks.live_service_pid_stable) {
            Add-Blocker 'SCM_SERVICE_PROCESS_CHANGED_DURING_INSPECTION'
          }
          $owner=Invoke-CimMethod -InputObject $proc -MethodName GetOwnerSid -ErrorAction Stop
          if ($owner.ReturnValue -ne 0 -or -not $owner.Sid) {
            Add-Blocker 'SCM_PROCESS_SID_QUERY_FAILED'
          } elseif ($ExpectedServiceSid) {
            $checks.service_process_owner_sid_matches_pin=(
              [string]::Equals([string]$owner.Sid,$ExpectedServiceSid,
                [StringComparison]::OrdinalIgnoreCase))
            if (-not $checks.service_process_owner_sid_matches_pin) { Add-Blocker 'SCM_PROCESS_SID_MISMATCH' }
          } else {
            Add-Blocker 'EXPECTED_SERVICE_SID_NOT_PINNED'
          }
        }
      } catch {
        Add-Blocker 'SCM_PROCESS_SID_UNVERIFIED'
      }
    } else {
      Add-Blocker 'SCM_LIVE_PROCESS_NOT_VERIFIED'
    }
  }
} catch {
  Add-Blocker 'SCM_QUERY_UNAVAILABLE'
}
if (-not $ExpectedServiceSid) { Add-Blocker 'EXPECTED_SERVICE_SID_NOT_PINNED' }
Add-Blocker 'INDEPENDENT_PROTECTED_RUNTIME_AND_ACL_REVIEW_REQUIRED'
Add-Blocker 'REAL_TWO_SID_AND_QA_E2E_REQUIRED'
$result=[ordered]@{
  schema='p085-owner-scm-readonly-v1'
  read_only=$true
  release_authorized=$false
  owner_approval_verified=$false
  auto_merge_authorized=$false
  service_name=$ServiceName
  checks=$checks
  blockers=@($blockers.ToArray() | Sort-Object -Unique)
}
$result | ConvertTo-Json -Depth 6 -Compress
