# Agent onboarding — Local Workspace Extensions

## Read order for a new agent

1. `README.md` — current working code and limitations.
2. `docs/TOOL_CATALOG.md` — tools, priorities, complexity and risk.
3. `docs/SPEC_TOOL_GUIDE.md`, then `openspec/config.yaml` and `openspec/changes/local-pc-agent-tooling/proposal.md`.
4. `openspec/changes/local-pc-agent-tooling/design.md`.
5. Exact one `openspec/changes/local-pc-agent-tooling/specs/<capability>/spec.md`.
6. `openspec/changes/local-pc-agent-tooling/tasks.md` for implementation task state.
7. `specs/001-local-pc-agent-tooling/spec.md`, `plan.md` and `tasks.md` for SDD traceability.
8. `.specify/memory/constitution.md`.

## New user-requested feature portfolio (72 ideas; planning-only)

The owner requested a strict usefulness audit and inclusion of all 72 ideas. Read `docs/MULTIAGENT_FEATURE_RANKING_2026-11-02.md`, `docs/FEATURE_IMPLEMENTATION_TASKS_V1.md`, and machine-checked `docs/FEATURE_PORTFOLIO_V1.json`. Check consistency using `python feature_portfolio.py check`. The planner retained 45 independent candidate implementation tracks, merged 20 duplicate/overlapping ideas into these tracks, deferred four, and rejected three high-risk/low-value designs. **None of the 72 is permission to alter live SQLite, bypass lease/reviewer gates, create canonical specs or change host permissions.**

Proposed new spec manifests: `requests/add-durable-agent-memory.json` (its previous owner request EXPIRED; always repeat `spec_preview` before requesting a new approval), `requests/add-agent-reliability-qa.json` (pending foreground owner approval), and `requests/add-professional-scene-pipeline.json` (previewed, NOT queued for approval yet). Meanwhile `openspec/changes/add-continuous-agent-work-loop` is an existing canonical change covering a related supervisor concept: reuse it instead of generating duplicate implementation. Never silently auto-approve or assume concurrent previews targeting the same SDD index can both be executed unchanged. Prioritize finishing/accepting the current developer queue before seeding new work. For any rollout, first verify the canonical owner-approved OpenSpec + SDD, user wishes, dependencies and actual host tool authority, then schedule only disjoint code tasks.

## Master SDD for self-development

Before selecting a new agent task, read `specs/001-local-pc-agent-tooling/MASTER_SDD.md`, `ARCHITECTURE_V2.md`, `IMPLEMENTATION_BACKLOG.md`, `checklists/multiagent-definition-of-done.md` and `docs/SDD_MULTI_TEAM_EXECUTION_V2.md` (non-normative execution supplement for multi-team work). The live SQLite queue and the checked `roadmap_tasks.json` are authoritative for the current wave: P104–P107 have been accepted, while some P108+ followups were already admitted after verified prerequisites. Never assume every P108–P147 task is blocked or ready; inspect `agent_team.py overview` and reviewer QA receipts each run. Run `python sdd_roadmap_check.py` before any follow-up seeding. Never use this document or a model-generated role string to grant MCP host permissions or owner approval.

## Mandatory repository reuse and architectural ownership guard (2026-11-02)

Read `docs/AGENT_CODE_REUSE_GOVERNANCE.md` before starting **every** coding task. Immediately after receiving a legitimate task/lease and BEFORE editing code, run `python task_reuse_preflight.py Pxxx` in the main authorized Local-Workspace-Extensions directory via Local Workspace, inspect the actual existing modules/functions and same-spec active tasks, and choose REUSE_EXISTING / EXTEND_CANONICAL_OWNER / PROPOSE_NEW_RESPONSIBILITY with concrete reasoning in the task checkpoint. Do not create a new module just because its output path is disjoint. Do not modify another owner's canonical files without approved scope. `agent_quality_gate.py audit` and `quality_submit.py` now reject substantial structurally duplicated production functions, and `agent_team.py review-preview` plus direct reviewer `review accept` independently check for clones before main-source merge. Heuristic near duplicates are architectural review signals, not semantic certainty. Never suppress or bypass these findings. Use exact SHA and independent evidence; on block route to architect for reuse/refactor. OpenSpec `add-agent-code-reuse-governance` was owner-approved and validated. The live coordinator now enforces **new-task-only** responsibility contracts in `agent_team.py`: after cutover, new seed admissions without `responsibility` fail; two active owners of one ID or module conflict atomically in SQLite; reviewer preview and direct accept run contract-scoped Python import-cycle/API checks. The pre-cutover tasks remain intentionally grandfathered, and runtime/dynamic imports and P085 host identity remain out of scope. Read `docs/RESPONSIBILITY_GATE_ROLLOUT.md` for the required task metadata and evidence. Future owner-ready reserve tasks lacking contracts are blocked before interactive admission; no approval bypass. After main changes, stale non-deliverable sandbox snapshots may need lease-owned CAS sync; never force-write another agent's sandbox.

## Strict engineering quality + 10+ feature discovery per backlog wave (2026-11-02)

Mandatory operating policy: read `docs/STRICT_ENGINEERING_AND_FEATURE_IDEATION.md`. For EVERY active coding task independently run focused/full negative tests, `spec_check.py`, OpenSpec strict and a substantive 9-dimension security/reliability/architecture/scalability/correctness/maintainability/performance/observability/spec-traceability assessment. Write task-specific `SANDBOX/agent_quality_report.json` with exact source SHA and actual job evidence, then call `experiments/chat_only_run/agent_quality_gate.py audit TASK_ID ROLE` via Local Workspace and require `can_submit_according_to_quality_policy=true` before any `submit`. Mandatory scheduled submit entrypoint: `experiments/chat_only_run/quality_submit.py ROLE TASK_ID LEASE_TOKEN EVIDENCE_NOTES`; it refuses the legacy coordinator transition when the independent static/evidence gate is red. Never call raw `agent_team.py submit` in scheduled developer chats. Fix architectural spaghetti and fail-open behavior rather than self-attesting PASS. This is a policy-level gate, not trusted MCP host-enforced attestation; architect verifies independently.

When no legitimate coding OR distinct peer-review task exists, each role prepares **10–20 detailed, distinct, justified** improvement candidates per canonical `team_seed.json` wave, once per role/wave. Read existing 72-item portfolio, OpenSpec and SDD first; use `experiments/chat_only_run/feature_idea_gate.py wave/validate/catalog`, fixed paths `.agent-team/feature-proposals/WAVE/developer-N.json` and per-run DRAFT continuation. Shared D3+D4 chat must submit 10+ PER LOGICAL ROLE. Every candidate needs 13 design sections, threat/reliability/scale analysis, measured impact hypothesis, tests, failure cases, alternatives, complexity, and actual dedup refs. The architect independently judges every valid candidate with detailed rationale and verified six-dimensional score, through `feature_idea_gate.py architect`. Max 8 of all 40+ per wave may be proposed to the OWNER for formal spec consideration, score >=78; none are owner-approved, admissible queue items or published code by themselves. No filler proposals, repeated hourly batches, fake job receipts, override of P085, or unauthorized spec/queue writes.

## Continuous useful-work cycle (2026-11-02)

Read `docs/VERIFIED_WORK_CYCLE.md`. After every actual completed coding, peer-review, architect-support, or truly novel advisory QA item, **call `verified_work_cycle.py ROLE` again**. If both leased review lanes are exhausted, allow at most 4 **distinct newly evidenced** read-only second-pass QA items per logical role and scheduled invocation (different foreign task + source SHA, no duplicate test, no claim); the cap is a safety maximum, never a required quota., inspect completed job rc=0 and `ok=true`, recheck SHA/lease and take the highest-priority remaining legitimately authorized work. Architect acts on independently verified review blockers and the 4 already promoted owner-ready feature proposals; all 40 previously authored feature ideas are already strictly validated and should not be generated anew each hour. Soft `target_useful_work_minutes=60` is aspiration only, not a claim that ChatGPT supports one-hour turns; no `sleep`, redundant QA, artificial active minutes, unapproved execution or retry of ambiguous side effects. Reuse existing durable agent/peer/support checkpoints across bounded scheduled runs; stop honestly on no new permitted work or provider/tool boundary. The F07 offline prototype `experiments/chat_only_run/retry_safety_advisor.py` is an advisor, NOT a host-sanctioned auto-retry policy.

## Virtual sixth logical planner (2026-11-02)

The ChatGPT Scheduled API returned `too_many_active_automations` (5/5) for an additional planner. `virtual_planner_agent.py` is the verified read-only **sixth logical role** inside the existing four hourly developer/architect scheduled chats; it does not create a sixth ChatGPT conversation or circumvent the limit. Read `docs/VIRTUAL_SIXTH_PLANNER.md`. It composes the existing, authoritative `agent_logistics_dispatch` and `queue_supply_watch` rather than introducing a second coordination database. After Local Workspace `list_workspaces`, run this script, require completed rc=0 and JSON ok=true, and inspect your own developer role (D3+D4 each separately) or all roles as architect. Validate original source SHA and proper leases before any work. Unapproved backlog suggestions are not coding grants and P085 remains open; never pretend an advisory message is direct control of another Web ChatGPT conversation.

## Developer ↔ peer-review switching (2026-11-02)

Read `docs/PEER_ROLE_SWITCH.md`. Four coding roles alternate between authorized coding and **advisory** independent review of tasks they never authored or contributed to. The scheduler uses `experiments/chat_only_run/peer_review_switch.py`: after a code submit, check `plan ROLE --after-code`, claim eligible foreign review under a separate peer-only lease, run independent tests and record evidence, then immediately check `plan ROLE` and return to coding if safe code is available. Developer-3 and developer-4 share one ChatGPT scheduled conversation and are prohibited from reviewing **either one's** authored tasks in that shared conversation. Peer review never grants `agent_team.py review accept/reject`, copies files to main, bypasses owner approval or fixes missing host authentication (P085). Enforce anti-self-review and peer lease on the local coordinator, not merely by instructions.

## Mandatory code ↔ peer-review ↔ architect-support ↔ feature-evidence loop (2026-11-02)

Read `docs/ARCHITECT_SUPPORT_LOOP.md` in addition to `docs/PEER_ROLE_SWITCH.md` and `docs/STRICT_ENGINEERING_AND_FEATURE_IDEATION.md`. An empty `agent_team.py plan-work ROLE` is **not** the end of a scheduled developer invocation: first perform a genuinely eligible independent peer-review; when that pool is exhausted, consult `experiments/chat_only_run/architect_support.py plan ROLE` and acquire one unclaimed advisory task under its separate lease. Work on independently reproducing reported regressions, new reliability/security cases, architecture/scalability evidence or validating the eight architect-selected feature hypotheses. Create and verify the report through `architect_support.py complete` and `overview` (report SHA). After EACH completed meaningful task, **recheck the coding queue first** and return to authorized implementation as soon as a legitimate scoped lease becomes available. Do not conclude `no_safe_work` just because coding and peer are empty while architect support remains available. After two support reviews, check `plan ROLE --prefer-features` for a distinct feature-evidence item; no duplicated hourly 10-feature portfolios after VALIDATED. Revalidate original source SHA, avoid own/coauthored tasks, do not change another role's sandbox and never claim advisory work is formal host-authenticated acceptance. In the combined Developer 3+4 chat the two logical roles must share attention but remain mutually excluded for independent review.

## Anti-idle task switching

When a task is blocked, read `docs/ANTI_IDLE_AGENT_POLICY.md`: classify whether the blocker is task-local, continue a separately authorized non-overlapping task, and route the blocked task to the reviewer. In particular, P096 source drift does not block P106's independent offline diagnostics. Never bypass leases, spec approval or reviewer security gates.

**Current second-wave QA incident (2026-11-01):** P108/P125/P111 sandbox snapshots have an older non-deliverable `test_sdd_roadmap_check.py` than canonical main. Read `docs/ARCH_REVIEW_2026-11-01_2200UTC.md` for independently reproduced evidence. Only the current developer task owner with its own live token may use `agent_team.py sync-sandbox ROLE TASK_ID TOKEN` to CAS-refresh unchanged non-deliverable Python files, then rerun the complete QA gates. Do not forge/copy SQLite acceptance records, manually overwrite test fixtures, reuse expired tokens, or treat the skipped sandbox integration as main acceptance evidence. P110 remains independent of stale P096, but the coordinator's rework-first selection requires a separate approved remedy; never merge P096 merely to clear the queue.

## Continuous coding queue — mandated watchdog (2026-11-02)

Read `docs/CONTINUOUS_DEVELOPER_BACKLOG.md`. The Architect Reviewer must run read-only `python experiments/chat_only_run/queue_supply_watch.py` on each hourly pass and maintain a high-quality owner-ready backlog before developers exhaust the legal work queue. The prepared pool `queue_supply_candidates_backlog.json` contains P154–P169 (8 owner-ready now, 8 reserve subject to cap). Aim for 2–3 live available coding tasks per role without source conflicts, stale QA or fictitious approval. The `owner_queue_admit.py` foreground human approval and reviewer QA gates are mandatory; do not bypass them or call `--apply` from MCP. If no coding task is legally available, use real peer-review and architect-support loops; never pretend a preview is a granted lease.

## Core priority: ship accepted OpenSpec + SDD code, not just economics

When there are no available developer tickets but ready predecessors exist, the architect must review the next safe, disjoint, spec-backed items in specs/001-local-pc-agent-tooling/IMPLEMENTATION_BACKLOG.md, seed them through the normal coordinator, and resume real coding roles. Never fabricate new grants or override stale rework P096. Economic reporting is secondary to code, independent review and QA.

## Financial KPI: gross avoided API vs full-month net

Read docs/NET_API_SAVINGS.md; use economic_savings_kpi.py or team_run_metrics.py --estimate --api-pricing --savings. Incomplete history must report monthly_net_savings_usd=null. Already paid Plus has $0 incremental charge for eligible runs, but the actual fixed monthly cash price remains $20. Do NOT subtract minute-weighted cost allocations from API scenario to claim monthly savings.

## GPT-6 API per-token cost (NOT ChatGPT subscription)

For counterfactual API usage pricing read `docs/GPT6_API_COST_ACCOUNTING.md`, run `api_token_pricing.py --token-scenarios .agent-team/reports/token_spend_scenarios_latest.json --save-report`, or use `team_run_metrics.py --estimate --api-pricing`. **Default pricing is gpt-6-sol Standard ($2/M input, $0.20/M cached input, $10/M output); scheduler actual model/Thinking High is NOT verifiable from Automation metadata.** Each alternative API SKU (Astra, Sol, Terra, Luna) has its own official input/output rate snapshot; cached-input assumptions are explicitly scenario-only. No API key, payment or charge is made. Never conflate the API what-if dollar metric with the separate flat $20/month ChatGPT subscription, or present these heuristic amounts as actual provider billing. Shared D3+D4 is still one scheduler run.

## Fixed-price subscription allocation (NOT tokens)

The independent owner-defined subscription-cost model is in `docs/SUBSCRIPTION_COST_ACCOUNTING.md` and `subscription_cost_allocation.py`. The assumption is $20/month, four planning weeks, five hypothetical limit-windows/week, 20 useful minutes/window, giving 400 *reference* minutes/month ($0.05/minute or $1/20-minute slot). This is **neither** provider billing **nor** actual five-hour quota metering. Keep its dollar allocations separate from all token forecasts; never add the minute-weighted and per-run variants, or double-count the shared Developer-3+4 job. `team_run_metrics.py --subscription-observations ...` adds its own section.

## Token consumption forecasting

For experimental run-level input/output estimates read `docs/TOKEN_FORECAST_CALIBRATION.md` and use `agent_token_forecast.py`. This is NOT a validated 90% estimator. It explicitly returns `UNCALIBRATED` until trustworthy same-run prompt metadata and provider usage receipts support calibration and independent holdout evaluation. Never label inferred text lengths as full LLM cost and never import predicted tokens into `token_usage`.

## Productivity, QA and token observability

Before evaluating agent throughput, read `docs/TEAM_PRODUCTIVITY.md` and `docs/TOKEN_ESTIMATION_V1_SDD.md`. `team_productivity.py` reports read-only queue and sandbox metrics; `team_run_metrics.py --estimate` adds **uncalibrated** input/output token-spend scenarios from `token_spend_estimator.py`. These numbers are explicitly NOT guaranteed 90%-accurate. Only real independently obtained provider usage can support calibration, and a 90% prediction interval is not the same as ±10% point accuracy. The actual LLM input/output tokens of ChatGPT Automations remain UNKNOWN without provider metadata; do not put estimates in the authoritative `token_usage` ledger. Do not require agents to waste time to satisfy arbitrary minimum session durations.

## Non-blocking task scheduling (implemented)

Read `docs/AGENT_NONBLOCKING_SCHEDULER.md`. Every developer scheduled invocation must consult `python agent_team.py plan-work ROLE` and the current OpenSpec/SDD before acquiring. The old P096-style stale-source/rework/expired-lease task is now automatically skipped if unsafe; eligible independent work (e.g. P110 for developer-3) is acquired via a fresh `python agent_team.py acquire ROLE UNIQUE_REQUEST_ID --task P110`. A plan is NOT a lease; inspect the returned task/token, and never use a previous task's lease token for another task. A new hourly invocation needs a fresh idempotency request ID; reuse the same ID only when retrying that same incomplete acquire. If a role already has an active task with a lost lease token, do not wait pointlessly when a separate scoped task is ready: acquire that other task legally. Do NOT bypass host actor authentication, expire/revoke another run's lease, modify stale P096 code or self-accept. The tool's role string is not a verified host identity (P085 remains blocked).

## Read-only resume packet for each hourly developer invocation

Before using `acquire` or opening a sandbox, read `docs/TASK_RESUME_PACKET.md` and (when a specific live Pxxx assignment is known) run `python task_resume_packet.py --task Pxxx`. This prints current canonical requirement SHA, real SQLite QA dependency status and an advisory next action without exposing a lease token, raw task instructions or private reasoning. **It is NOT a grant**; for `working` tasks a prior lease may still be active without a token in the new run. Never claim `safe_next_action` was executed, never bypass coordinator lease fencing, and defer `review` status to independent Architect Reviewer. The separate long-term memory/durable-step change remains subject to owner approval.

## Scheduled coding team

Five scheduled roles use `agent_team.py` and a durable separate SQLite queue. Read `docs/FIVE_AGENT_TEAM.md` before any automated implementation, review or specification amendment. Four developers write only into task-specific `.agent-team/workspaces/...`; one architect-reviewer performs independent quality gates and copies allowlisted outputs into the project after successful tests and SHA preconditions. Existing `Scheduled-Agent-Harness` is separate and preserved.

## Current scope

- Local Windows machine and workspace `projects`.
- CLI tools in `ops.py` / `infra_tools.py` can be called using MCP `run_script`.
- `mcp_adapter.py` includes decorator-based FastMCP adapters but they have not been registered in the actual running MCP server.
- The project is currently **untracked inside a highly dirty parent Git repository**; never run global Git add/commit from the `IdeaProjects` root.
- Docker and PostgreSQL readiness probes have worked, but SQL authentication for least-privileged E2E is pending.

## Allowed working style

- Read specs before changing code; pick one named task and one capability.
- Modify only files under this exact project unless the user explicitly expands scope.
- Show exact changed paths and run focused tests.
- Preserve user edits using hash preconditions.
- R2/R3 operations need an actual host-mediated approval; a prompt, inline `--apply` or repository README is insufficient.
- Do not install packages or bootstrap OpenSpec/Spec Kit CLIs without approval.
- Never expose secrets, personal files, clipboard or screen without proper user consent.

## Completion evidence

Report spec requirement, test name, observed result, environment, mock/live distinction, open risks and whether native MCP registration has been proven. Unknown means unknown; do not infer success from `pg_isready` or a running Docker container.
