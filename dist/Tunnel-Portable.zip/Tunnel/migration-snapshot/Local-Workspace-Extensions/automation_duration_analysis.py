"""Evidence-only analysis of observed ChatGPT scheduled run durations.

No scheduler access, background process, SQLite writes, or claims of a host timeout.
The JSON source is populated separately from exact Automation run IDs.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORT = ROOT / ".agent-team" / "reports" / "automation_timeout_repro_20261102.json"
ROLE_AUTOMATIONS = {
    "developer-1": "6ae6ba8a7edc8191a021b55a9ef1b595",
    "developer-2": "6ae6ba8b5d4c8191853883318aae7411",
    "developer-3+4": "6ae74da5c4548191b605d0566bfa56cf",
    "architect-reviewer": "6ae6ba8c7c1081919402e9d8bb58f0d7",
}
TREATMENT = {"developer-1", "developer-3+4"}
STATUS = {"completed", "failed", "cancelled", "canceled"}
NEAR_25_SECONDS = (1485, 1515)  # exploration band, not a platform SLA
MAX_BYTES = 100_000
MAX_SAMPLES = 400


class RunAnalysisError(ValueError):
    pass


def _parse_utc(value):
    if not isinstance(value, str) or len(value) > 48:
        raise RunAnalysisError("INVALID_RUN_TIMESTAMP")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, OverflowError) as exc:
        raise RunAnalysisError("INVALID_RUN_TIMESTAMP") from exc
    if dt.utcoffset() is None:
        raise RunAnalysisError("TIMESTAMP_MISSING_TIMEZONE")
    return dt.astimezone(timezone.utc)


def _run(row):
    if not isinstance(row, dict):
        raise RunAnalysisError("INVALID_RUN_ROW")
    role = row.get("role")
    if role not in ROLE_AUTOMATIONS or row.get("automation_id") != ROLE_AUTOMATIONS[role]:
        raise RunAnalysisError("ROLE_AUTOMATION_MISMATCH")
    run_id = row.get("run_id")
    if not isinstance(run_id, str) or not 3 <= len(run_id) <= 128:
        raise RunAnalysisError("INVALID_RUN_ID")
    if row.get("status") not in STATUS:
        raise RunAnalysisError("NOT_A_TERMINAL_RUN")
    start, end = _parse_utc(row.get("started_at")), _parse_utc(row.get("completed_at"))
    duration = (end - start).total_seconds()
    if not 0 <= duration <= 24 * 3600:
        raise RunAnalysisError("IMPLAUSIBLE_RUN_DURATION")
    if "duration_seconds" in row:
        recorded = row["duration_seconds"]
        if (isinstance(recorded, bool) or not isinstance(recorded, (int, float))
                or not math.isfinite(recorded) or abs(recorded - duration) > 0.005):
            raise RunAnalysisError("RUN_DURATION_DOES_NOT_MATCH_TIMESTAMPS")
    return {
        "run_id": run_id,
        "role": role,
        "status": row["status"],
        "start": start,
        "duration_seconds": round(duration, 3),
        "near_25m": NEAR_25_SECONDS[0] <= duration <= NEAR_25_SECONDS[1],
        "intended_arm": "treatment" if role in TREATMENT else "control",
        # A self-declared flag in a local JSON file is not a trusted
        # immutable scheduler prompt snapshot. No such attestation is exposed.
        "prompt_exposure_verified": False,
        "prompt_exposure_claimed_only": row.get("prompt_exposure_verified") is True,
    }


def _median(values):
    return round(statistics.median(values), 3) if values else None


def analyze(document):
    if not isinstance(document, dict) or document.get("schema") != "automation-duration-repeatability-v1":
        raise RunAnalysisError("INVALID_REPORT_SCHEMA")
    baseline, extra = document.get("existing_baseline_samples"), document.get("additional_samples")
    if not isinstance(baseline, list) or not isinstance(extra, list):
        raise RunAnalysisError("INVALID_SAMPLE_COLLECTION")
    if len(baseline) + len(extra) > MAX_SAMPLES:
        raise RunAnalysisError("UNBOUNDED_SAMPLE_COLLECTION")
    goal = document.get("sample_goal_additional")
    if isinstance(goal, bool) or not isinstance(goal, int) or not 1 <= goal <= 100:
        raise RunAnalysisError("INVALID_EXPERIMENT_TARGET")
    # A stale source count is an inconsistency, not a reason to fabricate
    # missing samples. Report both values rather than trusting the counter.
    reported = document.get("additional_samples_recorded")
    if isinstance(reported, bool) or not isinstance(reported, int) or reported < 0:
        raise RunAnalysisError("INVALID_REPORTED_COUNT")
    seen = set()
    normalized = []
    for source, group in ((baseline, "historical"), (extra, "additional")):
        for row in source:
            item = _run(row)
            if item["run_id"] in seen:
                raise RunAnalysisError("DUPLICATE_SCHEDULER_RUN_ID")
            seen.add(item["run_id"])
            item["cohort"] = group
            # Historical samples predate the A/B intervention and must never
            # be mislabelled as if they had the new treatment prompt.
            if group == "historical":
                item["intended_arm"] = "pre_intervention"
                item["prompt_exposure_verified"] = False
                item["prompt_exposure_claimed_only"] = False
            normalized.append(item)
    recent = [r for r in normalized if r["cohort"] == "additional"]
    history = [r for r in normalized if r["cohort"] == "historical"]
    control = [r for r in recent if r["intended_arm"] == "control"]
    treated = [r for r in recent if r["intended_arm"] == "treatment"]
    verified_treated = [r for r in treated if r["prompt_exposure_verified"]]
    failed_near = [r for r in recent if r["status"] == "failed" and r["near_25m"]]
    successful_over_40 = [r for r in recent
                          if r["status"] == "completed" and r["duration_seconds"] >= 2400]
    sufficient = len(recent) >= goal
    # This is a repeatability signal, not identification of why the
    # scheduler failed, much less a provider policy guarantee.
    verdict = ("INSUFFICIENT_ADDITIONAL_RUNS" if not sufficient else
               "ALL_ADDITIONAL_RUNS_FAILED_NEAR_25_MINUTES"
               if len(failed_near) == len(recent) else
               "MIXED_TERMINAL_DURATIONS_OR_OUTCOMES")
    durations = [r["duration_seconds"] for r in recent]
    return {
        "ok": True,
        "schema": "automation-duration-analysis-v1",
        "goal_additional": goal,
        "historical_count": len(history),
        "new_completed_or_failed_samples": len(recent),
        "additional_samples_remaining": max(0, goal-len(recent)),
        "recorded_counter_matches": reported == len(recent),
        "experimental_verdict": verdict,
        "provider_timeout_established": False,
        "source_status_counts": dict(sorted(Counter(r["status"] for r in recent).items())),
        "historical_failed_near_25m": sum(
            r["status"] == "failed" and r["near_25m"] for r in history),
        "additional_failed_near_25m": len(failed_near),
        "completed_over_40m": len(successful_over_40),
        "duration_seconds_median": _median(durations),
        "duration_seconds_min": min(durations, default=None),
        "duration_seconds_max": max(durations, default=None),
        "intended_treatment_count": len(treated),
        "intended_control_count": len(control),
        "confirmed_treatment_prompt_exposure_count": len(verified_treated),
        "exposure_caveat": "Prompt snapshot is not verifiable for a given scheduled run unless separately attested.",
        "methodology_caveat": "Roles differ in workloads and share a scheduler. A 25-minute cluster is evidence of a pattern, not proof of provider timeout; natural completions and missing observations require separate treatment.",
        "samples": [{
            "run_id": r["run_id"],
            "role": r["role"],
            "cohort": r["cohort"],
            "status": r["status"],
            "duration_seconds": r["duration_seconds"],
            "near_25m": r["near_25m"],
            "intended_arm": r["intended_arm"],
            "prompt_exposure_verified": r["prompt_exposure_verified"],
            "prompt_exposure_claimed_only": r["prompt_exposure_claimed_only"],
        } for r in normalized],
    }


def load(path=REPORT):
    path = Path(path)
    if (not path.is_file() or path.is_symlink()
            or getattr(path, "is_junction", lambda: False)()):
        raise RunAnalysisError("UNSAFE_OR_MISSING_REPORT")
    if path.stat().st_size > MAX_BYTES:
        raise RunAnalysisError("REPORT_TOO_LARGE")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RunAnalysisError("INVALID_REPORT_JSON") from exc


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pretty", action="store_true")
    ns = parser.parse_args(argv)
    try:
        result = analyze(load())
    except (RunAnalysisError, OSError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 2
    print(json.dumps(result, ensure_ascii=True, indent=2 if ns.pretty else None))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
