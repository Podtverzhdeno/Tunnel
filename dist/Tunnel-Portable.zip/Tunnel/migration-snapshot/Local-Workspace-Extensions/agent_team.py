"""Durable five-role spec-first coding team for Local Workspace Extensions.

Four developers produce scoped code in isolated project snapshots. The fifth
reviewer validates test evidence and may publish only reviewed allowlisted
artifacts using SHA256 compare-and-swap. No Git, Docker or global OS mutations.
"""
import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4
from review_merge import MergeIntent, MergeError
from agent_token_usage import UsageError
from code_reuse_guard import audit as audit_code_reuse, ReuseGuardError
from agent_responsibility_guard import (ResponsibilityError, validate_contract,
    check_ownership, audit_candidate_imports, _all_rows)

PROJECT = Path(__file__).resolve().parent
STATE = PROJECT / ".agent-team"
DATABASE = STATE / "team.sqlite3"
ROLES = ("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer")
DEVELOPERS = ROLES[:4]
TTL_MINUTES = 50
CODE_FILE = re.compile(r"^(?:[a-z][a-z0-9_]*|test_[a-z][a-z0-9_]*)\.py$")
TASK_ID = re.compile(r"^P[0-9]{3}$")
REQUEST_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$")
SPEC_TITLE = re.compile(r"^### Requirement: (.+)$", re.M)
SKIP_DIRS = {".git", ".venv", ".local-state", ".agent-team", "__pycache__", ".pytest_cache", "requests"}
ALLOWED_COPY_DIRS = ("openspec", "specs", ".specify", "host_snapshot")
MAX_BYTES = 2 * 1024 * 1024

class TeamError(Exception):
    def __init__(self, code, reason):
        super().__init__(reason)
        self.code = code


def utcnow():
    return datetime.now(timezone.utc)


def stamp():
    return utcnow().isoformat(timespec="seconds")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    if not path.exists():
        return None
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise TeamError("UNSAFE_FILE", "Unsafe, nonregular or oversized source")
    return digest(path.read_bytes())


def connect(db_path=DATABASE):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(db_path), isolation_level=None, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=20000")
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
      CREATE TABLE IF NOT EXISTS tasks(
        task_id TEXT PRIMARY KEY, title TEXT NOT NULL, spec_ref TEXT NOT NULL,
        instructions TEXT NOT NULL, role_hint TEXT NOT NULL,
        owner TEXT, status TEXT NOT NULL DEFAULT 'available',
        lease_token TEXT, lease_until TEXT,
        review_token TEXT, review_until TEXT,
        sandbox TEXT, deliverables TEXT NOT NULL, baseline TEXT,
        activity_at TEXT NOT NULL, created_at TEXT NOT NULL,
        submitted_at TEXT, reviewed_at TEXT, review_notes TEXT,
        revision INTEGER NOT NULL DEFAULT 0,
        priority INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS agents(
        role TEXT PRIMARY KEY, last_started TEXT, last_activity TEXT,
        sessions INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, role TEXT NOT NULL,
        action TEXT NOT NULL, detail TEXT, at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS acquisitions(
        role TEXT NOT NULL, request_id TEXT NOT NULL, task_id TEXT,
        lease_token TEXT, created_at TEXT NOT NULL,
        PRIMARY KEY(role, request_id)
      );
      CREATE TABLE IF NOT EXISTS acceptance_records(
        task_id TEXT PRIMARY KEY, reviewer_role TEXT NOT NULL,
        recorded_at TEXT NOT NULL, qa_json TEXT NOT NULL,
        artifacts_json TEXT NOT NULL, spec_sha256 TEXT
      );
      CREATE TABLE IF NOT EXISTS token_usage(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id TEXT NOT NULL, role TEXT NOT NULL,
        usage_id TEXT NOT NULL, lease_sha256 TEXT NOT NULL,
        model TEXT NOT NULL, provider TEXT NOT NULL,
        input_tokens INTEGER NOT NULL CHECK(input_tokens >= 0),
        output_tokens INTEGER NOT NULL CHECK(output_tokens >= 0),
        cached_input_tokens INTEGER NOT NULL DEFAULT 0,
        reasoning_output_tokens INTEGER NOT NULL DEFAULT 0,
        source TEXT NOT NULL, recorded_at TEXT NOT NULL,
        UNIQUE(role,usage_id)
      );
      CREATE TABLE IF NOT EXISTS task_responsibilities(
        task_id TEXT PRIMARY KEY REFERENCES tasks(task_id),
        payload_json TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS token_usage_by_role ON token_usage(role,task_id);
      CREATE TABLE IF NOT EXISTS task_checkpoints(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id TEXT NOT NULL, role TEXT NOT NULL,
        request_id TEXT NOT NULL, lease_token TEXT NOT NULL,
        progress_json TEXT NOT NULL, recorded_at TEXT NOT NULL,
        UNIQUE(role, request_id)
      );
    """)
    columns={x[1] for x in db.execute("PRAGMA table_info(tasks)")}
    if "priority" not in columns:
        db.execute("ALTER TABLE tasks ADD COLUMN priority INTEGER NOT NULL DEFAULT 0")
    for role in ROLES:
        db.execute("INSERT OR IGNORE INTO agents(role) VALUES (?)", (role,))
    return db


def connect_readonly(db_path=DATABASE):
    """Open an existing coordinator database with no schema or WAL mutations.

    Live reviewer preflight must not initialize tables, write agent sessions
    or switch journal modes. This is not a host authorization boundary.
    """
    path = Path(db_path)
    if (path.is_symlink() or getattr(path, "is_junction", lambda: False)()
            or not path.is_file()):
        raise TeamError("READONLY_DB_UNAVAILABLE",
                        "Reviewer inspection requires an existing regular database")
    try:
        db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro",
                             uri=True, timeout=5)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA query_only=ON")
        return db
    except sqlite3.Error as exc:
        raise TeamError("READONLY_DB_UNAVAILABLE",
                        "Reviewer inspection could not open database") from exc


def event(db, task_id, role, action, detail=""):
    db.execute("INSERT INTO events(task_id,role,action,detail,at) VALUES(?,?,?,?,?)",
               (task_id,role,action,str(detail)[:1600],stamp()))


def _validate_seed(item):
    task = item["id"]
    if not TASK_ID.fullmatch(task):
        raise TeamError("INVALID_TASK", "Task id must follow P000")
    if item["role_hint"] not in DEVELOPERS:
        raise TeamError("INVALID_ROLE", "Task must belong to developer role")
    spec_path, _, requirement = item["spec_ref"].partition(" / ")
    if not requirement or not spec_path.startswith("openspec/changes/local-pc-agent-tooling/specs/"):
        raise TeamError("INVALID_SPEC", "Provide canonical OpenSpec requirement reference")
    candidate = (PROJECT / spec_path).resolve()
    if not candidate.is_relative_to(PROJECT) or not candidate.is_file():
        raise TeamError("MISSING_SPEC", "Spec file not found")
    if requirement not in SPEC_TITLE.findall(candidate.read_text(encoding="utf-8")):
        raise TeamError("UNKNOWN_REQUIREMENT", "OpenSpec requirement does not exist")
    paths = item.get("deliverables", [])
    if not paths or len(paths) > 6 or len(set(paths)) != len(paths):
        raise TeamError("INVALID_OUTPUT", "Give 1..6 distinct output files")
    if type(item.get("priority",0)) is not int or not 0 <= item.get("priority",0) <= 100:
        raise TeamError("INVALID_PRIORITY","Task priority must be integer 0..100")
    for rel in paths:
        if not isinstance(rel, str) or not CODE_FILE.fullmatch(rel):
            raise TeamError("INVALID_OUTPUT", "Only root-level Python source/tests allowed")


def _responsibility_policy_active():
    """OpenSpec 004 approval cutover: old task IDs remain grandfathered."""
    return (PROJECT/"openspec/changes/add-agent-code-reuse-governance"
            /"specs/architecture-responsibility-contracts/spec.md").is_file()


def _responsibility_for(db, task_id):
    entry=db.execute("SELECT payload_json FROM task_responsibilities WHERE task_id=?",
                     (task_id,)).fetchone()
    if entry is None:
        return None
    try:
        return json.loads(entry["payload_json"])
    except (TypeError,ValueError) as exc:
        raise TeamError("RESPONSIBILITY_REGISTRY_INVALID",
                        "Stored responsibility contract is corrupt") from exc


def _check_responsibility(db,task_id,contract):
    try:
        check_ownership(db,task_id,contract)
    except ResponsibilityError as exc:
        raise TeamError("RESPONSIBILITY_CONFLICT",str(exc)) from exc


def _review_responsibility(db,row,files):
    """Check opted-in tasks even on direct reviewer acceptance."""
    contract=_responsibility_for(db,row["task_id"])
    if contract is None:
        return {"decision":"LEGACY_UNMAPPED","new_contract_gate":False}
    _check_responsibility(db,row["task_id"],contract)
    candidates={name:path for name,path in files if not name.startswith("test_")}
    try:
        contracts=[json.loads(x["payload_json"]) for x in _all_rows(db)]
        return audit_candidate_imports(PROJECT,candidates,contract,contracts)
    except (ResponsibilityError,ValueError,OSError,MemoryError,RecursionError) as exc:
        raise TeamError("RESPONSIBILITY_SOURCE_BLOCKED",str(exc)[:170]) from exc


def seed(path=None, db_path=DATABASE):
    manifest = Path(path) if path else PROJECT / "team_seed.json"
    tasks = json.loads(manifest.read_text(encoding="utf-8"))
    if not isinstance(tasks, list):
        raise TeamError("INVALID_SEED", "Expected list of tasks")
    seen = set()
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        inserted = 0
        revised = 0
        try:
            existing = {
                row["task_id"]: {"files":set(json.loads(row["deliverables"])),
                                 "status":row["status"],"owner":row["owner"],
                                 "sandbox":row["sandbox"]}
                for row in db.execute("SELECT task_id,deliverables,status,owner,sandbox FROM tasks")
            }
            used_files=set().union(*(info["files"] for info in existing.values()
                                     if info["status"]!="done")) if existing else set()
            new_files = set()
            for item in tasks:
                _validate_seed(item)
                if item["id"] in seen:
                    raise TeamError("DUPLICATE_TASK", "Duplicated seed task")
                seen.add(item["id"])
                paths=set(item["deliverables"])
                new_task=item["id"] not in existing
                raw_contract=item.get("responsibility")
                if new_task and _responsibility_policy_active() and raw_contract is None:
                    raise TeamError("RESPONSIBILITY_REQUIRED",
                                    "New coding task requires explicit canonical ownership contract")
                contract=None
                if raw_contract is not None:
                    try:
                        contract=validate_contract(raw_contract,paths)
                    except ResponsibilityError as exc:
                        raise TeamError("RESPONSIBILITY_INVALID",str(exc)) from exc
                recorded=_responsibility_for(db,item["id"])
                if not new_task and recorded is not None and contract!=recorded:
                    raise TeamError("RESPONSIBILITY_REDEFINED",
                                    "Existing responsibility contract cannot be silently changed")
                if not new_task and recorded is None and contract is not None:
                    raise TeamError("LEGACY_RESPONSIBILITY_MIGRATION_REQUIRED",
                                    "Grandfathered task requires separately reviewed migration")
                if new_task and contract is not None:
                    _check_responsibility(db,item["id"],contract)
                if item["id"] in existing:
                    original=existing[item["id"]]
                    if paths != original["files"]:
                        raise TeamError("TASK_REDEFINED","Existing task output scope cannot change")
                    if (original["status"]=="available" and original["owner"] is None
                            and original["sandbox"] is None):
                        old=db.execute("SELECT title,spec_ref,instructions,role_hint,priority "
                                       "FROM tasks WHERE task_id=?",(item["id"],)).fetchone()
                        incoming=(item["title"],item["spec_ref"],item["instructions"],
                                  item["role_hint"],item.get("priority",0))
                        if tuple(old)!=incoming:
                            db.execute("UPDATE tasks SET title=?,spec_ref=?,instructions=?,"
                                       "role_hint=?,priority=?,revision=revision+1,activity_at=? "
                                       "WHERE task_id=? AND status='available' AND owner IS NULL "
                                       "AND sandbox IS NULL",
                                       (*incoming,stamp(),item["id"]))
                            revised+=1
                            event(db,item["id"],"architect-reviewer","seed_revision",
                                  "Updated only unclaimed task metadata and priority")
                elif paths.intersection(used_files|new_files):
                    raise TeamError("OVERLAPPING_OUTPUT","Another task owns one or more deliverables")
                else:
                    new_files.update(paths)
                cur = db.execute(
                  """INSERT OR IGNORE INTO tasks
                  (task_id,title,spec_ref,instructions,role_hint,deliverables,priority,activity_at,created_at)
                  VALUES(?,?,?,?,?,?,?,?,?)""",
                  (item["id"],item["title"],item["spec_ref"],item["instructions"],
                   item["role_hint"],json.dumps(item["deliverables"]),item.get("priority",0),stamp(),stamp()))
                if cur.rowcount:
                    if contract is not None:
                        db.execute("INSERT INTO task_responsibilities(task_id,payload_json) VALUES(?,?)",
                                   (item["id"],json.dumps(contract,sort_keys=True)))
                    inserted += 1
                    event(db,item["id"],"architect-reviewer","seed","Created from canonical spec")
            db.execute("COMMIT")
        except BaseException:
            db.execute("ROLLBACK")
            raise
    return {"added": inserted, "revised":revised, "seed_total": len(tasks)}


HOST_FIXTURE_FILES = ("__init__.py", "manage.py", "http_server.py", "tools.py")


def _trusted_host_fixture(source):
    """Preflight bounded project-owned host fixture; NEVER read live Downloads."""
    source = Path(source)
    if (source.is_symlink() or getattr(source, "is_junction", lambda: False)()
            or not source.is_dir()):
        raise TeamError("UNSAFE_HOST_FIXTURE", "Fixture directory missing or linked")
    actual = set()
    for child in source.iterdir():
        if (child.name == "__pycache__" and child.is_dir() and not child.is_symlink()):
            continue
        if (child.name not in HOST_FIXTURE_FILES or child.is_symlink()
                or getattr(child, "is_junction", lambda: False)()
                or not child.is_file() or child.stat().st_size > MAX_BYTES):
            raise TeamError("UNSAFE_HOST_FIXTURE", "Unexpected or unsafe fixture entry")
        actual.add(child.name)
    if actual != set(HOST_FIXTURE_FILES):
        raise TeamError("HOST_FIXTURE_INCOMPLETE", "Required fixture files missing")
    return {name: (source / name).read_bytes() for name in HOST_FIXTURE_FILES}


def _restore_host_fixture_if_missing(folder):
    """Fill only missing trusted test fixtures in a lease-owned sandbox.

    Existing bytes must match the canonical project snapshot exactly.
    No developer deliverables, OpenSpec files, host config or SQLite edits.
    """
    source = PROJECT / "host_snapshot"
    if not source.exists():
        return []
    trusted = _trusted_host_fixture(source)
    dest = folder / "host_snapshot"
    if dest.is_symlink() or getattr(dest, "is_junction", lambda: False)():
        raise TeamError("UNSAFE_HOST_FIXTURE", "Sandbox fixture path linked")
    if dest.exists() and not dest.is_dir():
        raise TeamError("UNSAFE_HOST_FIXTURE", "Sandbox fixture path not directory")
    if dest.is_dir():
        for child in dest.iterdir():
            if child.name == "__pycache__" and child.is_dir() and not child.is_symlink():
                continue
            if (child.name not in trusted or child.is_symlink()
                    or getattr(child, "is_junction", lambda: False)()
                    or not child.is_file() or child.read_bytes() != trusted[child.name]):
                raise TeamError("HOST_FIXTURE_CONFLICT", "Sandbox fixture differs")
    else:
        dest.mkdir()
    added = []
    for name, raw in trusted.items():
        target = dest / name
        if target.exists():
            if target.read_bytes() != raw:
                raise TeamError("HOST_FIXTURE_CONFLICT", "Snapshot changed while copying")
            continue
        # Exclusive create; retry can resume a partial non-destructive copy.
        with open(target, "xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        added.append(name)
    return added


def _copy_sandbox(target):
    # Preflight the one required non-executable roadmap fixture before
    # creating a task directory, so missing/bad seed cannot strand a lease.
    manifest = PROJECT / "team_seed.json"
    if (manifest.is_symlink() or getattr(manifest, "is_junction", lambda: False)()
            or not manifest.is_file() or manifest.stat().st_size > 256 * 1024):
        raise TeamError("UNSAFE_SEED", "Canonical team seed is absent or unsafe")
    seed_bytes = manifest.read_bytes()
    try:
        parsed_seed = json.loads(seed_bytes)
    except (ValueError, UnicodeError):
        raise TeamError("INVALID_SEED", "Canonical team seed is malformed") from None
    if len(seed_bytes) > 256 * 1024 or not isinstance(parsed_seed, list):
        raise TeamError("INVALID_SEED", "Canonical team seed must be a bounded JSON array")
    # Fail before creating the sandbox when fixture provenance is unsafe.
    fixture_source = PROJECT / "host_snapshot"
    if fixture_source.exists():
        _trusted_host_fixture(fixture_source)
    target.mkdir(parents=True, exist_ok=False)
    for file in PROJECT.iterdir():
        if file.is_symlink():
            continue
        if file.is_file() and file.suffix == ".py" and file.stat().st_size <= MAX_BYTES:
            shutil.copy2(file,target/file.name)
        elif file.name == "team_seed.json":
            # The canonical SDD roadmap suite requires this non-executable
            # manifest in every isolated task snapshot. Copy from the
            # authenticated project root, never from a caller-supplied path.
            if (file.is_symlink() or getattr(file, "is_junction", lambda: False)()
                    or not file.is_file() or file.stat().st_size > 256 * 1024):
                raise TeamError("UNSAFE_SEED", "Cannot snapshot an unsafe team seed")
            raw = file.read_bytes()
            if len(raw) > 256 * 1024 or not isinstance(json.loads(raw), list):
                raise TeamError("INVALID_SEED", "Canonical team seed must be a bounded JSON array")
            (target / file.name).write_bytes(raw)
        elif file.is_file() and file.name in ("README.md", "AGENTS.md", "pyproject.toml"):
            shutil.copy2(file,target/file.name)
    for name in ALLOWED_COPY_DIRS:
        src = PROJECT / name
        if src.is_symlink() or getattr(src, "is_junction", lambda: False)():
            raise TeamError("UNSAFE_SNAPSHOT_DIR", "Cannot copy a linked fixture directory")
        if src.is_dir():
            if name == "host_snapshot":
                _trusted_host_fixture(src)
            shutil.copytree(src, target/name, ignore=shutil.ignore_patterns(
                "__pycache__", ".git", ".venv", ".local-state", "*.sqlite3", "*.pyc"))
    (target / "team_checkpoint.json").write_text(
      json.dumps({"created": stamp(), "state": "work_pending",
                  "instructions": "Read canonical spec; edit only assigned deliverables."},
                 ensure_ascii=False,indent=2),encoding="utf-8")


def _snapshot(db, row, role):
    if row["sandbox"]:
        folder = PROJECT / row["sandbox"]
        if folder.is_dir():
            return row["sandbox"]
        raise TeamError("MISSING_SANDBOX", "Previous work directory is missing; do not silently recreate it")
    rel = ".agent-team/workspaces/" + role + "/" + row["task_id"]
    dst = (PROJECT/rel).resolve()
    if not dst.is_relative_to(STATE.resolve()):
        raise TeamError("UNSAFE_PATH", "Sandbox escapes state area")
    dst.parent.mkdir(parents=True, exist_ok=True)
    _copy_sandbox(dst)
    base = {name:file_sha(PROJECT/name) for name in json.loads(row["deliverables"])}
    spec_rel = row["spec_ref"].partition(" / ")[0]
    base["__spec_sha__"] = file_sha(PROJECT/spec_rel)
    outputs=set(json.loads(row["deliverables"]))
    base["__snapshot_py__"]={p.name:file_sha(p) for p in dst.glob("*.py")
                               if p.name not in outputs and CODE_FILE.fullmatch(p.name)}
    fixture = dst / "host_snapshot"
    base["__snapshot_host_fixture__"] = (
        {name: file_sha(fixture / name) for name in HOST_FIXTURE_FILES}
        if fixture.is_dir() else {})
    db.execute("UPDATE tasks SET sandbox=?,baseline=? WHERE task_id=?",
               (rel,json.dumps(base,sort_keys=True),row["task_id"]))
    return rel


def _row_json(row):
    if row is None:
        return None
    keys=("task_id","title","spec_ref","instructions","role_hint","owner","status",
          "lease_until","sandbox","activity_at","submitted_at","reviewed_at","review_notes","revision","priority")
    out={k:row[k] for k in keys}
    out["deliverables"]=json.loads(row["deliverables"])
    return out


def status(db_path=DATABASE, role=None):
    with closing(connect(db_path)) as db:
        rows=db.execute("SELECT * FROM tasks ORDER BY created_at,task_id").fetchall()
        actors=db.execute("SELECT * FROM agents ORDER BY role").fetchall()
        events=db.execute("SELECT task_id,role,action,detail,at FROM events "
                          "ORDER BY id DESC LIMIT 30").fetchall()
        latest={}
        for cp in db.execute("SELECT task_id,role,progress_json,recorded_at "
                             "FROM task_checkpoints ORDER BY id DESC"):
            if cp["task_id"] not in latest:
                latest[cp["task_id"]]={"role":cp["role"],"recorded_at":cp["recorded_at"],
                                      "progress":json.loads(cp["progress_json"])}
    return {"project":"Local-Workspace-Extensions",
            "task_count":len(rows),
            "tasks":[{**_row_json(x),"latest_checkpoint":latest.get(x["task_id"])} for x in rows],
            "agents":[dict(x) for x in actors],
            "recent_activity":[dict(x) for x in events],
            "actor":role}


def overview(db_path=DATABASE, reference_time=None):
    """Read-only operational summary with UTC last-activity ages and lease alerts."""
    current = reference_time or utcnow()
    state = status(db_path)
    rows = []
    by_state = {}
    for task in state["tasks"]:
        phase = task["status"]
        by_state[phase] = by_state.get(phase, 0) + 1
        updated = datetime.fromisoformat(task["activity_at"])
        activity_minutes = max(0, round((current - updated).total_seconds() / 60, 1))
        lease_until = task["lease_until"]
        lease_remaining = None
        if lease_until:
            lease_remaining = round(
                (datetime.fromisoformat(lease_until) - current).total_seconds() / 60, 1
            )
        attention = []
        if MergeIntent(PROJECT,STATE,task["task_id"]).pending():
            attention.append("merge_intent_requires_owner_review")
        if phase == "working" and lease_remaining is not None and lease_remaining < 0:
            attention.append("developer_lease_expired")
        if phase == "review" and activity_minutes >= 60:
            attention.append("review_waiting_over_hour")
        if phase == "rework":
            attention.append("review_rework_required")
        progress = task.get("latest_checkpoint")
        rows.append({
            "task_id":task["task_id"], "status":phase, "owner":task["owner"],
            "last_activity_utc":task["activity_at"],
            "minutes_since_activity":activity_minutes,
            "lease_until_utc":lease_until, "lease_remaining_minutes":lease_remaining,
            "checkpoint_at_utc": progress["recorded_at"] if progress else None,
            "next_steps":progress["progress"]["next"][:4] if progress else [],
            "attention":attention,
        })
    agents=[]
    for actor in state["agents"]:
        seen=actor["last_activity"]
        agents.append({
            "role":actor["role"],"sessions":actor["sessions"],
            "last_started_utc":actor["last_started"],
            "last_activity_utc":seen,
            "minutes_since_activity":max(0,round(
                (current-datetime.fromisoformat(seen)).total_seconds()/60,1
            )) if seen else None,
        })
    return {"project":state["project"],"as_of_utc":current.isoformat(timespec="seconds"),
            "task_counts":by_state,"agents":agents,"tasks":rows,
            "alerts":[{"task_id":x["task_id"],"reasons":x["attention"]}
                      for x in rows if x["attention"]]}


def _check_request(request_id):
    if not REQUEST_ID.fullmatch(request_id):
        raise TeamError("REQUEST_ID_INVALID","Request ID must be 8..128 safe ASCII chars")


def _candidate_block_reason(row):
    """Read-only prelease preflight; never park/revoke or mutate a skipped task.

    Check only durable owned snapshots. A stale rework/expired task must not
    starve other disjoint, ready tasks in the same role.
    """
    if MergeIntent(PROJECT,STATE,row["task_id"]).pending():
        return "UNRESOLVED_MERGE_INTENT"
    if not row["sandbox"]:
        return None  # freshly available; _snapshot performs authoritative checks
    folder=PROJECT/row["sandbox"]
    if (folder.is_symlink() or getattr(folder,"is_junction",lambda:False)()
            or not folder.is_dir() or
            not folder.resolve().is_relative_to(STATE.resolve())):
        return "SANDBOX_UNSAFE_OR_MISSING"
    try:
        baseline=json.loads(row["baseline"] or "{}")
        if not isinstance(baseline,dict):
            return "BASELINE_INVALID"
        rel=row["spec_ref"].partition(" / ")[0]
        if file_sha(PROJECT/rel)!=baseline.get("__spec_sha__"):
            return "SPEC_DRIFT_REQUIRES_REBASE"
        for name in json.loads(row["deliverables"]):
            if file_sha(PROJECT/name)!=baseline.get(name):
                return "SOURCE_DRIFT_REQUIRES_REBASE"
    except (ValueError,TypeError,OSError,TeamError):
        return "BASELINE_OR_SOURCE_UNSAFE"
    return None


def _candidate_responsibility_block(db,row):
    try:
        contract=_responsibility_for(db,row["task_id"])
        if contract is not None:
            _check_responsibility(db,row["task_id"],contract)
    except TeamError as exc:
        return exc.code
    return None


def _developer_candidates(db,role):
    return db.execute(
        "SELECT * FROM tasks WHERE "
        "((owner=? AND (status IN ('available','rework') OR "
        "(status='working' AND lease_until < ?))) OR "
        "(owner IS NULL AND role_hint=? AND status='available')) "
        "ORDER BY CASE WHEN status='rework' THEN 0 WHEN owner=? THEN 1 ELSE 2 END,"
        "priority DESC,created_at,task_id LIMIT 5000",
        (role,stamp(),role,role)
    ).fetchall()


def plan_work(role,db_path=DATABASE):
    """Read-only advisory; a fresh atomic acquire must recheck every gate."""
    if role not in DEVELOPERS:
        raise TeamError("UNKNOWN_ROLE","Plan-work requires a developer role")
    path=Path(db_path)
    if (path.is_symlink() or getattr(path,"is_junction",lambda:False)()
            or not path.is_file()):
        raise TeamError("QUEUE_UNSAFE","Cannot inspect an absent or linked queue")
    try:
        with closing(sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True)) as db:
            db.row_factory=sqlite3.Row
            candidates=_developer_candidates(db,role)
            evaluated=[{
                "task_id":row["task_id"],"status":row["status"],
                "priority":row["priority"],
                "blocked_reason":(_candidate_block_reason(row) or
                                  _candidate_responsibility_block(db,row))
            } for row in candidates]
    except sqlite3.Error as exc:
        raise TeamError("QUEUE_UNAVAILABLE","Read-only queue inspection failed") from exc
    selected=next((x["task_id"] for x in evaluated
                   if x["blocked_reason"] is None),None)
    return {"role_hint_not_authenticated":role,
            "recommended_task_id":selected,
            "candidates":evaluated,
            "requires_new_lease":True,
            "authorizes_execution":False}


def acquire(role, request_id, db_path=DATABASE, *, task_id=None):
    if role not in ROLES:
        raise TeamError("UNKNOWN_ROLE","Role is not part of the five-agent team")
    _check_request(request_id)
    if task_id is not None:
        if role not in DEVELOPERS or not isinstance(task_id,str) or not TASK_ID.fullmatch(task_id):
            raise TeamError("TARGET_TASK_INVALID","Specific task selection requires a valid developer task ID")
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            previous=db.execute("SELECT * FROM acquisitions WHERE role=? AND request_id=?",
                                (role,request_id)).fetchone()
            if previous:
                if task_id is not None and previous["task_id"]!=task_id:
                    raise TeamError("REQUEST_TARGET_MISMATCH",
                                    "One idempotency request cannot target multiple tasks")
                task=db.execute("SELECT * FROM tasks WHERE task_id=?",
                                (previous["task_id"],)).fetchone() if previous["task_id"] else None
                if task and task["lease_token"]==previous["lease_token"] and task["status"]=="working" and task["lease_until"]>stamp():
                    db.execute("COMMIT")
                    payload=_row_json(task)
                    payload["responsibility"]=_responsibility_for(db,task["task_id"])
                    return {"role":role,"task":payload,"lease_token":task["lease_token"],"replayed":True}
                if task and task["review_token"]==previous["lease_token"] and task["status"]=="reviewing" and task["review_until"]>stamp():
                    db.execute("COMMIT")
                    payload=_row_json(task)
                    payload["responsibility"]=_responsibility_for(db,task["task_id"])
                    return {"role":role,"task":payload,"lease_token":task["review_token"],"replayed":True}
                if previous["task_id"] is None:
                    db.execute("COMMIT")
                    return {"role":role,"task":None,"replayed":True}
                raise TeamError("LEASE_SUPERSEDED","This request lost its lease; do not continue with old token")
            db.execute("UPDATE agents SET last_started=?,last_activity=?,sessions=sessions+1 WHERE role=?",
                       (stamp(),stamp(),role))
            if role=="architect-reviewer":
                candidates=db.execute("SELECT * FROM tasks WHERE status='review' OR "
                                      "(status='reviewing' AND review_until < ?) "
                                      "ORDER BY submitted_at,task_id LIMIT 50",(stamp(),)).fetchall()
                row=next((candidate for candidate in candidates
                          if not MergeIntent(PROJECT,STATE,candidate["task_id"]).pending()),None)
            else:
                # A stale prior task must not monopolize the role. Keep
                # ownership, lease and artifacts untouched while scanning.
                # The BEGIN IMMEDIATE transaction fences competing acquirers.
                candidates=_developer_candidates(db,role)
                if task_id is not None:
                    candidates=[r for r in candidates if r["task_id"]==task_id]
                    if not candidates:
                        raise TeamError("TARGET_NOT_READY",
                                        "Requested task is not independently ready for this role")
                row=next((r for r in candidates
                          if _candidate_block_reason(r) is None and
                          _candidate_responsibility_block(db,r) is None),None)
                if task_id is not None and row is None:
                    raise TeamError("TARGET_BLOCKED",
                                    "Requested task has stale source, spec, or pending merge intent")
            if row is None:
                db.execute("INSERT INTO acquisitions(role,request_id,task_id,lease_token,created_at) "
                           "VALUES(?,?,NULL,NULL,?)",(role,request_id,stamp()))
                db.execute("COMMIT")
                return {"role":role,"task":None,"replayed":False}
            token=uuid4().hex
            until=(utcnow()+timedelta(minutes=TTL_MINUTES)).isoformat(timespec="seconds")
            if role=="architect-reviewer":
                db.execute("UPDATE tasks SET status='reviewing',review_token=?,review_until=?,"
                           "activity_at=?,revision=revision+1 WHERE task_id=?",
                           (token,until,stamp(),row["task_id"]))
                event(db,row["task_id"],role,"review_acquire","Reviewer accepted review lease")
            else:
                folder=_snapshot(db,row,role)
                db.execute("UPDATE tasks SET owner=?,status='working',lease_token=?,lease_until=?,"
                           "activity_at=?,revision=revision+1 WHERE task_id=?",
                           (role,token,until,stamp(),row["task_id"]))
                event(db,row["task_id"],role,"acquire",folder)
            db.execute("INSERT INTO acquisitions(role,request_id,task_id,lease_token,created_at) "
                       "VALUES(?,?,?,?,?)",(role,request_id,row["task_id"],token,stamp()))
            fresh=db.execute("SELECT * FROM tasks WHERE task_id=?",(row["task_id"],)).fetchone()
            db.execute("COMMIT")
            payload=_row_json(fresh)
            payload["responsibility"]=_responsibility_for(db,fresh["task_id"])
            return {"role":role,"task":payload,"lease_token":token,"replayed":False}
        except BaseException:
            db.execute("ROLLBACK")
            raise


def _assert_lease(row, role, token, reviewer=False):
    if row is None:
        raise TeamError("UNKNOWN_TASK","Task not found")
    kind="review_token" if reviewer else "lease_token"
    expiry="review_until" if reviewer else "lease_until"
    expected="reviewing" if reviewer else "working"
    if row["status"]!=expected or row[kind]!=token or not row[expiry] or row[expiry] < stamp():
        raise TeamError("LEASE_INVALID","Lease is expired, invalid or superseded")
    if not reviewer and row["owner"]!=role:
        raise TeamError("NOT_OWNER","Task is owned by a different developer")


def heartbeat(role,task_id,token, db_path=DATABASE):
    if role not in ROLES:
        raise TeamError("UNKNOWN_ROLE","Invalid role")
    reviewer=role=="architect-reviewer"
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            _assert_lease(row,role,token,reviewer)
            until=(utcnow()+timedelta(minutes=TTL_MINUTES)).isoformat(timespec="seconds")
            field="review_until" if reviewer else "lease_until"
            db.execute(f"UPDATE tasks SET {field}=?,activity_at=? WHERE task_id=?",
                       (until,stamp(),task_id))
            db.execute("UPDATE agents SET last_activity=? WHERE role=?",(stamp(),role))
            event(db,task_id,role,"heartbeat","Lease extended")
            db.execute("COMMIT")
            return {"task_id":task_id,"role":role,"lease_until":until}
        except BaseException:
            db.execute("ROLLBACK")
            raise


def _normalize_progress(progress_json):
    if not isinstance(progress_json, str) or len(progress_json.encode("utf-8")) > 4096:
        raise TeamError("CHECKPOINT_INVALID", "Checkpoint JSON must be at most 4096 bytes")
    try:
        payload = json.loads(progress_json)
    except (ValueError, TypeError):
        raise TeamError("CHECKPOINT_INVALID", "Checkpoint must be valid JSON") from None
    allowed = {"done", "next", "tests", "blockers"}
    if not isinstance(payload, dict) or set(payload) - allowed:
        raise TeamError("CHECKPOINT_INVALID", "Unknown checkpoint fields")
    normalized = {}
    for key in ("done", "next", "tests", "blockers"):
        values = payload.get(key, [])
        if not isinstance(values, list) or len(values) > 12 or any(
            not isinstance(x, str) or not (1 <= len(x.strip()) <= 250)
            or any(ord(c) < 32 for c in x)
            for x in values
        ):
            raise TeamError("CHECKPOINT_INVALID", "Checkpoint fields must be short text arrays")
        normalized[key] = [x.strip() for x in values]
    if not normalized["done"] and not normalized["next"] and not normalized["blockers"]:
        raise TeamError("CHECKPOINT_INVALID", "Describe completed work, next step, or blocker")
    return json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def checkpoint(role, task_id, token, request_id, progress_json, db_path=DATABASE):
    """Durable idempotent progress; strict lease fencing prevents other roles writing."""
    if role not in ROLES:
        raise TeamError("UNKNOWN_ROLE", "Unknown team role")
    _check_request(request_id)
    canonical = _normalize_progress(progress_json)
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            prior = db.execute(
                "SELECT task_id,lease_token,progress_json,recorded_at "
                "FROM task_checkpoints WHERE role=? AND request_id=?",
                (role, request_id),
            ).fetchone()
            if prior is not None:
                if (prior["task_id"] != task_id or
                    prior["lease_token"] != token or
                    prior["progress_json"] != canonical):
                    raise TeamError("CHECKPOINT_CONFLICT",
                                    "Checkpoint request_id was reused with different content")
                db.execute("COMMIT")
                return {"task_id": task_id, "role": role,
                        "recorded_at": prior["recorded_at"], "replayed": True}
            row = db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            _assert_lease(row, role, token, reviewer=(role=="architect-reviewer"))
            current=stamp()
            db.execute(
                "INSERT INTO task_checkpoints(task_id,role,request_id,lease_token,progress_json,recorded_at)"
                " VALUES(?,?,?,?,?,?)",
                (task_id,role,request_id,token,canonical,current),
            )
            db.execute("UPDATE tasks SET activity_at=? WHERE task_id=?", (current,task_id))
            db.execute("UPDATE agents SET last_activity=? WHERE role=?", (current,role))
            event(db,task_id,role,"checkpoint",
                  "Saved progress; done/next/tests/blockers = "
                  + str([len(json.loads(canonical)[x])
                         for x in ("done","next","tests","blockers")]))
            db.execute("COMMIT")
            return {"task_id":task_id,"role":role,"recorded_at":current,"replayed":False}
        except BaseException:
            db.execute("ROLLBACK")
            raise


def checkpoint_file(role, task_id, token, request_id, db_path=DATABASE):
    """Persist a checkpoint from the fixed task-local JSON file.

    The MCP bridge restricts CLI arguments and may reject JSON punctuation.
    Reading one fixed filename avoids passing arbitrary JSON through run_script,
    while the existing checkpoint() enforces idempotency and the lease.
    """
    if role not in ROLES:
        raise TeamError("UNKNOWN_ROLE","Unknown team role")
    _check_request(request_id)
    with closing(connect(db_path)) as db:
        row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
        _assert_lease(row,role,token,reviewer=(role=="architect-reviewer"))
        if not row["sandbox"]:
            raise TeamError("SANDBOX_MISSING","No assigned task sandbox")
        folder=(PROJECT/row["sandbox"]).resolve()
        if not folder.is_relative_to(STATE.resolve()) or not folder.is_dir():
            raise TeamError("SANDBOX_MISSING","Task sandbox is unavailable")
    progress=folder/"agent_progress.json"
    if (progress.is_symlink() or
        (getattr(progress,"is_junction",lambda:False)()) or
        not progress.is_file() or progress.stat().st_size>4096):
        raise TeamError("CHECKPOINT_FILE_INVALID",
                        "Missing, linked or oversized sandbox progress file")
    try:
        raw=progress.read_bytes()
        progress_json=raw.decode("utf-8",errors="strict")
    except (OSError,UnicodeError):
        raise TeamError("CHECKPOINT_FILE_INVALID",
                        "Sandbox checkpoint is not valid UTF-8") from None
    # The shared checkpoint() double-checks the active lease in SQLite.
    result=checkpoint(role,task_id,token,request_id,progress_json,db_path)
    result["source"]="sandbox_progress_file"
    return result


def sync_sandbox(role,task_id,token,db_path=DATABASE):
    """Owner-fenced refresh of unchanged non-deliverable Python snapshots.

    Only source files currently matching either the recorded snapshot SHA or
    the current main SHA may be refreshed. Developer deliverables and canonical
    OpenSpec reference files are never modified. Interrupted refreshes can be
    safely re-entered only while main source hashes remain unchanged.
    """
    if role not in DEVELOPERS:
        raise TeamError("ROLE_INVALID","Only task owner may refresh its test snapshot")
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            _assert_lease(row,role,token)
            if MergeIntent(PROJECT,STATE,task_id).pending():
                raise MergeError("MERGE_PENDING","Recover interrupted integration first")
            if not row["sandbox"] or not row["baseline"]:
                raise TeamError("SANDBOX_MISSING","Task snapshot was not initialized")
            folder=(PROJECT/row["sandbox"]).resolve()
            if not folder.is_relative_to(STATE.resolve()) or not folder.is_dir():
                raise TeamError("SANDBOX_MISSING","Task sandbox is absent or unsafe")
            baseline=json.loads(row["baseline"])
            original=baseline.get("__snapshot_py__",{})
            if not isinstance(original,dict):
                raise TeamError("INVALID_BASELINE","Missing Python snapshot baseline")
            declared=set(json.loads(row["deliverables"]))
            current={}
            for path in PROJECT.glob("*.py"):
                if path.name in declared or not CODE_FILE.fullmatch(path.name):
                    continue
                if path.is_symlink() or getattr(path,"is_junction",lambda:False)():
                    raise TeamError("UNSAFE_FILE","Cannot copy link: "+path.name)
                if path.stat().st_size>MAX_BYTES:
                    # Original snapshots also omit oversized files.
                    if path.name in original:
                        raise TeamError("SOURCE_CHANGED","Snapshot file grew beyond cap")
                    continue
                current[path.name]=file_sha(path)
            target_names=set(original)|set(current)
            if len(target_names)>250:
                raise TeamError("SNAPSHOT_LIMIT","Too many Python files to refresh")
            for path in folder.glob("*.py"):
                if (path.name not in declared and path.name not in target_names):
                    raise TeamError("UNSCOPED_CHANGE",
                                    "Unknown Python file in task sandbox: "+path.name)
            changes=[]
            for name in sorted(target_names):
                path=folder/name
                old_sha=original.get(name)
                new_sha=current.get(name)
                existing=file_sha(path)
                if existing!=old_sha and existing!=new_sha:
                    raise TeamError("UNSCOPED_CHANGE",
                                    "Task modified non-deliverable file: "+name)
                if existing!=new_sha:
                    changes.append((name,path,existing,new_sha))
            # Plan is checked completely BEFORE the first overwrite. New bytes
            # are bounded and hash-checked; changing main files fail closed.
            staged={}
            for name,_,_,expected in changes:
                if expected is not None:
                    raw=(PROJECT/name).read_bytes()
                    if len(raw)>MAX_BYTES or digest(raw)!=expected:
                        raise TeamError("SOURCE_CHANGED","Main source changed: "+name)
                    staged[name]=raw
            before={}
            updated=[]
            try:
                for name,path,old_sha,new_sha in changes:
                    actual=file_sha(path)
                    if actual!=old_sha and actual!=new_sha:
                        raise TeamError("SNAPSHOT_RACE","Sandbox was modified during refresh")
                    if actual==new_sha:
                        continue
                    before[name]=path.read_bytes() if path.exists() else None
                    if new_sha is None:
                        path.unlink()
                    else:
                        with tempfile.NamedTemporaryFile(
                                prefix=".agent-snapshot-",suffix=".tmp",
                                dir=folder,delete=False) as handle:
                            temp=Path(handle.name)
                            handle.write(staged[name])
                            handle.flush()
                            os.fsync(handle.fileno())
                        try:
                            os.replace(temp,path)
                        finally:
                            temp.unlink(missing_ok=True)
                    updated.append(name)
                for name,wanted in current.items():
                    if file_sha(PROJECT/name)!=wanted:
                        raise TeamError("SOURCE_CHANGED","Main changed during refresh")
                for name in original:
                    if name not in current and (PROJECT/name).exists():
                        raise TeamError("SOURCE_CHANGED","Removed source was restored concurrently")
                fixture_added = _restore_host_fixture_if_missing(folder)
                fixture_dir = folder / "host_snapshot"
                baseline["__snapshot_host_fixture__"] = (
                    {name: file_sha(fixture_dir / name) for name in HOST_FIXTURE_FILES}
                    if fixture_dir.is_dir() else {})
                baseline["__snapshot_py__"]=current
                db.execute("UPDATE tasks SET baseline=?,activity_at=?,revision=revision+1 "
                           "WHERE task_id=?",
                           (json.dumps(baseline,sort_keys=True),stamp(),task_id))
                db.execute("UPDATE agents SET last_activity=? WHERE role=?",(stamp(),role))
                event(db,task_id,role,"sync_sandbox",
                      "Refreshed "+str(len(updated))+" unchanged non-deliverable Python snapshots")
                db.execute("COMMIT")
                return {"task_id":task_id,"sandbox":row["sandbox"],
                        "refreshed":updated,"tracked":len(current),
                        "host_fixture_added":fixture_added,
                        "deliverables_preserved":sorted(declared)}
            except BaseException:
                # Best-effort in-process rollback. A forced OS crash can leave a
                # mixture of old/new hashes, which this command can re-enter
                # without overwriting a third-party edit, provided main is stable.
                for name in reversed(updated):
                    path=folder/name
                    previous=before[name]
                    try:
                        if previous is None:
                            path.unlink(missing_ok=True)
                        else:
                            with tempfile.NamedTemporaryFile(
                                prefix=".agent-rollback-",suffix=".tmp",
                                dir=folder,delete=False) as handle:
                                temp=Path(handle.name)
                                handle.write(previous)
                                handle.flush()
                                os.fsync(handle.fileno())
                            os.replace(temp,path)
                    finally:
                        if "temp" in locals():
                            temp.unlink(missing_ok=True)
                raise
        except BaseException:
            db.execute("ROLLBACK")
            raise


def _candidate_files(row):
    folder=(PROJECT/row["sandbox"]).resolve()
    if not folder.is_relative_to(STATE.resolve()) or not folder.is_dir():
        raise TeamError("SANDBOX_MISSING","Task sandbox is missing")
    result=[]
    baseline=json.loads(row["baseline"])
    spec_rel=row["spec_ref"].partition(" / ")[0]
    if file_sha(PROJECT/spec_rel) != baseline.get("__spec_sha__"):
        raise TeamError("SPEC_CHANGED","Canonical OpenSpec changed after task acquisition; reread and rebaseline")
    declared=set(json.loads(row["deliverables"]))
    safe_original=baseline.get("__snapshot_py__", {})
    fixture_hashes=baseline.get("__snapshot_host_fixture__", {})
    if not isinstance(fixture_hashes,dict) or set(fixture_hashes)-set(HOST_FIXTURE_FILES):
        raise TeamError("INVALID_BASELINE","Invalid host snapshot manifest")
    for name,wanted in fixture_hashes.items():
        if (not isinstance(wanted,str) or file_sha(folder/"host_snapshot"/name)!=wanted
                or file_sha(PROJECT/"host_snapshot"/name)!=wanted):
            raise TeamError("HOST_FIXTURE_CHANGED",
                            "Host fixture differs from verified baseline")
    for path in folder.glob("*.py"):
        if path.name not in declared and path.name not in safe_original:
            raise TeamError("UNSCOPED_CHANGE","Unapproved Python file in sandbox: "+path.name)
    for name,wanted in safe_original.items():
        if file_sha(folder/name)!=wanted:
            raise TeamError("UNSCOPED_CHANGE","Sandbox changed a non-deliverable file: "+name)
    for name in declared:
        if not CODE_FILE.fullmatch(name):
            raise TeamError("UNSAFE_OUTPUT","Unapproved output path")
        path=folder/name
        if path.is_symlink() or not path.is_file() or path.stat().st_size>MAX_BYTES:
            raise TeamError("OUTPUT_MISSING","Required output is missing or unsafe: "+name)
        source_sha=file_sha(PROJECT/name)
        if source_sha != baseline[name]:
            raise TeamError("CONFLICT","Main project changed since task acquired: "+name)
        result.append((name,path))
    return folder,result


def submit(role,task_id,token,note,db_path=DATABASE):
    if role not in DEVELOPERS:
        raise TeamError("ROLE_INVALID","Only a coding agent may submit")
    if len(note.strip())<30:
        raise TeamError("EVIDENCE_MISSING","Provide at least 30 chars of test evidence and implementation notes")
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            _assert_lease(row,role,token)
            _, files=_candidate_files(row)
            contract=_responsibility_for(db,task_id)
            if contract is not None and (contract["reuse_decision"] not in note or
                                         contract["module"] not in note):
                raise TeamError("REUSE_EVIDENCE_REQUIRED",
                                "Explain canonical module and approved reuse disposition before submit")
            db.execute("UPDATE tasks SET status='review',review_notes=?,submitted_at=?,activity_at=?,"
                       "lease_token=NULL,lease_until=NULL,revision=revision+1 WHERE task_id=?",
                       (note[:4000],stamp(),stamp(),task_id))
            db.execute("UPDATE agents SET last_activity=? WHERE role=?",(stamp(),role))
            event(db,task_id,role,"submit",json.dumps([name for name,_ in files]))
            db.execute("COMMIT")
            return {"task_id":task_id,"status":"review","files":[name for name,_ in files]}
        except BaseException:
            db.execute("ROLLBACK")
            raise


def _review_code_reuse(files):
    """No unreviewed substantial cross-module code clones may be published.

    Executed from both read-only review-preview and the actual merge path,
    so a caller cannot bypass the veto by skipping a preview.
    """
    candidates={name:path for name,path in files if not name.startswith("test_")}
    if not candidates:
        return {"decision":"PASS","hard_blockers":[],"review_findings":[],
                "no_production_deliverables":True}
    try:
        return audit_code_reuse(PROJECT,candidates)
    except (ReuseGuardError,OSError,MemoryError,RecursionError) as exc:
        raise TeamError("REUSE_GUARD_ERROR",str(exc)[:160]) from exc


def review_preview(task_id, db_path=DATABASE):
    """Read-only reviewer evidence; never executes sandbox code or accepts a task.

    The report checks the canonical specification SHA, the exact task output
    allowlist and whether sandbox Python sources parse. Passing this inspection
    is NOT equivalent to security approval or the required runtime QA gates.
    """
    with closing(connect_readonly(db_path)) as db:
        row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
    if row is None:
        raise TeamError("UNKNOWN_TASK","Task was not found")
    journal=MergeIntent(PROJECT,STATE,task_id)
    if journal.pending():
        return {"task_id":task_id,"status":row["status"],"ready_for_review":False,
                "blockers":["MERGE_PENDING"],"merge":journal.inspect()}
    if row["status"] not in ("review","reviewing","done"):
        return {"task_id":task_id,"status":row["status"],"ready_for_review":False,
                "blockers":["NOT_SUBMITTED"],"owner":row["owner"]}
    if not row["sandbox"] or not row["baseline"]:
        raise TeamError("SANDBOX_MISSING","No task snapshot exists")
    folder=(PROJECT/row["sandbox"]).resolve()
    if not folder.is_relative_to(STATE.resolve()) or not folder.is_dir():
        raise TeamError("SANDBOX_MISSING","Sandbox directory is missing or unsafe")
    spec_rel=row["spec_ref"].partition(" / ")[0]
    baselines=json.loads(row["baseline"])
    spec_matches=file_sha(PROJECT/spec_rel)==baselines.get("__spec_sha__")
    changes=[]
    blockers=[]
    deliverables=json.loads(row["deliverables"])
    if not spec_matches:
        blockers.append("SPEC_CHANGED")
    extra={x.name for x in folder.glob("*.py") if x.name not in deliverables
           and x.name not in baselines.get("__snapshot_py__",{})}
    if extra:
        blockers.append("UNSCOPED_CHANGE")
    for name,wanted in baselines.get("__snapshot_py__",{}).items():
        if file_sha(folder/name)!=wanted:
            blockers.append("UNSCOPED_CHANGE")
            break
    for name in deliverables:
        if not CODE_FILE.fullmatch(name):
            raise TeamError("INVALID_OUTPUT","Output is outside allowlist")
        source=folder/name
        base_hash=baselines.get(name)
        current_hash=file_sha(PROJECT/name)
        candidate_hash=file_sha(source)
        syntax="missing"
        line_count=None
        if candidate_hash is not None:
            try:
                source_text=source.read_text(encoding="utf-8",errors="strict")
                line_count=len(source_text.splitlines())
                try:
                    ast.parse(source_text,filename=name)
                    syntax="valid"
                except (SyntaxError,ValueError,RecursionError):
                    syntax="invalid"
            except UnicodeError:
                syntax="invalid_encoding"
        if current_hash!=base_hash and row["status"]!="done":
            blockers.append("BASELINE_CONFLICT")
        if syntax!="valid":
            blockers.append("ENCODING_INVALID" if syntax=="invalid_encoding"
                            else "SYNTAX_INVALID")
        changes.append({"file":name,"baseline_sha256":base_hash,
                        "candidate_sha256":candidate_hash,
                        "main_sha256":current_hash,
                        "lines":line_count,
                        "python_syntax":syntax,
                        "changed_from_baseline":candidate_hash!=base_hash})
    if not any(x["file"].startswith("test_") for x in changes):
        blockers.append("TEST_DELIVERABLE_MISSING")
    try:
        reuse=_review_code_reuse([
            (name,folder/name) for name in deliverables
            if not name.startswith("test_") and (folder/name).is_file()
        ])
        if reuse["hard_blockers"]:
            blockers.append("DUPLICATE_IMPLEMENTATION")
    except TeamError as exc:
        blockers.append(exc.code)
        reuse={"decision":"ERROR","error":exc.code}
    try:
        with closing(connect_readonly(db_path)) as gate_db:
            architecture=_review_responsibility(
                gate_db,row,[(name,folder/name) for name in deliverables
                             if (folder/name).is_file()])
    except TeamError as exc:
        blockers.append(exc.code)
        architecture={"decision":"BLOCK","error":exc.code}
    return {"task_id":task_id,"status":row["status"],"owner":row["owner"],
            "submitted_at_utc":row["submitted_at"],"last_activity_utc":row["activity_at"],
            "review_notes":row["review_notes"],"spec_ref":row["spec_ref"],
            "canonical_spec_sha256":file_sha(PROJECT/spec_rel),
            "spec_matches_task_snapshot":spec_matches,
            "deliverables":changes,"blockers":sorted(set(blockers)),
            "reuse_guard":reuse,"architecture_guard":architecture,
            "ready_for_review":row["status"] in ("review","reviewing") and not blockers,
            "already_accepted":row["status"]=="done",
            "note":"Read-only inventory and syntax check, not an authenticated review or test execution"}


def _check_quality(folder):
    # Tests run against the sandbox only, never against shared source.
    openspec=shutil.which("openspec")
    if not openspec:
        raise TeamError("OPENSPEC_MISSING","Strict OpenSpec CLI is required for review acceptance")
    actions=[([sys.executable,"-m","unittest","discover"],60),
             ([sys.executable,"spec_check.py"],15),
             ([openspec,"validate","local-pc-agent-tooling","--strict"],35)]
    outputs=[]
    for argv,timeout in actions:
        try:
            p=subprocess.run(argv,cwd=folder,capture_output=True,text=True,encoding="utf-8",
                             errors="replace",timeout=timeout,stdin=subprocess.DEVNULL)
        except subprocess.TimeoutExpired:
            raise TeamError("TEST_TIMEOUT","Sandbox QA exceeded timeout")
        outputs.append({"command":" ".join(argv[1:]),"exit_code":p.returncode,
                        "stdout_tail":p.stdout[-1200:],"stderr_tail":p.stderr[-1200:]})
        if p.returncode!=0:
            # Do not copy arbitrary unittest output, tracebacks, file paths,
            # prompts or credentials into shared coordinator error responses.
            # Only safe test method identifiers and bounded summary counts.
            cases=re.findall(r"(?m)^(?:FAIL|ERROR): (test_[A-Za-z0-9_]+) \(",p.stderr)
            outcomes=re.findall(r"(?m)^FAILED \((?:failures|errors|skipped)=[0-9]+(?:, (?:failures|errors|skipped)=[0-9]+)*\)$",p.stderr)
            safe="; cases="+",".join(cases[:5]) if cases else ""
            safe+="; "+outcomes[-1] if outcomes else ""
            raise TeamError("TEST_FAILED","Sandbox quality gate failed: "
                            +" ".join(argv[1:])+"; exit_code="+str(p.returncode)+safe)
    return outputs


def review(role,task_id,token,decision,notes,db_path=DATABASE):
    if role!="architect-reviewer":
        raise TeamError("ROLE_INVALID","Only architect-reviewer may review")
    if decision not in ("accept","reject") or len(notes.strip())<25:
        raise TeamError("INVALID_REVIEW","Decision and concrete review notes required")
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            _assert_lease(row,role,token,True)
            if MergeIntent(PROJECT,STATE,task_id).pending():
                raise MergeError("MERGE_PENDING",
                                 "Unresolved merge journal requires owner recovery first")
            if decision=="reject":
                db.execute("UPDATE tasks SET status='rework',review_notes=?,review_token=NULL,"
                           "review_until=NULL,activity_at=?,reviewed_at=?,revision=revision+1 WHERE task_id=?",
                           (notes[:4000],stamp(),stamp(),task_id))
                event(db,task_id,role,"reject",notes[:1200])
                db.execute("COMMIT")
                return {"task_id":task_id,"status":"rework","notes":notes}
            if MergeIntent(PROJECT,STATE,task_id).pending():
                raise MergeError("MERGE_PENDING",
                                 "Unresolved merge intent: use merge-status and owner recovery")
            folder,changes=_candidate_files(row)
            candidate_sha_before={name:file_sha(path) for name,path in changes}
            reuse=_review_code_reuse(changes)
            if reuse["hard_blockers"]:
                first=reuse["hard_blockers"][0]
                raise TeamError("DUPLICATE_IMPLEMENTATION",
                    "Cross-module duplicate: "+first["candidate"]["file"]+":"+
                    first["candidate"]["symbol"]+" repeats "+
                    first["existing"]["file"]+":"+first["existing"]["symbol"])
            _review_responsibility(db,row,changes)
            checks=_check_quality(folder)
            # The tests, import analysis and structural clone scan must describe
            # the exact bytes promoted to main. Reject any sandbox race/drift.
            for name,path in changes:
                if file_sha(path)!=candidate_sha_before[name]:
                    raise TeamError("CANDIDATE_CHANGED_AFTER_QA",
                                    "Sandbox deliverable changed after independent checks: "+name)
            # Recheck hashes directly before writing shared files.
            for name,_ in changes:
                if file_sha(PROJECT/name)!=json.loads(row["baseline"])[name]:
                    raise TeamError("CONFLICT","Main file changed since snapshot: "+name)
            # Persist intent and backup bytes BEFORE modifying any shared files.
            # A crash leaves a durable intent and blocks future reviewer merges.
            intent=MergeIntent(PROJECT,STATE,task_id)
            prepared=False
            try:
                intent_doc=intent.prepare(changes,json.loads(row["baseline"]),row["revision"])
                prepared=True
                intent.apply()
            except Exception:
                if prepared:
                    try:
                        intent.rollback()
                        intent.cleanup()
                    except (MergeError,OSError):
                        # Never hide an ambiguous partial integration: preserve intent.
                        pass
                raise
            db.execute("UPDATE tasks SET status='done',review_notes=?,review_token=NULL,"
                       "review_until=NULL,activity_at=?,reviewed_at=?,revision=revision+1 WHERE task_id=?",
                       (notes[:4000],stamp(),stamp(),task_id))
            db.execute("UPDATE agents SET last_activity=? WHERE role=?",(stamp(),role))
            # Persist complete, bounded acceptance metadata in the SAME SQLite
            # commit as status=done. Never truncate the machine-readable QA
            # evidence to the 1600-character human event-detail limit.
            qa_evidence=[{"command":c.get("command","unspecified_mock"),"exit_code":c.get("exit_code",1),
                          "stdout_sha256":digest(c.get("stdout_tail","").encode("utf-8")),
                          "stderr_sha256":digest(c.get("stderr_tail","").encode("utf-8"))}
                         for c in checks]
            artifact_evidence=[{"file":e["name"],"sha256":e["after_sha"]}
                               for e in intent_doc["entries"]]
            recorded_at=stamp()
            qa_json=json.dumps(qa_evidence,sort_keys=True)
            artifact_json=json.dumps(artifact_evidence,sort_keys=True)
            spec_sha=json.loads(row["baseline"]).get("__spec_sha__")
            db.execute("INSERT INTO acceptance_records"
                       "(task_id,reviewer_role,recorded_at,qa_json,artifacts_json,spec_sha256)"
                       " VALUES(?,?,?,?,?,?)",
                       (task_id,role,recorded_at,qa_json,artifact_json,spec_sha))
            evidence_hash=digest((qa_json+artifact_json+(spec_sha or "")).encode("utf-8"))
            event(db,task_id,role,"accept",json.dumps({
                "files":[name for name,_ in changes],
                "qa_exit_codes":[c["exit_code"] for c in checks],
                "acceptance_evidence_sha256":evidence_hash
            },sort_keys=True))
            db.execute("COMMIT")
            try:
                intent.cleanup()
            except (MergeError,OSError):
                # SQLite commit already succeeded; retained intent is recoverable.
                pass
            return {"task_id":task_id,"status":"done","merged":[name for name,_ in changes],
                    "quality":checks}
        except BaseException:
            db.execute("ROLLBACK")
            raise


def merge_status(task_id, db_path=DATABASE):
    """Read-only inspection of an unfinished reviewer integration journal."""
    with closing(connect(db_path)) as db:
        row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
    if row is None:
        raise TeamError("UNKNOWN_TASK","Task not found")
    intent=MergeIntent(PROJECT,STATE,task_id)
    return {"task_id":task_id,"task_state":row["status"],
            "review_lease_until":row["review_until"],
            "intent":intent.inspect() if intent.pending() else None}


def recover_merge(task_id, stdin=None, stdout=None, db_path=DATABASE):
    """Local interactive owner audit of a pending merge; NEVER automatic.

    Does not authorize publishing new code. When DB did not commit, it reverts
    only exact recorded post-hashes; divergent user edits fail closed.
    """
    inp=sys.stdin if stdin is None else stdin
    out=sys.stdout if stdout is None else stdout
    if not getattr(inp,"isatty",lambda:False)() or not getattr(out,"isatty",lambda:False)():
        raise TeamError("INTERACTIVE_REQUIRED","Use a real foreground local terminal")
    intent=MergeIntent(PROJECT,STATE,task_id)
    if not intent.pending():
        raise TeamError("NO_MERGE_PENDING","No pending merge intent")
    with closing(connect(db_path)) as db:
        row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
        if row is None:
            raise TeamError("UNKNOWN_TASK","Task not found")
        if (row["status"]=="reviewing" and row["review_until"] and
            row["review_until"]>stamp()):
            raise TeamError("ACTIVE_LEASE","Reviewer may still be merging; retry after lease expires")
        before=intent.inspect()
        if before["diverged"]:
            raise TeamError("MERGE_DIVERGED","Files changed independently; do not overwrite")
        committed=row["status"]=="done"
        if committed and any(x["state"] not in ("applied","unchanged") for x in before["files"].values()):
            raise TeamError("MERGE_DIVERGED","Ledger says done but files do not match")
        action="ACK" if committed else "RESTORE"
        out.write("\nREVIEW MERGE RECOVERY (project source hashes only)\n")
        out.write("Project: "+str(PROJECT)+"\nTask: "+task_id+"\n")
        out.write("Ledger: "+row["status"]+"\nFiles: "+json.dumps(
            {n:x["state"] for n,x in before["files"].items()},sort_keys=True)+"\n")
        out.write("Type exactly "+action+" "+task_id+" to confirm: ")
        out.flush()
        if inp.readline().strip()!=action+" "+task_id:
            raise TeamError("RECOVERY_DECLINED","Owner declined recovery")
        db.execute("BEGIN IMMEDIATE")
        try:
            fresh=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            if fresh["status"]!=row["status"] or fresh["revision"]!=row["revision"]:
                raise TeamError("MERGE_RACE","Ledger changed during recovery")
            if (fresh["status"]=="reviewing" and fresh["review_until"] and
                fresh["review_until"]>stamp()):
                raise TeamError("ACTIVE_LEASE","Another review lease is active")
            after=intent.inspect()
            if after!=before or after["diverged"]:
                raise TeamError("MERGE_RACE","Files changed during owner review")
            if not committed:
                intent.rollback()
                db.execute("UPDATE tasks SET status='review',review_token=NULL,review_until=NULL,"
                           "activity_at=?,revision=revision+1 WHERE task_id=?",
                           (stamp(),task_id))
                event(db,task_id,"architect-reviewer","owner_restore",
                      "Owner authorized exact-hash merge rollback")
            else:
                event(db,task_id,"architect-reviewer","owner_ack",
                      "Owner acknowledged committed merge leftovers")
            db.execute("COMMIT")
        except BaseException:
            db.execute("ROLLBACK")
            raise
    try:
        intent.cleanup()
    except (MergeError,OSError):
        pass  # Leave evidence if cleanup was interrupted.
    return {"task_id":task_id,"restored":not committed,"acknowledged":committed,
            "status":"review" if not committed else "done"}


def rebase_spec(task_id, notes, db_path=DATABASE):
    """Reviewer-controlled refresh of a paused task's reference docs only.

    Never overwrite developer deliverables, and never alter a live lease.
    A spec amendment otherwise invalidates old requirements for submission.
    """
    if not isinstance(notes,str) or len(notes.strip())<25:
        raise TeamError("NOTES_REQUIRED","Explain the specification amendment before rebasing")
    with closing(connect(db_path)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            row=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            if not row or not row["sandbox"] or not row["baseline"]:
                raise TeamError("UNKNOWN_TASK","Only initialized tasks can be rebased")
            if MergeIntent(PROJECT,STATE,task_id).pending():
                raise MergeError("MERGE_PENDING","Recover the interrupted merge before rebasing")
            if row["status"]=="done":
                raise TeamError("TASK_DONE","Accepted tasks cannot be silently reopened")
            if ((row["status"]=="working" and row["lease_until"] and row["lease_until"]>stamp()) or
                (row["status"]=="reviewing" and row["review_until"] and row["review_until"]>stamp())):
                raise TeamError("ACTIVE_LEASE","Do not rebase files while an agent is working")
            folder=(PROJECT/row["sandbox"]).resolve()
            if not folder.is_relative_to(STATE.resolve()) or not folder.is_dir():
                raise TeamError("SANDBOX_MISSING","Task workspace is unavailable")
            canonical=row["spec_ref"].partition(" / ")[0]
            source=(PROJECT/canonical).resolve()
            target=(folder/canonical).resolve()
            if not source.is_relative_to(PROJECT) or not target.is_relative_to(folder):
                raise TeamError("UNSAFE_SPEC","Spec path escapes approved project")
            base=json.loads(row["baseline"])
            old_spec_hash=base.get("__spec_sha__")
            if file_sha(target)!=old_spec_hash:
                raise TeamError("SANDBOX_SPEC_EDITED","Agent modified reference specification; review manually")
            # Developer deliverables are left untouched; only reference docs change.
            for dirname in ALLOWED_COPY_DIRS:
                src=PROJECT/dirname
                dst=folder/dirname
                if src.is_dir():
                    shutil.copytree(src,dst,dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__",".git",".venv","*.sqlite3","*.pyc"))
            base["__spec_sha__"]=file_sha(source)
            db.execute("UPDATE tasks SET baseline=?,status='rework',review_notes=?,"
                       "lease_token=NULL,lease_until=NULL,review_token=NULL,review_until=NULL,"
                       "activity_at=?,revision=revision+1 WHERE task_id=?",
                       (json.dumps(base,sort_keys=True),notes[:4000],stamp(),task_id))
            event(db,task_id,"architect-reviewer","rebase_spec",notes[:1300])
            db.execute("COMMIT")
            return {"task_id":task_id,"status":"rework","spec_sha256":base["__spec_sha__"],
                    "sandbox":row["sandbox"]}
        except BaseException:
            db.execute("ROLLBACK")
            raise


def history(task_id,db_path=DATABASE):
    with closing(connect(db_path)) as db:
        task=db.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
        if not task:
            raise TeamError("UNKNOWN_TASK","Task not found")
        logs=db.execute("SELECT role,action,detail,at FROM events WHERE task_id=? "
                        "ORDER BY id DESC LIMIT 80",(task_id,)).fetchall()
        checkpoints=db.execute("SELECT role,progress_json,recorded_at FROM task_checkpoints "
                               "WHERE task_id=? ORDER BY id DESC LIMIT 20",(task_id,)).fetchall()
    return {"task":_row_json(task),"history":[dict(x) for x in logs],
            "checkpoints":[{"role":c["role"],"recorded_at":c["recorded_at"],
                            "progress":json.loads(c["progress_json"])} for c in checkpoints]}


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="command",required=True)
    s=sub.add_parser("init");s.add_argument("--seed")
    s=sub.add_parser("status");s.add_argument("--role",choices=ROLES)
    sub.add_parser("overview")
    s=sub.add_parser("acquire");s.add_argument("role",choices=ROLES);s.add_argument("request_id");s.add_argument("--task",dest="task_id",help="Select an independent ready Pxxx task under a new lease")
    s=sub.add_parser("plan-work");s.add_argument("role",choices=DEVELOPERS)
    s=sub.add_parser("heartbeat");s.add_argument("role",choices=ROLES);s.add_argument("task_id");s.add_argument("lease_token")
    s=sub.add_parser("checkpoint");s.add_argument("role",choices=ROLES);s.add_argument("task_id");s.add_argument("lease_token");s.add_argument("request_id");s.add_argument("progress_json")
    s=sub.add_parser("checkpoint-file");s.add_argument("role",choices=ROLES);s.add_argument("task_id");s.add_argument("lease_token");s.add_argument("request_id")
    s=sub.add_parser("usage-import");s.add_argument("role",choices=ROLES);s.add_argument("task_id");s.add_argument("lease_token")
    s=sub.add_parser("usage-report");s.add_argument("--role",choices=ROLES);s.add_argument("--task-id")
    sub.add_parser("usage-export")
    s=sub.add_parser("sync-sandbox");s.add_argument("role",choices=DEVELOPERS);s.add_argument("task_id");s.add_argument("lease_token")
    s=sub.add_parser("submit");s.add_argument("role",choices=DEVELOPERS);s.add_argument("task_id");s.add_argument("lease_token");s.add_argument("notes")
    s=sub.add_parser("review");s.add_argument("task_id");s.add_argument("lease_token");s.add_argument("decision",choices=["accept","reject"]);s.add_argument("notes")
    s=sub.add_parser("review-preview");s.add_argument("task_id")
    s=sub.add_parser("history");s.add_argument("task_id")
    s=sub.add_parser("rebase-spec");s.add_argument("task_id");s.add_argument("notes")
    s=sub.add_parser("merge-status");s.add_argument("task_id")
    s=sub.add_parser("new-request");s.add_argument("role",choices=ROLES)
    sub.add_parser("gate-check")
    return p


def main(args=None):
    try:
        a=parser().parse_args(args)
        if a.command=="init":result=seed(a.seed)
        elif a.command=="status":result=status(role=a.role)
        elif a.command=="overview":result=overview()
        elif a.command=="acquire":result=acquire(a.role,a.request_id,task_id=a.task_id)
        elif a.command=="plan-work":result=plan_work(a.role)
        elif a.command=="heartbeat":result=heartbeat(a.role,a.task_id,a.lease_token)
        elif a.command=="checkpoint":result=checkpoint(a.role,a.task_id,a.lease_token,a.request_id,a.progress_json)
        elif a.command=="checkpoint-file":result=checkpoint_file(a.role,a.task_id,a.lease_token,a.request_id)
        elif a.command=="usage-import":
            from agent_token_usage import import_usage_file
            result=import_usage_file(sys.modules[__name__],a.role,a.task_id,a.lease_token)
        elif a.command=="usage-report":
            from agent_token_usage import token_report
            result=token_report(sys.modules[__name__],role=a.role,task_id=a.task_id)
        elif a.command=="usage-export":
            from token_usage_export import export_reports
            result=export_reports(sys.modules[__name__])
        elif a.command=="sync-sandbox":result=sync_sandbox(a.role,a.task_id,a.lease_token)
        elif a.command=="submit":result=submit(a.role,a.task_id,a.lease_token,a.notes)
        elif a.command=="review":result=review("architect-reviewer",a.task_id,a.lease_token,a.decision,a.notes)
        elif a.command=="review-preview":result=review_preview(a.task_id)
        elif a.command=="history":result=history(a.task_id)
        elif a.command=="rebase-spec":result=rebase_spec(a.task_id,a.notes)
        elif a.command=="merge-status":result=merge_status(a.task_id)
        elif a.command=="gate-check":result={"project":PROJECT.name,"checks":_check_quality(PROJECT)}
        else:result={"request_id":uuid4().hex,"role":a.role}
        reply={"ok":True,"data":result};returncode=0
    except (TeamError,MergeError,UsageError) as e:
        reply={"ok":False,"error":{"code":e.code,"message":str(e)}};returncode=1
    except Exception as e:
        reply={"ok":False,"error":{"code":"INTERNAL_ERROR","message":str(e)[:250]}};returncode=2
    print(json.dumps(reply,ensure_ascii=True))
    return returncode


if __name__=="__main__":
    sys.exit(main())
