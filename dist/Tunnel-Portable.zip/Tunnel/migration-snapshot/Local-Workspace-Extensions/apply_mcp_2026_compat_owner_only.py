"""Owner-operated, fail-closed deployment for legacy 28-tool MCP HTTP compatibility.
Run ONLY from the owner's local terminal after stopping Local MCP and tunnel.
This script is not invoked through MCP and never modifies an active listener.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import socket
import tempfile
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT=Path(__file__).resolve().parent
CANDIDATE=ROOT/"host_patches"/"http_server_2026_discovery_legacy28_candidate_v3.py"
EXPECTED_OLD="00c663880d581a3aeb47d7028c443ef603f33b517b4ffdb4d84c4c51e1dd1491"
EXPECTED_NEW="8a81907ff4d0aaf25bdc061949f6c365ef5afeb406865c67086eef51a2d61585"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def listener_running(port=8765):
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
        sock.settimeout(0.35)
        return sock.connect_ex(("127.0.0.1",port))==0


def plan(target):
    supplied=Path(target)
    if supplied.is_symlink() or getattr(supplied,"is_junction",lambda:False)():
        raise RuntimeError("REFUSE_TARGET_LINK")
    p=supplied.resolve(strict=True)
    if p.name!="http_server.py" or p.parent.name!="workspace_mcp":
        raise RuntimeError("REFUSE_WRONG_TARGET: expected workspace_mcp/http_server.py")
    current=sha(p)
    if current==EXPECTED_NEW:
        return p,"ALREADY_UPDATED"
    if current!=EXPECTED_OLD:
        raise RuntimeError("REFUSE_SHA_MISMATCH: active host does not match audited 28-tool snapshot")
    if not CANDIDATE.is_file() or sha(CANDIDATE)!=EXPECTED_NEW:
        raise RuntimeError("REFUSE_CANDIDATE_SHA_MISMATCH")
    return p,"READY"


def apply(target):
    p,state=plan(target)
    if state=="ALREADY_UPDATED":
        return {"status":state,"sha256":EXPECTED_NEW}
    if listener_running():
        raise RuntimeError("REFUSE_ACTIVE_LISTENER: stop MCP and tunnel in owner's terminal first")
    backup=p.with_name("http_server.py.pre2026-"+EXPECTED_OLD[:12]+".bak")
    if backup.exists():
        raise RuntimeError("REFUSE_BACKUP_EXISTS: inspect prior deployment")
    shutil.copy2(p,backup)
    if sha(backup)!=EXPECTED_OLD:
        raise RuntimeError("BACKUP_VERIFICATION_FAILED")
    temp=None
    try:
        with tempfile.NamedTemporaryFile(mode="wb",prefix=".mcp-compat-",
                                         suffix=".py",dir=str(p.parent),delete=False) as h:
            temp=Path(h.name)
            h.write(CANDIDATE.read_bytes())
        shutil.copymode(backup,temp)
        if sha(temp)!=EXPECTED_NEW:
            raise RuntimeError("STAGED_SHA_MISMATCH")
        if listener_running():
            raise RuntimeError("REFUSE_LISTENER_RESTARTED")
        os.replace(temp,p)
        temp=None
        if sha(p)!=EXPECTED_NEW:
            raise RuntimeError("TARGET_VERIFICATION_FAILED")
        return {"status":"UPDATED_OFFLINE","sha256":EXPECTED_NEW,"backup":str(backup)}
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


def locate_default_target(home=None):
    """Owner-terminal preflight: check one fixed installation path, no recursion.

    This intentionally does not discover arbitrary Python files, inspect
    process command lines, or read configuration/secret files.
    """
    base=Path.home() if home is None else Path(home)
    downloads=base/"Downloads"
    root=downloads/"local-workspace-mcp"
    package=root/"workspace_mcp"
    target=package/"http_server.py"
    if any(p.is_symlink() or getattr(p,"is_junction",lambda:False)()
           for p in (downloads,root,package,target)):
        return {"state":"REFUSE_LINKED_PATH","live_mutated":False}
    if not target.is_file():
        return {"state":"NOT_FOUND","suggested_target":str(target),
                "live_mutated":False}
    try:
        _,state=plan(target)
    except (RuntimeError,OSError) as exc:
        reason=str(exc)
        if "SHA_MISMATCH" in reason:
            return {"state":"UNRECOGNIZED_SHA","suggested_target":str(target),
                    "live_mutated":False}
        return {"state":"REFUSED","reason":reason[:100],"live_mutated":False}
    return {"state":state,"suggested_target":str(target),
            "listener_running":listener_running(),"live_mutated":False}


def check_live_discovery(port=8765):
    """Safe read-only probe: no bearer, secrets, tool calls, or local writes."""
    msg={"jsonrpc":"2.0","id":"compat-probe",
         "method":"server/discover",
         "params":{"_meta":{
             "io.modelcontextprotocol/protocolVersion":"2026-07-28",
             "io.modelcontextprotocol/clientCapabilities":{},
             "io.modelcontextprotocol/clientInfo":{
                 "name":"local-compat-check","version":"1.0.0"}}}}
    request=Request(f"http://127.0.0.1:{port}/mcp",
                    data=json.dumps(msg).encode("utf-8"),method="POST",
                    headers={"Content-Type":"application/json",
                             "Accept":"application/json, text/event-stream",
                             "Mcp-Protocol-Version":"2026-07-28",
                             "Mcp-Method":"server/discover"})
    try:
        with urlopen(request,timeout=5) as response:
            code=response.status
            payload=json.loads(response.read(65536))
    except HTTPError as exc:
        code=exc.code
        try:
            payload=json.loads(exc.read(65536))
        except (ValueError,UnicodeError):
            payload={}
    except (URLError,TimeoutError,OSError,ValueError,UnicodeError) as exc:
        return {"state":"UNREACHABLE_OR_UNVERIFIED",
                "error_type":type(exc).__name__,
                "live_mutated":False}
    if not isinstance(payload,dict):payload={}
    result=payload.get("result") if isinstance(payload.get("result"),dict) else {}
    supported=result.get("supportedVersions") if isinstance(result.get("supportedVersions"),list) else []
    success=(code==200 and result.get("resultType")=="complete"
             and "2026-07-28" in supported)
    return {"state":("MODERN_DISCOVERY_READY" if success else
                     "AUTH_REQUIRED" if code==401 else
                     "LEGACY_OR_INCOMPATIBLE" if code==400 else "UNVERIFIED"),
            "http_status":code,"supports_2026_07_28":"2026-07-28" in supported,
            "live_mutated":False}


if __name__=="__main__":
    ap=argparse.ArgumentParser(description="Deploy tested MCP 2026 compatibility only after offline owner cutover.")
    ap.add_argument("--target",help="Exact local path to active workspace_mcp/http_server.py")
    ap.add_argument("--apply",action="store_true",help="Actually replace file after SHA and listener checks")
    ap.add_argument("--check-live",action="store_true",help="Read-only 2026 server/discover probe on localhost")
    ap.add_argument("--locate",action="store_true",help="Read-only default installation path and SHA check (owner terminal only)")
    args=ap.parse_args()
    if args.locate:
        if args.check_live or args.apply or args.target:
            ap.error("--locate cannot be combined with --target, --apply, or --check-live")
        print(locate_default_target())
    elif args.check_live:
        if args.apply or args.target:ap.error("--check-live cannot be combined with --target or --apply")
        print(check_live_discovery())
    else:
        if not args.target:ap.error("--target is required unless --check-live is used")
        if args.apply:print(apply(args.target))
        else:print({"target":str(plan(args.target)[0]),"state":plan(args.target)[1],
                    "running_listener":listener_running(),"live_mutated":False})
