"""Source import graph regression for declared ownership boundaries."""
from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from import_graph_guard import SourceAuditError, audit_source_imports
from contract_guard import inspect_file


def definition(name, dependencies=()):
    return {"id": name.replace("_", "-"), "module": name, "public_api": "run",
            "spec_ref": "openspec/changes/local-pc-agent-tooling/specs/agent-orchestration/spec.md",
            "depends_on": list(dependencies),
            "inputs": "Validated request record",
            "outputs": "Immutable result object",
            "errors": "Explicit mapped error",
            "scaling": "Bounded linear budget"}


def definition_set():
    return {"schema": "agent-responsibility-contracts-v1",
            "contracts": [definition("parser"), definition("worker", ["parser"])],
            "tasks": []}


class SourceDependencyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.manifest = definition_set()
        (self.root / "parser.py").write_text("def run():\n    return 1\n", encoding="utf-8")
        (self.root / "worker.py").write_text("from parser import run\n\ndef start():\n    return run()\n", encoding="utf-8")

    def test_allowed_dependency_passes_with_real_hashes(self):
        report = audit_source_imports(self.manifest, self.root)
        self.assertEqual(report["decision"], "PASS", report)
        self.assertEqual(len(report["source_hashes"]), 2)
        self.assertFalse(report["source_executed"])

    def test_undeclared_dependency_blocked(self):
        self.manifest["contracts"][1]["depends_on"] = []
        result = audit_source_imports(self.manifest, self.root)
        self.assertEqual(result["decision"], "BLOCK")
        self.assertEqual(result["findings"][0]["code"], "UNDECLARED_SOURCE_IMPORT")

    def test_cycle_blocked_without_running_modules(self):
        (self.root / "parser.py").write_text("import worker\n\ndef run():\n    return 1\n", encoding="utf-8")
        report = audit_source_imports(self.manifest, self.root)
        self.assertIn("SOURCE_IMPORT_CYCLE", [i["code"] for i in report["findings"]])

    def test_missing_file_fails_closed(self):
        (self.root / "worker.py").unlink()
        with self.assertRaisesRegex(SourceAuditError, "SOURCE_MODULE_MISSING"):
            audit_source_imports(self.manifest, self.root)

    def test_invalid_encoding_fails_closed(self):
        (self.root / "worker.py").write_bytes(b"\xff")
        with self.assertRaisesRegex(SourceAuditError, "SOURCE_PARSE_ERROR"):
            audit_source_imports(self.manifest, self.root)

    def test_imported_source_not_executed(self):
        (self.root / "worker.py").write_text("raise RuntimeError('MUST NOT RUN')\nfrom parser import run\n",
                                            encoding="utf-8")
        self.assertEqual(audit_source_imports(self.manifest, self.root)["decision"], "PASS")

    def test_nested_relative_import(self):
        (self.root / "pkg").mkdir()
        (self.root / "pkg" / "parser.py").write_text("def run():\n    return 1\n", encoding="utf-8")
        (self.root / "pkg" / "worker.py").write_text("from .parser import run\n", encoding="utf-8")
        self.manifest["contracts"][0]["module"] = "pkg.parser"
        self.manifest["contracts"][1]["module"] = "pkg.worker"
        self.assertEqual(audit_source_imports(self.manifest, self.root)["decision"], "PASS")
        self.manifest["contracts"][1]["depends_on"] = []
        self.assertEqual(audit_source_imports(self.manifest, self.root)["decision"], "BLOCK")

    def test_import_from_package_detected(self):
        (self.root / "pkg").mkdir()
        (self.root / "pkg" / "parser.py").write_text("def run():\n    return 1\n", encoding="utf-8")
        (self.root / "worker.py").write_text("from pkg import parser\n", encoding="utf-8")
        self.manifest["contracts"][0]["module"] = "pkg.parser"
        self.assertEqual(audit_source_imports(self.manifest, self.root)["decision"], "PASS")

    def test_unsafe_symlink_rejected_if_platform_supports(self):
        target = self.root / "worker.py"
        alias = self.root / "linked.py"
        try:
            alias.symlink_to(target)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks not permitted")
        self.manifest["contracts"][1]["module"] = "linked"
        with self.assertRaisesRegex(SourceAuditError, "LINKED_SOURCE_PATH"):
            audit_source_imports(self.manifest, self.root)

    def test_cli_compatible_inspection_is_read_only(self):
        name = self.root / "manifest.json"
        name.write_text(json.dumps(self.manifest), encoding="utf-8")
        report = inspect_file(name, source_root=self.root)
        self.assertEqual(report["decision"], "PASS")
        self.assertEqual(report["source_audit"]["source_files_scanned"], 2)
        self.assertEqual(report["source_sha256"], inspect_file(name)["source_sha256"])


if __name__ == "__main__":
    unittest.main()
