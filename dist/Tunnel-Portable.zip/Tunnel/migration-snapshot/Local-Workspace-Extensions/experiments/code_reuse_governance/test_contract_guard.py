"""Negative and positive contracts for the read-only architecture prototype."""
from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from contract_guard import ContractError, inspect_file, validate

SPEC = "openspec/changes/local-pc-agent-tooling/specs/agent-orchestration/spec.md"


def contract(key, deps=()):
    return {
        "id": key,
        "module": key.replace("-", "_"),
        "public_api": "execute",
        "spec_ref": SPEC,
        "depends_on": list(deps),
        "inputs": "Validated typed request data",
        "outputs": "Structured typed result payload",
        "errors": "Explicit failure codes returned",
        "scaling": "Linear workload with fixed bound",
    }


def task(key, rid, role="owner", status="working", **extra):
    return {
        "task_id": key, "responsibility_id": rid, "role": role,
        "status": status,
        "reuse_decision": "EXTEND_CANONICAL_OWNER" if role == "owner" else "REUSE_EXISTING",
        **extra,
    }


def registry():
    return {
        "schema": "agent-responsibility-contracts-v1",
        "contracts": [contract("shared-parser"), contract("report-builder", ["shared-parser"])],
        "tasks": [task("P154", "shared-parser"), task("P155", "report-builder")],
    }


class ContractGuardTests(unittest.TestCase):
    def setUp(self):
        self.payload = registry()

    def test_disjoint_owners_are_allowed(self):
        result = validate(self.payload)
        self.assertEqual(result["decision"], "PASS")
        self.assertFalse(result["verified_owner_identity"])
        self.assertFalse(result["queue_mutated"])

    def test_two_agents_same_responsibility_different_modules_blocked(self):
        self.payload["tasks"].append(task("P156", "shared-parser", status="ready"))
        result = validate(self.payload)
        self.assertEqual(result["decision"], "BLOCK")
        self.assertEqual(result["findings"][0]["code"], "MULTIPLE_ACTIVE_OWNERS")

    def test_consumer_can_reuse_owner_without_conflict(self):
        self.payload["tasks"].append(task("P156", "shared-parser", "consumer", "ready"))
        self.assertEqual(validate(self.payload)["decision"], "PASS")

    def test_explicit_handoff_from_completed_predecessor(self):
        self.payload["tasks"][0]["status"] = "done"
        self.payload["tasks"].append(task("P156", "shared-parser", handoff_from="P154"))
        self.assertEqual(validate(self.payload)["decision"], "PASS")

    def test_missing_handoff_is_not_silent(self):
        self.payload["tasks"][0]["status"] = "done"
        self.payload["tasks"].append(task("P156", "shared-parser"))
        result = validate(self.payload)
        self.assertIn("UNVERIFIED_HANDOFF", [x["code"] for x in result["findings"]])

    def test_fake_handoff_is_not_silent(self):
        self.payload["tasks"][0]["status"] = "done"
        self.payload["tasks"].append(task("P156", "shared-parser", handoff_from="P999"))
        result = validate(self.payload)
        self.assertIn("UNVERIFIED_HANDOFF", [x["code"] for x in result["findings"]])

    def test_cycle_reports_actual_cycle(self):
        self.payload["contracts"][0]["depends_on"] = ["report-builder"]
        result = validate(self.payload)
        self.assertEqual(result["decision"], "BLOCK")
        cycle = [x for x in result["findings"] if x["code"] == "IMPORT_CYCLE"][0]["path"]
        self.assertEqual(cycle[0], cycle[-1])
        self.assertEqual(set(cycle), {"shared-parser", "report-builder"})

    def test_missing_dependency_and_unknown_responsibility(self):
        self.payload["contracts"][0]["depends_on"] = ["nonexistent"]
        self.payload["tasks"].append(task("P156", "missing-id"))
        codes = {x["code"] for x in validate(self.payload)["findings"]}
        self.assertIn("UNKNOWN_DEPENDENCY", codes)
        self.assertIn("UNKNOWN_RESPONSIBILITY", codes)

    def test_duplicate_contract_or_task_fails(self):
        self.payload["contracts"].append(copy.deepcopy(self.payload["contracts"][0]))
        self.payload["tasks"].append(copy.deepcopy(self.payload["tasks"][0]))
        codes = {x["code"] for x in validate(self.payload)["findings"]}
        self.assertIn("DUPLICATE_CONTRACT", codes)
        self.assertIn("DUPLICATE_TASK_ID", codes)

    def test_spec_path_traversal_rejected(self):
        self.payload["contracts"][0]["spec_ref"] = "openspec/changes/../../secret"
        with self.assertRaisesRegex(ContractError, "INVALID_SPEC_REF"):
            validate(self.payload)

    def test_unsafe_module_name_rejected(self):
        self.payload["contracts"][0]["module"] = "../secret"
        with self.assertRaisesRegex(ContractError, "INVALID_MODULE"):
            validate(self.payload)

    def test_overlarge_registry_rejected(self):
        self.payload["tasks"] = [task(f"P{i:03d}", "shared-parser", status="done") for i in range(513)]
        with self.assertRaisesRegex(ContractError, "INVALID_TASK_COUNT"):
            validate(self.payload)

    def test_read_only_source_hash_is_stable_and_changes_when_modified(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / "contracts.json"
            file.write_text(json.dumps(self.payload), encoding="utf-8")
            first = inspect_file(file)
            self.assertEqual(first, inspect_file(file))
            self.payload["contracts"][0]["scaling"] = "Bounded linear time and memory footprint"
            file.write_text(json.dumps(self.payload), encoding="utf-8")
            self.assertNotEqual(first["source_sha256"], inspect_file(file)["source_sha256"])

    def test_malformed_utf8_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / "broken.json"
            file.write_bytes(b"\xff")
            with self.assertRaisesRegex(ContractError, "MALFORMED_MANIFEST"):
                inspect_file(file)

    def test_truncated_or_unknown_document_rejected(self):
        self.payload["schema"] = "unknown"
        with self.assertRaisesRegex(ContractError, "UNKNOWN_SCHEMA"):
            validate(self.payload)

    def test_untrusted_enum_type_returns_typed_error(self):
        self.payload["tasks"][0]["role"] = ["owner"]
        with self.assertRaisesRegex(ContractError, "INVALID_TASK_ENUM:role"):
            validate(self.payload)

    def test_oversized_file_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / "huge.json"
            file.write_bytes(b" " * (256 * 1024 + 1))
            with self.assertRaisesRegex(ContractError, "OVERSIZED_MANIFEST"):
                inspect_file(file)

    def test_consumer_handoff_is_rejected(self):
        self.payload["tasks"].append(task("P156", "shared-parser", "consumer",
                                          handoff_from="P154"))
        result = validate(self.payload)
        self.assertIn("CONSUMER_CANNOT_HANDOFF", [x["code"] for x in result["findings"]])

    def test_symlink_rejected_where_supported(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp) / "contracts.json"
            file.write_text(json.dumps(self.payload), encoding="utf-8")
            link = Path(tmp) / "link.json"
            try:
                link.symlink_to(file)
            except (OSError, NotImplementedError):
                self.skipTest("Windows symlink not permitted")
            with self.assertRaisesRegex(ContractError, "UNSAFE_MANIFEST_FILE"):
                inspect_file(link)


if __name__ == "__main__":
    unittest.main()
