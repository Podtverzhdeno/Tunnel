"""Read-only prototype for single-owner and dependency-contract validation.

NOT a trusted scheduler authorization gate. Does not mutate tasks, OpenSpec,
SDD, Git or code; a future integration requires foreground owner approval.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from import_graph_guard import audit_source_imports, SourceAuditError

MAX_BYTES = 256 * 1024
MAX_CONTRACTS = 256
MAX_TASKS = 512
MAX_DEPENDENCIES = 24
IDENT = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z")
MODULE = re.compile(r"[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)*\Z")
SYMBOL = re.compile(r"[a-zA-Z_][a-zA-Z_0-9]*\Z")
TASK_ID = re.compile(r"P[0-9]{3,6}\Z")
SPEC_REF = re.compile(r"(?:openspec/changes|specs)/[a-zA-Z0-9_./-]+\Z")
ROLES = {"owner", "consumer"}
STATES = {"planned", "ready", "working", "review", "reviewing", "done", "blocked"}
REUSE = {"REUSE_EXISTING", "EXTEND_CANONICAL_OWNER", "PROPOSE_NEW_RESPONSIBILITY"}


class ContractError(ValueError):
    """Bad input rather than an approved architecture decision."""


def _mapping(value, allowed, required, label):
    if not isinstance(value, dict) or not required.issubset(value) or set(value) - allowed:
        raise ContractError("INVALID_" + label)


def _string(value, pattern, label, limit=240):
    if not isinstance(value, str) or not 1 <= len(value) <= limit or not pattern.fullmatch(value):
        raise ContractError("INVALID_" + label)
    return value


def _description(value, label):
    if not isinstance(value, str) or not 8 <= len(value.strip()) <= 600:
        raise ContractError("INVALID_" + label)
    return value


def _spec(value):
    result = _string(value, SPEC_REF, "SPEC_REF")
    if ".." in result.split("/") or "//" in result or result.endswith("/"):
        raise ContractError("INVALID_SPEC_REF")
    return result


def _list(value, label, limit):
    if not isinstance(value, list) or len(value) > limit or any(not isinstance(x, str) for x in value):
        raise ContractError("INVALID_" + label)
    if len(value) != len(set(value)):
        raise ContractError("DUPLICATE_" + label)
    return value


def _cycle(graph):
    """Return an actual deterministic directed cycle, not an arbitrary downstream node."""
    visited = set()
    active = {}
    route = []

    def visit(node):
        if node in active:
            return route[active[node]:] + [node]
        if node in visited:
            return None
        active[node] = len(route)
        route.append(node)
        for neighbour in sorted(graph[node]):
            found = visit(neighbour)
            if found:
                return found
        route.pop()
        del active[node]
        visited.add(node)
        return None

    for node in sorted(graph):
        found = visit(node)
        if found:
            return found
    return None


def validate(document):
    """Check an explicit design proposal. Never infer a trusted owner from metadata."""
    _mapping(document, {"schema", "contracts", "tasks"}, {"schema", "contracts", "tasks"}, "MANIFEST")
    if document["schema"] != "agent-responsibility-contracts-v1":
        raise ContractError("UNKNOWN_SCHEMA")
    contracts = document["contracts"]
    tasks = document["tasks"]
    if not isinstance(contracts, list) or not 1 <= len(contracts) <= MAX_CONTRACTS:
        raise ContractError("INVALID_CONTRACT_COUNT")
    if not isinstance(tasks, list) or len(tasks) > MAX_TASKS:
        raise ContractError("INVALID_TASK_COUNT")
    graph = {}
    by_id = {}
    issues = []
    for contract in contracts:
        allowed = {"id", "module", "public_api", "spec_ref", "depends_on", "inputs", "outputs", "errors", "scaling"}
        _mapping(contract, allowed, allowed, "CONTRACT")
        key = _string(contract["id"], IDENT, "RESPONSIBILITY_ID", 80)
        if key in by_id:
            issues.append({"code": "DUPLICATE_CONTRACT", "responsibility_id": key})
            continue
        _string(contract["module"], MODULE, "MODULE")
        _string(contract["public_api"], SYMBOL, "PUBLIC_API", 120)
        _spec(contract["spec_ref"])
        for name in ("inputs", "outputs", "errors", "scaling"):
            _description(contract[name], name.upper())
        dependencies = _list(contract["depends_on"], "DEPENDENCIES", MAX_DEPENDENCIES)
        for dep in dependencies:
            _string(dep, IDENT, "DEPENDENCY_ID", 80)
        graph[key] = dependencies
        by_id[key] = contract
    for name, dependencies in sorted(graph.items()):
        for dependency in dependencies:
            if dependency not in graph:
                issues.append({"code": "UNKNOWN_DEPENDENCY", "responsibility_id": name, "dependency": dependency})
    if not any(x["code"] == "UNKNOWN_DEPENDENCY" for x in issues):
        cycle = _cycle(graph)
        if cycle:
            issues.append({"code": "IMPORT_CYCLE", "path": cycle})

    seen_tasks = set()
    owners = {}
    done = {}
    for task in tasks:
        allowed = {"task_id", "responsibility_id", "role", "status", "reuse_decision", "handoff_from"}
        required = allowed - {"handoff_from"}
        _mapping(task, allowed, required, "TASK")
        task_id = _string(task["task_id"], TASK_ID, "TASK_ID")
        if task_id in seen_tasks:
            issues.append({"code": "DUPLICATE_TASK_ID", "task_id": task_id})
        seen_tasks.add(task_id)
        rid = _string(task["responsibility_id"], IDENT, "TASK_RESPONSIBILITY", 80)
        if rid not in by_id:
            issues.append({"code": "UNKNOWN_RESPONSIBILITY", "task_id": task_id, "responsibility_id": rid})
        for field, choices in (("role", ROLES), ("status", STATES), ("reuse_decision", REUSE)):
            if type(task[field]) is not str or task[field] not in choices:
                raise ContractError("INVALID_TASK_ENUM:" + field)
        handoff = task.get("handoff_from")
        if handoff is not None:
            _string(handoff, TASK_ID, "HANDOFF")
        if task["role"] == "owner":
            if task["status"] == "done":
                done.setdefault(rid, set()).add(task_id)
            elif task["status"] != "blocked":
                owners.setdefault(rid, []).append((task_id, handoff))
        elif handoff is not None:
            issues.append({"code": "CONSUMER_CANNOT_HANDOFF", "task_id": task_id})
    for rid, pending in sorted(owners.items()):
        if len(pending) > 1:
            issues.append({"code": "MULTIPLE_ACTIVE_OWNERS", "responsibility_id": rid,
                           "tasks": sorted(x[0] for x in pending)})
        for task_id, previous in pending:
            historical = done.get(rid, set())
            if historical and previous not in historical:
                issues.append({"code": "UNVERIFIED_HANDOFF", "responsibility_id": rid, "task_id": task_id})
            if not historical and previous is not None:
                issues.append({"code": "UNKNOWN_HANDOFF", "responsibility_id": rid, "task_id": task_id})
    return {
        "schema": "agent-responsibility-validation-v1",
        "decision": "BLOCK" if issues else "PASS",
        "findings": issues[:60],
        "findings_truncated": len(issues) > 60,
        "responsibilities": len(by_id),
        "task_assignments": len(tasks),
        "verified_owner_identity": False,
        "queue_mutated": False,
        "normative_spec_approved": False,
    }


def inspect_file(path: Path, *, source_root=None):
    path = Path(path)
    if path.is_symlink() or getattr(path, "is_junction", lambda: False)() or not path.is_file():
        raise ContractError("UNSAFE_MANIFEST_FILE")
    if path.stat().st_size > MAX_BYTES:
        raise ContractError("OVERSIZED_MANIFEST")
    # Enforce the size limit on the actual read as well (files may grow after stat).
    with path.open("rb") as source:
        raw = source.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ContractError("OVERSIZED_MANIFEST")
    try:
        document = json.loads(raw.decode("utf-8", errors="strict"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ContractError("MALFORMED_MANIFEST") from exc
    result = validate(document)
    result["source_sha256"] = hashlib.sha256(raw).hexdigest()
    if source_root is not None and result["decision"] == "PASS":
        source_audit = audit_source_imports(document, source_root)
        result["source_audit"] = source_audit
        if source_audit["decision"] == "BLOCK":
            result["decision"] = "BLOCK"
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest")
    parser.add_argument("--source-root", help="Optional read-only verification of actual Python imports")
    args = parser.parse_args(argv)
    try:
        result = inspect_file(Path(args.manifest), source_root=args.source_root)
    except (ContractError, SourceAuditError, OSError, RecursionError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)[:160]}))
        return 2
    print(json.dumps({"ok": result["decision"] == "PASS", "data": result}, sort_keys=True))
    return 0 if result["decision"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
