# Architecture Contract Guard — isolated proof of concept

Status: **read-only prototype, not an active queue gate or approved normative OpenSpec change**.
Scope: `Local-Workspace-Extensions/experiments/code_reuse_governance/`.
No live task, agent lease, production SQLite, Git, or spec is changed by this checker.

## Purpose

Prevent **logical ownership duplication** that escapes an AST clone detector: two
agents may independently implement the same responsibility under different module
names while producing syntactically unrelated code. A responsibility ID is therefore
defined by the architect *before* assigning implementations.

The validator accepts a versioned manifest listing each responsibility's canonical
module, public API, spec reference, dependencies, input/output/error contracts and
scalability bound. Task entries declare a responsibility, role (owner/consumer),
state, reuse decision, and optional transfer from a completed owner.

### Fail-closed decisions

- Two non-completed owners for the same responsibility -> `MULTIPLE_ACTIVE_OWNERS`.
- Later ownership after completed work without referencing the completed owner ->
  `UNVERIFIED_HANDOFF`. A textual claim is not a verified lease.
- Directed dependency cycle -> `IMPORT_CYCLE` with an actual cycle path.
- Unknown or repeated contract, dependency or task -> blocked.
- Malformed schema, suspicious module/spec name, non-UTF-8 or oversize file -> CLI
  returns exit code 2 without touching runtime task state.

A PASS means the supplied **declarative manifest** is internally consistent. It does
not prove that developers' actual imports, APIs or delivered source match the manifest;
the manifest is not a trusted authorization record and ownership is not inferred from
the LLM role string. The static AST clone veto remains a separate check.

## Reproduce

From `Local-Workspace-Extensions`:

```powershell
python experiments/code_reuse_governance/contract_guard.py experiments/code_reuse_governance/example-contracts.json
python -m unittest discover -s experiments/code_reuse_governance -p "test_*.py" -v
```

To audit real Python source/import boundaries after the contracted modules exist,
add `--source-root PATH` to the command. This reads bounded UTF-8 Python files
without importing/executing modules, computes each module's SHA256, blocks
undeclared imports between owned modules and reports actual source-import cycles.
Missing files, malformed syntax, unsafe symlinks and oversize modules fail closed.
Dynamic imports, ambiguous external package ownership and runtime monkeypatching
are not proven safe; independent review and SHA-fenced publication are still required.
The provided example is intentionally a design manifest only: its modules have
not been created, so it should **not** be run with `--source-root`.

`example-contracts.json` is synthetic, not the canonical live queue. The CLI emits
a source SHA256, deterministic findings and `normative_spec_approved=false`.

## Proposed integration *after explicit owner-approved OpenSpec*

1. Define and review canonical responsibility IDs and interfaces in the authoritative
   OpenSpec/SDD, with backward-compatible migration for existing task IDs.
2. Version and bind the manifest to a real root source SHA and accepted spec SHA.
3. Enforce unique owners **transactionally** at queue admission and task acquisition
   against authoritative SQLite state, not by trusting a submitted JSON file.
4. Cross-check actual imports and public APIs; reject verified cycles and unauthorized
   boundary changes at independent reviewer acceptance, under SHA fencing.
5. Allow only owner-reviewed sequential handoffs. Add concurrent two-agent admission,
   crash/retry, stale snapshot, incorrect manifest, false-positive and bypass tests.
6. Preserve strict host actor identity and real terminal approvals (P085 unresolved).
   Prototype `PASS` is never merge permission.

This proof of concept cannot be promoted to a normative spec with MCP-only terminal
approval simulation. Formal pending request: `add-agent-code-reuse-governance`.
