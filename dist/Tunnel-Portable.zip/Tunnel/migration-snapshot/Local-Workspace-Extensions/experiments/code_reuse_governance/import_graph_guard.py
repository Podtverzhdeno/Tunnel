"""Optional read-only Python source/import verification for architecture contracts.

Works only on explicitly provided source trees. Does not import/execute code.
A PASS is a snapshot, not a merge authorization or authenticated actor proof.
"""
from __future__ import annotations

import ast
import hashlib
from pathlib import Path

MAX_SOURCE_BYTES = 2 * 1024 * 1024


class SourceAuditError(ValueError):
    pass


def _is_link(path):
    return path.is_symlink() or getattr(path, "is_junction", lambda: False)()


def _safe_source(root, module):
    candidate = root.joinpath(*module.split(".")).with_suffix(".py")
    if _is_link(root) or not root.is_dir() or not candidate.is_relative_to(root):
        raise SourceAuditError("UNSAFE_SOURCE_ROOT")
    current = candidate
    while current != root:
        if _is_link(current):
            raise SourceAuditError("LINKED_SOURCE_PATH")
        current = current.parent
    if not candidate.is_file():
        raise SourceAuditError("SOURCE_MODULE_MISSING:" + module)
    try:
        if candidate.stat().st_size > MAX_SOURCE_BYTES:
            raise SourceAuditError("SOURCE_OVERSIZED:" + module)
        with candidate.open("rb") as source:
            data = source.read(MAX_SOURCE_BYTES + 1)
        if len(data) > MAX_SOURCE_BYTES:
            raise SourceAuditError("SOURCE_OVERSIZED:" + module)
        source = data.decode("utf-8", errors="strict")
        parsed = ast.parse(source, filename=module)
    except (UnicodeError, SyntaxError, ValueError, RecursionError) as exc:
        raise SourceAuditError("SOURCE_PARSE_ERROR:" + module) from exc
    return parsed, hashlib.sha256(data).hexdigest()


def _dependencies(module, tree, known):
    """Extract direct imports of known modules; never guess external module ownership."""
    found = set()
    package = module.split(".")[:-1]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for item in node.names:
                if item.name in known:
                    found.add(item.name)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                # One leading dot stays in the current package. Each further
                # dot moves one package up; never resolve beyond the package root.
                if node.level > len(package):
                    continue
                prefix = package[:len(package) - node.level + 1]
                base = ".".join(prefix + ([node.module] if node.module else []))
            else:
                base = node.module or ""
            if base in known:
                found.add(base)
            for item in node.names:
                if item.name != "*":
                    sibling = base + "." + item.name if base else item.name
                    if sibling in known:
                        found.add(sibling)
    found.discard(module)
    return found


def _cycle(graph):
    visited, active, route = set(), {}, []

    def walk(node):
        if node in active:
            return route[active[node]:] + [node]
        if node in visited:
            return None
        active[node] = len(route)
        route.append(node)
        for dep in sorted(graph[node]):
            result = walk(dep)
            if result:
                return result
        route.pop()
        del active[node]
        visited.add(node)
        return None

    for item in sorted(graph):
        result = walk(item)
        if result:
            return result
    return None


def audit_source_imports(document, root):
    root = Path(root)
    if not root.is_dir() or _is_link(root):
        raise SourceAuditError("UNSAFE_SOURCE_ROOT")
    modules = {}
    for contract in document["contracts"]:
        if contract["module"] in modules:
            raise SourceAuditError("AMBIGUOUS_MODULE_OWNER:" + contract["module"])
        modules[contract["module"]] = contract["id"]
    by_id = {x["id"]: x for x in document["contracts"]}
    graph, hashes, findings = {}, {}, []
    for module in sorted(modules):
        tree, sha = _safe_source(root, module)
        hashes[module] = sha
        imported = _dependencies(module, tree, modules)
        owner = modules[module]
        graph[owner] = {modules[x] for x in imported}
        declared = set(by_id[owner]["depends_on"])
        for dependency in sorted(graph[owner] - declared):
            findings.append({"code": "UNDECLARED_SOURCE_IMPORT",
                             "responsibility_id": owner, "imported_responsibility_id": dependency})
    cycle = _cycle(graph)
    if cycle:
        findings.append({"code": "SOURCE_IMPORT_CYCLE", "path": cycle})
    return {"decision": "BLOCK" if findings else "PASS", "findings": findings[:60],
            "findings_truncated": len(findings) > 60, "source_hashes": hashes,
            "source_files_scanned": len(modules), "source_executed": False}
