"""Offline durable OpenClaw wake outbox: crash and retry safety tests.

Test-only loopback gateway. No real OpenClaw, ChatGPT API or live MCP.
"""
from __future__ import annotations

import json
import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import bridge_store as store
import result_outbox as box
from openclaw_wake_dispatcher import (
    dispatch_once, post_wake, validate_gateway_url,validate_token,wake_payload
)

TOKEN="FAKE_TEST_HOOK_TOKEN_012345678901234567"
REQUEST={"model":"chatgpt-web-queued",
         "messages":[{"role":"user","content":"SECRET_PROMPT_FOR_PRIVACY_TEST"}]}

class OutboxTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix="wake-outbox-tests-")
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"queue.sqlite3"
    def done(self):
        ident=store.submit(self.db,REQUEST)
        work=store.claim(self.db)
        store.complete(self.db,ident,work["lease_token"],
                       {"content":"SECRET_GENERATED_ANSWER"})
        return ident
    def _shift(self,id,seconds=120):
        with closing(store.connect(self.db)) as con:
            con.execute(
                "UPDATE result_wake_outbox SET lease_until=lease_until-? WHERE job_id=?",
                (seconds,id))
            con.commit()
    def test_restart_reconciles_completed_work_without_data_leak(self):
        ident=self.done()
        one=box.sync_terminal_results(self.db)
        self.assertEqual(one["ready"],1)
        again=box.sync_terminal_results(self.db)
        self.assertEqual(again["ready"],1)
        with closing(store.connect(self.db)) as con:
            n=con.execute("SELECT COUNT(*) FROM result_wake_outbox").fetchone()[0]
        self.assertEqual(n,1)
        record=box.event_status(self.db,ident)
        self.assertEqual(record["terminal_status"],"done")
        self.assertNotIn("SECRET",json.dumps(record))
    def test_queued_and_claimed_never_produce_wake(self):
        ident=store.submit(self.db,REQUEST)
        self.assertEqual(box.sync_terminal_results(self.db)["ready"],0)
        store.claim(self.db)
        self.assertEqual(box.sync_terminal_results(self.db)["ready"],0)
    def test_cancelled_and_failed_jobs_are_materialized(self):
        a=store.submit(self.db,REQUEST)
        store.cancel_queued(self.db,a)
        b=store.submit(self.db,REQUEST)
        claim=store.claim(self.db)
        self.assertEqual(claim["job_id"],b)
        store.fail(self.db,b,claim["lease_token"],"TASK_ERROR")
        self.assertEqual(box.sync_terminal_results(self.db)["ready"],2)
        self.assertEqual(box.event_status(self.db,a)["terminal_status"],"failed")
        self.assertEqual(box.event_status(self.db,b)["terminal_status"],"failed")
    def test_lease_expiry_uncertain_job_is_not_replayed_as_model_job(self):
        a=store.submit(self.db,REQUEST)
        store.claim(self.db)
        with closing(sqlite3.connect(self.db)) as con:
            con.execute("UPDATE requests SET lease_until=0 WHERE id=?",(a,))
            con.commit()
        self.assertIsNone(store.claim(self.db))
        self.assertEqual(box.sync_terminal_results(self.db)["ready"],1)
        self.assertEqual(box.event_status(self.db,a)["terminal_status"],"needs_reconcile")
        self.assertIsNone(store.claim(self.db))
    def test_one_delivery_receipt_and_bad_token_denied(self):
        ident=self.done()
        box.sync_terminal_results(self.db)
        delivery=box.reserve(self.db)
        self.assertEqual(delivery["job_id"],ident)
        self.assertIsNone(box.reserve(self.db))
        with self.assertRaisesRegex(store.BridgeError,"DELIVERY_LEASE_EXPIRED_OR_INVALID"):
            box.finish_delivery(self.db,ident,"wrong-token-0000000000000000",accepted=True)
        result=box.finish_delivery(self.db,ident,delivery["delivery_lease_token"],accepted=True)
        self.assertTrue(result["delivery_accepted"])
        self.assertEqual(result["state"],"delivered")
        self.assertEqual(box.sync_terminal_results(self.db)["counts"]["delivered"],1)
        self.assertIsNone(box.reserve(self.db))
    def test_retry_backoff_eventually_delivers(self):
        ident=self.done()
        box.sync_terminal_results(self.db)
        delivery=box.reserve(self.db)
        result=box.finish_delivery(self.db,ident,delivery["delivery_lease_token"],
                                   accepted=False,failure_code="NETWORK_ERROR")
        self.assertEqual(result["state"],"ready")
        self.assertEqual(box.event_status(self.db,ident)["last_code"],"NETWORK_ERROR")
        self.assertIsNone(box.reserve(self.db))
        with closing(store.connect(self.db)) as con:
            con.execute("UPDATE result_wake_outbox SET next_retry=0 WHERE job_id=?",(ident,))
            con.commit()
        next_del=box.reserve(self.db)
        self.assertEqual(next_del["attempt"],2)
        box.finish_delivery(self.db,ident,next_del["delivery_lease_token"],accepted=True)
        self.assertEqual(box.event_status(self.db,ident)["state"],"delivered")
    def test_expired_delivery_lease_recovers_with_uncertain_record(self):
        ident=self.done()
        box.sync_terminal_results(self.db)
        old=box.reserve(self.db)
        self._shift(ident,180)
        renewed=box.reserve(self.db)
        self.assertIsNotNone(renewed)
        self.assertEqual(renewed["attempt"],2)
        with self.assertRaisesRegex(store.BridgeError,"DELIVERY_LEASE_EXPIRED_OR_INVALID"):
            box.finish_delivery(self.db,ident,old["delivery_lease_token"],accepted=True)
        box.finish_delivery(self.db,ident,renewed["delivery_lease_token"],accepted=True)
    def test_retry_limit_blocks_more_attempts(self):
        ident=self.done()
        box.sync_terminal_results(self.db)
        for i in range(box.MAX_ATTEMPTS):
            delivery=box.reserve(self.db)
            self.assertIsNotNone(delivery,(i,box.event_status(self.db,ident)))
            answer=box.finish_delivery(self.db,ident,delivery["delivery_lease_token"],
                                       accepted=False,failure_code="NETWORK_ERROR")
            if i+1<box.MAX_ATTEMPTS:
                with closing(store.connect(self.db)) as con:
                    con.execute("UPDATE result_wake_outbox SET next_retry=0 WHERE job_id=?",(ident,))
                    con.commit()
        self.assertEqual(answer["state"],"blocked")
        self.assertIsNone(box.reserve(self.db))
    def test_reject_invalid_ack_or_unknown_job(self):
        ident=self.done()
        box.sync_terminal_results(self.db)
        lease=box.reserve(self.db)
        for invalid in ("foo",[],True,0):
            with self.subTest(value=invalid):
                with self.assertRaises(store.BridgeError):
                    box.finish_delivery(self.db,ident,invalid,accepted=True)
        with self.assertRaisesRegex(store.BridgeError,"INVALID_ACK_DECISION"):
            box.finish_delivery(self.db,ident,lease["delivery_lease_token"],accepted=1)
        with self.assertRaisesRegex(store.BridgeError,"INVALID_ACK_REASON"):
            box.finish_delivery(self.db,ident,lease["delivery_lease_token"],
                                accepted=False,failure_code="anything")
        self.assertEqual(box.event_status(self.db,ident)["state"],"sending")
    def test_atomic_reservation_for_multiple_threads(self):
        ident=self.done()
        box.sync_terminal_results(self.db)
        out=[]
        errors=[]
        lock=threading.Lock()
        start=threading.Barrier(7)
        def threadfn():
            try:
                start.wait(timeout=7)
                item=box.reserve(self.db)
                with lock:out.append(item)
            except Exception as exc:
                with lock:errors.append(type(exc).__name__+":"+str(exc))
        threads=[threading.Thread(target=threadfn) for _ in range(7)]
        for t in threads:t.start()
        for t in threads:t.join(12)
        self.assertFalse(any(t.is_alive() for t in threads))
        self.assertEqual(errors,[])
        self.assertEqual(len([x for x in out if x is not None]),1)
        self.assertEqual([x["job_id"] for x in out if x is not None],[ident])

class FakeWakeHandler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args):pass
    def do_POST(self):
        self.server.hits+=1
        size=int(self.headers.get("Content-Length",0))
        body=self.rfile.read(size)
        self.server.last_path=self.path
        self.server.last_auth=self.headers.get("Authorization")
        self.server.last_payload=json.loads(body)
        status=self.server.status_code
        payload=self.server.payload
        encoded=json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

class WakeDispatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"requests.db"
        self.gateway=ThreadingHTTPServer(("127.0.0.1",0),FakeWakeHandler)
        self.gateway.hits=0
        self.gateway.payload={"ok":True,"mode":"now","eventOutcome":"queued"}
        self.gateway.status_code=200
        self.thread=threading.Thread(target=self.gateway.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(lambda:(self.gateway.shutdown(),self.gateway.server_close(),self.thread.join(3)))
        self.url=f"http://127.0.0.1:{self.gateway.server_address[1]}/hooks/wake"
    def done(self):
        job=store.submit(self.db,REQUEST)
        lease=store.claim(self.db)
        store.complete(self.db,job,lease["lease_token"],{"content":"SECRET_MODEL_OUTPUT"})
        return job
    def test_real_loopback_http_ack_and_no_prompt_in_hook(self):
        ident=self.done()
        result=dispatch_once(self.db,self.url,TOKEN)
        self.assertTrue(result["sent"])
        self.assertEqual(result["job_id"],ident)
        self.assertEqual(self.gateway.hits,1)
        self.assertEqual(self.gateway.last_path,"/hooks/wake")
        self.assertEqual(self.gateway.last_auth,"Bearer "+TOKEN)
        self.assertEqual(self.gateway.last_payload["mode"],"now")
        self.assertIn(ident,self.gateway.last_payload["text"])
        self.assertNotIn("SECRET",str(self.gateway.last_payload))
        self.assertEqual(box.event_status(self.db,ident)["state"],"delivered")
        self.assertEqual(dispatch_once(self.db,self.url,TOKEN)["status"],"NO_PENDING_WAKE")
    def test_http_failure_retries_with_no_second_immediate_wake(self):
        ident=self.done()
        self.gateway.status_code=401
        outcome=dispatch_once(self.db,self.url,TOKEN)
        self.assertFalse(outcome["sent"])
        self.assertEqual(outcome["outbox_state"],"ready")
        self.assertEqual(self.gateway.hits,1)
        result=dispatch_once(self.db,self.url,TOKEN)
        self.assertEqual(result["status"],"NO_PENDING_WAKE")
        self.assertEqual(self.gateway.hits,1)
        self.assertEqual(box.event_status(self.db,ident)["last_code"],"NETWORK_ERROR")
    def test_invalid_success_response_does_not_ack(self):
        ident=self.done()
        self.gateway.payload={"ok":True,"mode":"now"}  # no eventOutcome
        result=dispatch_once(self.db,self.url,TOKEN)
        self.assertFalse(result["sent"])
        self.assertEqual(box.event_status(self.db,ident)["last_code"],"GATEWAY_RESPONSE_INVALID")
    def test_untrusted_endpoint_rejected(self):
        for url in (
            "http://example.com:18789/hooks/wake",
            "https://127.0.0.1:18789/hooks/wake",
            "http://localhost:18789/hooks/wake",
            "http://127.0.0.1:18789/hooks/agent",
            "http://127.0.0.1:18789/hooks/wake?token=secret",
            "http://u:p@127.0.0.1:18789/hooks/wake",
            "http://127.0.0.1:bad/hooks/wake",
            "http://127.0.0.1/hooks/wake",
        ):
            with self.subTest(url=url):
                with self.assertRaises(store.BridgeError):
                    validate_gateway_url(url)
    def test_short_or_unsafe_token_rejected(self):
        for token in ("foo","A"*21,"has\nnewline-000000000000000000000","🧪"*50,False):
            with self.subTest(token=str(token)[:8]):
                with self.assertRaises(store.BridgeError):
                    validate_token(token)
    def test_dry_run_sync_does_not_reserve_or_send(self):
        ident=self.done()
        summary=box.sync_terminal_results(self.db)
        self.assertEqual(summary["ready"],1)
        self.assertEqual(self.gateway.hits,0)
        self.assertEqual(box.event_status(self.db,ident)["state"],"ready")
    def test_wake_payload_rejects_nonterminal(self):
        with self.assertRaisesRegex(store.BridgeError,"INVALID_TERMINAL_STATUS"):
            wake_payload("0"*32,"claimed")

if __name__=="__main__":
    unittest.main()
