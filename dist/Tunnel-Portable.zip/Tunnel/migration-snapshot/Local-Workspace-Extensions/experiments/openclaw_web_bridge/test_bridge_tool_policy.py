"""Tool-call authorization and real SSE framing regression tests.

A worker is untrusted: it may only return function calls that the requester
declared in the exact queue entry. Runs offline with an in-process loopback
HTTP server, no third-party model and no live MCP tools.
"""
from __future__ import annotations
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
import bridge_store as store
from server import Server

TOKEN="synthetic-tool-policy-test-secret-0123456789"
def req(*,stream=False,choice="auto"):
    return {
        "model":"chatgpt-web-queued",
        "messages":[{"role":"user","content":"Run declared function in a synthetic test"}],
        "stream":stream,
        "stream_options":{"include_usage":True},
        "tool_choice":choice,
        "tools":[
            {"type":"function","function":{"name":"example_read_only",
                "description":"Synthetic test-only function",
                "parameters":{"type":"object","properties":{}}}},
            {"type":"function","function":{"name":"lookup_status",
                "parameters":{"type":"object","properties":{}}}},
        ],
    }
def call(name="example_read_only",identifier="call_a",args="{}"):
    return {"id":identifier,"type":"function",
            "function":{"name":name,"arguments":args}}

class ToolAuthorizationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"calls.sqlite3"
    def submit_claim(self,request=None):
        ident=store.submit(self.db,request or req())
        lease=store.claim(self.db)
        self.assertEqual(lease["job_id"],ident)
        return ident,lease
    def test_valid_declared_tool_can_complete(self):
        ident,lease=self.submit_claim()
        store.complete(self.db,ident,lease["lease_token"],
                       {"tool_calls":[call()]})
        answer=json.loads(store.status(self.db,ident)["answer_json"])
        self.assertEqual(answer["tool_calls"][0]["function"]["name"],"example_read_only")
    def test_undeclared_function_is_denied_and_job_remains_claimed(self):
        ident,lease=self.submit_claim()
        with self.assertRaisesRegex(store.BridgeError,"UNDECLARED_TOOL_CALL"):
            store.complete(self.db,ident,lease["lease_token"],
                           {"tool_calls":[call("dangerous_execute")]})
        self.assertEqual(store.status(self.db,ident)["status"],"claimed")
    def test_tool_choice_none_blocks_calls_despite_tool_definitions(self):
        ident,lease=self.submit_claim(req(choice="none"))
        self.assertEqual(lease["tools"],[])
        with self.assertRaisesRegex(store.BridgeError,"UNDECLARED_TOOL_CALL"):
            store.complete(self.db,ident,lease["lease_token"],{"tool_calls":[call()]})
        store.complete(self.db,ident,lease["lease_token"],{"content":"No tools requested"})
    def test_duplicated_tool_call_ids_rejected(self):
        ident,lease=self.submit_claim()
        with self.assertRaisesRegex(store.BridgeError,"TOOL_CALL_ID_DUPLICATE_OR_INVALID"):
            store.complete(self.db,ident,lease["lease_token"],
                           {"tool_calls":[call(identifier="same"),call("lookup_status","same")]})
    def test_empty_or_excessive_ids_are_rejected(self):
        for bad in ("","x"*101):
            ident,lease=self.submit_claim()
            with self.subTest(id_size=len(bad)):
                with self.assertRaisesRegex(store.BridgeError,"TOOL_CALL_ID_DUPLICATE_OR_INVALID"):
                    store.complete(self.db,ident,lease["lease_token"],
                                   {"tool_calls":[call(identifier=bad)]})
    def test_duplicate_or_illegal_declared_function_names(self):
        r=req()
        r["tools"].append(r["tools"][0])
        with self.assertRaisesRegex(store.BridgeError,"DUPLICATE_TOOL_NAME"):
            store.validate_request(r)
        r=req()
        r["tools"][0]["function"]["name"]="file/read"
        with self.assertRaisesRegex(store.BridgeError,"UNSUPPORTED_TOOL_SCHEMA"):
            store.validate_request(r)
    def test_no_declared_tools_blocks_any_toolcall(self):
        ident,lease=self.submit_claim({"model":"chatgpt-web-queued",
            "messages":[{"role":"user","content":"Hello"}]})
        with self.assertRaisesRegex(store.BridgeError,"UNDECLARED_TOOL_CALL"):
            store.complete(self.db,ident,lease["lease_token"],
                           {"tool_calls":[call()]})
    def test_wrong_lease_never_completes(self):
        ident,lease=self.submit_claim()
        with self.assertRaisesRegex(store.BridgeError,"LEASE_UNAVAILABLE_OR_EXPIRED"):
            store.complete(self.db,ident,"not-the-valid-lease",{"tool_calls":[call()]})
        self.assertEqual(store.status(self.db,ident)["status"],"claimed")

class StreamingToolCallsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"server.sqlite3"
        self.server=Server("127.0.0.1",0,self.db,TOKEN,5)
        thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        thread.start()
        self.addCleanup(lambda:(self.server.shutdown(),self.server.server_close(),thread.join(3)))
        self.url="http://127.0.0.1:"+str(self.server.server_address[1])+"/v1/chat/completions"
    def test_streamed_tool_call_has_index_and_finish_reason(self):
        got={}
        def sender():
            payload=json.dumps(req(stream=True)).encode()
            message=Request(self.url,data=payload,headers={
                "Authorization":"Bearer "+TOKEN,"Content-Type":"application/json"})
            with urlopen(message,timeout=15) as response:
                got["code"]=response.status
                got["events"]=response.read().decode()
        t=threading.Thread(target=sender,daemon=True)
        t.start()
        lease=None
        for _ in range(75):
            lease=store.claim(self.db)
            if lease is not None:break
            time.sleep(.04)
        self.assertIsNotNone(lease)
        store.complete(self.db,lease["job_id"],lease["lease_token"],
                       {"tool_calls":[call("example_read_only","call_demo","{\"x\":2}")]})
        t.join(8)
        self.assertFalse(t.is_alive())
        self.assertEqual(got["code"],200)
        events=[json.loads(s[6:]) for s in got["events"].splitlines()
                if s.startswith("data: ") and s!="data: [DONE]"]
        chunks=[c for e in events for c in e["choices"]]
        calls=[x for c in chunks for x in c["delta"].get("tool_calls",[])]
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0]["index"],0)
        self.assertEqual(calls[0]["function"]["arguments"],"{\"x\":2}")
        self.assertEqual(chunks[-1]["finish_reason"],"tool_calls")
        self.assertTrue(got["events"].endswith("data: [DONE]\n\n"))
        self.assertFalse(any("usage" in e for e in events))

if __name__=="__main__":
    unittest.main()
