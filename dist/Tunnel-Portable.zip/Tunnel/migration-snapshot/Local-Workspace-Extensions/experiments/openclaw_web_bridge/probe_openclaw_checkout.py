"""Probe the cloned OpenClaw CLI with verified isolated Node, without login or Gateway.

Runs only harmless help/version/config-validation commands. Redirects state
and config into a temporary dir; no edits to system account or other projects.
"""
from __future__ import annotations
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]/"OpenClaw-lab"
NODE=HERE/"portable-node"/"node.exe"

def run(node,args,env):
    try:
        p=subprocess.run([str(node),str(ROOT/"openclaw.mjs"),*args],
                         cwd=ROOT,env=env,capture_output=True,text=True,
                         encoding="utf-8",errors="replace",timeout=40)
        return {"argv":args,"exit":p.returncode,
                "stdout":p.stdout[:2600],"stderr":p.stderr[:1200]}
    except (OSError,subprocess.TimeoutExpired) as exc:
        return {"argv":args,"error":type(exc).__name__}

def main():
    if not ROOT.is_dir() or not NODE.is_file():
        print(json.dumps({"ok":False,"error":"CHECKOUT_OR_NODE_MISSING"}))
        return 2
    with tempfile.TemporaryDirectory(prefix="openclaw-cli-probe-") as tmp:
        state=Path(tmp)
        env=dict(os.environ)
        env["OPENCLAW_STATE_DIR"]=str(state)
        env["OPENCLAW_CONFIG_PATH"]=str(state/"openclaw.json")
        env["PATH"]=str(NODE.parent)+os.pathsep+env.get("PATH","")
        env["NO_COLOR"]="1"
        # Config contains no credentials and is used only for validation.
        config={
           "agents":{"defaults":{"model":{"primary":"openai/gpt-6-astra"}}},
           "models":{"providers":{"openai":{"agentRuntime":{"id":"openclaw"}}}},
           "mcp":{"servers":{"local-workspace":{
                "url":"http://127.0.0.1:8765/mcp",
                "transport":"streamable-http","enabled":True,
                "toolFilter":{"include":["list_workspaces","list_directory","file_info","read_file","search_text","job_status","job_output"]}
           }}}
        }
        (state/"openclaw.json").write_text(json.dumps(config),encoding="utf-8")
        commands=[["--version"],["config","--help"],["config","validate"],
                  ["mcp","--help"]]
        results=[run(NODE,cmd,env) for cmd in commands]
        print(json.dumps({"node":str(NODE),"repo":str(ROOT),
                          "temp_config_no_auth":True,"results":results},ensure_ascii=True))
        return 0

if __name__=="__main__":
    sys.exit(main())
