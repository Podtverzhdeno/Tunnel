"""Loopback-only OpenAI Completions shim for an experimental scheduled-chat worker.

Not a real-time model API. No browser automation, session cookies, OpenAI API,
or automatic quota bypass. A separately authorized ChatGPT automation must
read jobs through Local Workspace MCP and explicitly complete them.
"""
from __future__ import annotations
import argparse
import hmac
import json
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from bridge_store import BridgeError, cancel_queued, submit, status, queue_summary, recovery_snapshot, validate_request, MAX_BODY

MODEL = "chatgpt-web-queued"
DEFAULT_DB = Path(__file__).resolve().parent / ".data" / "requests.sqlite3"


def completion(ident, row):
    answer=json.loads(row["answer_json"])
    calls=answer.get("tool_calls")
    message={"role":"assistant","content":answer.get("content")}
    if calls:
        message["tool_calls"]=calls
    return {
        "id":"chatcmpl-"+ident,
        "object":"chat.completion",
        "created":int(row["created"]),
        "model":MODEL,
        "choices":[{
            "index":0,
            "message":message,
            "finish_reason":"tool_calls" if calls else "stop",
        }],
        # Omit usage: ChatGPT Web provider usage is not available here.
        "system_fingerprint":None,
    }


class Handler(BaseHTTPRequestHandler):
    server_version="ChatBridge/0.1"
    sys_version=""
    def log_message(self, fmt, *args):
        # Do not log prompts, tokens or URLs containing user data.
        pass

    def _send(self, code, payload, headers=None):
        buf=json.dumps(payload,ensure_ascii=True,separators=(",",":")).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Content-Length",str(len(buf)))
        for key,val in (headers or {}).items():self.send_header(key,val)
        self.end_headers()
        try:self.wfile.write(buf)
        except (BrokenPipeError,ConnectionResetError):pass

    def _authorized(self):
        auth=self.headers.get("Authorization","")
        expected="Bearer "+self.server.local_token
        return hmac.compare_digest(auth,expected)

    def _error(self,ex):
        self._send(ex.http,{"error":{"message":ex.code,"type":"bridge_error","code":ex.code}})

    def do_GET(self):
        if not self._authorized():
            self._send(401,{"error":{"message":"UNAUTHORIZED","type":"auth_error"}})
            return
        route=urlsplit(self.path).path
        try:
            if route=="/v1/models":
                self._send(200,{"object":"list","data":[{
                    "id":MODEL,"object":"model","owned_by":"local-experimental-queue",
                    "created":0,
                }]})
            elif route=="/bridge/health":
                self._send(200,queue_summary(self.server.db_file))
            elif route=="/bridge/recovery":
                self._send(200,recovery_snapshot(self.server.db_file))
            elif route.startswith("/bridge/jobs/"):
                ident=route.removeprefix("/bridge/jobs/")
                row=status(self.server.db_file,ident)
                data={"id":ident,"status":row["status"],"created":row["created"],
                      "updated":row["updated"],"error_code":row["error_code"]}
                if row["status"]=="done":
                    data["completion"]=completion(ident,row)
                self._send(200,data)
            else:
                self._error(BridgeError("ROUTE_NOT_FOUND",404))
        except BridgeError as exc:self._error(exc)

    def do_POST(self):
        if not self._authorized():
            self._send(401,{"error":{"message":"UNAUTHORIZED","type":"auth_error"}})
            return
        route=urlsplit(self.path).path
        if route.startswith("/bridge/jobs/") and route.endswith("/cancel"):
            # A cancellation never reaches a claimed job. Do not let a retrying
            # HTTP client silently invalidate work whose outcome is uncertain.
            try:
                job_id=route[len("/bridge/jobs/"):-len("/cancel")]
                raw_length=self.headers.get("Content-Length","0")
                if "/" in job_id:
                    raise BridgeError("INVALID_CANCEL_REQUEST",400)
                if raw_length not in ("","0"):
                    # Drain bounded input before rejecting on Windows; closing
                    # a TCP socket with unread bytes may cause a reset instead
                    # of delivering the intended 400 error to the client.
                    if raw_length.isdecimal() and int(raw_length)<=MAX_BODY:
                        self.rfile.read(int(raw_length))
                    else:
                        self.close_connection=True
                    raise BridgeError("INVALID_CANCEL_REQUEST",400)
                self._send(200,cancel_queued(self.server.db_file,job_id))
            except BridgeError as exc:
                self._error(exc)
            return
        if route!="/v1/chat/completions":
            self._error(BridgeError("ROUTE_NOT_FOUND",404))
            return
        try:
            length=self.headers.get("Content-Length")
            if length is None or not length.isdecimal() or not 0<int(length)<=MAX_BODY:
                raise BridgeError("BODY_SIZE_INVALID",413)
            raw=self.rfile.read(int(length))
            try:request=json.loads(raw)
            except (UnicodeDecodeError,ValueError) as exc:raise BridgeError("INVALID_JSON") from exc
            validate_request(request)
            # Only authenticated clients may select an idempotency key. OpenClaw
            # does not send this header by default; independent model turns
            # therefore continue to generate distinct jobs.
            dedupe_key=self.headers.get("Idempotency-Key")
            ident=submit(self.server.db_file,request,idempotency_key=dedupe_key)
            end=time.monotonic()+self.server.wait_seconds
            row=None
            while time.monotonic()<end:
                row=status(self.server.db_file,ident)
                if row["status"] in ("done","failed","needs_reconcile"):break
                time.sleep(0.3)
            if row is None or row["status"] in ("queued","claimed"):
                # OpenClaw's OpenAI adapter cannot natively poll bridge jobs.
                # Return an explicit retryable error, never a fabricated answer.
                self._send(503,{"error":{
                    "message":"WORKER_PENDING_NOT_A_SYNCHRONOUS_MODEL",
                    "type":"temporarily_unavailable",
                    "code":"BRIDGE_PENDING",
                    "job_id":ident,
                }},{"Retry-After":"30","X-Bridge-Job-ID":ident})
            elif row["status"]=="done":
                if request.get("stream"):
                    self._send_stream(ident,row)
                else:self._send(200,completion(ident,row),{"X-Bridge-Job-ID":ident})
            else:
                self._send(503,{"error":{
                    "message":row["error_code"] or "WORKER_OUTCOME_UNVERIFIED",
                    "type":"bridge_error",
                    "code":row["status"],
                    "job_id":ident,
                }},{"X-Bridge-Job-ID":ident})
        except BridgeError as exc:self._error(exc)
        except (OSError,ValueError) as exc:
            self._error(BridgeError("LOCAL_BRIDGE_FAILURE",503))

    def _send_stream(self,ident,row):
        result=completion(ident,row)
        choice=result["choices"][0]
        created=result["created"]
        self.send_response(200)
        self.send_header("Content-Type","text/event-stream; charset=utf-8")
        self.send_header("Cache-Control","no-cache, no-store")
        self.send_header("X-Accel-Buffering","no")
        self.end_headers()
        def event(delta,finish):
            obj={"id":"chatcmpl-"+ident,"object":"chat.completion.chunk",
                 "model":MODEL,"created":created,
                 "choices":[{"index":0,"delta":delta,"finish_reason":finish}]}
            self.wfile.write(("data: "+json.dumps(obj,ensure_ascii=True)+"\n\n").encode())
            self.wfile.flush()
        try:
            event({"role":"assistant"},None)
            delta={}
            if choice["message"]["content"] is not None:
                delta["content"]=choice["message"]["content"]
            if delta:
                event(delta,None)
            # OpenAI streaming tool-call deltas need a stable per-call index.
            # A complete call can be delivered as one delta, but not as a
            # non-indexed tool_calls array (which many agent clients discard).
            for i,call in enumerate(choice["message"].get("tool_calls",[])):
                event({"tool_calls":[{
                    "index":i,
                    "id":call["id"],
                    "type":"function",
                    "function":{"name":call["function"]["name"],
                                "arguments":call["function"]["arguments"]},
                }]},None)
            event({},choice["finish_reason"])
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError):pass


class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,host,port,db_file,local_token,wait_seconds):
        if host!="127.0.0.1":
            raise BridgeError("LOOPBACK_ONLY")
        if type(local_token) is not str or len(local_token)<24:
            raise BridgeError("STRONG_LOCAL_BEARER_TOKEN_REQUIRED")
        if not 1<=wait_seconds<=300:
            raise BridgeError("WAIT_SECONDS_INVALID")
        super().__init__((host,port),Handler)
        self.db_file=db_file
        self.local_token=local_token
        self.wait_seconds=wait_seconds


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port",type=int,default=8786)
    parser.add_argument("--wait-seconds",type=int,default=180)
    parser.add_argument("--db",default=str(DEFAULT_DB))
    args=parser.parse_args()
    token=os.environ.get("OPENCLAW_BRIDGE_TOKEN","")
    try:
        server=Server("127.0.0.1",args.port,args.db,token,args.wait_seconds)
    except (BridgeError,OSError) as exc:
        parser.error(str(exc))
    print("OpenClaw experimental queue bridge listening on 127.0.0.1:%d"%args.port,flush=True)
    print("Model: "+MODEL+"; worker must be connected; no model tokens measured",flush=True)
    try:server.serve_forever(poll_interval=.4)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=="__main__":
    main()
