"""Inspect cloned checkout/build requirements; read-only and bounded."""
import json,os,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[3]/"OpenClaw-lab"
p=json.loads((root/"package.json").read_text(encoding="utf-8"))
out={
"path":str(root),"exists":root.is_dir(),"version":p.get("version"),
"packageManager":p.get("packageManager"),"engines":p.get("engines"),
"scripts":{k:v for k,v in p.get("scripts",{}).items() if k in ("build","build:runtime","build:cli","build:plugins","test","check","typecheck","prepare","postinstall")},
"node_modules":(root/"node_modules").exists(),"dist_entry":(root/"dist"/"entry.js").exists(),"lockfile":(root/"pnpm-lock.yaml").exists(),
"disk":{key:(shutil.disk_usage(root).free//(1024*1024*1024)) for key in ["free_gb"]},
}
print(json.dumps(out,ensure_ascii=True))
