"""Install prebuilt OpenClaw runtime into an isolated lab, with disk/time caps.

Original checked-out OpenClaw-lab remains untouched. No global installation,
no npm lifecycle scripts, no OpenAI/ChatGPT login and no running Gateway.
"""
from __future__ import annotations
import json,os,subprocess,sys,time,shutil
from collections import deque
from pathlib import Path

ROOT=Path(__file__).resolve().parent
NODE=ROOT/"portable-node"/"node.exe"
PNPM=ROOT/"portable-pnpm"/"bin"/"pnpm.mjs"
DEST=ROOT/"npm-runtime"
STORE=ROOT/"pnpm-store"
MAX_SECS=390
MIN_FREE_GIB=8
def main():
    if not NODE.is_file() or not PNPM.is_file() or not (DEST/"package.json").is_file():
        print("MISSING_ISOLATED_RUNTIME_COMPONENTS")
        return 2
    space=shutil.disk_usage(ROOT).free
    if space<MIN_FREE_GIB*1024**3+1024**3:
        print("INSUFFICIENT_FREE_SPACE",space//1024**3)
        return 2
    env=dict(os.environ)
    env["PATH"]=str(NODE.parent)+os.pathsep+env.get("PATH","")
    env["PNPM_HOME"]=str(ROOT/"pnpm-home")
    env["OPENCLAW_STATE_DIR"]=str(ROOT/"isolated-empty-state")
    env["NPM_CONFIG_UPDATE_NOTIFIER"]="false"
    cmd=[str(NODE),str(PNPM),"--dir",str(DEST),"add","openclaw@2026.10.9",
         "--ignore-scripts","--no-optional","--reporter=append-only",
         "--store-dir",str(STORE)]
    print("INSTALL_START free_gib",round(space/1024**3,2),"max_seconds",MAX_SECS,flush=True)
    try:
        p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT,text=True,encoding="utf-8",
                           errors="replace",bufsize=1)
    except OSError as exc:
        print("INSTALL_LAUNCH_FAILED",type(exc).__name__)
        return 2
    from threading import Thread
    tail=deque(maxlen=50)
    def drain():
        for line in p.stdout:
            tail.append(line.rstrip()[:600])
    th=Thread(target=drain,daemon=True);th.start()
    stopreason=None
    started=time.monotonic()
    try:
        while p.poll() is None:
            if time.monotonic()-started>MAX_SECS:
                stopreason="TIME_LIMIT"
                break
            if shutil.disk_usage(ROOT).free<MIN_FREE_GIB*1024**3:
                stopreason="DISK_RESERVE_GUARD"
                break
            time.sleep(3)
        if stopreason:
            p.kill()
            try:p.wait(timeout=12)
            except subprocess.TimeoutExpired:pass
    finally:
        th.join(timeout=5)
    print(json.dumps({"status":"guard_stop" if stopreason else "completed",
                      "reason":stopreason,"returncode":p.returncode,
                      "elapsed_sec":round(time.monotonic()-started,1),
                      "remaining_gib":round(shutil.disk_usage(ROOT).free/1024**3,2),
                      "log_tail":list(tail)[-30:],
                      "runtime_package":str(DEST),
                      "actual_entry":str(DEST/"node_modules"/"openclaw"/"openclaw.mjs"),
                      "install_scripts_executed":False},ensure_ascii=True),flush=True)
    return 0 if p.returncode==0 and not stopreason else 2

if __name__=="__main__":
    sys.exit(main())
