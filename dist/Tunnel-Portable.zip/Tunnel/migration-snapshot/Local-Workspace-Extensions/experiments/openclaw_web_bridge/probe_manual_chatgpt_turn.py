"""One live, manual ChatGPT-worker integration probe; isolated and consent-free.

This script NEVER generates model text, logs into ChatGPT, scrapes a browser,
starts a scheduled job or bypasses usage limits. It launches an isolated
OpenClaw agent and submits one synthetic question to the local queued adapter.
A separate human-authorized ChatGPT chat may inspect and answer exactly one
queued request via the existing worker.py CLI. Both sides are bounded.
"""
from __future__ import annotations
import json,os,subprocess,sys,tempfile,threading,time
from pathlib import Path
from server import Server
from smoke_openclaw_synthetic_model import HERE,NODE,CLI,SOURCE,TOKEN

CONTROL=HERE/".data"/"live_probe_control.json"
QUESTION="In this integration test, add 19 and 23. Reply with only the number."

def update(data):
    CONTROL.parent.mkdir(parents=True,exist_ok=True)
    tmp=CONTROL.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=True),encoding="utf-8")
    tmp.replace(CONTROL)

def main():
    if not all(p.is_file() for p in (NODE,CLI,SOURCE)):
        print(json.dumps({"ok":False,"error":"OPENCLAW_NOT_PREPARED"}),flush=True)
        return 2
    if CONTROL.exists():
        print(json.dumps({"ok":False,"error":"EXISTING_PROBE_CONTROL_REVIEW_BEFORE_RETRY"}),flush=True)
        return 2
    CONTROL.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="openclaw-live-chat-probe-",dir=HERE/".data") as temp:
        root=Path(temp)
        database=root/"queue.db"
        srv=Server("127.0.0.1",0,database,TOKEN,170)
        thread=threading.Thread(target=srv.serve_forever,daemon=True)
        thread.start()
        cfg=json.loads(SOURCE.read_text(encoding="utf-8"))
        cfg.pop("mcp",None)
        cfg["models"]["providers"]["local-chat-queue"]["baseUrl"]=(
            f"http://127.0.0.1:{srv.server_address[1]}/v1")
        cfg["models"]["providers"]["local-chat-queue"]["apiKey"]=TOKEN
        cfg["agents"]["defaults"]["workspace"]=str(root/"workspace")
        cfg["tools"]={"deny":["*"]}
        conf=root/"openclaw.json"
        conf.write_text(json.dumps(cfg),encoding="utf-8")
        env=dict(os.environ)
        env.update({"OPENCLAW_STATE_DIR":str(root/"state"),
                    "OPENCLAW_CONFIG_PATH":str(conf),
                    "PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
                    "NO_COLOR":"1"})
        update({"schema":"openclaw-chat-manual-probe-v1",
                "status":"running",
                "db_path":str(database),"port":srv.server_address[1],
                "answer_expected":"42","model":"chatgpt-web-queued",
                "question":QUESTION,"real_model_input_source":"this_chat_only",
                "external_mcp_enabled":False})
        print("LIVE_PROBE_READY "+str(CONTROL),flush=True)
        cmd=[str(NODE),str(CLI),"agent","--local",
             "--message",QUESTION,"--session-id","isolated-one-turn-gpt-worker",
             "--model","local-chat-queue/chatgpt-web-queued",
             "--timeout","170","--json"]
        try:
            p=subprocess.run(cmd,cwd=HERE/"npm-runtime",env=env,
                             capture_output=True,text=True,encoding="utf-8",
                             errors="replace",timeout=210)
            success=p.returncode==0 and '"42"' in p.stdout
            result={"status":"completed" if success else "failed",
                    "cli_returncode":p.returncode,
                    "answer_observed":'"42"' in p.stdout,
                    "stdout_tail":p.stdout[-1700:] if not success else "REDACTED_SUCCESS",
                    "stderr_tail":p.stderr[-900:] if not success else ""}
        except (subprocess.TimeoutExpired,OSError) as exc:
            result={"status":"failed","error":type(exc).__name__}
        finally:
            srv.shutdown();srv.server_close();thread.join(3)
        # Do not keep a stale DB path after disposable state deletion.
        update({"schema":"openclaw-chat-manual-probe-v1",
                "status":result["status"],
                "cli_returncode":result.get("cli_returncode"),
                "answer_observed":result.get("answer_observed",False),
                "model":"chatgpt-web-queued","external_mcp_enabled":False})
        print(json.dumps({"ok":result["status"]=="completed",
                          "result":result,"model_responses_generated_by_script":0,
                          "chatgpt_web_extraction_performed":False},ensure_ascii=True),
              flush=True)
        return 0 if result["status"]=="completed" else 2

if __name__=="__main__":
    sys.exit(main())
