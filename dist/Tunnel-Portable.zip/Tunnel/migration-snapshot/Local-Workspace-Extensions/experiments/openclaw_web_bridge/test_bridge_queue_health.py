"""Queue expiry, crash reconciliation and safe health endpoint regression.

All tests use disposable SQLite/loopback server, no model or MCP connection.
"""
from __future__ import annotations
import json
import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import patch

import bridge_store as bridge
from server import Server

REQ={"model":"chatgpt-web-queued","messages":[
    {"role":"user","content":"private-synthetic-prompt-never-in-health"}]}
TOKEN="test-health-protected-local-bearer-0123456789"


class QueueExpiryTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.db=Path(self.t.name)/"queue.sqlite3"

    def _age(self,job,seconds,field="created"):
        with closing(sqlite3.connect(self.db)) as con:
            con.execute(f"UPDATE requests SET {field}={field}-? WHERE id=?",
                        (seconds,job))
            con.commit()

    def test_stale_unclaimed_job_fails_and_is_never_claimed(self):
        old=bridge.submit(self.db,REQ)
        self._age(old,bridge.MAX_QUEUE_AGE_SECONDS+10)
        self.assertIsNone(bridge.claim(self.db))
        state=bridge.status(self.db,old)
        self.assertEqual(state["status"],"failed")
        self.assertEqual(state["error_code"],"QUEUE_WAIT_EXPIRED")

    def test_new_submission_expires_old_queue_entry(self):
        old=bridge.submit(self.db,REQ)
        self._age(old,bridge.MAX_QUEUE_AGE_SECONDS+10)
        other={"model":"chatgpt-web-queued","messages":[{"role":"user","content":"next"}]}
        with patch.object(bridge,"MAX_PENDING",1):
            new=bridge.submit(self.db,other)
        self.assertNotEqual(new,old)
        self.assertEqual(bridge.status(self.db,old)["error_code"],"QUEUE_WAIT_EXPIRED")
        self.assertEqual(bridge.status(self.db,new)["status"],"queued")

    def test_active_claim_never_expires_as_queued(self):
        job=bridge.submit(self.db,REQ)
        lease=bridge.claim(self.db)
        self._age(job,bridge.MAX_QUEUE_AGE_SECONDS+10)
        fresh=bridge.submit(self.db,{
            "model":"chatgpt-web-queued","messages":[{"role":"user","content":"next"}]})
        self.assertEqual(bridge.status(self.db,job)["status"],"claimed")
        bridge.complete(self.db,job,lease["lease_token"],{"content":"real test response"})
        self.assertEqual(bridge.status(self.db,job)["status"],"done")
        self.assertEqual(bridge.status(self.db,fresh)["status"],"queued")

    def test_expired_claim_is_reconciliation_not_retry(self):
        job=bridge.submit(self.db,REQ)
        lease=bridge.claim(self.db)
        with closing(sqlite3.connect(self.db)) as con:
            con.execute("UPDATE requests SET lease_until=0 WHERE id=?",(job,))
            con.commit()
        self.assertIsNone(bridge.claim(self.db))
        state=bridge.status(self.db,job)
        self.assertEqual(state["status"],"needs_reconcile")
        self.assertEqual(state["error_code"],"LEASE_EXPIRED_OUTCOME_UNKNOWN")
        with self.assertRaisesRegex(bridge.BridgeError,"LEASE_UNAVAILABLE"):
            bridge.complete(self.db,job,lease["lease_token"],{"content":"late"})

    def test_reusing_idempotency_key_does_not_silently_requeue_expired(self):
        job=bridge.submit(self.db,REQ,"long-running-key-0000")
        self._age(job,bridge.MAX_QUEUE_AGE_SECONDS+10)
        bridge.claim(self.db)
        same=bridge.submit(self.db,REQ,"long-running-key-0000")
        self.assertEqual(same,job)
        self.assertEqual(bridge.status(self.db,same)["status"],"failed")

    def test_read_only_queue_summary_has_no_raw_prompt_data(self):
        self.assertEqual(bridge.queue_summary(self.db)["inflight"],0)
        job=bridge.submit(self.db,REQ)
        summary=bridge.queue_summary(self.db)
        self.assertEqual(summary["counts"]["queued"],1)
        self.assertEqual(summary["inflight"],1)
        self.assertGreaterEqual(summary["oldest_queued_age_seconds"],0)
        self.assertNotIn("private-synthetic-prompt",json.dumps(summary))
        self.assertFalse(summary["actual_model_usage_known"])
        self.assertFalse(summary["host_actor_authenticated"])
        self.assertEqual(bridge.status(self.db,job)["status"],"queued")


class HealthEndpointTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.db=Path(self.t.name)/"server.sqlite3"
        self.server=Server("127.0.0.1",0,self.db,TOKEN,1)
        self.worker=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.worker.start()
        self.addCleanup(lambda:(self.server.shutdown(),self.server.server_close(),self.worker.join(3)))
        self.base="http://127.0.0.1:"+str(self.server.server_address[1])
    def get(self,path,token=TOKEN):
        req=Request(self.base+path,headers={"Authorization":"Bearer "+token})
        try:
            with urlopen(req,timeout=4) as response:
                return response.status,json.loads(response.read())
        except HTTPError as err:
            return err.code,json.loads(err.read())

    def test_health_endpoint_is_authenticated(self):
        code,_=self.get("/bridge/health",token="invalid")
        self.assertEqual(code,401)
        self.assertFalse(self.db.exists())

    def test_health_counters_match_jobs_without_exposing_prompts(self):
        job=bridge.submit(self.db,REQ)
        code,data=self.get("/bridge/health")
        self.assertEqual(code,200)
        self.assertEqual(data["schema"],"openclaw-bridge-queue-health-v1")
        self.assertEqual(data["counts"]["queued"],1)
        self.assertNotIn("private-synthetic-prompt",json.dumps(data))
        lease=bridge.claim(self.db)
        bridge.complete(self.db,job,lease["lease_token"],{"content":"test done"})
        code,data=self.get("/bridge/health")
        self.assertEqual(code,200)
        self.assertEqual(data["counts"]["done"],1)
        self.assertEqual(data["inflight"],0)

if __name__=="__main__":
    unittest.main()
