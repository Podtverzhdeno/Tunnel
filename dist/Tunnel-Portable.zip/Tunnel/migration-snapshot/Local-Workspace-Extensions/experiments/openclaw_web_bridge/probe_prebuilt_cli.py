"""Offline runtime CLI smoke in an isolated temp state, no OAuth/model request.

Uses installed OpenClaw 2026.10.9 package with separately verified Node 26.
"""
import json,os,subprocess,sys,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
NODE=HERE/"portable-node"/"node.exe"
CLI=HERE/"npm-runtime"/"node_modules"/"openclaw"/"openclaw.mjs"
LAB=HERE/"openclaw.queued-model.LAB-only.json"

def run(args,env):
    try:
        proc=subprocess.run([str(NODE),str(CLI),*args],cwd=HERE/"npm-runtime",
            env=env,capture_output=True,text=True,encoding="utf-8",
            errors="replace",timeout=55)
        return {"args":args,"returncode":proc.returncode,
                "stdout":proc.stdout[-4500:],"stderr":proc.stderr[-2400:]}
    except (subprocess.TimeoutExpired,OSError) as exc:
        return {"args":args,"error":type(exc).__name__}

def main():
    if not NODE.is_file() or not CLI.is_file() or not LAB.is_file():
        print(json.dumps({"ok":False,"reason":"RUNTIME_MISSING"}))
        return 2
    with tempfile.TemporaryDirectory(prefix="openclaw-probe-") as tmp:
        root=Path(tmp)
        env=dict(os.environ)
        env.update({
            "OPENCLAW_STATE_DIR":str(root),
            "OPENCLAW_CONFIG_PATH":str(root/"openclaw.json"),
            "OPENCLAW_BRIDGE_TOKEN":"ISOLATED_DUMMY_NOT_REAL_SESSION_CREDENTIAL",
            "PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
            "NO_COLOR":"1",
        })
        (root/"openclaw.json").write_text(LAB.read_text(encoding="utf-8"),encoding="utf-8")
        results=[run(args,env) for args in (
            ["--version"],["config","validate"],["mcp","--help"],["models","--help"],
            ["models","list","--json"],["mcp","list","--json"],["mcp","probe","--help"])]
        print(json.dumps({"isolated_state":True,"gateway_started":False,
            "oauth_attempted":False,"mcp_remote_called":False,"tests":results},ensure_ascii=True))
        return 0
if __name__=="__main__":
    sys.exit(main())
