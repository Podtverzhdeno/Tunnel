"""Offline regression tests for isolated OpenClaw + local custom provider config.

No running Gateway, login, session tokens, or network MCP probe.
"""
from __future__ import annotations
import json,os,subprocess,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
NODE=HERE/"portable-node"/"node.exe"
APP=HERE/"npm-runtime"/"node_modules"/"openclaw"/"openclaw.mjs"
CONFIG=HERE/"openclaw.queued-model.LAB-only.json"

class OfflineRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not all(x.is_file() for x in (NODE,APP,CONFIG)):
            raise unittest.SkipTest("isolated OpenClaw runtime not installed")
        cls.temp=tempfile.TemporaryDirectory(prefix="openclaw-offline-tests-")
        cls.path=Path(cls.temp.name)
        (cls.path/"openclaw.json").write_text(CONFIG.read_text(encoding="utf-8"),encoding="utf-8")
        cls.env=dict(os.environ)
        cls.env.update({"OPENCLAW_STATE_DIR":str(cls.path),
                        "OPENCLAW_CONFIG_PATH":str(cls.path/"openclaw.json"),
                        "OPENCLAW_BRIDGE_TOKEN":"DUMMY_LOCAL_TEST_VALUE_NOT_A_REAL_KEY",
                        "PATH":str(NODE.parent)+os.pathsep+cls.env.get("PATH",""),
                        "NO_COLOR":"1"})
    @classmethod
    def tearDownClass(cls):
        if hasattr(cls,"temp"):cls.temp.cleanup()
    @classmethod
    def run_cli(cls,*args):
        return subprocess.run([str(NODE),str(APP),*args],
            cwd=HERE/"npm-runtime",env=cls.env,capture_output=True,text=True,
            encoding="utf-8",errors="replace",timeout=40)

    def test_real_runtime_version(self):
        p=self.run_cli("--version")
        self.assertEqual(p.returncode,0,p.stderr[-1200:])
        self.assertIn("OpenClaw 2026.10.9",p.stdout)

    def test_real_runtime_validates_custom_model_and_mcp(self):
        p=self.run_cli("config","validate")
        self.assertEqual(p.returncode,0,p.stderr[-1500:])
        self.assertIn("Config valid",p.stdout)

    def test_model_catalog_contains_local_queue_without_fake_openai_account(self):
        p=self.run_cli("models","list","--json")
        self.assertEqual(p.returncode,0,p.stderr[-1500:])
        d=json.loads(p.stdout)
        self.assertEqual(d["count"],1)
        self.assertEqual(d["models"][0]["key"],"local-chat-queue/chatgpt-web-queued")

    def test_mcp_config_registered_read_only(self):
        p=self.run_cli("mcp","list","--json")
        self.assertEqual(p.returncode,0,p.stderr[-1500:])
        cfg=json.loads(p.stdout)["local-workspace"]
        self.assertEqual(cfg["url"],"http://127.0.0.1:8765/mcp")
        self.assertFalse(cfg["supportsParallelToolCalls"])
        allowed=cfg["toolFilter"]["include"]
        self.assertNotIn("run_command",allowed)
        self.assertNotIn("write_file",allowed)

if __name__=="__main__":
    unittest.main()
