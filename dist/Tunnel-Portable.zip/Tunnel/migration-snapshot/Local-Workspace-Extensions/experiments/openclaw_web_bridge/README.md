# OpenClaw + ChatGPT subscription + Local Workspace MCP

## Post-timeout OpenClaw notification outbox — 2026-11-02

OpenClaw's current Gateway supports bearer-protected `POST /hooks/wake` with `mode: now` and admission receipts `eventOutcome: queued/coalesced`. This is the **supported asynchronous event channel**, separate from the OpenAI-style synchronous model API. Official reference: https://docs.openclaw.ai/gateway/config-hooks

New isolated modules `result_outbox.py`, `openclaw_wake_dispatcher.py`:
- A crash-safe SQLite outbox is materialized from committed terminal bridge jobs; one event per original job across process restarts, no plaintext model input/output copied to the notification log.
- Short delivery leases, up to five attempts with bounded backoff, conservative recovery of uncertain HTTP responses. **At-least-once**, not exactly-once remote delivery. Duplicate notifications are harmless only if receiving agents use their own idempotent job processing.
- **Opt-in only:** by default the dispatcher performs a local dry-run sync. An explicit `--dispatch-once` and a secure `OPENCLAW_HOOK_TOKEN` in process environment are required before any wake HTTP request. Transport is restricted to `http://127.0.0.1:<port>/hooks/wake`, rejects redirects and URL credentials. No production Gateway was configured or contacted.
- A fixed-format notification includes only job ID and final state. It is not a model answer. The recipient fetches the answer separately from the authenticated bridge if authorized.

**Critical limitation:** OpenClaw wake events initiate a *new agent event*, rather than resuming the original, timed-out model call. A receiving OpenClaw agent using only this same delayed queue model would recursively enqueue another job and can deadlock. A distinct ready model or independent control-plane handler is needed. This design therefore supports delayed *notifications* but is **not** an autonomous ChatGPT Web replacement model. No automated subscription-limit bypass is built or asserted.

Tests: `test_result_outbox.py` 17 PASS (fake loopback Gateway, negative SSRF/auth checks, no leaked content, durable restarts, concurrent delivery reservation, bounded retry/leases). Full bridge unittest discovery: **100 PASS**. `WORKER_RUNBOOK.md` documents deployment prerequisites and the disabled-by-default delivery path.



## Queue lease reliability milestone — 2026-11-02

This experimental local model transport supports three additional guarded controls:

1. **Queued-only cancellation** via authenticated `POST /bridge/jobs/JOB_ID/cancel`. A queued job becomes terminal `failed / CLIENT_CANCELLED_BEFORE_CLAIM`, with no schema migration. Claimed or uncertain jobs return 409 and cannot be silently interrupted. Explicit cancel never occurs merely because an HTTP client timed out.
2. **Read-only recovery view** via authenticated `GET /bridge/recovery`. It reports IDs of expired claimed leases and already-`needs_reconcile` jobs, without raw prompts, output text or lease tokens. It cannot approve retry, change actor roles, or convert an uncertain result into a new job.
3. **Bounded worker heartbeat** via `worker.py --db <db> heartbeat JOB_ID`. A valid lease token can extend a still-live claim by up to 15 minutes from the call, **never beyond 60 minutes after first claim**. The new additive `request_lease_envelopes` table stores the first claim timestamp and heartbeat counts. Expired/legacy/foreign leases fail closed. The model HTTP client still has its separate **1–300 s** response wait and therefore an hourly scheduled agent is not a real-time provider.

Security and testing: `test_bridge_cancellation.py` (10 PASS); `test_bridge_recovery.py` (8 PASS); `test_bridge_heartbeat.py` (8 PASS). Full bridge suite **83 PASS**. A separate real OpenClaw 2026.10.9 **synthetic backend** smoke completed two queued turns, one built-in tool call, CLI exit 0, no worker errors after these changes. This does not claim an autonomous ChatGPT Web backend is running. The previous manual single-response ChatGPT-to-OpenClaw test remains the only live ChatGPT reply experiment.

See `WORKER_RUNBOOK.md` for operator safety, authorization limitations and how to distinguish lease failure, cancellation, outstanding work and unknown outcomes.



## First chat-mediated real ChatGPT response — 2026-11-02

`probe_manual_chatgpt_turn.py` launched the **real OpenClaw 2026.10.9 embedded harness** in a disposable local profile and deliberately did **not** create an automated model worker. The OpenClaw user prompt was `In this integration test, add 19 and 23. Reply with only the number.`. The current ChatGPT conversation obtained the queued job through Local Workspace MCP, authored the model response `42`, wrote it as the worker answer file, and explicitly completed the job through `worker.py`. Observed:

- Queue job `823cd51e2b794e568e9f309942de39e1` completed with `worker.py status=COMPLETED`.
- Isolated OpenClaw CLI reported `cli_returncode=0`, `answer_observed=true` and the live experiment script reported `ok=true`.
- This **does** verify a ChatGPT-generated response can traverse the tested MCP/SQLite/HTTP adapter and appear as a model response in OpenClaw.
- This **does not** attach a real-time, scheduled or unlimited ChatGPT inference backend. The ChatGPT worker action was manually performed within one chat turn, without browser scraping or API credentials. Scheduled-task quotas and model token usage were not measured.
- Experiment control record: `.data/live_probe_control.json` retains only completion status. The disposable HTTP server and temporary SQLite/OpenClaw profile were stopped and removed. The model was **not** automatically available to any third-party user.

### Safe worker packets (post-probe hardening)

`worker.py claim` now stores the complete untrusted OpenClaw request in a **separate** `.data/claims/{job_id}.json` file and returns only role names, message/tool counts and the path — **never the complete prompt or lease token in CLI/MCP stdout**. An authorized worker must deliberately open the packet as untrusted input and complete via `.data/answers/{job_id}.json` plus `worker.py complete JOB_ID`. Lease tokens are separately stored in `.data/leases/`, never printed. This reduces accidental text disclosure in MCP logs but **does not** isolate secrets from other processes with access to the same Windows account/workspace. Don't put production credentials, sensitive prompts or third-party personal data in this lab without an OS-enforced worker identity, ACL separation, encrypted storage and retention policy.

`test_worker_packet.py`: 4 PASS including redaction from stdout, completion from separate file, no re-claim of live jobs and fail-closed packet overwrite.



## Cross-process concurrency and worker handoff — 2026-11-02

After a full bridge-suite stress run exposed intermittent `database is locked` on Windows, `bridge_store.connect()` now serializes schema initialization **within the process**, avoids repeatedly resetting an already-WAL journal mode, and uses SQLite's busy timeout for cross-process contention. The actual atomic idempotency boundary remains the `BEGIN IMMEDIATE` transaction and unique `request_idempotency.key_sha256` constraint. `test_bridge_multiprocess.py`: four independent Windows Python processes launched simultaneously all returned the **same job ID** and produced exactly one SQLite request/receipt. It does not claim zero lock failures under every possible filesystem or cross-host environment; this remains local-SQLite-only.

For future bounded scheduled-worker integration read **`WORKER_RUNBOOK.md`** before claiming work. The worker explicitly handles only one queued model turn at a time, treats full OpenClaw messages as untrusted data, validates names of requested function calls, and reports unknown model usage as unknown. Never turn the disposable manual probe into a persistent public model API without worker identity, consent, secure storage and latency design.

The previous manual ChatGPT experiment's completed lease and answer files were moved to reversible private trash after success; no live bearer or unfinished lease remains in that experiment's local `.data` tree. Control metadata with the confirmed OpenClaw exit result remains available.

## Reliable queued-model transport — 2026-11-02

This lab now implements **explicit per-request idempotency** for clients that provide an `Idempotency-Key` header (ASCII, 8–128 chars). The mapping is transactional in the SQLite WAL: one key with the exact same canonical request maps to **one original job**, even after completion; changing the request under the same key is an HTTP **409** (`IDEMPOTENCY_KEY_PAYLOAD_CONFLICT`), not a second model turn. The key is stored only as SHA-256; it is never an authorization credential. Without a key each request remains a separate model invocation. **OpenClaw does not automatically send this header in our current test configuration**, so the feature must not be advertised as automatic OpenClaw deduplication.

Retry example for a separately authorized local HTTP client:
```text
POST /v1/chat/completions
Authorization: Bearer <locally configured strong bearer>
Idempotency-Key: client-generated-unique-turn-id
Content-Type: application/json

{"model":"chatgpt-web-queued","messages":[{"role":"user","content":"synthetic example"}]}
```
When the worker has not responded within the wait window, the service returns `503 BRIDGE_PENDING` with `job_id`. A follow-up request with the **same body and idempotency key** returns the original job result when ready. A response can also be polled by `GET /bridge/jobs/{id}` using the same bearer. This is an asynchronous queue, not a synchronous ChatGPT Web model API. Never equate `503` with model failure or claim the provider generated an answer.

**Queue hygiene:** an unclaimed queued job older than 24 hours is marked `failed / QUEUE_WAIT_EXPIRED` at the next queue admission/claim sweep; its idempotency receipt remains intact, so replaying an old key does **not** silently relaunch work. A claimed job whose lease expires is instead marked `needs_reconcile / LEASE_EXPIRED_OUTCOME_UNKNOWN`, because work could have occurred and must not be repeated blindly.

**Privacy-conscious health:** authenticated `GET /bridge/health` returns only aggregate status counts, number in flight and age of oldest queued job. It never returns prompt contents, generated responses, lease tokens or ChatGPT usage estimates. Explicit `actual_model_usage_known=false` and `host_actor_authenticated=false` make the current limitations visible.

**Validation:** `test_bridge_idempotency.py`: 12 PASS, including simultaneous same-key submissions (eight threads, exactly one SQLite job), queued HTTP retry, response replay and conflict rejection; `test_bridge_queue_health.py`: 8 PASS, including expiry, never replaying uncertain claimed work and protected health counters. Neither test makes real GPT calls or touches the production MCP server.

**Production warning:** the SQLite file contains raw submitted prompts and answers in plaintext. This is a local isolated experiment only, not a secure multi-user service. Do not expose the loopback HTTP port to the internet or allow untrusted users to submit requests. Retention/encryption, authenticated worker identity, rate limits per client, full model usage receipts and provider-specific semantics are still unimplemented.



## Persistent OpenClaw session across separate CLI processes — 2026-11-02

`smoke_openclaw_session_persistence.py` completed successfully using **two independently launched OpenClaw CLI processes with the same isolated session ID**, zero real model requests and zero external MCP calls. Both returned exit code 0. The first outbound model request carried `system,user` roles; the second carried `system,user,assistant,user`. The prior synthetic assistant reply was verified present in the second outbound model request. The disposable queue worker completed exactly two jobs, and all temporary state was cleaned up. This verifies continuity of agent conversation context across process restarts for this synthetic harness; it does not prove reliability of scheduled ChatGPT worker delivery.

## Strict tool permission boundary — 2026-11-02

`bridge_store.py` now checks a proposed worker tool-call **against the exact function names declared in the originating OpenClaw request**. Duplicate declared names, duplicate worker call IDs, unknown function names and `tool_choice: none` escapes fail closed before any completion is committed. Only caller-defined tool names can be propagated into OpenClaw's tool loop. The caller's original tools remain the authoritative permission envelope; this does not authenticate the worker or replace actual host authorization. `server.py` SSE now includes a per-call `tool_calls[].index` as required by the OpenAI-compatible streaming protocol. `test_bridge_tool_policy.py`: nine PASS including negative privilege checks and a real streaming event assertion.

Full project regression following changes: `python -m unittest discover -q` — **1197 tests, 31 skipped, 0 failures**. The new isolated persistent-session smoke completed separately; these long-running harness smoke tests are not included in the fast default unittest discovery.

## Completed two-turn OpenClaw tool loop — 2026-11-02

`smoke_openclaw_tool_loop.py` passed on the **real isolated OpenClaw 2026.10.9 embedded agent runtime** using the synthetic queue backend only:
- Two model requests were received, claimed and completed through local HTTP + SQLite; both were distinct jobs with fresh lease credentials.
- First model response returned a single declared, read-only built-in `tool_search` call in a correctly indexed OpenAI SSE tool-call delta.
- OpenClaw executed its own built-in `tool_search` (reported `toolSummary.calls=1, failures=0`). The second model request contained the four roles `system → user → assistant → tool`, preserving tool-call and tool-result context.
- The synthetic second response was `SYNTHETIC_TOOL_LOOP_COMPLETE_NOT_CHATGPT`; OpenClaw reported CLI exit 0, `runner=embedded`, `stopReason=stop` and terminal reply with that exact text. It **did not call any external MCP tool, real model or subscription service**.
- Prior negative and protocol tests: `test_bridge_tool_policy.py` (9 PASS) verifies only caller-declared tools may be emitted by the worker, duplicate IDs are denied, `tool_choice=none` cannot call tools, and SSE `tool_calls[].index` is present. The worker cannot escalate OpenClaw tool permissions by inventing a name. This is mandatory before enabling any independent backend.

### Reproduce in the existing lab (no real model/network)
```powershell
cd C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions\\experiments\\openclaw_web_bridge
python test_bridge.py
python test_bridge_tool_policy.py
python test_openclaw_offline_runtime.py
python smoke_openclaw_synthetic_model.py
python smoke_openclaw_tool_loop.py
```

The smoke scripts use loopback ephemeral ports, short-lived temp config directories and disposable SQLite files, with only their own synthetic workers. They do not contact ChatGPT, touch the existing `8765` host, modify OAuth credentials or install a persistent Gateway. The test tool `tool_search` is an OpenClaw built-in and searches only inside the deliberately isolated harness profile.

**Unresolved for genuine ChatGPT-as-model use:** the bridge has no real model worker attached, cannot guarantee a synchronous OpenClaw response when work is driven by scheduled sessions, cannot authenticate worker identities at the MCP host trust boundary, and should not be exposed remotely without a separate hardened broker. Actual ChatGPT provider usage and quota are unknown. This smoke does not establish a bypass or unlimited access.

## Successful OpenClaw harness E2E smoke — 2026-11-02

`smoke_openclaw_synthetic_model.py` now passes with **real OpenClaw embedded runtime** (CLI exit 0). The model path `local-chat-queue/chatgpt-web-queued` sent an OpenAI-compatible request to our loopback HTTP server, SQLite WAL queued it, a test-only synthetic worker claimed and completed it, and OpenClaw emitted `finalAssistantVisibleText=SYNTHETIC_BACKEND_RESPONSE_NOT_CHATGPT`, `runner=embedded`, `stopReason=stop`. The provider execution trace marked this route successful. **This is a protocol/integration test with a fake model; it proves neither ChatGPT Web model access nor any exception from usage limits.**

Bugs found and fixed via actual protocol testing:
- OpenClaw automatically includes `stream_options: {include_usage: true}`; our `bridge_store.validate_request` now permits and strictly validates that field, without inventing model usage receipts. Added malformed-options regression tests.
- A model declared with `contextWindow=8192` failed *before* making an HTTP request because OpenClaw's default system bootstrap estimated >8962 input tokens. LAB model config now declares `contextWindow=65536` for **synthetic testing only**; this is not a claim about a real ChatGPT session context limit.
- Initial synthetic worker lifetime expired before embedded runtime initialized; test worker now waits through the entire bounded CLI session. Worker token is generated and used only inside temp directory.
- `config validate` was intermittently blocked by missing Windows Koffi/fs-safe optional binaries; installed required platform optional packages isolated via `install_optional_natives.py`, still with `--ignore-scripts`. Repeated four real CLI regression tests all PASS.
- Active `openclaw mcp probe` was blocked by the local security boundary, so tool connectivity is still **registered/configured, not network-E2E verified**. Do not bypass the block.

Remaining production gaps: real authorized model backend, supported account authentication if using OpenAI, authenticated per-agent local MCP actor, encrypted/retained job data, strict worker identity, idempotent/latency-aware synchronous responses, native module functionality checks and Gateways/skills owner consent. The synthetic test explicitly omitted MCP and all real model credentials.

## Verified local runtime — 2026-11-02 (latest)

- **Working prebuilt runtime**: `experiments/openclaw_web_bridge/npm-runtime/node_modules/openclaw/openclaw.mjs`, OpenClaw **2026.10.9** (npm build `8b18b55`), installed using repository-pinned **pnpm 12.15.0** and isolated **Node 26.12.1**. 333 packages; dependency lifecycle scripts skipped. The source checkout in `C:\\Users\\user\\IdeaProjects\\OpenClaw-lab` remains clean and is a separate Git revision `d56403f` (not identical to npm build).
- **Config accepted by real OpenClaw CLI**: `openclaw config validate` returned exit 0 / `Config valid` for `openclaw.queued-model.LAB-only.json` with isolated temporary `OPENCLAW_CONFIG_PATH`, dummy local variable for unresolved bearer, and no existing user account access.
- **Model registered (not answering)**: `openclaw models list --json` returned exactly the custom model `local-chat-queue/chatgpt-web-queued`, marked default. It is *local config only*; `available: true` does **NOT** mean a real ChatGPT model is reachable. No actual scheduled worker/ChatGPT model backend is connected and port 8786 is not running.
- **MCP configuration parsed**: `openclaw mcp list --json` returned `local-workspace` at `http://127.0.0.1:8765/mcp` with only the seven read-only tools and `supportsParallelToolCalls=false`. This verifies registration, not a network handshake. The attempted active probe was blocked by the local tool safety boundary; do not claim E2E MCP OpenClaw connectivity.
- **No user OAuth login, no Gateway startup, no credential export, no live GPT inference, and no modification of existing Local Workspace MCP host.** The deferred `pnpm approve` for OpenClaw agent skills has not been granted. Prebuilt runtime emitted an optional `fs-safe` native dependency warning because lifecycle scripts were skipped; do not assume all native functionality works.
- **Reproducible offline tests**: `probe_prebuilt_cli.py` and `test_openclaw_offline_runtime.py`; the latter asserts actual installed CLI version, config validation, custom model registration and MCP configuration without invoking a tool or model. `test_bridge.py` has in-process synthetic worker HTTP tests, not actual ChatGPT responses.



## Real cloned-source experiment (2026-11-02)

Repository successfully cloned to `C:\\Users\\user\\IdeaProjects\\OpenClaw-lab` from `https://github.com/openclaw/openclaw.git`, shallow filtered branch `main`, checked-out commit `d56403f`, 62,728 tracked checkout entries, clean upstream worktree. `node openclaw.mjs --version` reported OpenClaw 2026.10.9.

Existing system Node 24.14.0 is **unsupported**; `node openclaw.mjs config --help` refused to run. Downloaded official, checksum-verified portable Node 26.12.1 into this experiment's `portable-node/node.exe` without touching system PATH. Official archive SHA256: `b3efd5c70cba3308ed46e7e699a9b8aac075bbc6b027fcb39c84c31acc25e2b4`.

With portable Node, the version command works, but live `config validate` and `mcp --help` correctly fail because Git source does not include `dist/entry.js` until `pnpm install && pnpm build:runtime`. No global pnpm or system Node updates attempted; no OAuth, Gateway, or third-party account has been opened.

`openclaw.queued-model.LAB-only.json` is an isolated **NOT DEPLOYED** custom `models.providers.local-chat-queue` config for `http://127.0.0.1:8786/v1` using `openai-completions`, with local MCP `127.0.0.1:8765` restricted to read-only discovery tools. The queue shim is not serving on 8786, and it is not a supported ChatGPT subscription model API. It returns 503 if no independently authorized worker responds; no fabricated model turns, no streaming tokens manufactured. Do not copy this config to an actual OpenClaw account before a separately approved backend exists.

`test_cloned_openclaw.py`: 6 PASS for real local repo modules, OpenClaw runtime selector, model/MCP config, isolated Node and MCP loopback port. Earlier `test_bridge.py`: 13 PASS (in-process fake-worker HTTP tests, NOT OpenClaw live inference).

Source-verified integration points:
- `OpenClaw-lab/src/config/schema.help.models.ts`: `models.providers.*.agentRuntime.id` and `agents.defaults.models.*.agentRuntime.id`
- `OpenClaw-lab/src/agents/agent-bundle-mcp-runtime.ts`: MCP registration and tool discovery
- `OpenClaw-lab/src/agents/agent-runtime-config.ts`: scoped agent config resolution, SecretRefs
- `OpenClaw-lab/package.json`: pinned pnpm workspace and build scripts

To build the actual OpenClaw checkout later, use the repository-pinned pnpm and portable Node 26 on a dedicated branch/sandbox. Prefer `pnpm build:runtime` for a runtime-only build; preserve the existing `OpenClaw-lab` upstream source clean until a specific change is reviewed. Do not run onboarding automatically.



## Recommended supported route — GPT as model, OpenClaw as harness

The OpenClaw docs (checked 2026-11-02) explicitly support an OpenAI OAuth profile with the built-in **OpenClaw agent runtime**. This is NOT the native Codex agent harness and NOT a ChatGPT browser scraping proxy.

- Model/provider: `openai/gpt-6-astra` (or a different model visible to this account).
- Auth: `openclaw models auth login --provider openai --method oauth`.
- Runtime: `models.providers.openai.agentRuntime.id="openclaw"`.
- Tools: our existing Local Workspace MCP, streamable HTTP, at `http://127.0.0.1:8765/mcp` **if OpenClaw runs on the SAME PC**.
- Suggested config MERGE fragment: `openclaw.subscription-harness.partial.json`. Do not overwrite an existing `openclaw.json` wholesale. These settings must be merged with pre-existing providers, channels, agents and secrets.

OpenClaw CLI is currently **not found on PATH** on the local Windows PC (read-only probe); Node is present and Local Workspace port 8765 is open. Thus no live OpenClaw model turn or OpenClaw MCP connection has been verified. We cannot complete login for the user through a Local Workspace tool: OAuth requires the owner's explicit login/consent.

### When OpenClaw is installed

Use the supported CLI on the OpenClaw host to authenticate once:

```powershell
openclaw models auth login --provider openai --method oauth
```

Keep existing config; merge the content of `openclaw.subscription-harness.partial.json` and inspect it before saving. An alternative to manual JSON editing is OpenClaw's Control UI, Settings -> Models and Settings -> MCP. To connect Local Workspace as a separate tool server on this same computer:

```powershell
openclaw mcp add local-workspace --url http://127.0.0.1:8765/mcp --transport streamable-http --include "list_workspaces,list_directory,file_info,read_file,search_text,job_status,job_output"
openclaw mcp doctor local-workspace --probe
openclaw models status
```

Only grant `run_script`, `write_file`, `run_command`, Git tools, etc. to a separately reviewed trusted OpenClaw agent with proper approval and least-privilege policies. The existing MCP host has OS user privileges and does not currently authenticate per-agent roles (P085).

To verify the *actual harness* inspect the completed run or `/status`; it should indicate **OpenClaw runtime**, not **OpenAI Codex**. Merely setting `agentRuntime.id` is not evidence of a successful model request.

If OpenClaw runs on another machine, `127.0.0.1:8765` refers to THAT machine. Use an authenticated private SSH/local port forward or a protected HTTPS tunnel for the MCP transport; do not publish the current unauthenticated server to the public Internet.

### Architectural distinction

```text
OpenClaw (channels, tools, memory, agent loop)
      |-- Model: OpenAI ChatGPT/Codex OAuth transport -> GPT
      |           agentRuntime.id = openclaw (NOT Codex harness)
      |-- Tools: Local Workspace MCP 127.0.0.1:8765
      |-- Existing scheduled ChatGPT agents may independently use same MCP
```

This uses supported OpenClaw authentication; it is subject to subscription usage limits, and does not promise unlimited tokens.

Sources (vendor docs):
- https://docs.openclaw.ai/concepts/agent-runtimes
- https://docs.openclaw.ai/providers/openai/setup
- https://docs.openclaw.ai/providers/openai/authentication
- https://docs.openclaw.ai/cli/mcp

## Experimental alternate route — queued completions shim, NOT connected to ChatGPT Web

This folder also contains a **non-deployed LAB prototype**:
- `bridge_store.py`: SQLite WAL request queue, bounded payloads, lease digests, duplicate/expired lease checks, conservative unknown outcome.
- `server.py`: loopback-only HTTP, bearer token mandatory, `GET /v1/models`, `POST /v1/chat/completions`, `GET /bridge/jobs/{id}`, supports a subset of OpenAI messages, function calls and SSE.
- `worker.py`: local queued-job claim and explicit completion using a response JSON file, not a model.
- `test_bridge.py`: 13 independent integration tests, all PASS on Windows, no OpenAI/API/ChatGPT calls.
- `probe_environment.py`: non-mutating dependency and port check.

The shim **has no model backend attached**. It cannot generate any output by itself. If no worker actually completes a request within the server wait window, it returns HTTP 503 with job ID and `BRIDGE_PENDING`, never a false model answer. No OpenClaw adapter is configured to use this queued shim by default. It cannot promise the latency/throughput required for an interactive OpenClaw harness.

Any worker must be independently authorized to handle model requests. Do not build an unapproved automatic ChatGPT Web output extractor, scrape browser/session cookies, infer missing token counts, claim exemption from subscription limits, or give arbitrary third parties access via the owner's account. ChatGPT Scheduled Tasks are not a supported low-latency third-party model API.

For a self-contained lab of the queue (no model calls):
```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\openclaw_web_bridge
python test_bridge.py
```

To run the HTTP shim locally **only for explicit experiments with a separate authorized worker**, first set a high-entropy `OPENCLAW_BRIDGE_TOKEN` in your own secure environment, then run `python server.py --port 8786`. Leave this listener bound to `127.0.0.1` only. It is NOT a drop-in GPT web inference service and will respond 503 until independently completed jobs exist.

Security notes: SQLite stores raw submitted prompts and outputs in plaintext on the local disk; file-based worker lease tokens are not host-authenticated and other local agents with project file access could read them. This is NOT suitable for third-party/multi-tenant production until OS isolation, ACLs, encryption, secure identity, retention, and prompt-injection boundaries exist.
