"""Inspect live MCP tools from an isolated OpenClaw CLI, without invoking them.

Never runs an agent/model, never writes OpenClaw user auth or main MCP state.
"""
from __future__ import annotations
import json,os,subprocess,sys,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
NODE=HERE/"portable-node"/"node.exe"
CLI=HERE/"npm-runtime"/"node_modules"/"openclaw"/"openclaw.mjs"
CONFIG=HERE/"openclaw.queued-model.LAB-only.json"
def main():
    with tempfile.TemporaryDirectory(prefix="openclaw-mcp-test-") as tmp:
        t=Path(tmp)
        (t/"openclaw.json").write_text(CONFIG.read_text(encoding="utf-8"),encoding="utf-8")
        env=dict(os.environ)
        env.update({"OPENCLAW_STATE_DIR":str(t),"OPENCLAW_CONFIG_PATH":str(t/"openclaw.json"),
                    "OPENCLAW_BRIDGE_TOKEN":"ISOLATED_DUMMY_NOT_A_REAL_SECRET",
                    "PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
                    "NO_COLOR":"1"})
        try:
            p=subprocess.run([str(NODE),str(CLI),"mcp","probe","local-workspace","--json"],
                cwd=HERE/"npm-runtime",env=env,capture_output=True,text=True,
                encoding="utf-8",errors="replace",timeout=70)
        except (subprocess.TimeoutExpired,OSError) as ex:
            print(json.dumps({"ok":False,"error":type(ex).__name__}))
            return 2
        try:
            obj=json.loads(p.stdout)
            keys=obj.keys() if isinstance(obj,dict) else []
            print(json.dumps({"ok":p.returncode==0,"exit_code":p.returncode,
                "keys":list(keys),"details":obj if len(p.stdout)<12000 else str(obj)[:9000],
                "stderr_tail":p.stderr[-1400:],"mcp_tools_executed":False},ensure_ascii=True))
        except ValueError:
            print(json.dumps({"ok":p.returncode==0,"exit_code":p.returncode,
                              "stdout_tail":p.stdout[-8500:],"stderr_tail":p.stderr[-1600:]}))
        return 0 if p.returncode==0 else 2
if __name__=="__main__":
    sys.exit(main())
