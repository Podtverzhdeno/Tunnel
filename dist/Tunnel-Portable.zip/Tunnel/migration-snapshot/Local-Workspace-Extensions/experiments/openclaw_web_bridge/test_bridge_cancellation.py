"""Queue cancellation and restart-safe recovery checks.

No external model, OpenClaw account, scheduler, or live MCP host involved.
Cancellation is allowed only for queued work; claimed work is never silently
stopped or retried because its result may already exist.
"""
from __future__ import annotations
import json
import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import bridge_store as store
from server import Server

REQ={"model":"chatgpt-web-queued","messages":[
    {"role":"user","content":"Synthetic cancellation request"}]}
TOKEN="bridge-cancel-tests-0123456789-strong-bearer"

class CancelStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"queue.db"
    def test_cancelled_unclaimed_request_is_never_delivered(self):
        jid=store.submit(self.db,REQ)
        result=store.cancel_queued(self.db,jid)
        self.assertTrue(result["cancelled_now"])
        self.assertEqual(result["error_code"],"CLIENT_CANCELLED_BEFORE_CLAIM")
        self.assertEqual(store.status(self.db,jid)["status"],"failed")
        self.assertIsNone(store.claim(self.db))
    def test_repeat_cancel_is_idempotent_without_restart(self):
        jid=store.submit(self.db,REQ,"unique-request-key-00001")
        self.assertTrue(store.cancel_queued(self.db,jid)["cancelled_now"])
        self.assertFalse(store.cancel_queued(self.db,jid)["cancelled_now"])
        self.assertEqual(store.submit(self.db,REQ,"unique-request-key-00001"),jid)
        self.assertIsNone(store.claim(self.db))
    def test_cannot_cancel_active_claim(self):
        jid=store.submit(self.db,REQ)
        task=store.claim(self.db)
        with self.assertRaisesRegex(store.BridgeError,"CANNOT_CANCEL_CLAIMED_OR_UNCERTAIN_WORK"):
            store.cancel_queued(self.db,jid)
        self.assertEqual(store.status(self.db,jid)["status"],"claimed")
        store.complete(self.db,jid,task["lease_token"],{"content":"finished"})
    def test_cannot_cancel_uncertain_lease(self):
        jid=store.submit(self.db,REQ)
        store.claim(self.db)
        with closing(sqlite3.connect(self.db)) as con:
            con.execute("UPDATE requests SET lease_until=0 WHERE id=?",(jid,))
            con.commit()
        store.claim(self.db)
        self.assertEqual(store.status(self.db,jid)["status"],"needs_reconcile")
        with self.assertRaisesRegex(store.BridgeError,"CANNOT_CANCEL_CLAIMED_OR_UNCERTAIN_WORK"):
            store.cancel_queued(self.db,jid)
    def test_completed_is_not_retroactively_cancelled(self):
        jid=store.submit(self.db,REQ)
        task=store.claim(self.db)
        store.complete(self.db,jid,task["lease_token"],{"content":"already done"})
        result=store.cancel_queued(self.db,jid)
        self.assertEqual(result["status"],"done")
        self.assertFalse(result["cancelled_now"])
        self.assertEqual(json.loads(store.status(self.db,jid)["answer_json"])["content"],"already done")
    def test_invalid_or_absent_ids_do_not_create_jobs(self):
        for jid in ("../x","",123,"zz"*16,"a"*33):
            with self.subTest(value=jid):
                with self.assertRaisesRegex(store.BridgeError,"INVALID_JOB_ID"):
                    store.cancel_queued(self.db,jid)
        with self.assertRaisesRegex(store.BridgeError,"JOB_NOT_FOUND"):
            store.cancel_queued(self.db,"0"*32)
        with closing(store.connect(self.db)) as con:
            self.assertEqual(con.execute("SELECT COUNT(*) FROM requests").fetchone()[0],0)

class CancelHttpTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"server.db"
        self.server=Server("127.0.0.1",0,self.db,TOKEN,1)
        self.worker=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.worker.start()
        self.addCleanup(self.stop)
        self.base="http://127.0.0.1:"+str(self.server.server_address[1])
    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.worker.join(3)
    def post(self,jid,*,token=TOKEN,body=None):
        headers={"Authorization":"Bearer "+token}
        request=Request(self.base+"/bridge/jobs/"+jid+"/cancel",
                        data=b"" if body is None else body,
                        headers=headers,method="POST")
        try:
            with urlopen(request,timeout=6) as response:
                return response.status,json.loads(response.read())
        except HTTPError as ex:
            return ex.code,json.loads(ex.read())
    def test_authenticated_cancel_and_job_status(self):
        jid=store.submit(self.db,REQ)
        code,data=self.post(jid)
        self.assertEqual(code,200)
        self.assertTrue(data["cancelled_now"])
        self.assertEqual(store.status(self.db,jid)["error_code"],"CLIENT_CANCELLED_BEFORE_CLAIM")
    def test_no_access_for_untrusted_http_client(self):
        jid=store.submit(self.db,REQ)
        code,_=self.post(jid,token="untrusted")
        self.assertEqual(code,401)
        self.assertEqual(store.status(self.db,jid)["status"],"queued")
    def test_cancel_claimed_returns_conflict(self):
        jid=store.submit(self.db,REQ)
        store.claim(self.db)
        code,data=self.post(jid)
        self.assertEqual(code,409)
        self.assertEqual(data["error"]["code"],"CANNOT_CANCEL_CLAIMED_OR_UNCERTAIN_WORK")
    def test_bad_cancel_path_or_body_fails(self):
        jid=store.submit(self.db,REQ)
        code,data=self.post(jid,body=b"not an empty cancel")
        self.assertEqual(code,400)
        self.assertEqual(data["error"]["code"],"INVALID_CANCEL_REQUEST")
        code,data=self.post("invalid")
        self.assertEqual(code,404)
        self.assertEqual(data["error"]["code"],"INVALID_JOB_ID")
        self.assertEqual(store.status(self.db,jid)["status"],"queued")

if __name__=="__main__":
    unittest.main()
