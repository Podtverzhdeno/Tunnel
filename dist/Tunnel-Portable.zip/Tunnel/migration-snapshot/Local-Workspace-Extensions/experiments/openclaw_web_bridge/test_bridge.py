"""Offline/in-process tests; no OpenAI or ChatGPT requests, no MCP host changes."""
from __future__ import annotations
import json
import sqlite3
from contextlib import closing
import tempfile
import threading
import time
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import bridge_store as store
from server import MODEL, Server

TOKEN="integration-test-token-no-real-secret-12345"
REQUEST={"model":MODEL,"messages":[{"role":"user","content":"Hello"}],"stream":False}


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"queue.sqlite3"

    def test_enqueued_job_needs_real_response(self):
        job=store.submit(self.db,REQUEST)
        state=store.status(self.db,job)
        self.assertEqual(state["status"],"queued")
        self.assertIsNone(state["answer_json"])
        claimed=store.claim(self.db)
        self.assertEqual(claimed["job_id"],job)
        self.assertEqual(claimed["messages"][0]["content"],"Hello")
        self.assertIsNone(store.claim(self.db))
        store.complete(self.db,job,claimed["lease_token"],{"content":"Real worker supplied this"})
        state=store.status(self.db,job)
        self.assertEqual(state["status"],"done")
        self.assertEqual(json.loads(state["answer_json"])["content"],"Real worker supplied this")
        with self.assertRaises(store.BridgeError):
            store.complete(self.db,job,claimed["lease_token"],{"content":"replay"})

    def test_unauthorized_lease_is_rejected(self):
        job=store.submit(self.db,REQUEST)
        claimed=store.claim(self.db)
        with self.assertRaises(store.BridgeError):
            store.complete(self.db,job,"wrong",{"content":"fake"})
        self.assertEqual(store.status(self.db,job)["status"],"claimed")
        store.fail(self.db,job,claimed["lease_token"],"TASK_ERROR")
        self.assertEqual(store.status(self.db,job)["status"],"failed")

    def test_expired_lease_fails_closed_and_not_replayed(self):
        ident=store.submit(self.db,REQUEST)
        claimed=store.claim(self.db)
        with closing(sqlite3.connect(self.db)) as conn:
            conn.execute("UPDATE requests SET lease_until=0 WHERE id=?",(ident,))
            conn.commit()
        self.assertIsNone(store.claim(self.db))
        self.assertEqual(store.status(self.db,ident)["status"],"needs_reconcile")
        with self.assertRaises(store.BridgeError):
            store.complete(self.db,ident,claimed["lease_token"],{"content":"late"})

    def test_no_invented_usage(self):
        ident=store.submit(self.db,REQUEST)
        from server import completion
        got=store.claim(self.db)
        store.complete(self.db,ident,got["lease_token"],{"content":"Hello"})
        response=completion(ident,store.status(self.db,ident))
        self.assertNotIn("usage",response)

    def test_function_call_round_trip(self):
        req=dict(REQUEST)
        req["tools"]=[{"type":"function","function":{"name":"read_status",
                     "description":"Status","parameters":{"type":"object","properties":{}}}}]
        ident=store.submit(self.db,req)
        token=store.claim(self.db)["lease_token"]
        call={"id":"call_42","type":"function","function":{"name":"read_status","arguments":"{}"}}
        store.complete(self.db,ident,token,{"content":None,"tool_calls":[call]})
        result=json.loads(store.status(self.db,ident)["answer_json"])
        self.assertEqual(result["tool_calls"][0]["function"]["name"],"read_status")

    def test_function_result_context_allowed(self):
        req=dict(REQUEST)
        req["messages"]=[
            {"role":"assistant","content":None,
             "tool_calls":[{"id":"call_42","type":"function",
                            "function":{"name":"read_status","arguments":"{}"}}]},
            {"role":"tool","tool_call_id":"call_42","content":"Done"},
        ]
        store.validate_request(req)

    def test_invalid_requests_denied(self):
        examples=[
            {"model":MODEL,"messages":[]},
            {"model":MODEL,"messages":[{"role":"user","content":["not text"]}]},
            {"model":MODEL,"messages":[{"role":"user","content":"x"}],"unknown":1},
            {"model":"fake-model","messages":REQUEST["messages"]},
            {"model":MODEL,"messages":[{"role":"user","content":"x"*34000}]},
            {"model":MODEL,"messages":[{"role":"tool","content":"x"}]},
            {"model":MODEL,"messages":REQUEST["messages"],"stream":"yes"},
            {"model":MODEL,"messages":REQUEST["messages"],"stream_options":{"include_usage":"true"}},
            {"model":MODEL,"messages":REQUEST["messages"],"stream_options":{"unexpected":True}},
        ]
        for invalid in examples:
            with self.subTest(invalid=str(invalid)[:100]):
                with self.assertRaises(store.BridgeError):
                    store.validate_request(invalid)

    def test_answer_schema_denial(self):
        ident=store.submit(self.db,REQUEST)
        token=store.claim(self.db)["lease_token"]
        for invalid in ({},{"content":"" ,"extra":"no"},{"tool_calls":[{"type":"function"}]},
                        {"tool_calls":[{"id":"x","type":"function","function":{
                            "name":"foo","arguments":"not-json"}}]}):
            with self.subTest(invalid=invalid):
                with self.assertRaises(store.BridgeError):
                    store.complete(self.db,ident,token,invalid)


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/"bridge.db"
        self.server=Server("127.0.0.1",0,self.db,TOKEN,1)
        self.host="http://127.0.0.1:"+str(self.server.server_address[1])
        th=threading.Thread(target=self.server.serve_forever,daemon=True)
        th.start()
        self.addCleanup(lambda:(self.server.shutdown(),self.server.server_close(),th.join(2)))

    def req(self,path,body=None,token=TOKEN):
        data=None if body is None else json.dumps(body).encode()
        headers={"Authorization":"Bearer "+token}
        if data is not None:headers["Content-Type"]="application/json"
        request=Request(self.host+path,data=data,headers=headers,
                        method="GET" if body is None else "POST")
        try:
            with urlopen(request,timeout=8) as resp:
                return resp.status,dict(resp.headers),resp.read()
        except HTTPError as err:
            return err.code,dict(err.headers),err.read()

    def test_bad_token_never_reveals_models(self):
        status,_,_=self.req("/v1/models",token="bad")
        self.assertEqual(status,401)

    def test_models_catalog(self):
        code,_,payload=self.req("/v1/models")
        self.assertEqual(code,200)
        self.assertEqual(json.loads(payload)["data"][0]["id"],MODEL)

    def test_pending_is_error_not_fake_text(self):
        code,headers,payload=self.req("/v1/chat/completions",REQUEST)
        self.assertEqual(code,503)
        data=json.loads(payload)
        self.assertEqual(data["error"]["code"],"BRIDGE_PENDING")
        ident=data["error"]["job_id"]
        self.assertEqual(self.req("/bridge/jobs/"+ident)[0],200)
        self.assertEqual(store.status(self.db,ident)["status"],"queued")

    def test_actual_completion_returned(self):
        result={}
        def caller():
            result["response"]=self.req("/v1/chat/completions",REQUEST)
        t=threading.Thread(target=caller)
        t.start()
        claim=None
        for _ in range(30):
            claim=store.claim(self.db)
            if claim:break
            time.sleep(.05)
        self.assertIsNotNone(claim)
        store.complete(self.db,claim["job_id"],claim["lease_token"],{"content":"Real response"})
        t.join(6)
        self.assertFalse(t.is_alive())
        code,headers,payload=result["response"]
        self.assertEqual(code,200)
        obj=json.loads(payload)
        self.assertEqual(obj["choices"][0]["message"]["content"],"Real response")
        self.assertNotIn("usage",obj)

    def test_stream_completion_sse(self):
        result={}
        req=dict(REQUEST,stream=True)
        t=threading.Thread(target=lambda:result.update(response=self.req("/v1/chat/completions",req)))
        t.start()
        claim=None
        for _ in range(30):
            claim=store.claim(self.db)
            if claim:break
            time.sleep(.05)
        self.assertIsNotNone(claim)
        store.complete(self.db,claim["job_id"],claim["lease_token"],{"content":"streamed"})
        t.join(6)
        code,headers,payload=result["response"]
        self.assertEqual(code,200)
        self.assertIn("text/event-stream",headers["Content-Type"])
        self.assertIn(b"data: [DONE]",payload)
        self.assertIn(b"streamed",payload)


if __name__=="__main__":
    unittest.main()
