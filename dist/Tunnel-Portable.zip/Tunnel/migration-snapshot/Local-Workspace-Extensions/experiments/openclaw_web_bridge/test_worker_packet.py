"""No-prompt-in-stdout tests for the experimental MCP worker CLI.

Raw OpenClaw prompts are stored only in a separate untrusted claim packet,
not echoed into the MCP job output. This is not a security boundary between
local users with access to the same workspace.
"""
from __future__ import annotations
import argparse
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import bridge_store as store
import worker

SENSITIVE="CONFIDENTIAL_SYNTHETIC_CONTEXT_SENTINEL"
REQ={
    "model":"chatgpt-web-queued",
    "messages":[
        {"role":"system","content":"Synthetic system instruction "+SENSITIVE},
        {"role":"user","content":"What is 19 + 23?"},
    ],
    "tools":[{"type":"function","function":{"name":"synthetic_lookup",
              "parameters":{"type":"object","properties":{}}}}],
}

class WorkerPacketTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.db=self.root/"queue.sqlite3"
        self.data=self.root/"private_worker_files"
        self.patch=patch.object(worker,"DATA",self.data)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def command(self,action,job_id=None,reason=None):
        return worker.run(argparse.Namespace(
            db=str(self.db),command=action,job_id=job_id,reason=reason
        ))

    def test_claim_stdout_has_no_prompt_token_or_tools_schema(self):
        job=store.submit(self.db,REQ)
        response=self.command("claim")
        self.assertEqual(response["job_id"],job)
        self.assertEqual(response["status"],"CLAIMED_UNVERIFIED_WORKER")
        self.assertFalse(response["host_actor_authenticated"])
        self.assertFalse(response["raw_messages_written_to_stdout"])
        self.assertEqual(response["message_roles"],["system","user"])
        self.assertEqual(response["tool_count"],1)
        output=json.dumps(response)
        self.assertNotIn(SENSITIVE,output)
        self.assertNotIn("What is 19 + 23?",output)
        self.assertNotIn("lease_token",output)
        self.assertNotIn("synthetic_lookup",output)
        packet_path=Path(response["claim_packet_file"])
        packet=json.loads(packet_path.read_text(encoding="utf-8"))
        self.assertIn(SENSITIVE,packet["messages"][0]["content"])
        self.assertEqual(packet["job_id"],job)
        self.assertEqual(packet["schema"],"openclaw-queued-claim-v1")
        self.assertFalse(self.data.joinpath("leases",job+".token").stat().st_size==0)

    def test_packet_can_be_completed_without_emitting_prompt(self):
        ident=store.submit(self.db,REQ)
        claim=self.command("claim")
        worker.safe_write(self.data/"answers"/(ident+".json"),
                          json.dumps({"content":"42"}))
        result=self.command("complete",ident)
        self.assertEqual(result["status"],"COMPLETED")
        self.assertNotIn(SENSITIVE,json.dumps(result))
        self.assertEqual(store.status(self.db,ident)["status"],"done")
        self.assertEqual(json.loads(store.status(self.db,ident)["answer_json"])["content"],"42")

    def test_duplicate_claim_returns_no_work_not_stale_token(self):
        store.submit(self.db,REQ)
        self.assertEqual(self.command("claim")["status"],"CLAIMED_UNVERIFIED_WORKER")
        again=self.command("claim")
        self.assertEqual(again["status"],"NO_PENDING_WORK")

    def test_untrusted_existing_claim_packet_refuses_overwrite(self):
        ident=store.submit(self.db,REQ)
        bad_path=self.data/"claims"/(ident+".json")
        worker.safe_write(bad_path,"{\"untrusted\":true}")
        with self.assertRaisesRegex(store.BridgeError,"JOB_FILE_ALREADY_EXISTS_RECONCILE"):
            self.command("claim")
        self.assertEqual(store.status(self.db,ident)["status"],"claimed")

if __name__=="__main__":
    unittest.main()
