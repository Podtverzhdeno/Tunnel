"""Offline inspection of native deps needed by prebuilt OpenClaw install."""
from pathlib import Path
import json
base=Path(__file__).resolve().parent/"npm-runtime"
app=base/"node_modules"/"openclaw"
pkg=json.loads((app/"package.json").read_text(encoding="utf-8"))
keys=("koffi","fs-safe","sqlite","native","node-pty","sharp")
hits={cat:{k:v for k,v in pkg.get(cat,{}).items() if any(t in k.lower() for t in keys)}
      for cat in ("dependencies","optionalDependencies","peerDependencies")}
dirs={}
for name in ("koffi","@openclaw/fs-safe","@openclaw/fs-safe-native","better-sqlite3"):
    p=base/"node_modules"/name
    dirs[name]={"exists":p.exists(),"is_symlink":p.is_symlink()}
print(json.dumps({"deps":hits,"dirs":dirs,"package":pkg.get("version")},ensure_ascii=True))
