"""Two-turn OpenClaw harness smoke with an explicitly synthetic tool call.

The first model response requests OpenClaw's built-in read-only tool_search.
The second returns a deterministic synthetic answer. No real MCP server,
ChatGPT, session cookie, API model or unrestricted tools are involved.
"""
from __future__ import annotations
import json,os,subprocess,sys,tempfile,threading,time
from pathlib import Path
import bridge_store as store
from server import Server
from smoke_openclaw_synthetic_model import (ProbeHandler,HERE,NODE,CLI,SOURCE,TOKEN)

ANSWER="SYNTHETIC_TOOL_LOOP_COMPLETE_NOT_CHATGPT"
class TraceHandler(ProbeHandler):
    def do_POST(self):
        super().do_POST()
        self.server.shapes.append(dict(self.server.http_shape))

def main():
    if not all(p.is_file() for p in (NODE,CLI,SOURCE)):
        print(json.dumps({"ok":False,"reason":"ISOLATED_RUNTIME_MISSING"}))
        return 2
    with tempfile.TemporaryDirectory(prefix="openclaw-tool-loop-") as d:
        root=Path(d)
        db=root/"queue.sqlite3"
        srv=Server("127.0.0.1",0,db,TOKEN,25)
        srv.RequestHandlerClass=TraceHandler
        srv.http_codes=[]
        srv.reasons=[]
        srv.http_shape={}
        srv.shapes=[]
        server_thread=threading.Thread(target=srv.serve_forever,daemon=True)
        server_thread.start()
        observation={"claims":0,"completions":0,"errors":[],
                     "offered_tool_names":[],"arg_keys":[],"turn_kinds":[]}
        worker_stop=threading.Event()
        def worker():
            finish=time.monotonic()+110
            while not worker_stop.is_set() and time.monotonic()<finish:
                try:
                    job=store.claim(db)
                    if not job:
                        time.sleep(.15)
                        continue
                    observation["claims"]+=1
                    names=[t["function"]["name"] for t in (job["tools"] or [])
                           if t.get("type")=="function"]
                    if observation["claims"]==1:
                        observation["offered_tool_names"]=names
                        if "tool_search" not in names:
                            observation["errors"].append("NO_READ_ONLY_DISCOVERY_TOOL")
                            store.fail(db,job["job_id"],job["lease_token"],"UNSUPPORTED_REQUEST")
                            break
                        function=next(t["function"] for t in job["tools"]
                                      if t.get("type")=="function" and t["function"]["name"]=="tool_search")
                        params=function.get("parameters") or {}
                        observation["arg_keys"]=sorted((params.get("properties") or {}).keys())
                        # This is deliberately harmless: inspect tool descriptors,
                        # never execute an external process or a Local Workspace tool.
                        args={"query":"synthetic metadata lookup"}
                        response={"tool_calls":[{
                            "id":"call_synthetic_lookup_1","type":"function",
                            "function":{"name":"tool_search","arguments":json.dumps(args)}
                        }]}
                    elif observation["claims"]==2:
                        observation["turn_kinds"]=[m.get("role") for m in job["messages"]]
                        response={"content":ANSWER}
                    else:
                        observation["errors"].append("UNEXPECTED_THIRD_MODEL_TURN")
                        store.fail(db,job["job_id"],job["lease_token"],"TASK_ERROR")
                        break
                    store.complete(db,job["job_id"],job["lease_token"],response)
                    observation["completions"]+=1
                    if observation["completions"]>=2:break
                except Exception as exc:
                    observation["errors"].append(type(exc).__name__+":"+str(exc)[:100])
                    break
        th=threading.Thread(target=worker,daemon=True)
        th.start()
        cfg=json.loads(SOURCE.read_text(encoding="utf-8"))
        cfg.pop("mcp",None)
        provider=cfg["models"]["providers"]["local-chat-queue"]
        provider["baseUrl"]=f"http://127.0.0.1:{srv.server_address[1]}/v1"
        provider["apiKey"]=TOKEN
        cfg["agents"]["defaults"]["workspace"]=str(root/"workspace")
        cfg["tools"]={"deny":["*"]}
        conf=root/"openclaw.json"
        conf.write_text(json.dumps(cfg),encoding="utf-8")
        env=dict(os.environ)
        env.update({"OPENCLAW_STATE_DIR":str(root/"state"),
                    "OPENCLAW_CONFIG_PATH":str(conf),
                    "PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
                    "NO_COLOR":"1"})
        args=[str(NODE),str(CLI),"agent","--local",
              "--message","Perform a harmless synthetic test, then return a short completion.",
              "--session-id","openclaw-synthetic-tool-loop",
              "--model","local-chat-queue/chatgpt-web-queued",
              "--timeout","60","--json"]
        try:
            proc=subprocess.run(args,cwd=HERE/"npm-runtime",env=env,
                capture_output=True,text=True,encoding="utf-8",
                errors="replace",timeout=95)
            result={"cli_exit":proc.returncode,"stdout_tail":proc.stdout[-2400:],
                    "stderr_tail":proc.stderr[-1800:]}
        except (subprocess.TimeoutExpired,OSError) as exc:
            result={"error":type(exc).__name__}
        worker_stop.set()
        th.join(3)
        srv.shutdown()
        srv.server_close()
        server_thread.join(3)
        passed=(result.get("cli_exit")==0 and observation["completions"]==2
                and ANSWER in result.get("stdout_tail","")
                and not observation["errors"])
        print(json.dumps({"ok":passed,"observation":observation,"http_codes":srv.http_codes,
                          "http_errors":srv.reasons,"request_shapes":srv.shapes,
                          "result":result,
                          "synthetic_only":True,"chatgpt_contacted":False,
                          "external_mcp_contacted":False},ensure_ascii=True))
        return 0 if passed else 2
if __name__=="__main__":
    sys.exit(main())
