"""Read only OpenClaw agent command usage using isolated Node and empty state."""
import json,os,subprocess,tempfile
from pathlib import Path
r=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix="oc-help-") as t:
    env=dict(os.environ)
    env.update({"OPENCLAW_STATE_DIR":t,"OPENCLAW_CONFIG_PATH":str(Path(t)/"openclaw.json"),
                "PATH":str(r/"portable-node")+os.pathsep+env.get("PATH",""),
                "NO_COLOR":"1"})
    p=subprocess.run([str(r/"portable-node"/"node.exe"),str(r/"npm-runtime"/"node_modules"/"openclaw"/"openclaw.mjs"),"agent","--help"],cwd=r/"npm-runtime",env=env,
                     capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=40)
    print(json.dumps({"returncode":p.returncode,"stdout":p.stdout[-7500:],"stderr":p.stderr[-1500:]},ensure_ascii=True))
