"""Bounded durable job queue for an experimental OpenClaw -> scheduled-chat bridge.

This is NOT a ChatGPT API, subscription entitlement, model credential,
or an authenticated MCP actor. The scheduled ChatGPT worker must explicitly
claim and complete each job; the queue never fabricates model results.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import threading
import time
import uuid
from pathlib import Path

MAX_PENDING = 100
# Expire only UNCLAIMED jobs. Claimed jobs with uncertain results remain
# needs_reconcile; never silently requeue work that might have side effects.
MAX_QUEUE_AGE_SECONDS = 24 * 3600
MAX_BODY = 64_000
MAX_OUTPUT = 32_000
LEASE_SECONDS = 900
MAX_LEASE_LIFETIME_SECONDS = 3600

# Connecting and running schema DDL are serialized inside this process;
# SQLite transactions still provide the cross-process exclusion/atomicity.
_SCHEMA_INIT_LOCK = threading.RLock()

class BridgeError(ValueError):
    def __init__(self, code, http=400):
        super().__init__(code)
        self.code = code
        self.http = http


def connect(path):
    db = Path(path)
    if db.is_symlink() or getattr(db, "is_junction", lambda: False)():
        raise BridgeError("DATABASE_LINK_DENIED")
    db.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(db), isolation_level=None, timeout=30)
    con.row_factory = sqlite3.Row
    try:
        with _SCHEMA_INIT_LOCK:
            con.execute("PRAGMA busy_timeout=30000")
            # PRAGMA journal_mode=WAL can itself require an exclusive lock.
            # Avoid repeatedly writing the journal mode on every connection.
            mode=con.execute("PRAGMA journal_mode").fetchone()[0]
            if mode.lower() != "wal":
                con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA foreign_keys=ON")
            con.executescript("""
    CREATE TABLE IF NOT EXISTS requests (
      id TEXT PRIMARY KEY,
      digest TEXT NOT NULL,
      model TEXT NOT NULL,
      messages_json TEXT NOT NULL,
      tools_json TEXT,
      status TEXT NOT NULL CHECK(status IN
        ('queued','claimed','done','failed','needs_reconcile')),
      created REAL NOT NULL,
      updated REAL NOT NULL,
      lease_until REAL,
      lease_digest TEXT,
      answer_json TEXT,
      error_code TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_requests_ready ON requests(status,created);
    -- Separate mapping avoids changing existing requests schema and keeps
    -- duplicate submits atomic with the actual job insertion.
    CREATE TABLE IF NOT EXISTS request_idempotency (
       key_sha256 TEXT PRIMARY KEY,
       request_sha256 TEXT NOT NULL,
       job_id TEXT NOT NULL UNIQUE REFERENCES requests(id)
    );
    -- Immutable first-claim timestamp permits a bounded heartbeat without
    -- migrating the original requests CHECK constraint.
    CREATE TABLE IF NOT EXISTS request_lease_envelopes (
       job_id TEXT PRIMARY KEY REFERENCES requests(id),
       claimed_at REAL NOT NULL,
       heartbeat_count INTEGER NOT NULL DEFAULT 0
    );
            """)
    except BaseException:
        con.close()
        raise
    return con


def validate_request(request):
    if type(request) is not dict:
        raise BridgeError("INVALID_REQUEST")
    allowed = {"model", "messages", "stream", "stream_options",
               "temperature", "max_tokens", "max_completion_tokens", "tools",
               "tool_choice", "user", "response_format", "top_p"}
    if set(request) - allowed or not isinstance(request.get("model"), str):
        raise BridgeError("UNSUPPORTED_FIELDS_OR_MODEL")
    if request["model"] != "chatgpt-web-queued":
        raise BridgeError("UNKNOWN_MODEL", 404)
    msgs = request.get("messages")
    if type(msgs) is not list or not 1 <= len(msgs) <= 32:
        raise BridgeError("INVALID_MESSAGES")
    content_len = 0
    for m in msgs:
        if type(m) is not dict or "role" not in m:
            raise BridgeError("UNSUPPORTED_MESSAGE_FORMAT")
        role=m["role"]
        if role in ("system","developer","user"):
            if set(m) != {"role","content"} or type(m["content"]) is not str:
                raise BridgeError("ONLY_TEXT_MESSAGES_SUPPORTED")
            content_len += len(m["content"])
        elif role == "tool":
            if set(m) != {"role","content","tool_call_id"} or type(m["content"]) is not str:
                raise BridgeError("INVALID_TOOL_RESULT")
            if type(m["tool_call_id"]) is not str or len(m["tool_call_id"])>100:
                raise BridgeError("INVALID_TOOL_CALL_ID")
            content_len += len(m["content"])
        elif role == "assistant":
            if not {"role","content"}.issubset(m) or set(m)-{"role","content","tool_calls"}:
                raise BridgeError("INVALID_ASSISTANT_TURN")
            if m["content"] is not None and type(m["content"]) is not str:
                raise BridgeError("INVALID_ASSISTANT_CONTENT")
            if "tool_calls" in m:
                if type(m["tool_calls"]) is not list or len(m["tool_calls"])>8:
                    raise BridgeError("INVALID_TOOL_CALL_HISTORY")
                content_len += len(json.dumps(m["tool_calls"],ensure_ascii=True))
            content_len += len(m["content"] or "")
        else:
            raise BridgeError("UNSUPPORTED_ROLE")
    if content_len > 32_000:
        raise BridgeError("PROMPT_TOO_LARGE", 413)
    tools = request.get("tools")
    if tools is not None:
        if type(tools) is not list or len(tools) > 24:
            raise BridgeError("INVALID_TOOLS")
        tool_names = set()
        for t in tools:
            if (type(t) is not dict or t.get("type") != "function"
                or type(t.get("function")) is not dict
                or type(t["function"].get("name")) is not str
                or re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", t["function"]["name"]) is None):
                raise BridgeError("UNSUPPORTED_TOOL_SCHEMA")
            name = t["function"]["name"]
            if name in tool_names:
                raise BridgeError("DUPLICATE_TOOL_NAME")
            tool_names.add(name)
    if request.get("tool_choice") not in (None, "none", "auto", "required"):
        raise BridgeError("UNSUPPORTED_TOOL_CHOICE")
    if type(request.get("stream",False)) is not bool:
        raise BridgeError("INVALID_STREAM")
    options=request.get("stream_options")
    if options is not None and (
        type(options) is not dict or set(options) != {"include_usage"}
        or type(options["include_usage"]) is not bool
    ):
        raise BridgeError("INVALID_STREAM_OPTIONS")
    raw = json.dumps(request, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    if len(raw.encode()) > MAX_BODY:
        raise BridgeError("REQUEST_TOO_LARGE", 413)
    return raw


def _expire_unclaimed(con, now):
    """Bound queue occupancy; retain immutable request/idempotency history."""
    con.execute(
        """UPDATE requests SET status='failed',updated=?,
               error_code='QUEUE_WAIT_EXPIRED'
           WHERE status='queued' AND created < ?""",
        (now, now - MAX_QUEUE_AGE_SECONDS),
    )


def queue_summary(db):
    """Read-only operational counters. Does not expose prompts or answers."""
    con = connect(db)
    try:
        rows = con.execute(
            "SELECT status,COUNT(*) AS total FROM requests GROUP BY status"
        ).fetchall()
        counts = {name: 0 for name in
                  ("queued", "claimed", "done", "failed", "needs_reconcile")}
        for row in rows:
            counts[row["status"]] = row["total"]
        oldest = con.execute(
            "SELECT MIN(created) FROM requests WHERE status='queued'"
        ).fetchone()[0]
        return {
            "schema": "openclaw-bridge-queue-health-v1",
            "counts": counts,
            "inflight": counts["queued"] + counts["claimed"],
            "oldest_queued_age_seconds": max(0, round(time.time() - oldest, 2))
                if oldest is not None else None,
            "actual_model_usage_known": False,
            "host_actor_authenticated": False,
        }
    finally:
        con.close()


def recovery_snapshot(db, limit=20):
    """Read-only operator diagnostics for leases with unverified outcomes.

    Expired claimed jobs are *not* automatically requeued. A later claim()
    may transition them to needs_reconcile, but this view does not write.
    No prompts, responses, secrets or worker tokens are returned.
    """
    if type(limit) is not int or not 1 <= limit <= 50:
        raise BridgeError("RECOVERY_LIMIT_INVALID")
    observed=time.time()
    con=connect(db)
    try:
        stale=con.execute(
            """SELECT id,lease_until FROM requests
               WHERE status='claimed' AND lease_until <= ?
               ORDER BY lease_until,id LIMIT ?""",
            (observed,limit),
        ).fetchall()
        pending=con.execute(
            """SELECT id,updated,error_code FROM requests
               WHERE status='needs_reconcile'
               ORDER BY updated,id LIMIT ?""",
            (limit,),
        ).fetchall()
        count_expired=con.execute(
            "SELECT COUNT(*) FROM requests WHERE status='claimed' AND lease_until <= ?",
            (observed,),
        ).fetchone()[0]
        count_pending=con.execute(
            "SELECT COUNT(*) FROM requests WHERE status='needs_reconcile'"
        ).fetchone()[0]
        return {
            "schema":"openclaw-bridge-recovery-v1",
            "observed_epoch_seconds":observed,
            "expired_claim_count":count_expired,
            "unreconciled_count":count_pending,
            "expired_claims":[
                {"job_id":row["id"],
                 "expired_seconds_ago":max(0,round(observed-row["lease_until"],2))}
                for row in stale
            ],
            "unreconciled_jobs":[
                {"job_id":row["id"],"error_code":row["error_code"]}
                for row in pending
            ],
            "truncated":count_expired>len(stale) or count_pending>len(pending),
            "automatic_requeue_allowed":False,
            "host_actor_authenticated":False,
        }
    finally:
        con.close()


def submit(db, request, idempotency_key=None):
    """Insert once per explicit key. No key means a new independent model turn.

    An idempotency key is NOT an authentication credential. The HTTP boundary
    must first validate its bearer token. Reusing a key with changed payload
    is a conflict rather than an invisible model-answer substitution.
    """
    raw = validate_request(request)
    digest = hashlib.sha256(raw.encode()).hexdigest()
    key_digest = None
    if idempotency_key is not None:
        if (type(idempotency_key) is not str or
            re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{7,127}", idempotency_key) is None):
            raise BridgeError("INVALID_IDEMPOTENCY_KEY")
        key_digest = hashlib.sha256(idempotency_key.encode("ascii")).hexdigest()
    now = time.time()
    con = connect(db)
    try:
        con.execute("BEGIN IMMEDIATE")
        if key_digest is not None:
            existing = con.execute(
                "SELECT job_id,request_sha256 FROM request_idempotency WHERE key_sha256=?",
                (key_digest,)
            ).fetchone()
            if existing is not None:
                if existing["request_sha256"] != digest:
                    raise BridgeError("IDEMPOTENCY_KEY_PAYLOAD_CONFLICT",409)
                con.commit()
                return existing["job_id"]
        _expire_unclaimed(con, now)
        n = con.execute("SELECT count(*) FROM requests WHERE status IN ('queued','claimed')").fetchone()[0]
        if n >= MAX_PENDING:
            raise BridgeError("QUEUE_FULL", 503)
        ident = uuid.uuid4().hex
        con.execute("""INSERT INTO requests
           (id,digest,model,messages_json,tools_json,status,created,updated)
           VALUES (?,?,?,?,?,?,?,?)""",
           (ident,digest,request["model"],json.dumps(request["messages"],ensure_ascii=True),
            json.dumps(request["tools"] if request.get("tool_choice") != "none" else [],ensure_ascii=True) if request.get("tools") is not None else None,
            "queued",now,now))
        if key_digest is not None:
            con.execute("""INSERT INTO request_idempotency
                (key_sha256,request_sha256,job_id) VALUES (?,?,?)""",
                (key_digest,digest,ident))
        con.commit()
        return ident
    except BaseException:
        if con.in_transaction: con.rollback()
        raise
    finally:
        con.close()


def status(db, ident):
    if type(ident) is not str or len(ident)!=32 or any(c not in "0123456789abcdef" for c in ident):
        raise BridgeError("INVALID_JOB_ID",404)
    con=connect(db)
    try:
        row=con.execute("""SELECT id,model,status,created,updated,answer_json,error_code
                           FROM requests WHERE id=?""",(ident,)).fetchone()
        if not row: raise BridgeError("JOB_NOT_FOUND",404)
        return dict(row)
    finally: con.close()


def cancel_queued(db, ident):
    """Cancel only *unclaimed* work, atomically.

    The existing SQLite CHECK constraint already supports terminal 'failed'
    with a specific error code. Do not migrate the database or add a status.
    Claimed work is explicitly NOT cancelled: an outcome may already exist.
    """
    if (type(ident) is not str or len(ident) != 32 or
            any(c not in "0123456789abcdef" for c in ident)):
        raise BridgeError("INVALID_JOB_ID", 404)
    con = connect(db)
    try:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT status,error_code FROM requests WHERE id=?",
                          (ident,)).fetchone()
        if row is None:
            raise BridgeError("JOB_NOT_FOUND", 404)
        state = row["status"]
        if state == "claimed" or state == "needs_reconcile":
            raise BridgeError("CANNOT_CANCEL_CLAIMED_OR_UNCERTAIN_WORK", 409)
        if state == "queued":
            cur = con.execute(
                """UPDATE requests SET status='failed',updated=?,
                          error_code='CLIENT_CANCELLED_BEFORE_CLAIM'
                   WHERE id=? AND status='queued'""",
                (time.time(), ident),
            )
            if cur.rowcount != 1:
                raise BridgeError("CANCEL_CONFLICT", 409)
            con.commit()
            return {"id": ident, "status": "failed", "error_code": "CLIENT_CANCELLED_BEFORE_CLAIM",
                    "cancelled_now": True}
        con.commit()
        return {"id": ident, "status": state, "error_code": row["error_code"],
                "cancelled_now": False}
    except BaseException:
        if con.in_transaction:
            con.rollback()
        raise
    finally:
        con.close()


def claim(db):
    now=time.time()
    con=connect(db)
    try:
        con.execute("BEGIN IMMEDIATE")
        _expire_unclaimed(con, now)
        # Do not silently replay an old claim whose outcome may be unknown.
        con.execute("""UPDATE requests SET status='needs_reconcile',updated=?,
                       error_code='LEASE_EXPIRED_OUTCOME_UNKNOWN'
                       WHERE status='claimed' AND lease_until < ?""",(now,now))
        row=con.execute("""SELECT id,messages_json,tools_json,model FROM requests
                           WHERE status='queued' ORDER BY created,id LIMIT 1""").fetchone()
        if row is None:
            con.commit()
            return None
        token=secrets.token_urlsafe(32)
        digest=hashlib.sha256(token.encode()).hexdigest()
        con.execute("""UPDATE requests SET status='claimed', lease_until=?,
                       lease_digest=?,updated=? WHERE id=? AND status='queued'""",
                    (now+LEASE_SECONDS,digest,now,row["id"]))
        con.execute("""INSERT INTO request_lease_envelopes
                       (job_id,claimed_at,heartbeat_count) VALUES (?,?,0)""",
                    (row["id"],now))
        con.commit()
        return {"job_id":row["id"],"lease_token":token,"model":row["model"],
                "messages":json.loads(row["messages_json"]),
                "tools":json.loads(row["tools_json"]) if row["tools_json"] else None,
                "lease_seconds":LEASE_SECONDS}
    except BaseException:
        if con.in_transaction: con.rollback()
        raise
    finally: con.close()


def heartbeat(db, ident, token):
    """Extend only a live lease, never past one hour since initial claim.

    This is a local token-based lease extension, NOT an authenticated model
    actor. Unknown, expired or legacy claims without an envelope fail closed.
    """
    if (type(ident) is not str or len(ident)!=32 or
            any(c not in "0123456789abcdef" for c in ident)):
        raise BridgeError("INVALID_JOB_ID",404)
    if type(token) is not str or not 20<=len(token)<=200:
        raise BridgeError("LEASE_TOKEN_INVALID",403)
    digest=hashlib.sha256(token.encode()).hexdigest()
    now=time.time()
    con=connect(db)
    try:
        con.execute("BEGIN IMMEDIATE")
        row=con.execute(
            """SELECT r.status,r.lease_digest,r.lease_until,
                      e.claimed_at,e.heartbeat_count
               FROM requests r LEFT JOIN request_lease_envelopes e
                 ON e.job_id=r.id
               WHERE r.id=?""",(ident,)
        ).fetchone()
        if row is None:
            raise BridgeError("JOB_NOT_FOUND",404)
        if (row["status"]!="claimed" or
                row["lease_digest"] is None or
                not hmac.compare_digest(row["lease_digest"],digest) or
                row["lease_until"] is None or row["lease_until"]<=now):
            raise BridgeError("LEASE_UNAVAILABLE_OR_EXPIRED",409)
        if row["claimed_at"] is None:
            raise BridgeError("CLAIM_ENVELOPE_UNAVAILABLE",409)
        hard_deadline=row["claimed_at"]+MAX_LEASE_LIFETIME_SECONDS
        if hard_deadline<=now:
            raise BridgeError("LEASE_MAX_LIFETIME_EXCEEDED",409)
        extension=min(now+LEASE_SECONDS,hard_deadline)
        extended=extension>row["lease_until"]
        if extended:
            con.execute(
                "UPDATE requests SET lease_until=?,updated=? WHERE id=?",
                (extension,now,ident))
            con.execute(
                """UPDATE request_lease_envelopes
                   SET heartbeat_count=heartbeat_count+1 WHERE job_id=?""",
                (ident,))
        con.commit()
        return {
            "job_id":ident,
            "status":"claimed",
            "lease_until_epoch_seconds":extension if extended else row["lease_until"],
            "max_lease_until_epoch_seconds":hard_deadline,
            "heartbeat_count":row["heartbeat_count"]+(1 if extended else 0),
            "extended":extended,
            "model_usage_known":False,
            "host_actor_authenticated":False,
        }
    except BaseException:
        if con.in_transaction: con.rollback()
        raise
    finally: con.close()


def _answer(value, allowed_names):
    """Validate a worker response against the exact tools authorized by requester.

    A worker cannot grant itself extra OpenClaw tool privileges merely by
    returning a syntactically valid function call.
    """
    if type(value) is not dict or set(value) not in ({"content"},{"tool_calls"},{"content","tool_calls"}):
        raise BridgeError("ANSWER_SCHEMA_INVALID")
    content=value.get("content")
    if content is not None and (type(content) is not str or len(content)>MAX_OUTPUT):
        raise BridgeError("ANSWER_TOO_LARGE",413)
    calls=value.get("tool_calls")
    if calls is not None:
        if type(calls) is not list or not 1<=len(calls)<=8:
            raise BridgeError("TOOL_CALLS_INVALID")
        ids = set()
        for call in calls:
            if (type(call) is not dict or set(call)!={"id","type","function"}
                or call["type"]!="function" or type(call["id"]) is not str
                or type(call["function"]) is not dict or set(call["function"])!={"name","arguments"}
                or type(call["function"]["name"]) is not str
                or type(call["function"]["arguments"]) is not str):
                raise BridgeError("TOOL_CALL_INVALID")
            call_id = call["id"]
            if not 1 <= len(call_id) <= 100 or call_id in ids:
                raise BridgeError("TOOL_CALL_ID_DUPLICATE_OR_INVALID")
            ids.add(call_id)
            if call["function"]["name"] not in allowed_names:
                raise BridgeError("UNDECLARED_TOOL_CALL")
            try: args=json.loads(call["function"]["arguments"])
            except (ValueError,TypeError) as exc: raise BridgeError("TOOL_ARGS_INVALID") from exc
            if not isinstance(args,dict):raise BridgeError("TOOL_ARGS_MUST_BE_OBJECT")
    if content is None and not calls:raise BridgeError("EMPTY_ANSWER")
    if len(json.dumps(value,ensure_ascii=True).encode())>MAX_BODY:
        raise BridgeError("ANSWER_TOO_LARGE",413)
    return json.dumps(value,ensure_ascii=True)


def complete(db, ident, token, answer):
    if type(token) is not str or len(token)>200:
        raise BridgeError("LEASE_TOKEN_INVALID",403)
    digest=hashlib.sha256(token.encode()).hexdigest()
    con=connect(db)
    try:
        now=time.time()
        con.execute("BEGIN IMMEDIATE")
        row=con.execute("SELECT status,lease_digest,lease_until,tools_json FROM requests WHERE id=?",(ident,)).fetchone()
        if row is None:raise BridgeError("JOB_NOT_FOUND",404)
        if row["status"]!="claimed" or row["lease_digest"]!=digest or row["lease_until"]<=now:
            raise BridgeError("LEASE_UNAVAILABLE_OR_EXPIRED",409)
        requested_tools=json.loads(row["tools_json"]) if row["tools_json"] is not None else []
        allowed_names={tool["function"]["name"] for tool in requested_tools}
        payload=_answer(answer,allowed_names)
        con.execute("""UPDATE requests SET status='done',answer_json=?,lease_digest=NULL,
                       lease_until=NULL,updated=? WHERE id=?""",(payload,now,ident))
        con.commit()
        return True
    except BaseException:
        if con.in_transaction: con.rollback()
        raise
    finally: con.close()


def fail(db, ident, token, reason):
    if reason not in ("UNSUPPORTED_REQUEST","MODEL_DECLINED","TASK_ERROR"):
        raise BridgeError("REASON_NOT_ALLOWED")
    if type(token) is not str:raise BridgeError("LEASE_TOKEN_INVALID")
    digest=hashlib.sha256(token.encode()).hexdigest()
    con=connect(db)
    try:
        con.execute("BEGIN IMMEDIATE")
        r=con.execute("SELECT lease_digest,status,lease_until FROM requests WHERE id=?",(ident,)).fetchone()
        if not r or r["status"]!="claimed" or r["lease_digest"]!=digest or r["lease_until"]<=time.time():
            raise BridgeError("LEASE_UNAVAILABLE_OR_EXPIRED",409)
        con.execute("""UPDATE requests SET status='failed',lease_digest=NULL,lease_until=NULL,
                       error_code=?,updated=? WHERE id=?""",(reason,time.time(),ident))
        con.commit()
    except BaseException:
        if con.in_transaction:con.rollback()
        raise
    finally:con.close()
