"""Bounded, authenticated-by-lease-token heartbeat tests.

No external model or ChatGPT account, no real MCP service, no plaintext lease
token included in tool stdout.
"""
from __future__ import annotations
import argparse
import sqlite3
import tempfile
import time
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import bridge_store as store
import worker

REQ={"model":"chatgpt-web-queued","messages":[{"role":"user","content":"Synthetic long task"}]}

class HeartbeatTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"queue.db"
    def setup_claim(self):
        jid=store.submit(self.db,REQ)
        return jid,store.claim(self.db)
    def change(self,jid,sql,args=()):
        with closing(sqlite3.connect(self.db)) as con:
            con.execute(sql,(*args,jid))
            con.commit()
    def test_renew_live_lease_without_new_job(self):
        jid,lease=self.setup_claim()
        self.change(jid,"UPDATE requests SET lease_until=? WHERE id=?",
                    (time.time()+2,))
        result=store.heartbeat(self.db,jid,lease["lease_token"])
        self.assertEqual(result["status"],"claimed")
        self.assertTrue(result["extended"])
        self.assertGreater(result["lease_until_epoch_seconds"],time.time()+800)
        self.assertLessEqual(result["lease_until_epoch_seconds"],
                             result["max_lease_until_epoch_seconds"])
        self.assertFalse(result["model_usage_known"])
        self.assertFalse(result["host_actor_authenticated"])
        with closing(store.connect(self.db)) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM requests").fetchone()[0],1)
        store.complete(self.db,jid,lease["lease_token"],{"content":"finished"})
    def test_heartbeat_is_not_a_free_lease_extension_each_call(self):
        jid,lease=self.setup_claim()
        result=store.heartbeat(self.db,jid,lease["lease_token"])
        self.assertEqual(result["status"],"claimed")
        self.assertIs(type(result["extended"]),bool)
        self.assertGreaterEqual(result["heartbeat_count"],0)
        self.assertLessEqual(result["lease_until_epoch_seconds"],
                             result["max_lease_until_epoch_seconds"])
    def test_invalid_or_other_job_token_rejected(self):
        jid,lease=self.setup_claim()
        for invalid in ("","short","token-from-another-job-0123456789","bad"*100):
            with self.subTest(token=invalid[:12]):
                with self.assertRaises(store.BridgeError):
                    store.heartbeat(self.db,jid,invalid)
        self.assertEqual(store.status(self.db,jid)["status"],"claimed")
    def test_expired_or_completed_lease_never_renewed(self):
        jid,lease=self.setup_claim()
        self.change(jid,"UPDATE requests SET lease_until=0 WHERE id=?")
        with self.assertRaisesRegex(store.BridgeError,"LEASE_UNAVAILABLE_OR_EXPIRED"):
            store.heartbeat(self.db,jid,lease["lease_token"])
        self.assertEqual(store.status(self.db,jid)["status"],"claimed")
        jid2=store.submit(self.db,REQ)
        task2=store.claim(self.db)
        store.complete(self.db,jid2,task2["lease_token"],{"content":"done"})
        with self.assertRaisesRegex(store.BridgeError,"LEASE_UNAVAILABLE_OR_EXPIRED"):
            store.heartbeat(self.db,jid2,task2["lease_token"])
    def test_lease_never_exceeds_one_hour_from_claim(self):
        jid,lease=self.setup_claim()
        self.change(jid,
                    "UPDATE request_lease_envelopes SET claimed_at=? WHERE job_id=?",
                    (time.time()-store.MAX_LEASE_LIFETIME_SECONDS+500,))
        self.change(jid,
                    "UPDATE requests SET lease_until=? WHERE id=?",
                    (time.time()+1,))
        result=store.heartbeat(self.db,jid,lease["lease_token"])
        self.assertGreater(result["lease_until_epoch_seconds"],time.time()+400)
        self.assertLess(result["lease_until_epoch_seconds"],time.time()+510)
        self.assertEqual(result["heartbeat_count"],1)
        self.assertTrue(result["extended"])
    def test_cap_exceeded_fails_closed(self):
        jid,lease=self.setup_claim()
        self.change(jid,
                    "UPDATE request_lease_envelopes SET claimed_at=? WHERE job_id=?",
                    (time.time()-store.MAX_LEASE_LIFETIME_SECONDS-1,))
        with self.assertRaisesRegex(store.BridgeError,"LEASE_MAX_LIFETIME_EXCEEDED"):
            store.heartbeat(self.db,jid,lease["lease_token"])
    def test_legacy_claim_without_envelope_rejected(self):
        jid,lease=self.setup_claim()
        self.change(jid,"DELETE FROM request_lease_envelopes WHERE job_id=?")
        with self.assertRaisesRegex(store.BridgeError,"CLAIM_ENVELOPE_UNAVAILABLE"):
            store.heartbeat(self.db,jid,lease["lease_token"])
    def test_worker_cli_heartbeat_hides_token(self):
        with patch.object(worker,"DATA",Path(self.temp.name)/"private"):
            jid=store.submit(self.db,REQ)
            result=worker.run(argparse.Namespace(db=str(self.db),command="claim",
                                                  job_id=None,reason=None))
            self.assertEqual(result["job_id"],jid)
            output=worker.run(argparse.Namespace(db=str(self.db),command="heartbeat",
                                                  job_id=jid,reason=None))
            self.assertIn(output["status"],("LEASE_RENEWED","LEASE_STILL_VALID"))
            self.assertFalse(output["host_actor_authenticated"])
            self.assertNotIn("lease_token",str(output))
            self.assertNotIn("messages",str(output))

if __name__=="__main__":
    unittest.main()
