"""Real OpenClaw harness -> local HTTP adapter -> SYNTHETIC worker smoke test.

Never touches ChatGPT Web, model accounts, existing MCP, Gateway, or real
credentials. The fake worker gives a deterministic response explicitly
labeled synthetic. No browser/session automation.
"""
from __future__ import annotations
import io,json,os,subprocess,sys,tempfile,threading,time
from pathlib import Path
import bridge_store as store
from server import Server,Handler
HERE=Path(__file__).resolve().parent
NODE=HERE/"portable-node"/"node.exe"
CLI=HERE/"npm-runtime"/"node_modules"/"openclaw"/"openclaw.mjs"
SOURCE=HERE/"openclaw.queued-model.LAB-only.json"
TOKEN="LOCAL_INTEGRATION_ONLY_TEST_TOKEN_1234567890"
SYNTHETIC="SYNTHETIC_BACKEND_RESPONSE_NOT_CHATGPT"

class ProbeHandler(Handler):
    def do_POST(self):
        size=int(self.headers.get("Content-Length","0") or "0")
        if 0<size<64000:
            raw=self.rfile.read(size)
            try:
                payload=json.loads(raw)
                self.server.http_shape={
                    "top_keys":sorted(payload) if isinstance(payload,dict) else [],
                    "model":payload.get("model") if isinstance(payload,dict) else None,
                    "message_kinds":[{"role":m.get("role"),"fields":sorted(m)} for m in payload.get("messages",[])[:6]
                        if isinstance(m,dict)] if isinstance(payload,dict) else [],
                    "tools_count":len(payload.get("tools",[])) if isinstance(payload,dict) and isinstance(payload.get("tools"),list) else None}
            except (ValueError,TypeError): pass
            self.rfile=io.BytesIO(raw)
        return super().do_POST()
    def _send(self,code,payload,headers=None):
        self.server.http_codes.append(code)
        if isinstance(payload,dict) and isinstance(payload.get("error"),dict):
            self.server.reasons.append(str(payload["error"].get("code"))[:90])
        return super()._send(code,payload,headers)

def main():
    if not all(p.is_file() for p in (NODE,CLI,SOURCE)):
        print(json.dumps({"ok":False,"error":"MISSING_TEST_COMPONENTS"}))
        return 2
    with tempfile.TemporaryDirectory(prefix="openclaw-synthetic-model-") as temp:
        root=Path(temp)
        db=root/"queue.db"
        srv=Server("127.0.0.1",0,db,TOKEN,25)
        srv.RequestHandlerClass=ProbeHandler
        srv.http_codes=[]
        srv.reasons=[]
        srv.http_shape={}
        thread=threading.Thread(target=srv.serve_forever,daemon=True)
        thread.start()
        work={"claimed":False,"completed":False,"errors":[]}
        worker_stop=threading.Event()
        def fake_worker():
            end=time.monotonic()+110
            while time.monotonic()<end and not worker_stop.is_set():
                try:
                    job=store.claim(db)
                    if job:
                        work["claimed"]=True
                        store.complete(db,job["job_id"],job["lease_token"],{"content":SYNTHETIC})
                        work["completed"]=True
                        break
                except Exception as ex:
                    work["errors"].append(type(ex).__name__)
                    break
                time.sleep(.2)
        w=threading.Thread(target=fake_worker,daemon=True)
        w.start()
        cfg=json.loads(SOURCE.read_text(encoding="utf-8"))
        cfg.pop("mcp",None)  # no access to live workspace tools in this test
        cfg["models"]["providers"]["local-chat-queue"]["baseUrl"]=f"http://127.0.0.1:{srv.server_address[1]}/v1"
        cfg["models"]["providers"]["local-chat-queue"]["apiKey"]=TOKEN
        cfg["agents"]["defaults"]["workspace"]=str(root/"workspace")
        cfg["tools"]={"deny":["*"]}
        conf=root/"openclaw.json"
        conf.write_text(json.dumps(cfg),encoding="utf-8")
        env=dict(os.environ)
        env.update({"OPENCLAW_STATE_DIR":str(root/"state"),"OPENCLAW_CONFIG_PATH":str(conf),
                    "PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
                    "NO_COLOR":"1"})
        args=[str(NODE),str(CLI),"agent","--local","--message","Respond with one short test phrase.",
              "--session-id","openclaw-synthetic-bridge-test",
              "--model","local-chat-queue/chatgpt-web-queued",
              "--timeout","32","--json"]
        try:
            p=subprocess.run(args,cwd=HERE/"npm-runtime",env=env,
                             capture_output=True,text=True,encoding="utf-8",
                             errors="replace",timeout=66)
            result={"cli_exit":p.returncode,"stdout_tail":p.stdout[-5000:],
                    "stderr_tail":p.stderr[-4200:]}
        except (subprocess.TimeoutExpired,OSError) as ex:
            result={"error":type(ex).__name__}
        worker_stop.set()
        w.join(3)
        srv.shutdown()
        srv.server_close()
        thread.join(3)
        result.update({"http_codes":srv.http_codes[:20],"errors":srv.reasons[:20],
                       "http_shape":srv.http_shape,
                       "fake_worker":work,"synthetic_only":True,"chatgpt_contacted":False,
                       "mcp_host_contacted":False})
        passed=result.get("cli_exit")==0 and work["completed"] and SYNTHETIC in result.get("stdout_tail","")
        print(json.dumps({"ok":passed,"result":result},ensure_ascii=True))
        return 0 if passed else 2
if __name__=="__main__":
    sys.exit(main())
