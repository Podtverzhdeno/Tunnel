"""Read-only recovery diagnostics for uncertain OpenClaw model jobs.

No automatic retry, fabricated model reply, privileged worker identity,
external GPT, or live MCP interaction.
"""
from __future__ import annotations
import json
import sqlite3
import tempfile
import threading
import unittest
from contextlib import closing
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request,urlopen

import bridge_store as bridge
from server import Server

SECRET="PROMPT_SECRET_DO_NOT_LEAK_IN_HEALTH"
REQ={"model":"chatgpt-web-queued","messages":[{"role":"user","content":SECRET}]}
TOKEN="recovery-diagnostics-test-bearer-token-01234"

class RecoveryStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"queue.db"
    def expire(self,id):
        with closing(sqlite3.connect(self.db)) as c:
            c.execute("UPDATE requests SET lease_until=0 WHERE id=?",(id,))
            c.commit()
    def test_report_expired_claim_without_mutation(self):
        jid=bridge.submit(self.db,REQ)
        bridge.claim(self.db)
        self.expire(jid)
        one=bridge.recovery_snapshot(self.db)
        self.assertEqual(one["expired_claim_count"],1)
        self.assertEqual(one["unreconciled_count"],0)
        self.assertEqual(one["expired_claims"][0]["job_id"],jid)
        self.assertFalse(one["automatic_requeue_allowed"])
        self.assertFalse(one["host_actor_authenticated"])
        self.assertEqual(bridge.status(self.db,jid)["status"],"claimed")
        self.assertNotIn(SECRET,json.dumps(one))
    def test_after_claim_sweep_report_uses_needs_reconcile(self):
        jid=bridge.submit(self.db,REQ)
        bridge.claim(self.db)
        self.expire(jid)
        self.assertIsNone(bridge.claim(self.db))
        report=bridge.recovery_snapshot(self.db)
        self.assertEqual(report["expired_claim_count"],0)
        self.assertEqual(report["unreconciled_count"],1)
        self.assertEqual(report["unreconciled_jobs"][0]["job_id"],jid)
        self.assertEqual(report["unreconciled_jobs"][0]["error_code"],
                         "LEASE_EXPIRED_OUTCOME_UNKNOWN")
        self.assertEqual(bridge.status(self.db,jid)["status"],"needs_reconcile")
    def test_report_does_not_mark_active_claim_stale(self):
        jid=bridge.submit(self.db,REQ)
        lease=bridge.claim(self.db)
        report=bridge.recovery_snapshot(self.db)
        self.assertEqual(report["expired_claim_count"],0)
        self.assertEqual(report["unreconciled_count"],0)
        bridge.complete(self.db,jid,lease["lease_token"],{"content":"real synthetic response"})
        self.assertEqual(bridge.recovery_snapshot(self.db)["unreconciled_count"],0)
    def test_recovery_limit_and_truncation_are_truthful(self):
        for i in range(4):
            q=dict(REQ,messages=[{"role":"user","content":SECRET+str(i)}])
            jid=bridge.submit(self.db,q)
            bridge.claim(self.db)
            self.expire(jid)
            bridge.claim(self.db)
        report=bridge.recovery_snapshot(self.db,limit=2)
        self.assertTrue(report["truncated"])
        self.assertEqual(report["unreconciled_count"],4)
        self.assertEqual(len(report["unreconciled_jobs"]),2)
    def test_invalid_limits_rejected(self):
        for limit in (0,51,True,False,"10",None,-2):
            with self.subTest(limit=limit):
                with self.assertRaisesRegex(bridge.BridgeError,"RECOVERY_LIMIT_INVALID"):
                    bridge.recovery_snapshot(self.db,limit=limit)
    def test_queued_and_cancelled_jobs_not_recovered(self):
        one=bridge.submit(self.db,REQ)
        two=bridge.submit(self.db,REQ)
        bridge.cancel_queued(self.db,one)
        report=bridge.recovery_snapshot(self.db)
        self.assertEqual(report["expired_claim_count"],0)
        self.assertEqual(report["unreconciled_count"],0)
        self.assertEqual(bridge.status(self.db,two)["status"],"queued")

class RecoveryHttpTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"server.db"
        self.server=Server("127.0.0.1",0,self.db,TOKEN,1)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(self.stop)
        self.base="http://127.0.0.1:"+str(self.server.server_address[1])
    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(3)
    def get(self,token):
        request=Request(self.base+"/bridge/recovery",headers={
            "Authorization":"Bearer "+token})
        try:
            with urlopen(request,timeout=7) as resp:
                return resp.status,json.loads(resp.read())
        except HTTPError as err:
            return err.code,json.loads(err.read())
    def test_authorization_before_db_access(self):
        code,_=self.get("wrong")
        self.assertEqual(code,401)
        self.assertFalse(self.db.exists())
    def test_authenticated_recovery_report_no_prompt_data(self):
        jid=bridge.submit(self.db,REQ)
        bridge.claim(self.db)
        with closing(sqlite3.connect(self.db)) as con:
            con.execute("UPDATE requests SET lease_until=0 WHERE id=?",(jid,))
            con.commit()
        code,data=self.get(TOKEN)
        self.assertEqual(code,200)
        self.assertEqual(data["schema"],"openclaw-bridge-recovery-v1")
        self.assertEqual(data["expired_claim_count"],1)
        self.assertNotIn(SECRET,json.dumps(data))
        self.assertEqual(bridge.status(self.db,jid)["status"],"claimed")

if __name__=="__main__":
    unittest.main()
