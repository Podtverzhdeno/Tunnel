"""Install platform optional native packages for isolated OpenClaw runtime only.

No global installs or lifecycle scripts. Free-space and runtime caps.
"""
import json,os,subprocess,sys,shutil,time
from pathlib import Path
from threading import Thread
from collections import deque

ROOT=Path(__file__).resolve().parent
NODE=ROOT/"portable-node"/"node.exe"
PNPM=ROOT/"portable-pnpm"/"bin"/"pnpm.mjs"
DEST=ROOT/"npm-runtime"
STORE=ROOT/"pnpm-store"
def main():
    if not (NODE.is_file() and PNPM.is_file() and (DEST/"pnpm-lock.yaml").is_file()):
        print("ISOLATED_DEPENDENCIES_NOT_READY")
        return 2
    env=dict(os.environ)
    env.update({"PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
                "PNPM_HOME":str(ROOT/"pnpm-home"),
                "NPM_CONFIG_UPDATE_NOTIFIER":"false"})
    cmd=[str(NODE),str(PNPM),"--dir",str(DEST),"install",
         "--ignore-scripts","--reporter=append-only","--store-dir",str(STORE)]
    proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT,encoding="utf-8",text=True,errors="replace")
    tail=deque(maxlen=24)
    def drain():
        for line in proc.stdout: tail.append(line.strip()[:430])
    th=Thread(target=drain,daemon=True);th.start()
    start=time.monotonic()
    stopped=None
    while proc.poll() is None:
        if time.monotonic()-start>240:
            stopped="TIME_LIMIT";proc.kill();break
        if shutil.disk_usage(ROOT).free<8*1024**3:
            stopped="DISK_GUARD";proc.kill();break
        time.sleep(3)
    proc.wait(timeout=15)
    th.join(4)
    print(json.dumps({"exit":proc.returncode,"stop":stopped,"elapsed":round(time.monotonic()-start,1),
                     "free_gib":round(shutil.disk_usage(ROOT).free/1024**3,2),
                     "logs":list(tail)},ensure_ascii=True))
    return 0 if proc.returncode==0 and not stopped else 2
if __name__=="__main__":
    sys.exit(main())
