"""Durable, privacy-minimal wake notification outbox for a queued model bridge.

OpenClaw hooks/wake can notify an independently configured agent of a model
result AFTER the original OpenAI-completions HTTP request has timed out.
This is NOT continuation of that same model invocation.

No secrets, prompts, answers, or model tokens are stored in the outbox.
The request table remains the authoritative source of terminal state.
Wake delivery is AT-LEAST-ONCE (never claim exactly-once remote effects).
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
import sqlite3
import time

from bridge_store import BridgeError, connect

MAX_ATTEMPTS = 5
DELIVERY_LEASE_SECONDS = 30
MAX_RETRY_SECONDS = 1800

_SCHEMA = """
CREATE TABLE IF NOT EXISTS result_wake_outbox(
    job_id TEXT PRIMARY KEY REFERENCES requests(id),
    terminal_status TEXT NOT NULL CHECK(terminal_status IN ('done','failed','needs_reconcile')),
    state TEXT NOT NULL CHECK(state IN ('ready','sending','delivered','blocked')),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_retry REAL NOT NULL,
    lease_digest TEXT,
    lease_until REAL,
    last_code TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS result_wake_ready
    ON result_wake_outbox(state,next_retry,created_at);
"""


def _schema(con):
    con.executescript(_SCHEMA)


def sync_terminal_results(db):
    """Materialize terminal jobs durably. Safe across process restarts.

    A crash after bridge.complete() but before this call is recoverable:
    next sync selects committed terminal rows. Do not include raw messages.
    """
    con = connect(db)
    try:
        _schema(con)
        now = time.time()
        con.execute("BEGIN IMMEDIATE")
        con.execute(
            """INSERT OR IGNORE INTO result_wake_outbox(
                   job_id,terminal_status,state,next_retry,created_at,updated_at)
               SELECT id,status,'ready',?,updated,?
               FROM requests WHERE status IN ('done','failed','needs_reconcile')""",
            (now, now),
        )
        con.commit()
        return outbox_summary(db)
    except BaseException:
        if con.in_transaction:
            con.rollback()
        raise
    finally:
        con.close()


def outbox_summary(db):
    con = connect(db)
    try:
        _schema(con)
        rows = con.execute(
            "SELECT state,COUNT(*) AS c FROM result_wake_outbox GROUP BY state"
        ).fetchall()
        counts = {key: 0 for key in ("ready","sending","delivered","blocked")}
        for row in rows:
            counts[row["state"]] = row["c"]
        return {"schema":"bridge-wake-outbox-v1","counts":counts,
                "ready":counts["ready"],
                "at_least_once_delivery":True,
                "openclaw_gateway_connected":False,
                "model_provider_connected":False}
    finally:
        con.close()


def reserve(db):
    """Reserve exactly one event. Lease token is not meant for logging."""
    con = connect(db)
    try:
        _schema(con)
        now = time.time()
        con.execute("BEGIN IMMEDIATE")
        # A network timeout may occur *after* the remote gateway has accepted
        # the wake. Re-delivery is thus at-least-once, not exactly-once.
        con.execute(
            """UPDATE result_wake_outbox
               SET state=CASE WHEN attempt_count>=? THEN 'blocked' ELSE 'ready' END,
                   lease_digest=NULL,lease_until=NULL,
                   last_code='DELIVERY_OUTCOME_UNCERTAIN',updated_at=?
               WHERE state='sending' AND lease_until<=?""",
            (MAX_ATTEMPTS, now, now),
        )
        row = con.execute(
            """SELECT job_id,terminal_status,attempt_count
               FROM result_wake_outbox
               WHERE state='ready' AND next_retry<=?
               ORDER BY created_at,job_id LIMIT 1""",
            (now,),
        ).fetchone()
        if row is None:
            con.commit()
            return None
        if row["attempt_count"] >= MAX_ATTEMPTS:
            con.execute(
                """UPDATE result_wake_outbox SET state='blocked',
                   last_code='ATTEMPT_LIMIT_REACHED',updated_at=? WHERE job_id=?""",
                (now,row["job_id"]),
            )
            con.commit()
            return None
        token = secrets.token_urlsafe(32)
        digest = hashlib.sha256(token.encode("ascii")).hexdigest()
        cur=con.execute(
            """UPDATE result_wake_outbox SET state='sending',lease_digest=?,
                   lease_until=?,attempt_count=attempt_count+1,updated_at=?
               WHERE job_id=? AND state='ready'""",
            (digest,now+DELIVERY_LEASE_SECONDS,now,row["job_id"]),
        )
        if cur.rowcount!=1:
            raise BridgeError("OUTBOX_RESERVATION_CONFLICT",409)
        con.commit()
        return {"job_id":row["job_id"],
                "terminal_status":row["terminal_status"],
                "delivery_lease_token":token,
                "attempt":row["attempt_count"]+1}
    except BaseException:
        if con.in_transaction:
            con.rollback()
        raise
    finally:
        con.close()


def finish_delivery(db, job_id, token, *, accepted, failure_code=None):
    """Acknowledge after checking the actual Gateway hook HTTP response."""
    if type(job_id) is not str or len(job_id)!=32 or any(c not in "0123456789abcdef" for c in job_id):
        raise BridgeError("INVALID_JOB_ID",404)
    if type(token) is not str or not 20<=len(token)<=200:
        raise BridgeError("INVALID_DELIVERY_TOKEN",403)
    if type(accepted) is not bool:
        raise BridgeError("INVALID_ACK_DECISION")
    if accepted:
        if failure_code is not None: raise BridgeError("INVALID_ACK_REASON")
    elif failure_code not in ("NETWORK_ERROR","HTTP_REJECTED","GATEWAY_RESPONSE_INVALID"):
        raise BridgeError("INVALID_ACK_REASON")
    con=connect(db)
    try:
        _schema(con)
        now=time.time()
        con.execute("BEGIN IMMEDIATE")
        row=con.execute(
            """SELECT state,lease_digest,lease_until,attempt_count
               FROM result_wake_outbox WHERE job_id=?""",(job_id,),
        ).fetchone()
        if row is None:raise BridgeError("OUTBOX_EVENT_NOT_FOUND",404)
        digest=hashlib.sha256(token.encode("ascii")).hexdigest()
        if (row["state"]!="sending" or row["lease_digest"] is None or
                not hmac.compare_digest(row["lease_digest"],digest) or
                row["lease_until"] is None or row["lease_until"]<=now):
            raise BridgeError("DELIVERY_LEASE_EXPIRED_OR_INVALID",409)
        if accepted:
            state="delivered"
            next_attempt=now
            code=None
        else:
            state="blocked" if row["attempt_count"]>=MAX_ATTEMPTS else "ready"
            delay=min(MAX_RETRY_SECONDS,2**min(row["attempt_count"],10))
            next_attempt=now+delay
            code=failure_code
        con.execute(
            """UPDATE result_wake_outbox
               SET state=?,next_retry=?,lease_digest=NULL,
                   lease_until=NULL,last_code=?,updated_at=?
               WHERE job_id=?""",
            (state,next_attempt,code,now,job_id),
        )
        con.commit()
        return {"job_id":job_id,"state":state,"attempt_count":row["attempt_count"],
                "delivery_accepted":accepted,"at_least_once":True}
    except BaseException:
        if con.in_transaction:con.rollback()
        raise
    finally:
        con.close()


def event_status(db, job_id):
    """Operator-readable state without prompt, answer, auth or lease token."""
    con=connect(db)
    try:
        _schema(con)
        row=con.execute(
            """SELECT job_id,terminal_status,state,attempt_count,next_retry,last_code
               FROM result_wake_outbox WHERE job_id=?""",(job_id,),
        ).fetchone()
        if row is None: raise BridgeError("OUTBOX_EVENT_NOT_FOUND",404)
        return dict(row)
    finally:
        con.close()
