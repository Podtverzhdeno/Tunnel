"""Install repository-pinned pnpm from npm registry, verifying npm SHA-512 integrity.

Extract only the JS executable/manifest from the registry tarball into the
experiment; no global installs, lifecycle scripts or writes to other projects.
"""
import base64,hashlib,json,os,subprocess,sys,tarfile,io,urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DEST=ROOT/"portable-pnpm"
NODE=ROOT/"portable-node"/"node.exe"
VERSION="12.15.0"
LIMIT=45*1024*1024

def fetch(url,max_len):
    req=urllib.request.Request(url,headers={"User-Agent":"OpenClaw-Local-Lab/1.0","Accept":"application/json"})
    with urllib.request.urlopen(req,timeout=90) as response:
        if urllib.request.urlparse(response.url).hostname!="registry.npmjs.org":
            raise ValueError("REGISTRY_REDIRECT_DENIED")
        data=bytearray()
        while True:
            buf=response.read(1024*1024)
            if not buf:break
            data.extend(buf)
            if len(data)>max_len:raise ValueError("REGISTRY_PAYLOAD_OVERSIZED")
    return bytes(data)

def main():
    meta=json.loads(fetch(f"https://registry.npmjs.org/pnpm/{VERSION}",500000))
    tarball=meta["dist"]["tarball"]
    integrity=meta["dist"]["integrity"]
    if tarball!=f"https://registry.npmjs.org/pnpm/-/pnpm-{VERSION}.tgz" or not integrity.startswith("sha512-"):
        raise ValueError("REGISTRY_METADATA_UNEXPECTED")
    archive=fetch(tarball,LIMIT)
    if base64.b64encode(hashlib.sha512(archive).digest()).decode()!=integrity[7:]:
        raise ValueError("PNPM_TARBALL_INTEGRITY_MISMATCH")
    with tarfile.open(fileobj=io.BytesIO(archive),mode="r:gz") as source:
        members={}
        total=0
        for m in source.getmembers():
            if not m.name.startswith("package/") or m.name.startswith("package/../"):
                raise ValueError("PNPM_TARBALL_PATH_DENIED")
            relative=Path(m.name).relative_to("package")
            if ".." in relative.parts or relative.is_absolute() or m.issym() or m.islnk():
                raise ValueError("PNPM_TARBALL_LINK_OR_ESCAPE")
            if not m.isfile():
                continue
            total+=m.size
            if m.size>38*1024*1024 or total>180*1024*1024:
                raise ValueError("PNPM_EXTRACT_SIZE_EXCEEDED")
            members[m.name]=m
        if "package/bin/pnpm.mjs" not in members or "package/package.json" not in members:
            raise ValueError("PNPM_ENTRIES_MISSING")
        for name,m in members.items():
            output=DEST/Path(name).relative_to("package")
            output.parent.mkdir(parents=True,exist_ok=True)
            with source.extractfile(m) as stream,open(output,"wb") as fp:
                fp.write(stream.read())
    # Verify the package is correct and self-contained.
    pkg=json.loads((DEST/"package.json").read_text(encoding="utf-8"))
    if pkg.get("name")!="pnpm" or pkg.get("version")!=VERSION:
        raise ValueError("INSTALLED_PNPM_VERSION_MISMATCH")
    r=subprocess.run([str(NODE),str(DEST/"bin"/"pnpm.mjs"),"--version"],
                     capture_output=True,text=True,timeout=25)
    print(json.dumps({"exit":r.returncode,"version":r.stdout.strip(),
        "stderr":r.stderr[-800:],"expected":VERSION,
        "files":sorted(members),"archive_sha512_verified":True},ensure_ascii=True))
    return 0 if r.returncode==0 and r.stdout.strip()==VERSION else 2

if __name__=="__main__":
    try:sys.exit(main())
    except Exception as ex:
        print(json.dumps({"error":type(ex).__name__,"detail":str(ex)[:2500]}))
        sys.exit(2)
