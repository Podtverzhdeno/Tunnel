"""Install a verified, portable Node.js 26 into the isolated experiment folder.

Downloads only from nodejs.org HTTPS, verifies the zip against the published
SHASUMS256.txt, extracts node.exe only, never changes PATH or system registry.
"""
from __future__ import annotations
import hashlib
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

VERSION="v26.12.1"
ARCHIVE=f"node-{VERSION}-win-x64.zip"
ROOT=Path(__file__).resolve().parent
OUT=ROOT/"portable-node"
URL=f"https://nodejs.org/dist/{VERSION}/"
LIMIT=96*1024*1024

def get(url, max_size):
    req=urllib.request.Request(url,headers={"User-Agent":"OpenClaw-local-runtime-setup/1.0"})
    with urllib.request.urlopen(req,timeout=90) as resp:
        if resp.url.split("/")[2].lower()!="nodejs.org":
            raise ValueError("UNEXPECTED_DOWNLOAD_HOST")
        body=bytearray()
        while True:
            b=resp.read(1024*1024)
            if not b:break
            body.extend(b)
            if len(body)>max_size:raise ValueError("DOWNLOAD_TOO_LARGE")
        return bytes(body)

def main():
    import subprocess
    target=OUT/"node.exe"
    if target.is_file():
        res=subprocess.run([str(target),"--version"],capture_output=True,
                           text=True,timeout=15)
        if res.returncode==0 and res.stdout.strip()==VERSION:
            print("PORTABLE_NODE_READY",str(target),VERSION)
            return 0
        raise ValueError("EXISTING_PORTABLE_NODE_NOT_EXPECTED_VERSION")
    sums=get(URL+"SHASUMS256.txt",200000).decode("utf-8")
    wanted=None
    for line in sums.splitlines():
        chunks=line.strip().split()
        if len(chunks)==2 and chunks[1].lstrip("*")==ARCHIVE:
            wanted=chunks[0]
            break
    if not wanted or len(wanted)!=64:
        raise ValueError("OFFICIAL_ZIP_SHA256_MISSING")
    zipbytes=get(URL+ARCHIVE,LIMIT)
    observed=hashlib.sha256(zipbytes).hexdigest()
    if observed!=wanted:raise ValueError("ZIP_SHA256_MISMATCH")
    import io
    with zipfile.ZipFile(io.BytesIO(zipbytes)) as z:
        target_name=f"node-{VERSION}-win-x64/node.exe"
        candidates=[n for n in z.namelist() if n.replace("\\","/")==target_name]
        if len(candidates)!=1:raise ValueError("ZIP_NODE_MEMBER_MISSING")
        member=z.getinfo(candidates[0])
        if member.file_size>125*1024*1024:raise ValueError("NODE_EXECUTABLE_OVERSIZED")
        OUT.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(dir=OUT,prefix="node-new-",suffix=".exe")
        try:
            with os.fdopen(fd,"wb") as dest,z.open(member) as source:
                shutil.copyfileobj(source,dest,length=1024*1024)
                dest.flush();os.fsync(dest.fileno())
            os.replace(tmp,target)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
    r=subprocess.run([str(target),"--version"],capture_output=True,text=True,timeout=20)
    if r.returncode!=0 or r.stdout.strip()!=VERSION:
        raise ValueError("NODE_POST_INSTALL_CHECK_FAILED")
    print("PORTABLE_NODE_INSTALLED",str(target),VERSION,"zip_sha256",observed)
    return 0

if __name__=="__main__":
    try:sys.exit(main())
    except (OSError,ValueError,RuntimeError) as exc:
        print("PORTABLE_NODE_SETUP_FAILED",type(exc).__name__,str(exc)[:220])
        sys.exit(2)
