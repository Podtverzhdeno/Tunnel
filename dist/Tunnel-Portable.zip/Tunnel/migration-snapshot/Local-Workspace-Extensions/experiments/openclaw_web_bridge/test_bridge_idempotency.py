"""Idempotent HTTP retries and SQLite concurrency tests for OpenClaw bridge.

No real model, no ChatGPT, no external MCP, no production SQLite DB.
"""
from __future__ import annotations
import hashlib
from contextlib import closing
import json
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import patch

import bridge_store as bridge
from server import Server

REQ={"model":"chatgpt-web-queued",
     "messages":[{"role":"user","content":"A synthetic idempotency test"}],
     "stream":False}
TOKEN="synthetic-http-idempotency-test-key-0000001"
KEY="test-client-turn-0001"


class StoreIdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"requests.sqlite3"

    def test_replay_returns_same_job_with_no_extra_row(self):
        first=bridge.submit(self.db,REQ,KEY)
        second=bridge.submit(self.db,REQ,KEY)
        self.assertEqual(first,second)
        with closing(bridge.connect(self.db)) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM requests").fetchone()[0],1)
            self.assertEqual(con.execute("SELECT count(*) FROM request_idempotency").fetchone()[0],1)

    def test_changed_payload_same_key_is_conflict(self):
        bridge.submit(self.db,REQ,KEY)
        modified=dict(REQ,messages=[{"role":"user","content":"Not the original text"}])
        with self.assertRaisesRegex(bridge.BridgeError,"IDEMPOTENCY_KEY_PAYLOAD_CONFLICT") as result:
            bridge.submit(self.db,modified,KEY)
        self.assertEqual(result.exception.http,409)

    def test_no_key_means_two_real_jobs(self):
        a=bridge.submit(self.db,REQ)
        b=bridge.submit(self.db,REQ)
        self.assertNotEqual(a,b)

    def test_invalid_key_rejected_without_db_writes(self):
        for key in ("x","spaces forbidden","🦀"*5,"../escape","key/with/slash","k"*129,123,True,""):
            with self.subTest(key=repr(key)):
                with self.assertRaisesRegex(bridge.BridgeError,"INVALID_IDEMPOTENCY_KEY"):
                    bridge.submit(self.db,REQ,key)
        self.assertFalse(self.db.exists())

    def test_keys_not_stored_as_plaintext(self):
        bridge.submit(self.db,REQ,KEY)
        with closing(bridge.connect(self.db)) as con:
            digest=con.execute("SELECT key_sha256 FROM request_idempotency").fetchone()[0]
        self.assertEqual(digest,hashlib.sha256(KEY.encode()).hexdigest())
        self.assertNotEqual(KEY,digest)

    def test_same_key_replay_allowed_even_when_new_work_full(self):
        with patch.object(bridge,"MAX_PENDING",1):
            ident=bridge.submit(self.db,REQ,KEY)
            self.assertEqual(bridge.submit(self.db,REQ,KEY),ident)
            with self.assertRaisesRegex(bridge.BridgeError,"QUEUE_FULL"):
                bridge.submit(self.db,REQ,"another-key-0000002")

    def test_replay_after_completion_retains_original_answer(self):
        ident=bridge.submit(self.db,REQ,KEY)
        leased=bridge.claim(self.db)
        bridge.complete(self.db,ident,leased["lease_token"],{"content":"synthetic answer"})
        self.assertEqual(bridge.submit(self.db,REQ,KEY),ident)
        state=bridge.status(self.db,ident)
        self.assertEqual(state["status"],"done")
        self.assertEqual(json.loads(state["answer_json"])["content"],"synthetic answer")

    def test_multithreaded_submit_has_exactly_one_job(self):
        results=[]
        errors=[]
        start=threading.Barrier(8)
        lock=threading.Lock()
        def writer():
            try:
                start.wait(timeout=3)
                ident=bridge.submit(self.db,REQ,KEY)
                with lock:results.append(ident)
            except Exception as ex:
                with lock:errors.append(type(ex).__name__+":"+str(ex))
        workers=[threading.Thread(target=writer) for _ in range(8)]
        for thread in workers:thread.start()
        for thread in workers:thread.join(12)
        self.assertFalse(any(t.is_alive() for t in workers))
        self.assertEqual(errors,[])
        self.assertEqual(len(results),8)
        self.assertEqual(len(set(results)),1)
        with closing(bridge.connect(self.db)) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM requests").fetchone()[0],1)


class HttpIdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db=Path(self.temp.name)/"server.sqlite3"
        self.server=Server("127.0.0.1",0,self.db,TOKEN,1)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(self.stop)
        self.url="http://127.0.0.1:"+str(self.server.server_address[1])
    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(5)
    def post(self,req,*,key=None,token=TOKEN):
        headers={"Authorization":"Bearer "+token,"Content-Type":"application/json"}
        if key is not None:headers["Idempotency-Key"]=key
        request=Request(self.url+"/v1/chat/completions",data=json.dumps(req).encode(),
                        headers=headers)
        try:
            with urlopen(request,timeout=7) as response:
                return response.status,json.loads(response.read())
        except HTTPError as ex:
            return ex.code,json.loads(ex.read())

    def test_client_can_retry_pending_job_then_get_completed_answer(self):
        code1,b1=self.post(REQ,key=KEY)
        self.assertEqual(code1,503)
        self.assertEqual(b1["error"]["code"],"BRIDGE_PENDING")
        ident=b1["error"]["job_id"]
        self.assertEqual(bridge.status(self.db,ident)["status"],"queued")
        lease=bridge.claim(self.db)
        bridge.complete(self.db,ident,lease["lease_token"],{"content":"real synthetic response"})
        code2,b2=self.post(REQ,key=KEY)
        self.assertEqual(code2,200)
        self.assertEqual(b2["choices"][0]["message"]["content"],"real synthetic response")
        self.assertEqual(b2["id"],"chatcmpl-"+ident)
        self.assertEqual(b2["model"],"chatgpt-web-queued")
        with closing(bridge.connect(self.db)) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM requests").fetchone()[0],1)

    def test_authenticated_conflicting_retry_returns_409(self):
        code1,_=self.post(REQ,key=KEY)
        self.assertEqual(code1,503)
        alt=dict(REQ,messages=[{"role":"user","content":"Other request"}])
        code2,body=self.post(alt,key=KEY)
        self.assertEqual(code2,409)
        self.assertEqual(body["error"]["code"],"IDEMPOTENCY_KEY_PAYLOAD_CONFLICT")

    def test_invalid_key_is_not_accepted(self):
        code,body=self.post(REQ,key="hi")
        self.assertEqual(code,400)
        self.assertEqual(body["error"]["code"],"INVALID_IDEMPOTENCY_KEY")

    def test_unauthenticated_replay_denied(self):
        code,body=self.post(REQ,key=KEY,token="wrong")
        self.assertEqual(code,401)
        self.assertFalse(self.db.exists())


if __name__=="__main__":
    unittest.main()
