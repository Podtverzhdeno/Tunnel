"""Opt-in, loopback-only OpenClaw wake publisher for terminal bridge jobs.

NO automatic model worker, no ChatGPT browser automation, no polling of user
accounts, and no external model API. Hook delivery only works when a separately
configured OpenClaw Gateway is running with a distinct authorized agent/model.

Default command is DRY RUN. Live sends require --dispatch-once and a secret
OPENCLAW_HOOK_TOKEN in the process environment. Never print that token.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import (
    Request, build_opener, HTTPHandler, HTTPRedirectHandler
)

from bridge_store import BridgeError
from result_outbox import sync_terminal_results, reserve, finish_delivery, outbox_summary

DEFAULT_GATEWAY = "http://127.0.0.1:18789/hooks/wake"
MAX_RESPONSE_BYTES = 8192


class DenyRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise BridgeError("GATEWAY_REDIRECT_DENIED", 409)


def validate_gateway_url(url):
    if type(url) is not str:
        raise BridgeError("INVALID_HOOK_URL")
    try:
        parsed = urlsplit(url)
        port=parsed.port
    except ValueError as exc:
        raise BridgeError("INVALID_HOOK_URL") from exc
    if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or
            not 1 <= (port or 0) <= 65535 or parsed.path != "/hooks/wake" or
            parsed.username is not None or parsed.password is not None or
            parsed.query or parsed.fragment):
        raise BridgeError("LOOPBACK_OPENCLAW_WAKE_ONLY")
    return url


def validate_token(value):
    if type(value) is not str or not 24 <= len(value) <= 512 or "\n" in value or "\r" in value:
        raise BridgeError("OPENCLAW_HOOK_TOKEN_REQUIRED", 403)
    if not value.isascii() or any(ord(c)<33 or ord(c)>126 for c in value):
        raise BridgeError("INVALID_HOOK_TOKEN", 403)
    return value


def wake_payload(job_id, terminal_status):
    """Notice only, with no raw user message or generated model text."""
    if terminal_status not in ("done","failed","needs_reconcile"):
        raise BridgeError("INVALID_TERMINAL_STATUS")
    return {
        "text": (
            f"External queued model job {job_id}: {terminal_status}. "
            "The result is in the authorized local bridge job lookup. "
            "This notice does not continue a previous model HTTP call."
        ),
        "mode": "now",
    }


def post_wake(url, token, payload, *, opener=None):
    validate_gateway_url(url)
    validate_token(token)
    if type(payload) is not dict or set(payload) != {"text","mode"}:
        raise BridgeError("WAKE_PAYLOAD_SCHEMA_INVALID")
    wire = json.dumps(payload,ensure_ascii=True).encode("utf-8")
    if len(wire) > 1024:
        raise BridgeError("WAKE_PAYLOAD_OVERSIZED")
    req=Request(url,data=wire,method="POST",headers={
        "Content-Type":"application/json",
        "Authorization":"Bearer "+token,
    })
    client=opener or build_opener(DenyRedirect(), HTTPHandler())
    try:
        with client.open(req,timeout=4) as response:
            if response.status!=200:
                return False, "HTTP_REJECTED"
            raw=response.read(MAX_RESPONSE_BYTES+1)
            if len(raw)>MAX_RESPONSE_BYTES:
                return False, "GATEWAY_RESPONSE_INVALID"
            try:parsed=json.loads(raw)
            except (UnicodeDecodeError,ValueError):
                return False, "GATEWAY_RESPONSE_INVALID"
            if (type(parsed) is not dict or parsed.get("ok") is not True or
                    parsed.get("eventOutcome") not in ("queued","coalesced")):
                return False, "GATEWAY_RESPONSE_INVALID"
            return True, None
    except (HTTPError, URLError, OSError, TimeoutError):
        return False, "NETWORK_ERROR"


def dispatch_once(db, url, token):
    """One bounded external wake attempt; never runs a GPT model turn."""
    validate_gateway_url(url)
    validate_token(token)
    sync_terminal_results(db)
    item=reserve(db)
    if item is None:
        return {"status":"NO_PENDING_WAKE","sent":False}
    payload=wake_payload(item["job_id"],item["terminal_status"])
    try:
        accepted,reason=post_wake(url,token,payload)
    except BridgeError:
        # A route validation failure is still a rejectable attempt; never
        # leave a live lease because of malformed environmental inputs.
        accepted,reason=False,"GATEWAY_RESPONSE_INVALID"
    out=finish_delivery(db,item["job_id"],item["delivery_lease_token"],
                        accepted=accepted,failure_code=reason)
    # No token or user prompt is returned or logged.
    return {"status":"WAKE_ACKNOWLEDGED" if accepted else "WAKE_RETRY_PENDING",
            "sent":accepted,"job_id":item["job_id"],
            "terminal_status":item["terminal_status"],
            "outbox_state":out["state"],"attempt":out["attempt_count"],
            "at_least_once_delivery":True,
            "model_result_included":False}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db",required=True,
                        help="Approved isolated model-bridge SQLite path")
    parser.add_argument("--gateway",default=DEFAULT_GATEWAY)
    parser.add_argument("--dispatch-once",action="store_true",
                        help="Opt in to sending exactly one wake attempt")
    args=parser.parse_args(argv)
    try:
        validate_gateway_url(args.gateway)
        if not args.dispatch_once:
            # Dry-run syncs completed jobs into the local outbox, but never
            # claims an event or sends any HTTP request.
            report=sync_terminal_results(args.db)
            print(json.dumps({"mode":"DRY_RUN_NO_WAKE_SENT",
                              "outbox":report,"gateway_connected":False}))
            return 0
        token=validate_token(os.environ.get("OPENCLAW_HOOK_TOKEN",""))
        result=dispatch_once(args.db,args.gateway,token)
        print(json.dumps(result))
        return 0 if result["sent"] or result["status"]=="NO_PENDING_WAKE" else 2
    except (BridgeError,OSError,ValueError,TimeoutError) as err:
        code=err.code if isinstance(err,BridgeError) else type(err).__name__
        print(json.dumps({"ok":False,"error":code,"gateway_contacted":False}))
        return 2


if __name__=="__main__":
    sys.exit(main())
