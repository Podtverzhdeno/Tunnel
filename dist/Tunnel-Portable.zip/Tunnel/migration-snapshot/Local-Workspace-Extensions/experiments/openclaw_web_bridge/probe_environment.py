"""Non-mutating check for OpenClaw CLI and local MCP port.

Does not inspect OpenClaw credential stores or read personal config files.
"""
import json
import shutil
import socket

def available(port):
    try:
        with socket.create_connection(("127.0.0.1",port),timeout=.4):
            return True
    except OSError:
        return False

print(json.dumps({
    "openclaw_cli_on_path": bool(shutil.which("openclaw") or shutil.which("openclaw.cmd")),
    "node_cli_on_path": bool(shutil.which("node")),
    "local_mcp_port_8765_open": available(8765),
    "experimental_bridge_8786_open": available(8786),
    "openclaw_config_modified": False,
    "oauth_status_checked": False
},sort_keys=True))
