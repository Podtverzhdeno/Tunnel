"""Cross-process SQLite idempotency stress test (Windows spawn-safe).

Four independent Python processes submit an identical keyed model request
simultaneously to one disposable WAL DB. No OpenClaw/GPT/MCP service used.
"""
from __future__ import annotations
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from contextlib import closing
from pathlib import Path

import bridge_store as bridge

REQUEST={"model":"chatgpt-web-queued",
         "messages":[{"role":"user","content":"synthetic concurrent process test"}]}
IDEMPOTENCY="crossprocess-unique-test-job-001"

def child_main(argv):
    db,ready_dir,release=map(Path,argv)
    ready_dir.mkdir(parents=True,exist_ok=True)
    (ready_dir/(str(os.getpid())+".ready")).write_text("ready",encoding="utf-8")
    deadline=time.monotonic()+25
    while not release.is_file() and time.monotonic()<deadline:
        time.sleep(.025)
    if not release.is_file():
        print(json.dumps({"ok":False,"error":"PARENT_RELEASE_NOT_RECEIVED"}))
        return 2
    try:
        job=bridge.submit(db,REQUEST,IDEMPOTENCY)
        print(json.dumps({"ok":True,"job_id":job}))
        return 0
    except Exception as e:
        print(json.dumps({"ok":False,"error":type(e).__name__,
                          "detail":str(e)[:160]}))
        return 2

class MultiprocessIdempotencyTest(unittest.TestCase):
    def test_four_processes_share_exactly_one_atomic_job(self):
        with tempfile.TemporaryDirectory(prefix="bridge-four-process-") as tmp:
            root=Path(tmp)
            db=root/"requests.sqlite3"
            ready=root/"ready"
            release=root/"release.txt"
            children=[]
            try:
                for _ in range(4):
                    children.append(subprocess.Popen(
                        [sys.executable,str(Path(__file__).resolve()),"--child",
                         str(db),str(ready),str(release)],
                        cwd=Path(__file__).resolve().parent,
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                        text=True,encoding="utf-8",errors="replace"))
                end=time.monotonic()+25
                while time.monotonic()<end and len(list(ready.glob("*.ready"))) < 4:
                    time.sleep(.05)
                self.assertEqual(len(list(ready.glob("*.ready"))),4)
                release.write_text("go",encoding="utf-8")
                results=[]
                for process in children:
                    stdout,stderr=process.communicate(timeout=32)
                    self.assertEqual(process.returncode,0,stdout+" "+stderr[-300:])
                    results.append(json.loads(stdout.strip()))
                self.assertTrue(all(x.get("ok") for x in results),results)
                self.assertEqual(len(set(r["job_id"] for r in results)),1)
                with closing(bridge.connect(db)) as con:
                    n=con.execute("SELECT COUNT(*) FROM requests").fetchone()[0]
                    ids=con.execute("SELECT COUNT(*) FROM request_idempotency").fetchone()[0]
                    self.assertEqual((n,ids),(1,1))
            finally:
                for process in children:
                    if process.poll() is None:process.kill()
                    try:process.communicate(timeout=3)
                    except subprocess.TimeoutExpired:pass

if __name__=="__main__":
    if len(sys.argv)>1 and sys.argv[1]=="--child":
        sys.exit(child_main(sys.argv[2:]))
    unittest.main()
