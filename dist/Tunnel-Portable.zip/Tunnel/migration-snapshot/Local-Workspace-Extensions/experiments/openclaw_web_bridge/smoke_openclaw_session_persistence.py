"""Real OpenClaw local harness persistence check with synthetic model replies.

Two separate CLI processes share one temporary, isolated OpenClaw session.
The synthetic worker checks that the second outbound model request includes
the prior assistant response. No ChatGPT, external MCP or real credentials.
"""
from __future__ import annotations
import json,os,subprocess,sys,tempfile,threading,time
from pathlib import Path
import bridge_store as store
from server import Server
from smoke_openclaw_synthetic_model import HERE,NODE,CLI,SOURCE,TOKEN

MARKERS=("SYNTHETIC_FIRST_SESSION_REPLY","SYNTHETIC_SECOND_SESSION_REPLY")
class Observation:
    def __init__(self):
        self.jobs=[]
        self.errors=[]
        self.done=0
        self.stop=threading.Event()
def main():
    if not all(p.is_file() for p in (NODE,CLI,SOURCE)):
        print(json.dumps({"ok":False,"error":"EXPERIMENTAL_RUNTIME_NOT_INSTALLED"}));return 2
    with tempfile.TemporaryDirectory(prefix="openclaw-session-test-") as tmp:
        root=Path(tmp);db=root/"queue.sqlite3"
        srv=Server("127.0.0.1",0,db,TOKEN,25)
        thread=threading.Thread(target=srv.serve_forever,daemon=True)
        thread.start()
        obs=Observation()
        def worker():
            deadline=time.monotonic()+145
            while not obs.stop.is_set() and time.monotonic()<deadline and obs.done<2:
                try:
                    job=store.claim(db)
                    if not job:
                        time.sleep(.15);continue
                    roles=[m.get("role") for m in job["messages"]]
                    previous=any(m.get("role")=="assistant" and
                                 isinstance(m.get("content"),str) and MARKERS[0] in m["content"]
                                 for m in job["messages"])
                    obs.jobs.append({"ordinal":len(obs.jobs)+1,"roles":roles,
                                     "prior_assistant_present":previous,
                                     "messages_total":len(job["messages"])})
                    idx=obs.done
                    store.complete(db,job["job_id"],job["lease_token"],
                                   {"content":MARKERS[idx]})
                    obs.done+=1
                except Exception as ex:
                    obs.errors.append(type(ex).__name__+":"+str(ex)[:110])
                    break
        fake=threading.Thread(target=worker,daemon=True);fake.start()
        cfg=json.loads(SOURCE.read_text(encoding="utf-8"))
        cfg.pop("mcp",None)
        cfg["models"]["providers"]["local-chat-queue"]["baseUrl"]=(
            f"http://127.0.0.1:{srv.server_address[1]}/v1")
        cfg["models"]["providers"]["local-chat-queue"]["apiKey"]=TOKEN
        cfg["agents"]["defaults"]["workspace"]=str(root/"workspace")
        cfg["tools"]={"deny":["*"]}
        config=root/"openclaw.json"
        config.write_text(json.dumps(cfg),encoding="utf-8")
        env=dict(os.environ)
        env.update({"OPENCLAW_STATE_DIR":str(root/"state"),
                    "OPENCLAW_CONFIG_PATH":str(config),
                    "PATH":str(NODE.parent)+os.pathsep+env.get("PATH",""),
                    "NO_COLOR":"1"})
        results=[]
        for i in range(2):
            text="This is synthetic session first turn." if i==0 else "Continue the same synthetic session."
            cmd=[str(NODE),str(CLI),"agent","--local","--message",text,
                 "--session-id","openclaw-persistent-synthetic-session",
                 "--model","local-chat-queue/chatgpt-web-queued",
                 "--timeout","60","--json"]
            try:
                p=subprocess.run(cmd,cwd=HERE/"npm-runtime",env=env,
                                 capture_output=True,text=True,encoding="utf-8",
                                 errors="replace",timeout=85)
                results.append({"ordinal":i+1,"exit":p.returncode,
                                "marker_present":MARKERS[i] in p.stdout,
                                "stderr_tail":p.stderr[-800:] if p.returncode else ""})
            except (subprocess.TimeoutExpired,OSError) as ex:
                results.append({"ordinal":i+1,"error":type(ex).__name__})
                break
        obs.stop.set();fake.join(3)
        srv.shutdown();srv.server_close();thread.join(3)
        ok=(len(results)==2 and all(x.get("exit")==0 and x.get("marker_present")
                                     for x in results)
            and obs.done==2 and len(obs.jobs)==2
            and obs.jobs[1]["prior_assistant_present"] and not obs.errors)
        print(json.dumps({"ok":ok,"model":"synthetic-only","results":results,
                          "observed_model_requests":obs.jobs,
                          "worker_completions":obs.done,"errors":obs.errors,
                          "actual_gpt_requests":0,"external_mcp_calls":0},ensure_ascii=True))
        return 0 if ok else 2

if __name__=="__main__":
    sys.exit(main())
