"""Offline checks against the freshly cloned OpenClaw source and queue shim config.

Do not contact OpenAI or run Gateway; do not mutate user OpenClaw auth or config.
"""
import json
import socket
import subprocess
import unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]/"OpenClaw-lab"
CONFIG=HERE/"openclaw.queued-model.LAB-only.json"
NODE=HERE/"portable-node"/"node.exe"

class OpenClawLocalCheckoutTests(unittest.TestCase):
    def test_cloned_source_has_runtime_and_mcp_modules(self):
        for path in ("package.json","openclaw.mjs",
                     "src/config/schema.help.models.ts",
                     "src/agents/agent-bundle-mcp-runtime.ts",
                     "src/agents/agent-runtime-config.ts"):
            self.assertTrue((REPO/path).is_file(),path)
        pkg=json.loads((REPO/"package.json").read_text(encoding="utf-8"))
        self.assertEqual(pkg["name"],"openclaw")
        self.assertIn("packageManager",pkg)

    def test_source_exposes_custom_model_and_openclaw_runtime(self):
        src=(REPO/"src/config/schema.help.models.ts").read_text(encoding="utf-8")
        self.assertIn("models.providers.*.agentRuntime.id",src)
        self.assertIn("agents.defaults.models.*.agentRuntime.id",src)

    def test_lab_queue_model_is_not_aliasing_public_openai_provider(self):
        cfg=json.loads(CONFIG.read_text(encoding="utf-8"))
        self.assertEqual(cfg["agents"]["defaults"]["model"]["primary"],
                         "local-chat-queue/chatgpt-web-queued")
        custom=cfg["models"]["providers"]["local-chat-queue"]
        self.assertEqual(custom["api"],"openai-completions")
        self.assertEqual(custom["baseUrl"],"http://127.0.0.1:8786/v1")
        self.assertEqual(custom["apiKey"],"${OPENCLAW_BRIDGE_TOKEN}")
        self.assertEqual(custom["models"][0]["id"],"chatgpt-web-queued")
        self.assertNotIn("openai",cfg["models"]["providers"])

    def test_mcp_is_loopback_readonly_tools(self):
        cfg=json.loads(CONFIG.read_text(encoding="utf-8"))
        mcp=cfg["mcp"]["servers"]["local-workspace"]
        self.assertEqual(mcp["url"],"http://127.0.0.1:8765/mcp")
        self.assertEqual(mcp["transport"],"streamable-http")
        self.assertTrue(mcp["toolFilter"]["include"])
        self.assertNotIn("run_command",mcp["toolFilter"]["include"])
        self.assertNotIn("write_file",mcp["toolFilter"]["include"])

    def test_portable_node_correct_and_no_mutating_cli(self):
        out=subprocess.run([str(NODE),"--version"],capture_output=True,text=True,timeout=10)
        self.assertEqual(out.returncode,0)
        self.assertEqual(out.stdout.strip(),"v26.12.1")

    def test_mcp_port_is_reachable_but_not_claim_model_readiness(self):
        with socket.create_connection(("127.0.0.1",8765),timeout=2):
            pass
        self.assertFalse((REPO/"dist"/"entry.js").is_file())

if __name__=="__main__":
    unittest.main()
