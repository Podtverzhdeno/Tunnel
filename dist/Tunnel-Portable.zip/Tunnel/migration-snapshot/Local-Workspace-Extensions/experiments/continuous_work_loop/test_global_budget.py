"""Atomic five-role global budget tests on disposable databases only."""
import concurrent.futures
import tempfile
import unittest
from pathlib import Path

from global_budget import GlobalBudgetLedger


class GlobalBudgetTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "budget.sqlite"
        self.ledger = GlobalBudgetLedger(self.path, 100_000_000)

    def test_five_roles_reserve_shared_cap_and_sixth_is_denied(self):
        for i, role in enumerate((
            "developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer"
        )):
            self.assertTrue(self.ledger.reserve(f"r{i}", role, f"P10{i}", 20_000_000))
        self.assertFalse(self.ledger.reserve("r6", "developer-1", "P200", 1))
        self.assertEqual(self.ledger.summary()["remaining_nanodollars"], 0)

    def test_duplicate_reservation_does_not_double_charge(self):
        self.assertTrue(self.ledger.reserve("r1", "developer-1", "P100", 40_000_000))
        self.assertTrue(self.ledger.reserve("r1", "developer-1", "P100", 40_000_000))
        self.assertEqual(self.ledger.summary()["accounted_or_held_nanodollars"], 40_000_000)

    def test_conflicting_request_id_is_rejected(self):
        self.ledger.reserve("r1", "developer-1", "P100", 10_000_000)
        with self.assertRaises(ValueError):
            self.ledger.reserve("r1", "developer-2", "P200", 10_000_000)
        with self.assertRaises(ValueError):
            self.ledger.reserve("r1", "developer-1", "P100", 20_000_000)

    def test_settle_releases_unused_reservation_once(self):
        self.ledger.reserve("r1", "developer-1", "P100", 80_000_000)
        self.assertEqual(self.ledger.settle("r1", 30_000_000), "settled")
        self.assertEqual(self.ledger.settle("r1", 30_000_000), "settled")
        self.assertEqual(self.ledger.summary()["remaining_nanodollars"], 70_000_000)
        with self.assertRaises(ValueError):
            self.ledger.settle("r1", 31_000_000)

    def test_ambiguous_charge_stays_reserved_and_requires_owner(self):
        self.ledger.reserve("r1", "developer-2", "P101", 90_000_000)
        self.assertEqual(self.ledger.mark_unknown("r1"), "unknown")
        self.assertEqual(self.ledger.mark_unknown("r1"), "unknown")
        self.assertFalse(self.ledger.reserve("r2", "developer-2", "P101", 20_000_000))
        self.assertEqual(self.ledger.summary()["ambiguous_held"], 1)
        with self.assertRaises(ValueError):
            self.ledger.settle("r1", 15_000_000)

    def test_overrun_fails_closed_on_next_attempt(self):
        self.ledger.reserve("r1", "developer-1", "P101", 20_000_000)
        self.ledger.settle("r1", 120_000_000)
        self.assertTrue(self.ledger.summary()["over_cap"])
        self.assertFalse(self.ledger.reserve("r2", "developer-3", "P102", 1))

    def test_reopen_does_not_silently_increase_cap(self):
        self.ledger.reserve("r1", "developer-1", "P101", 10_000_000)
        self.assertEqual(GlobalBudgetLedger(self.path, 100_000_000).summary()["reservations"], 1)
        with self.assertRaises(ValueError):
            GlobalBudgetLedger(self.path, 200_000_000)

    def test_parallel_reservations_do_not_exceed_ceiling(self):
        roles = ["developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer"]
        def task(i):
            own = GlobalBudgetLedger(self.path, 100_000_000)
            return own.reserve(f"parallel-{i}", roles[i%5], f"P{i}", 15_000_000)
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
            wins = list(pool.map(task, range(20)))
        self.assertEqual(sum(wins), 6)
        self.assertEqual(self.ledger.summary()["accounted_or_held_nanodollars"], 90_000_000)

    def test_invalid_scope_and_nanodollar_values(self):
        with self.assertRaises(ValueError):
            self.ledger.reserve("../r", "developer-1", "P101", 20)
        with self.assertRaises(ValueError):
            self.ledger.reserve("r", "superadmin", "P101", 20)
        with self.assertRaises(ValueError):
            self.ledger.reserve("r", "developer-1", "P101", -1)
        with self.assertRaises(ValueError):
            self.ledger.settle("missing", -1)

    def test_unapproved_global_cap_cannot_be_used(self):
        with self.assertRaises(ValueError):
            GlobalBudgetLedger(self.path, 0)
        with self.assertRaises(ValueError):
            GlobalBudgetLedger(self.path, 2_000_000_000_000)


if __name__ == "__main__":
    unittest.main()
