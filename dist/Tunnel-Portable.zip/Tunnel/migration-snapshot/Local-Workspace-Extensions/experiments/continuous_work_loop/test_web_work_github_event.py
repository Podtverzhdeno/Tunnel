"""Web-native GitHub event bridge tests: all network operations mocked."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import web_work_github_event as web


def event():
    return {"role": "developer-2", "task_id": "P106",
            "checkpoint_sha256": "b" * 64,
            "event_id": "checkpoint-P106-v2", "status": "checkpoint"}


class WebEventBridgeTests(unittest.TestCase):
    def test_checkpoint_validation(self):
        self.assertEqual(web.validate(event())["role"], "developer-2")
        for v in ("developer-5", "owner", ""):
            bad = event()
            bad["role"] = v
            with self.assertRaises(web.EventError):
                web.validate(bad)

    def test_invalid_ids_and_unknown_fields(self):
        for field, bad_value in (("task_id", "../../.env"),
                                 ("event_id", "bad"),
                                 ("checkpoint_sha256", "bad"),
                                 ("status", "approved")):
            data = event()
            data[field] = bad_value
            with self.assertRaises(web.EventError):
                web.validate(data)
        data = event()
        data["secret"] = "must never be forwarded"
        with self.assertRaises(web.EventError):
            web.validate(data)

    def test_message_contains_no_code_or_secrets(self):
        body = web.message(event())
        self.assertIn("P106", body)
        self.assertIn("not as proof", body)
        self.assertNotIn("codex exec", body)

    def test_request_uses_real_github_pr_comment_endpoint(self):
        req = web.github_request("Podtverzhdeno/Example", 123, "fake-token", web.message(event()))
        self.assertEqual(req.get_method(), "POST")
        self.assertEqual(req.full_url, "https://api.github.com/repos/Podtverzhdeno/Example/issues/123/comments")
        body = json.loads(req.data)
        self.assertEqual(set(body), {"body"})
        self.assertIn("checkpoint-P106-v2", body["body"])

    def test_repo_pr_token_validation(self):
        for repo in ("../../bad", "oneonly", "a/b/c"):
            with self.assertRaises(web.EventError):
                web.github_request(repo, 1, "tok", "hello")
        with self.assertRaises(web.EventError):
            web.github_request("a/b", 0, "tok", "hello")
        with self.assertRaises(web.EventError):
            web.github_request("a/b", 1, "", "hello")

    def test_confirmed_comment_mock(self):
        class Response:
            status = 201
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def read(self, n): return b'{"id":123456,"body":"example"}'
        r = web.github_request("a/b", 1, "test", "hello")
        result = web.create_comment(r, opener=lambda req, timeout: Response())
        self.assertEqual(result, {"created": True, "comment_id": 123456})

    def test_unconfirmed_comment_not_success(self):
        class Response:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def read(self, n): return b'{"id":3}'
        with self.assertRaises(web.EventError):
            web.create_comment("request", opener=lambda req, timeout: Response())

    def test_dry_run_never_calls_network(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "checkpoint.json"
            p.write_text(json.dumps(event()), encoding="utf-8")
            out = io.StringIO()
            with patch.object(web, "create_comment", side_effect=AssertionError("network")):
                with contextlib.redirect_stdout(out):
                    rc = web.main(["--event-file", str(p), "--repo",
                                   "Podtverzhdeno/Example", "--pr", "123"])
            self.assertEqual(rc, 0)
            obj = json.loads(out.getvalue())
            self.assertEqual(obj["mode"], "dry-run")
            self.assertFalse(obj["chatgpt_work_started"])
            self.assertFalse(obj["github_comment_created"])

    def test_send_requires_confirmation_and_token(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "checkpoint.json"
            p.write_text(json.dumps(event()), encoding="utf-8")
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as e:
                    web.main(["--event-file", str(p), "--repo",
                              "a/b", "--pr", "1", "--send"])
            self.assertEqual(e.exception.code, 2)
            with patch.dict("os.environ", {"GITHUB_TOKEN": ""}):
                with self.assertRaises(web.EventError):
                    with contextlib.redirect_stderr(io.StringIO()):
                        web.main(["--event-file", str(p), "--repo", "a/b",
                                  "--pr", "1", "--send", "--confirm", "a/b#1"])

    def test_same_event_fails_closed_after_first_reservation(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(web, "EVENT_RECEIPTS", Path(tmp) / "receipts"):
                marker = web.reserve_event_once("checkpoint-P106-v2", "a/b#1")
                self.assertTrue(marker.exists())
                with self.assertRaises(web.EventError):
                    web.reserve_event_once("checkpoint-P106-v2", "a/b#1")
                web.mark_confirmed(marker, 123)
                self.assertEqual(json.loads(marker.read_text())["state"], "confirmed")
                with self.assertRaises(web.EventError):
                    web.reserve_event_once("checkpoint-P106-v2", "a/b#1")

    def test_send_only_one_event_when_mocked(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "checkpoint.json"
            p.write_text(json.dumps(event()), encoding="utf-8")
            out = io.StringIO()
            with patch.dict("os.environ", {"GITHUB_TOKEN": "mock-test-key"}):
                with patch.object(web, "EVENT_RECEIPTS", Path(t) / "receipts"):
                    with patch.object(web, "create_comment", return_value={"created": True, "comment_id": 12}) as mocked:
                        with contextlib.redirect_stdout(out):
                            rc = web.main(["--event-file", str(p), "--repo", "a/b",
                                           "--pr", "1", "--send", "--confirm", "a/b#1"])
            self.assertEqual(rc, 0)
            mocked.assert_called_once()
            self.assertEqual(json.loads(out.getvalue())["chatgpt_work_run"], "not_verified")


if __name__ == "__main__":
    unittest.main()
