"""Experimental shared, atomic budget reservation for five agent roles.

Uses a disposable SQLite file independent of the production coordinator.
Reservations are pessimistic: ambiguous provider outcomes keep full cost held.
This module grants no tool, role or owner privileges.
"""
from __future__ import annotations

import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path

ID = re.compile(r"^[A-Za-z0-9._-]{1,120}$")
ROLE = re.compile(r"^(?:developer-[1-4]|architect-reviewer)$")
MAX_CAP_NANODOLLARS = 1_000_000_000_000  # $1,000 is a strict experiment ceiling


@contextmanager
def db_connection(path: Path):
    conn = sqlite3.connect(str(path), timeout=10, isolation_level=None)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS config (
                single_id INTEGER PRIMARY KEY CHECK(single_id=1),
                cap_nano INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS reservations (
                request_id TEXT PRIMARY KEY,
                role TEXT NOT NULL,
                task_id TEXT NOT NULL,
                reserve_nano INTEGER NOT NULL,
                actual_nano INTEGER,
                status TEXT NOT NULL CHECK(status IN ('reserved','settled','unknown'))
            );
        """)
        with conn:
            yield conn
    finally:
        conn.close()


class GlobalBudgetLedger:
    def __init__(self, path: Path, cap_nanodollars: int):
        if (not isinstance(cap_nanodollars, int) or isinstance(cap_nanodollars, bool)
                or not 1 <= cap_nanodollars <= MAX_CAP_NANODOLLARS):
            raise ValueError("invalid global spending ceiling")
        self.path = Path(path)
        self.cap = cap_nanodollars
        with db_connection(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT OR IGNORE INTO config(single_id,cap_nano) VALUES(1,?)", (self.cap,))
            row = db.execute("SELECT cap_nano FROM config WHERE single_id=1").fetchone()
            if row["cap_nano"] != self.cap:
                raise ValueError("budget limit cannot be silently modified")

    def _spent(self, db):
        row = db.execute("""
          SELECT COALESCE(SUM(
            CASE WHEN status='settled' THEN actual_nano ELSE reserve_nano END
          ),0) AS total FROM reservations
        """).fetchone()
        return int(row["total"])

    def reserve(self, request_id: str, role: str, task_id: str, amount_nanodollars: int) -> bool:
        if (not isinstance(request_id, str) or not ID.fullmatch(request_id)
            or not isinstance(task_id, str) or not ID.fullmatch(task_id)
            or not isinstance(role, str) or not ROLE.fullmatch(role)):
            raise ValueError("invalid scope or id")
        if not isinstance(amount_nanodollars, int) or isinstance(amount_nanodollars, bool) or amount_nanodollars <= 0:
            raise ValueError("reserve must be positive")
        with db_connection(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            previous = db.execute("SELECT * FROM reservations WHERE request_id=?", (request_id,)).fetchone()
            if previous:
                if (previous["role"], previous["task_id"], previous["reserve_nano"]) != (role, task_id, amount_nanodollars):
                    raise ValueError("conflicting idempotency key")
                return True  # existing reservation, no second charge
            if self._spent(db) + amount_nanodollars > self.cap:
                return False
            db.execute(
                "INSERT INTO reservations(request_id,role,task_id,reserve_nano,status) VALUES(?,?,?,?,?)",
                (request_id, role, task_id, amount_nanodollars, "reserved"))
        return True

    def settle(self, request_id: str, actual_nanodollars: int) -> str:
        if not isinstance(actual_nanodollars, int) or isinstance(actual_nanodollars, bool) or actual_nanodollars < 0:
            raise ValueError("actual must be nonnegative")
        with db_connection(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            r = db.execute("SELECT * FROM reservations WHERE request_id=?", (request_id,)).fetchone()
            if r is None:
                raise KeyError("no reservation")
            if r["status"] == "settled":
                if r["actual_nano"] != actual_nanodollars:
                    raise ValueError("conflicting provider receipt")
                return "settled"
            if r["status"] == "unknown":
                raise ValueError("unknown outcome requires owner reconciliation")
            # Always record reality, even if provider used more than reserved.
            # If it pushes spent above cap, future reserves are rejected.
            db.execute("UPDATE reservations SET actual_nano=?,status='settled' WHERE request_id=?",
                       (actual_nanodollars, request_id))
            return "settled"

    def mark_unknown(self, request_id: str) -> str:
        with db_connection(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            r = db.execute("SELECT * FROM reservations WHERE request_id=?", (request_id,)).fetchone()
            if r is None:
                raise KeyError("no reservation")
            if r["status"] == "settled":
                raise ValueError("already settled")
            db.execute("UPDATE reservations SET status='unknown' WHERE request_id=?", (request_id,))
            return "unknown"

    def summary(self) -> dict:
        with db_connection(self.path) as db:
            total = self._spent(db)
            counts = {x["status"]: x["n"] for x in
                db.execute("SELECT status,COUNT(*) AS n FROM reservations GROUP BY status")}
            return {
                "cap_nanodollars": self.cap,
                "accounted_or_held_nanodollars": total,
                "remaining_nanodollars": max(0, self.cap-total),
                "over_cap": total > self.cap,
                "reservations": counts.get("reserved", 0),
                "settled": counts.get("settled", 0),
                "ambiguous_held": counts.get("unknown", 0),
                "actual_external_provider_billing_verified": False,
            }
