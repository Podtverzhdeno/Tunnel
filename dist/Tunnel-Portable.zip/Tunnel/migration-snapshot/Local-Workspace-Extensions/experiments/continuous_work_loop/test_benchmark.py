"""A/B checks: no misleading claims of free output or real provider calls."""
import unittest
from benchmark import ROLES, compare, scenario


class OfflineFiveAgentBenchmark(unittest.TestCase):
    def test_all_five_roles_are_present(self):
        result = scenario(1)
        self.assertEqual(result["roles"], 5)
        self.assertEqual({r["role"] for r in result["per_role"]}, set(ROLES))
        self.assertEqual(result["provider_calls_simulated"], 5)
        self.assertEqual(result["actual_llm_calls"], 0)

    def test_continuous_starts_more_turns_and_costs_more(self):
        result = compare()
        a, b = result["baseline"], result["continuous"]
        self.assertEqual(a["verified_steps_simulated"], 5)
        self.assertEqual(b["verified_steps_simulated"], 15)
        self.assertEqual(a["provider_calls_simulated"], 5)
        self.assertEqual(b["provider_calls_simulated"], 15)
        self.assertEqual(round(b["cost_usd_simulated"] / a["cost_usd_simulated"]), 3)
        self.assertEqual(b["actual_llm_calls"], 0)


if __name__ == "__main__":
    unittest.main()
