# Continuous Work Loop — offline spike (NOT production)

Location: `Local-Workspace-Extensions/experiments/continuous_work_loop`.

This experiment demonstrates **bounded fresh provider turns**, not indefinite thinking
inside ChatGPT, not a way around ChatGPT Scheduled quotas, and not a working API client.
It does not alter `agent_team.py`, the active 5-role SQLite team queue,
Automations, MCP permissions, git repositories or any real external services.

## Run (Windows, no added dependencies)

From this directory:
```powershell
python -m unittest discover -v
python loop.py
python benchmark.py
```

`loop.py` runs one fake worker through three turns. `benchmark.py` runs two
*synthetic* five-role scenarios (one turn per role vs three turns per role).
No provider SDK is imported, no credentials are accessed, and actual_llm_calls=0.
The synthetic price coefficient is $2/M input and $10/M output **for illustration
only**, not verified billing. More turns produce more fake accepted steps and
increase proportional cost. This is not a productivity result from GPT-6.

## Behavior and safety controls

- `Supervisor.tick()` initiates at most one bounded injected provider call.
  `drive()` is capped to 256 local iterations and defaults to at most 16.
- SQLite WAL stores per-run status, model turn IDs, exact usage receipts when
  supplied, accepted evidence hashes and stop reason. It does **not** store
  raw prompts, keys or hidden reasoning. A new process may continue a completed
  turn using the same run ID and database.
- Each turn reserves its worst-case input/output cost against the configured
  total budget *before* calling the provider. Wall-clock and no-progress limits
  also stop more turns. External adapters must enforce per-call timeouts and
  output-token caps, because this process cannot forcibly stop an already
  running provider call.
- `authorize` and `verify` are **injected trusted host callbacks**. The
  built-in examples use deterministic fake callbacks, not real security grants.
  Provider claims alone never count as verified code or QA results.
- The supervisor refuses to replay ambiguous in-flight calls after restart,
  returning `reconciliation_needed`. Such a call might already have been
  billed even when its exact usage was not recorded.
- `usage_complete=0` means aggregate token/cost totals are **partial/unknown**,
  not accurate zero totals. All simulated totals are explicitly labeled fake.
- `requires_action` stops for external approval; there is no automatic
  authorization, self-review, auto-merge or privilege escalation.
- A standalone Python script cannot wake ChatGPT Scheduled or create additional
  ChatGPT messages. True API continuation would require a separately authorized
  long-running application and API account.

## Promotion prerequisites

1. Owner approves the exact OpenSpec request
   `add-continuous-agent-work-loop` via interactive local terminal. Its
   request ID and expiration are managed outside this experiment.
2. Reviewer reconciles the final OpenSpec and SDD requirements with this
   standalone spike; do not declare it canonically accepted yet.
3. Implement a real provider adapter behind an opt-in API spending cap, handle
   provider output statuses/rate limits, capture exact usage and verify the
   provider's token ceiling semantics. Keep keys in a trusted secret manager.
4. Add host-enforced identity/grants, task lease and spec SHA revalidation,
   independent QA and reconciled external tool receipts. These cannot be
   implemented merely by Python caller-provided booleans.
5. End-to-end chaos tests: concurrent two-process claim prevention, SIGKILL,
   network failure after provider success, power-loss and WAL durability,
   incomplete receipts and owner-denied approvals.
6. Only after approval: connect the new runner to the existing coordinator
   without modifying live SQLite schema out-of-band; canary test at a tiny
   authorized cost cap before any persistent paid workload.

**Current acceptance:** experiment runs offline and its unittest suite can be
executed locally. There is **no** real GPT-6 connection, 24/7 service,
scheduler rescheduling or verified production token usage in this spike.
