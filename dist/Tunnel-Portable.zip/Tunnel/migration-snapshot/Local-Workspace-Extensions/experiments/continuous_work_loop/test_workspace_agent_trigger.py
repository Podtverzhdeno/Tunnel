"""Official Workspace Agents API offline contract tests. Network is never called."""
import contextlib
import io
import json
import unittest
from unittest.mock import patch
import workspace_agent_trigger as mod


class WorkspaceAgentTriggerTests(unittest.TestCase):
    def test_exact_supported_role_and_conversation(self):
        obj = mod.payload("developer-3", "P110", "my-project")
        self.assertEqual(obj["conversation_key"], "my-project")
        self.assertIn("developer-3", obj["input"])
        with self.assertRaises(ValueError):
            mod.payload("superadmin", "P110", "my-project")

    def test_no_unsafe_topic_or_path_in_query(self):
        with self.assertRaises(ValueError):
            mod.payload("developer-1", "../.env", "my-project")
        with self.assertRaises(ValueError):
            mod.payload("developer-1", "P110", "../../root")

    def test_request_is_official_endpoint_with_idempotency(self):
        r = mod.build_request(
            "agtch_fixture", "architect-reviewer", "P110", "project-1",
            "verified-event-abc", "not-a-real-access-token")
        self.assertEqual(r.get_method(), "POST")
        self.assertEqual(r.full_url, "https://api.chatgpt.com/v1/workspace_agents/agtch_fixture/trigger")
        self.assertEqual(r.get_header("Idempotency-key"), "verified-event-abc")
        self.assertEqual(r.get_header("Openai-beta"), "workspace_agent_runs=v1")
        self.assertEqual(json.loads(r.data)["conversation_key"], "project-1")

    def test_missing_credentials_or_bad_trigger_refused(self):
        with self.assertRaises(ValueError):
            mod.build_request("bad", "developer-1", "P110", "project", "verified-event-abc", "token")
        with self.assertRaises(ValueError):
            mod.build_request("agtch_fixture", "developer-1", "P110", "project", "", "token")
        with self.assertRaises(ValueError):
            mod.build_request("agtch_fixture", "developer-1", "P110", "project", "verified-event-abc", "")

    def test_accepted_only_on_202(self):
        result = mod.interpret_trigger_response(202, {
            "conversation_url": "https://chatgpt.com/c/123",
            "agent_trigger_run_id": "apirun_123"
        })
        self.assertTrue(result["accepted"])
        self.assertEqual(result["run_id"], "apirun_123")
        self.assertFalse(result["text_response_available_via_api"])
        with self.assertRaises(mod.WorkspaceTriggerFailure):
            mod.interpret_trigger_response(200, {"conversation_url": "https://chatgpt.com/c/123"})

    def test_wrong_domain_not_accepted(self):
        with self.assertRaises(mod.WorkspaceTriggerFailure):
            mod.interpret_trigger_response(202, {"conversation_url": "https://evil.test/c/123"})

    def test_status_poll_only_returns_status_not_agent_answer(self):
        req = mod.build_status_request("agtch_fixture", "apirun_123", "token")
        self.assertEqual(req.get_method(), "GET")
        self.assertIn("/runs/apirun_123", req.full_url)
        response = mod.interpret_status({"status": "completed", "error": None})
        self.assertTrue(response["terminal"])
        self.assertIsNone(response["verified_code_changes"])
        self.assertFalse(mod.interpret_status({"status": "suspended"})["terminal"])

    def test_unknown_status_fails_closed(self):
        with self.assertRaises(mod.WorkspaceTriggerFailure):
            mod.interpret_status({"status": "something_unexpected"})

    def test_dry_run_default_not_network(self):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = mod.main(["--role", "developer-2"])
        self.assertEqual(code, 0)
        result = json.loads(buffer.getvalue())
        self.assertEqual(result["mode"], "dry-run")
        self.assertEqual(result["api_calls"], 0)

    def test_real_call_requires_explicit_token_trigger_and_event(self):
        with patch.dict("os.environ", {"WORKSPACE_AGENT_ACCESS_TOKEN": ""},
                        clear=False):
            with self.assertRaises(SystemExit) as outcome:
                mod.main(["--execute"])
        self.assertEqual(outcome.exception.code, 2)

    def test_mock_post_does_not_access_live_network(self):
        class Response:
            status = 202
            def __enter__(self):
                return self
            def __exit__(self, *args):
                return False
            def read(self, n):
                return b'{"conversation_url":"https://chatgpt.com/c/123","agent_trigger_run_id":"apirun_123"}'
        request = mod.build_request("agtch_demo", "developer-1", "P100",
                                     "project", "event-001", "fake-token")
        result = mod.perform(request, opener=lambda req, timeout: Response())
        self.assertEqual(result[0], 202)
        self.assertTrue(mod.interpret_trigger_response(*result)["accepted"])


if __name__ == "__main__":
    unittest.main()
