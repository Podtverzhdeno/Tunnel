"""ChatGPT-plan Codex CLI bridge: explicit, bounded, read-only five-role pilot.

Does NOT automate chatgpt.com, bypass quota, or use an OpenAI API key.
Real runs require Codex CLI installed and signed in with ChatGPT, and --execute.
The current pilot cannot mark real development tickets done or self-approve merges.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
STATE = ROOT / ".codex_subscription_state.json"
LOCK = ROOT / ".codex_subscription_run.lock"
ROLES = ("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer")
SESSION_RE = re.compile(r"^[a-f0-9-]{20,80}$")
MAX_OUTPUT_BYTES = 2_000_000


def codex_executable() -> str | None:
    return shutil.which("codex") or shutil.which("codex.cmd") or shutil.which("codex.exe")


def prompt_for(role: str) -> str:
    if role not in ROLES:
        raise ValueError("unknown role")
    focus = ("independent architecture, threat-model and QA gap review"
             if role == "architect-reviewer" else
             "one small independently testable implementation recommendation")
    return (
        f"Role: {role}. Work in a restricted, READ-ONLY subscription-powered pilot. "
        "Read only project documentation relevant to the assigned role in the current directory. "
        "No source edits, terminal modifications, Git operations, commits, pushes, MCP writes or approvals. "
        f"Identify {focus} for Local-Workspace-Extensions. "
        "Do not claim the production queue assigned a ticket; you have no lease. "
        "Use existing OpenSpec/SDD terminology; do not invent PASS evidence. "
        "Return concise next steps. If unable to read the project files, report the limitation. "
        "Stop normally after one useful output, and do not ask to circumvent usage limits."
    )


def build_command(executable: str, role: str, session: str | None = None) -> list[str]:
    prompt = prompt_for(role)
    if session:
        if not SESSION_RE.fullmatch(session):
            raise ValueError("malformed session ID")
        # resume is an experimental path until tested with the local Codex version.
        return [executable, "exec", "--sandbox", "read-only", "resume", "--json", session, prompt]
    return [executable, "exec", "--json", "--sandbox", "read-only",
            "--skip-git-repo-check", prompt]


def parse_jsonl(text: str) -> dict:
    status = "unknown"
    thread = None
    usage = None
    answer_digest = None
    events = 0
    if len(text.encode("utf-8")) > MAX_OUTPUT_BYTES:
        return {"status": "output_too_large", "thread_id": None,
                "usage": None, "events": 0, "answer_sha256": None}
    for line in text.splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except (ValueError, TypeError):
            continue
        if not isinstance(event, dict):
            continue
        events += 1
        kind = event.get("type")
        if kind == "thread.started":
            candidate = event.get("thread_id")
            if isinstance(candidate, str) and SESSION_RE.fullmatch(candidate):
                thread = candidate
        elif kind == "turn.completed":
            status = "completed"
            u = event.get("usage")
            if isinstance(u, dict):
                fields = ("input_tokens", "cached_input_tokens", "output_tokens")
                if all(type(u.get(k)) is int and u[k] >= 0 for k in fields):
                    usage = {k: u[k] for k in fields}
        elif kind in ("turn.failed", "error"):
            status = "failed"
        elif kind == "turn.interrupted":
            status = "interrupted"
        elif kind == "item.completed":
            item = event.get("item")
            if isinstance(item, dict) and item.get("type") == "agent_message":
                msg = item.get("text")
                if isinstance(msg, str):
                    answer_digest = hashlib.sha256(msg.encode("utf-8")).hexdigest()
    return {"status": status, "thread_id": thread, "usage": usage,
            "events": events, "answer_sha256": answer_digest}


def clean_environment() -> dict[str, str]:
    env = os.environ.copy()
    # Prefer a signed-in ChatGPT plan. Prevent accidental per-token API billing.
    for key in ("OPENAI_API_KEY", "CODEX_API_KEY"):
        env.pop(key, None)
    return env


def chatgpt_subscription_login(executable: str) -> bool:
    """Fail closed unless Codex explicitly reports ChatGPT sign-in, not API-key auth."""
    try:
        result = subprocess.run(
            [executable, "login", "status"], cwd=str(ROOT), env=clean_environment(),
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=15, shell=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    output = ((result.stdout or "") + "\n" + (result.stderr or "")).lower()
    return result.returncode == 0 and "chatgpt" in output and "api key" not in output


def read_state() -> dict:
    if not STATE.exists():
        return {"schema": 1, "roles": {}, "runs": 0}
    obj = json.loads(STATE.read_text(encoding="utf-8"))
    if (not isinstance(obj, dict) or obj.get("schema") != 1
        or not isinstance(obj.get("roles"), dict)
        or type(obj.get("runs")) is not int):
        raise ValueError("existing session metadata needs manual reconciliation")
    return obj


def save_state(state: dict) -> None:
    data = json.dumps(state, ensure_ascii=True, indent=2)
    fd, tmp = tempfile.mkstemp(prefix=".codex-state-", suffix=".json", dir=ROOT)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, STATE)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def invoke(executable: str, role: str, timeout: int, *, session: str | None = None,
           runner=subprocess.run) -> dict:
    command = build_command(executable, role, session)
    try:
        result = runner(
            command, cwd=str(ROOT), env=clean_environment(),
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, shell=False,
        )
    except subprocess.TimeoutExpired:
        return {"role": role, "status": "timeout_requires_review",
                "thread_id": None, "usage": None, "events": 0, "returncode": None}
    except (OSError, ValueError):
        return {"role": role, "status": "spawn_failed",
                "thread_id": None, "usage": None, "events": 0, "returncode": None}
    result_meta = parse_jsonl(result.stdout or "")
    result_meta["role"] = role
    result_meta["returncode"] = result.returncode
    if result.returncode != 0:
        result_meta["status"] = "failed"
    # Never persist or display raw prompts, model text, stderr or auth tokens.
    return result_meta


def execute(roles: tuple[str, ...], max_turns: int, timeout: int,
            *, resume: bool = False, invoker=invoke, executable: str | None = None,
            max_daily_turns: int = 20, max_daily_input: int = 2_000_000,
            max_daily_output: int = 100_000) -> dict:
    if not 1 <= max_turns <= 20:
        raise ValueError("max-turns must be <= 20")
    if not 10 <= timeout <= 600:
        raise ValueError("timeout must be 10..600 seconds")
    if not 1 <= max_daily_turns <= 100:
        raise ValueError("max_daily_turns must be 1..100")
    if not 1 <= max_daily_input <= 20_000_000 or not 1 <= max_daily_output <= 2_000_000:
        raise ValueError("invalid daily token budget")
    if not roles or any(role not in ROLES for role in roles):
        raise ValueError("invalid roles")
    exe = executable or codex_executable()
    if not exe:
        return {"status": "codex_cli_not_installed", "calls": 0, "results": []}
    if LOCK.exists():
        return {"status": "lock_exists_manual_inspection", "calls": 0, "results": []}
    if invoker is invoke and not chatgpt_subscription_login(exe):
        return {"status": "chatgpt_subscription_auth_unverified", "calls": 0, "results": []}
    # Fail closed if another run is in progress; no stale automatic lock takeover.
    try:
        fd = os.open(str(LOCK), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        return {"status": "lock_exists_manual_inspection", "calls": 0, "results": []}
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("Local read-only Codex run; inspect owner before clearing lock.\n")
        state = read_state()
        results = []
        for i in range(max_turns):
            role = roles[i % len(roles)]
            session = state["roles"].get(role, {}).get("thread_id") if resume else None
            outcome = invoker(exe, role, timeout, session=session)
            results.append(outcome)
            if outcome.get("status") != "completed":
                break  # authorization, quota and network failures are NOT retried
            previous = state["roles"].get(role, {})
            state["roles"][role] = {
                "thread_id": outcome.get("thread_id") or previous.get("thread_id"),
                "last_status": "completed",
                "last_result_sha256": outcome.get("answer_sha256"),
                "last_usage": outcome.get("usage"),
                "updated_utc": datetime.now(timezone.utc).isoformat(),
            }
            state["runs"] += 1
            save_state(state)
        return {"status": "completed" if len(results) == max_turns else "stopped",
                "calls": len(results), "results": results,
                "real_code_edits": 0, "production_agent_queue_unchanged": True}
    finally:
        LOCK.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true",
                        help="Explicit opt-in to consume ChatGPT/Codex plan allowance")
    parser.add_argument("--turns", type=int, default=5)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--role", choices=ROLES, help="run only one role")
    parser.add_argument("--resume-experimental", action="store_true",
                        help="Resume prior Codex thread ID (requires CLI compatibility)")
    args = parser.parse_args(argv)
    if not 1 <= args.turns <= 20 or not 10 <= args.timeout <= 600:
        parser.error("bounded turns 1..20 and timeout 10..600 required")
    roles = (args.role,) if args.role else ROLES
    if not args.execute:
        payload = {
            "mode": "dry-run",
            "codex_cli_found": bool(codex_executable()),
            "subscription_auth_verified": False,
            "max_turns": args.turns,
            "roles": list(roles),
            "commands_preview": [
                build_command("codex", role, None)[:5] + ["<role-specific prompt>"]
                for role in roles
            ],
            "paid_api_keys_read": False,
            "chatgpt_website_automated": False,
            "production_queue_mutated": False,
        }
        print(json.dumps(payload, indent=2, ensure_ascii=True))
        return 0
    result = execute(roles, args.turns, args.timeout, resume=args.resume_experimental)
    print(json.dumps(result, indent=2, ensure_ascii=True))
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
