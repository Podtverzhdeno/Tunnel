"""Read-only Codex CLI capability/auth probe; prints no account details or secrets."""
import json
import shutil
import subprocess
import os

exe = shutil.which("codex") or shutil.which("codex.cmd") or shutil.which("codex.exe")
output = {"codex_found": bool(exe), "version_available": False,
          "chatgpt_login_confirmed": False, "auth_method": "unknown",
          "exec_json_supported": False, "exec_resume_available": False,
          "tested_real_model": False, "model_calls": 0}
if exe:
    env = os.environ.copy()
    for secret in ("CODEX_API_KEY", "OPENAI_API_KEY"):
        env.pop(secret, None)
    def ask(*args):
        try:
            return subprocess.run([exe, *args], capture_output=True, text=True,
                                  encoding="utf-8", errors="replace", env=env,
                                  timeout=15, shell=False)
        except (OSError, subprocess.TimeoutExpired):
            return None
    v = ask("--version")
    output["version_available"] = bool(v and v.returncode == 0)
    if v:
        output["version_format_ok"] = v.returncode == 0 and "codex" in v.stdout.lower()
    login = ask("login", "status")
    if login:
        status = (login.stdout + "\n" + login.stderr).lower()
        output["login_status_succeeded"] = login.returncode == 0
        if login.returncode == 0 and "chatgpt" in status:
            output["chatgpt_login_confirmed"] = True
            output["auth_method"] = "chatgpt"
        elif login.returncode == 0 and "api key" in status:
            output["auth_method"] = "api_key_not_suitable"
        else:
            output["auth_method"] = "unknown"
    flags = ask("exec", "--help")
    if flags and flags.returncode == 0:
        h = (flags.stdout + flags.stderr).lower()
        output["exec_json_supported"] = "--json" in h
        output["read_only_sandbox_supported"] = "sandbox" in h
        output["exec_resume_available"] = "resume" in h
print(json.dumps(output, sort_keys=True))
