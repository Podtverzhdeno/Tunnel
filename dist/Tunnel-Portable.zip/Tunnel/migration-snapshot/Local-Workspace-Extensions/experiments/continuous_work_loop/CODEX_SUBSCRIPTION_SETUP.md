# Two supported ways to initiate agents from this Windows PC

Updated for the locally verified Codex CLI and the official Workspace Agents API.

## A. Codex CLI via ChatGPT plan (available on this PC)

Locally observed without a model call:
- Codex CLI executable detected.
- `codex --version` succeeded.
- `codex login status` reported sign-in via ChatGPT.
- Non-interactive JSON events and resume command are advertised by the CLI.
- Auth tokens, account email, raw CLI output and credentials were not logged by the probe.

This is **not** the same conversation as a web ChatGPT chat. It is an official
local coding-agent client authenticated by the user's ChatGPT plan; its use
consumes applicable Codex/Work allowance and credits if the user chooses
credit-backed usage. No limit bypass is attempted.

Open Windows Terminal:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\continuous_work_loop
python codex_auth_probe.py
python codex_subscription_bridge.py
```

The second command is offline dry-run. To explicitly consume a **single**
read-only subscription agent turn:

```powershell
python codex_subscription_bridge.py --execute --role developer-1 --turns 1 --timeout 90
```

To authorize one bounded read-only rotation across **all five** roles,
after inspecting your remaining ChatGPT/Codex allowance:

```powershell
python codex_subscription_bridge.py --execute --turns 5 --timeout 180
```

The pilot uses a subprocess without a shell; it removes OPENAI_API_KEY
and CODEX_API_KEY from the child environment to avoid accidentally
switching to per-token API-key billing. Still, check `codex login status`
manually before using real subscription calls. The built-in scope is
read-only. It cannot truthfully report implemented code, production QA,
a lease on a developer ticket, a real 24/7 daemon or a bypass of quotas.

A local JSON state file records only per-role session IDs, usage values,
output hashes and timestamps. No raw ChatGPT prompts or transcripts are
saved by this script. Session metadata is excluded via .gitignore and
should not be shared. A lock prevents overlapping invocations. Stale locks
require manual inspection: they are never removed automatically.
`--resume-experimental` can reuse saved Codex threads, but remains
disabled by default until real resume/version compatibility is tested.

**Before making it a production coding worker:** enforce task lease and
host-authenticated role, project-scoped OS sandbox, approved OpenSpec
requirements, independent test proof and reviewer queue transition. Do
not let the CLI write into the highly dirty parent IdeaProjects Git root.

## B. Official ChatGPT Workspace Agents API (eligibility-dependent)

This API triggers a **published Workspace Agent** from external systems
without automating the web page. It requires an administrative workspace,
an API channel trigger ID (agtch_...), and a Workspace Agent access token
provisioned under Admin > Access tokens. Personal Plus access to an
ordinary chat does not imply these features exist.

Offline plan:
```powershell
python workspace_agent_trigger.py --role developer-1 --task P110
```

If the authorized admin provisioned a token and a published trigger, set
`WORKSPACE_AGENT_ACCESS_TOKEN` in the local shell via an approved secret
mechanism (never commit it, paste it into chat, or put it in the task body).
One operator-initiated trigger:
```powershell
python workspace_agent_trigger.py --execute --trigger-id agtch_YOUR_ID --event-id approved-P110-001 --role developer-1 --task P110 --conversation-key LWE-DEV1
```

The event ID is a stable idempotency key: retry the same event with the same
key only after checking for an ambiguous prior submission. The server
returns a chat URL and optionally a run ID; it does **not** return the agent
answer text. Polling status (when enabled) does not prove actual code
changes or QA acceptance. Our code deliberately does not continuously
retrigger this API while no new, independently verified task exists.

Official references:
- https://learn.chatgpt.com/docs/non-interactive-mode
- https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan
- https://learn.chatgpt.com/workspace-agents/trigger-runs
- https://learn.chatgpt.com/workspace-agents/authentication

## Safety and limits

No Playwright/DOM automation of chatgpt.com is used. These official
interfaces do not remove ChatGPT usage allowances or grant a guaranteed
60-minute reasoning window. Any integration with the actual 5-agent
SQLite queue must be developed as a separate reviewed/approved phase.
The experimental Python drivers are intentionally bounded and never run
as an infinite, self-waking daemon by default.
