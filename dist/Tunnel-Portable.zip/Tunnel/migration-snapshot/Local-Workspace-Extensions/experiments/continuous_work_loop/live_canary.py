"""One-turn opt-in API canary. Dry-run is always the default.

No code edits, no tool use, no background service. The user explicitly chooses
the paid flag, a small dollar ceiling, and supplies their own API credentials.
"""
from __future__ import annotations

import argparse
import json
import os
import tempfile
import uuid
from decimal import Decimal, InvalidOperation
from pathlib import Path

from global_budget import GlobalBudgetLedger
from loop import Limits, Supervisor
from openai_response_adapter import (
    ApiSettings, OpenAIResponsesAdapter, build_payload,
)

USD_NANODOLLARS = 1_000_000_000
DEFAULT_MODEL = "gpt-6.1-sol"
MAX_INPUT = 2_000
MAX_OUTPUT = 256
# Standard short-context price snapshot for gpt-6.1-sol, independently revisable.
RATE_INPUT = 2_000
RATE_OUTPUT = 10_000
MAX_CANARY_USD = Decimal("0.10")


def requested_budget(value: str) -> int:
    try:
        amount = Decimal(value)
    except (InvalidOperation, TypeError):
        raise argparse.ArgumentTypeError("budget must be a USD decimal") from None
    if not amount.is_finite() or amount <= 0 or amount > MAX_CANARY_USD:
        raise argparse.ArgumentTypeError("budget must be > $0 and <= $0.10")
    return int(amount * USD_NANODOLLARS)


def plan(role: str, task: str, maximum_nanodollars: int) -> dict:
    limits = Limits(
        max_turns=1,
        max_total_input=MAX_INPUT,
        max_total_output=MAX_OUTPUT,
        max_turn_input=MAX_INPUT,
        max_turn_output=MAX_OUTPUT,
        max_cost_nanodollars=maximum_nanodollars,
        max_no_progress=1,
        max_wall_seconds=300,
    )
    snapshot = {"role": role, "task": task, "spec_sha": "a" * 64}
    payload = build_payload(snapshot, 1, limits.max_turn_input, limits.max_turn_output, ApiSettings())
    worst = (MAX_INPUT * RATE_INPUT + MAX_OUTPUT * RATE_OUTPUT)
    return {"run_mode": "dry-run", "model": DEFAULT_MODEL,
            "role": role, "task": task, "request_body": payload,
            "max_input_conservative_bytes": MAX_INPUT,
            "max_output_tokens": MAX_OUTPUT,
            "worst_case_usd": round(worst / USD_NANODOLLARS, 6),
            "budget_usd": maximum_nanodollars / USD_NANODOLLARS,
            "within_budget": worst <= maximum_nanodollars,
            "api_calls_permitted_in_dry_run": 0}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", choices=[
        "developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer"
    ], default="developer-1")
    parser.add_argument("--task", default="api-canary-1")
    parser.add_argument("--max-usd", type=requested_budget, default=requested_budget("0.02"))
    parser.add_argument("--execute-paid", action="store_true",
                        help="Explicitly opt into one paid API call (requires OPENAI_API_KEY)")
    args = parser.parse_args(argv)
    data = plan(args.role, args.task, args.max_usd)
    if not args.execute_paid:
        print(json.dumps(data, indent=2))
        return 0
    if not data["within_budget"]:
        parser.error("worst-case token reservation exceeds the dollar cap")
    token = os.environ.get("OPENAI_API_KEY")
    if not token:
        parser.error("OPENAI_API_KEY is required for --execute-paid; do not paste secrets into chat")
    settings = ApiSettings()
    provider = OpenAIResponsesAdapter(settings, token)
    with tempfile.TemporaryDirectory(prefix="loop_canary_") as folder:
        supervisor = Supervisor(
            Path(folder) / "one_turn.sqlite",
            Limits(max_turns=1, max_total_input=MAX_INPUT, max_total_output=MAX_OUTPUT,
                   max_turn_input=MAX_INPUT, max_turn_output=MAX_OUTPUT,
                   max_cost_nanodollars=args.max_usd, max_no_progress=1,
                   max_wall_seconds=300),
            lambda ctx: ctx["role"] == args.role and ctx["task"] == args.task,
            provider,
            lambda ctx, digest: False,  # No QA evidence from text-only API.
        )
        run_id = supervisor.start(args.role, args.task, "a" * 64, 1)
        reason = supervisor.tick(run_id)
        state = supervisor.state(run_id)
        total = state["cost_nanodollars"] / USD_NANODOLLARS if state["usage_complete"] else None
        print(json.dumps({
            "mode": "paid_single_call_canary", "status": reason,
            "role": args.role, "turns_recorded": state["turns"],
            "provider_usage_complete": bool(state["usage_complete"]),
            "input_tokens": state["input_tokens"] if state["usage_complete"] else None,
            "output_tokens": state["output_tokens"] if state["usage_complete"] else None,
            "estimated_api_usd": total,
            "response_id": provider.last_result.response_id if provider.last_result else None,
            "accepted_code_changes": 0, "tools_executed": 0,
            "warning": "No code/QA work is possible in transport-only canary. Provider billing is independent of local estimation."
        }, indent=2))
    return 0 if state["usage_complete"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
