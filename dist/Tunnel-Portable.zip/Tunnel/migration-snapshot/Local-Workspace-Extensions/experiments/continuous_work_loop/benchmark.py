"""Five-role offline A/B illustration; never reaches any provider API."""
from __future__ import annotations

import hashlib
import json
import tempfile
from pathlib import Path

from loop import Limits, Reply, Supervisor

ROLES = ("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer")


def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


def scenario(turns_per_role: int) -> dict:
    if not 1 <= turns_per_role <= 8:
        raise ValueError("invalid offline sample size")
    with tempfile.TemporaryDirectory() as root:
        verified = {sha(f"{r}-step-{i}") for r in ROLES for i in range(1, turns_per_role + 1)}
        calls = []

        def fake_provider(run, seq, max_in, max_out):
            calls.append((run["role"], seq))
            return Reply("completed", 1000, 400, sha(f"{run['role']}-step-{seq}"))

        supervisor = Supervisor(
            Path(root) / "five-agent-ab.sqlite",
            Limits(max_turns=turns_per_role, max_total_input=40_000,
                   max_total_output=12_000, max_cost_nanodollars=200_000_000),
            lambda run: run["role"] in ROLES,
            fake_provider,
            lambda run, digest: digest in verified,
        )
        rows = []
        for i, role in enumerate(ROLES):
            run_id = supervisor.start(role, f"offline-{i}", sha(f"spec-{i}"), 1)
            reason = supervisor.drive(run_id)
            run = supervisor.state(run_id)
            rows.append({
                "role": role, "turns": run["turns"], "verified_steps": sum(
                    x["evidence_verified"] for x in supervisor.turn_log(run_id)),
                "stop_reason": reason, "cost_usd_simulated": run["cost_nanodollars"] / 1_000_000_000
            })
        return {
            "mode": "offline_fake_provider",
            "roles": len(ROLES),
            "provider_calls_simulated": len(calls),
            "verified_steps_simulated": sum(x["verified_steps"] for x in rows),
            "cost_usd_simulated": round(sum(x["cost_usd_simulated"] for x in rows), 5),
            "per_role": rows,
            "actual_llm_calls": 0
        }


def compare() -> dict:
    baseline = scenario(1)
    resumed = scenario(3)
    return {
        "experiment": "5-role scheduler-one-turn vs bounded-three-turn supervisor",
        "notes": "Synthetic workload; more calls entail more cost; not evidence of production effectiveness.",
        "baseline": baseline,
        "continuous": resumed
    }


if __name__ == "__main__":
    print(json.dumps(compare(), indent=2, ensure_ascii=True))
