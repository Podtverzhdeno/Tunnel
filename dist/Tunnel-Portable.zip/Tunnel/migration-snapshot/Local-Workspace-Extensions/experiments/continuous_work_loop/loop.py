"""Offline, provider-agnostic continuity experiment. Not a ChatGPT Scheduler bypass.

No network access, API client, local execution, tool authorization or source edits.
A production adapter must supply authenticated queue/grant checks and independent proof.
"""
from __future__ import annotations

import json
import re
import sqlite3
import tempfile
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

INPUT_NANODOLLARS_PER_TOKEN = 2_000
OUTPUT_NANODOLLARS_PER_TOKEN = 10_000
HEX_SHA = re.compile(r"^[a-f0-9]{64}$")
SAFE_ID = re.compile(r"^[a-zA-Z0-9_-]{1,80}$")
FINAL_STATUSES = frozenset(("completed", "incomplete", "failed", "cancelled",
                            "rate_limited", "requires_action"))


@dataclass(frozen=True)
class Limits:
    max_turns: int = 8
    max_wall_seconds: int = 900
    max_total_input: int = 40_000
    max_total_output: int = 12_000
    max_turn_input: int = 5_000
    max_turn_output: int = 1_500
    max_cost_nanodollars: int = 200_000_000  # $0.20
    max_no_progress: int = 2

    def __post_init__(self):
        for field in self.__dataclass_fields__:
            if not isinstance(getattr(self, field), int) or isinstance(getattr(self, field), bool) or getattr(self, field) <= 0:
                raise ValueError("limits must be positive integers")
        if self.max_turn_input > self.max_total_input or self.max_turn_output > self.max_total_output:
            raise ValueError("per-turn token ceiling exceeds total ceiling")


@dataclass(frozen=True)
class Reply:
    status: str
    input_tokens: Optional[int]
    output_tokens: Optional[int]
    evidence_digest: Optional[str] = None

    def __post_init__(self):
        if self.status not in FINAL_STATUSES:
            raise ValueError("unsupported provider status")
        for n in (self.input_tokens, self.output_tokens):
            if n is not None and (not isinstance(n, int) or isinstance(n, bool) or n < 0):
                raise ValueError("invalid usage")
        if self.evidence_digest is not None and not HEX_SHA.fullmatch(self.evidence_digest):
            raise ValueError("bad evidence digest")


@contextmanager
def connect(db_path: Path):
    """Yield a transaction and ALWAYS close the Windows SQLite file handle."""
    conn = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS runs (
                id TEXT PRIMARY KEY, role TEXT NOT NULL, task TEXT NOT NULL,
                spec_sha TEXT NOT NULL, lease_revision INTEGER NOT NULL,
                status TEXT NOT NULL, created_unix REAL NOT NULL,
            usage_complete INTEGER NOT NULL DEFAULT 1,
            turns INTEGER NOT NULL DEFAULT 0,
                input_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0,
                cost_nanodollars INTEGER NOT NULL DEFAULT 0,
                no_progress INTEGER NOT NULL DEFAULT 0,
                last_digest TEXT, stop_reason TEXT
            );
            CREATE TABLE IF NOT EXISTS turns (
                run_id TEXT NOT NULL, seq INTEGER NOT NULL, state TEXT NOT NULL,
                provider_status TEXT, input_tokens INTEGER, output_tokens INTEGER,
                evidence_digest TEXT, evidence_verified INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (run_id, seq),
                FOREIGN KEY (run_id) REFERENCES runs(id)
            );
            CREATE TABLE IF NOT EXISTS evidence (
                run_id TEXT NOT NULL, digest TEXT NOT NULL,
                PRIMARY KEY (run_id, digest)
            );
        """)
        with conn:
            yield conn
    finally:
        conn.close()


class Supervisor:
    """One tick = at most one provider turn. No implicit privileged tool calls."""

    def __init__(self, db_path: Path, limits: Limits,
                 authorize: Callable[[dict], bool],
                 provider: Callable[[dict, int, int, int], Reply],
                 verify: Callable[[dict, str], bool],
                 clock: Callable[[], float] = time.time):
        self.db_path = Path(db_path)
        self.limits = limits
        self.authorize = authorize  # trusted host callback, NEVER a model claim
        self.provider = provider  # inject fake for all offline tests
        self.verify = verify  # independent evidence verifier
        self.clock = clock

    def start(self, role: str, task: str, spec_sha: str, lease_revision: int, run_id: Optional[str] = None) -> str:
        if not SAFE_ID.fullmatch(role) or not SAFE_ID.fullmatch(task) or not HEX_SHA.fullmatch(spec_sha):
            raise ValueError("invalid run identity")
        if not isinstance(lease_revision, int) or isinstance(lease_revision, bool) or lease_revision <= 0:
            raise ValueError("invalid revision")
        run_id = run_id or uuid.uuid4().hex
        if not SAFE_ID.fullmatch(run_id):
            raise ValueError("invalid run ID")
        with connect(self.db_path) as db:
            db.execute("INSERT INTO runs(id,role,task,spec_sha,lease_revision,status,created_unix) VALUES(?,?,?,?,?,?,?)",
                       (run_id, role, task, spec_sha, lease_revision, "ready", self.clock()))
        return run_id

    def state(self, run_id: str) -> dict:
        with connect(self.db_path) as db:
            r = db.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
            if r is None:
                raise KeyError("unknown run")
            return dict(r)

    def turn_log(self, run_id: str) -> list[dict]:
        with connect(self.db_path) as db:
            return [dict(x) for x in db.execute(
                "SELECT * FROM turns WHERE run_id=? ORDER BY seq", (run_id,))]

    def _stop(self, db: sqlite3.Connection, run_id: str, reason: str) -> str:
        db.execute("UPDATE runs SET status='stopped',stop_reason=? WHERE id=?", (reason, run_id))
        return reason

    def _remaining(self, r: sqlite3.Row) -> bool:
        b = self.limits
        # Reserve the entire per-turn ceiling before spending real money.
        return (r["turns"] < b.max_turns
                and r["input_tokens"] + b.max_turn_input <= b.max_total_input
                and r["output_tokens"] + b.max_turn_output <= b.max_total_output
                and r["cost_nanodollars"] +
                b.max_turn_input * INPUT_NANODOLLARS_PER_TOKEN +
                b.max_turn_output * OUTPUT_NANODOLLARS_PER_TOKEN <= b.max_cost_nanodollars)

    def tick(self, run_id: str) -> str:
        with connect(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
            if row is None:
                raise KeyError("unknown run")
            if row["status"] == "in_flight":
                return "in_flight"  # do not start another turn or replay
            if row["status"] == "stopped":
                return row["stop_reason"]
            snapshot = dict(row)
            if self.clock() < row["created_unix"] - 1:
                return self._stop(db, run_id, "clock_skew")
            if self.clock() - row["created_unix"] >= self.limits.max_wall_seconds:
                return self._stop(db, run_id, "wall_time_exhausted")
            if not self.authorize(snapshot):
                return self._stop(db, run_id, "not_authorized_or_no_work")
            if not self._remaining(row):
                return self._stop(db, run_id, "budget_exhausted")
            seq = row["turns"] + 1
            db.execute("INSERT INTO turns(run_id,seq,state) VALUES(?,?,'in_flight')", (run_id, seq))
            db.execute("UPDATE runs SET status='in_flight' WHERE id=?", (run_id,))

        try:
            answer = self.provider(snapshot, seq, self.limits.max_turn_input, self.limits.max_turn_output)
            if not isinstance(answer, Reply):
                raise TypeError("provider must return Reply")
        except Exception:
            # Unknown whether the remote provider performed the call. Fail closed.
            with connect(self.db_path) as db:
                db.execute("UPDATE runs SET status='stopped',stop_reason='reconciliation_needed',usage_complete=0 WHERE id=? AND status='in_flight'", (run_id,))
            return "reconciliation_needed"

        with connect(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
            if row["status"] != "in_flight":
                return "reconciliation_needed"
            db.execute("UPDATE turns SET state='received',provider_status=?,input_tokens=?,output_tokens=?,evidence_digest=? WHERE run_id=? AND seq=?",
                       (answer.status, answer.input_tokens, answer.output_tokens, answer.evidence_digest, run_id, seq))
            # Unknown provider billing is NOT zero.
            if answer.input_tokens is None or answer.output_tokens is None:
                db.execute("UPDATE runs SET usage_complete=0 WHERE id=?", (run_id,))
                return self._stop(db, run_id, "usage_unknown")
            if answer.input_tokens > self.limits.max_turn_input or answer.output_tokens > self.limits.max_turn_output:
                db.execute("UPDATE runs SET usage_complete=0 WHERE id=?", (run_id,))
                return self._stop(db, run_id, "provider_limit_violation")
            cost = answer.input_tokens * INPUT_NANODOLLARS_PER_TOKEN + answer.output_tokens * OUTPUT_NANODOLLARS_PER_TOKEN
            db.execute("UPDATE runs SET turns=turns+1,input_tokens=input_tokens+?,output_tokens=output_tokens+?,cost_nanodollars=cost_nanodollars+? WHERE id=?",
                       (answer.input_tokens, answer.output_tokens, cost, run_id))
            if not self.authorize(dict(row)):
                return self._stop(db, run_id, "authorization_changed")
            if answer.status != "completed":
                why = "approval_needed" if answer.status == "requires_action" else "provider_" + answer.status
                return self._stop(db, run_id, why)
            verified = False
            if answer.evidence_digest:
                try:
                    verified = bool(self.verify(snapshot, answer.evidence_digest))
                except Exception:
                    return self._stop(db, run_id, "verification_failed")
                if verified:
                    existing = db.execute("SELECT 1 FROM evidence WHERE run_id=? AND digest=?",
                                          (run_id, answer.evidence_digest)).fetchone()
                    verified = existing is None
                    if verified:
                        db.execute("INSERT INTO evidence(run_id,digest) VALUES(?,?)",
                                   (run_id, answer.evidence_digest))
                        db.execute("UPDATE runs SET last_digest=?,no_progress=0 WHERE id=?",
                                   (answer.evidence_digest, run_id))
            db.execute("UPDATE turns SET state='committed',evidence_verified=? WHERE run_id=? AND seq=?",
                       (int(verified), run_id, seq))
            if not verified:
                db.execute("UPDATE runs SET no_progress=no_progress+1 WHERE id=?", (run_id,))
            row2 = db.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
            if self.clock() < row2["created_unix"] - 1:
                return self._stop(db, run_id, "clock_skew")
            if self.clock() - row2["created_unix"] >= self.limits.max_wall_seconds:
                return self._stop(db, run_id, "wall_time_exhausted")
            if row2["no_progress"] >= self.limits.max_no_progress:
                return self._stop(db, run_id, "no_verified_progress")
            if not self._remaining(row2):
                return self._stop(db, run_id, "budget_exhausted")
            db.execute("UPDATE runs SET status='ready' WHERE id=?", (run_id,))
        return "continue"

    def recover(self, run_id: str) -> str:
        """Recovery never replays an ambiguous in-flight external call."""
        with connect(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT status,stop_reason FROM runs WHERE id=?", (run_id,)).fetchone()
            if row is None:
                raise KeyError("unknown run")
            if row["status"] == "in_flight":
                db.execute("UPDATE runs SET usage_complete=0 WHERE id=?", (run_id,))
                return self._stop(db, run_id, "reconciliation_needed")
            return row["stop_reason"] or row["status"]

    def drive(self, run_id: str, max_local_turns: int = 16) -> str:
        if not 1 <= max_local_turns <= 256:
            raise ValueError("bounded driver required")
        outcome = "continue"
        for _ in range(max_local_turns):
            outcome = self.tick(run_id)
            if outcome != "continue":
                return outcome
        return "driver_budget_reached"


def demonstration() -> dict:
    import hashlib
    with tempfile.TemporaryDirectory() as t:
        digests = [hashlib.sha256(x.encode()).hexdigest() for x in ("verified-code-a", "verified-code-b")]
        calls = []
        def fake_provider(snapshot, seq, max_in, max_out):
            calls.append(seq)
            return Reply("completed", 100, 40, digests[(seq-1) % 2])
        engine = Supervisor(Path(t) / "offline.sqlite", Limits(max_turns=3),
                            lambda run: True, fake_provider, lambda run, digest: digest in digests)
        run_id = engine.start("developer-1", "fixture-1", "a"*64, 1)
        reason = engine.drive(run_id)
        return {"mode": "offline_fake_provider", "turns": calls, "stop_reason": reason,
                "input_tokens": engine.state(run_id)["input_tokens"],
                "output_tokens": engine.state(run_id)["output_tokens"],
                "accepted_evidence": sum(t["evidence_verified"] for t in engine.turn_log(run_id)),
                "real_api_calls": 0}


if __name__ == "__main__":
    print(json.dumps(demonstration(), sort_keys=True))
