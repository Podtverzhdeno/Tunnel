"""Offline tests: no Codex process, browser login or paid model calls."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import codex_subscription_bridge as b


def mock_stream(thread="0199a213-81c0-7800-8aa1-bbab2a035a53"):
    return "\n".join([
        json.dumps({"type": "thread.started", "thread_id": thread}),
        json.dumps({"type": "turn.started"}),
        json.dumps({"type": "item.completed", "item": {"type": "agent_message", "text": "Safe suggestion"}}),
        json.dumps({"type": "turn.completed", "usage": {"input_tokens": 150,
            "cached_input_tokens": 30, "output_tokens": 55}}),
    ])


class CodexBridgeTests(unittest.TestCase):
    def test_five_known_roles(self):
        self.assertEqual(len(b.ROLES), 5)
        self.assertEqual(b.ROLES[-1], "architect-reviewer")

    def test_command_is_readonly_no_browser(self):
        c = b.build_command("codex", "developer-1")
        self.assertEqual(c[:6], ["codex", "exec", "--json", "--sandbox", "read-only", "--skip-git-repo-check"])
        self.assertNotIn("danger-full-access", c)
        self.assertNotIn("--execute-paid", c)
        self.assertIn("READ-ONLY", c[-1])

    def test_resume_command_targets_session(self):
        sid = "0199a213-81c0-7800-8aa1-bbab2a035a53"
        cmd = b.build_command("codex", "developer-3", sid)
        self.assertEqual(cmd[:7], ["codex", "exec", "--sandbox", "read-only", "resume", "--json", sid])

    def test_roles_restricted(self):
        with self.assertRaises(ValueError):
            b.build_command("codex", "super-admin")
        with self.assertRaises(ValueError):
            b.build_command("codex", "developer-1", "../session")

    def test_parse_completed_and_tokens(self):
        report = b.parse_jsonl(mock_stream())
        self.assertEqual(report["status"], "completed")
        self.assertEqual(report["usage"]["output_tokens"], 55)
        self.assertIsNotNone(report["thread_id"])
        self.assertIsNotNone(report["answer_sha256"])

    def test_invalid_json_or_unfinished_is_unknown(self):
        self.assertEqual(b.parse_jsonl("random text")["status"], "unknown")
        self.assertIsNone(b.parse_jsonl('{"type":"turn.started"}')["usage"])

    def test_failure_is_not_success(self):
        result = b.parse_jsonl('{"type":"turn.failed"}\n')
        self.assertEqual(result["status"], "failed")
        result = b.parse_jsonl('{"type":"error"}\n')
        self.assertEqual(result["status"], "failed")

    def test_runner_mock_does_not_execute_any_binary(self):
        events = []
        def runner(args, **kwargs):
            events.append((args, kwargs))
            return SimpleNamespace(stdout=mock_stream(), returncode=0)
        result = b.invoke("fake-codex", "developer-2", 40, runner=runner)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(events[0][1]["shell"], False)
        self.assertNotIn("CODEX_API_KEY", events[0][1]["env"])
        self.assertNotIn("OPENAI_API_KEY", events[0][1]["env"])

    def test_failure_stops(self):
        def runner(args, **kwargs):
            return SimpleNamespace(stdout='{"type":"turn.failed"}', returncode=1)
        self.assertEqual(b.invoke("fake", "developer-2", 30, runner=runner)["status"], "failed")

    def test_cli_timeout_is_fail_closed(self):
        import subprocess
        def runner(args, **kwargs):
            raise subprocess.TimeoutExpired(args, 5)
        self.assertEqual(b.invoke("fake", "developer-3", 30, runner=runner)["status"],
                         "timeout_requires_review")

    def test_login_requires_chatgpt_subscription(self):
        def signed_in(*a, **kw):
            return SimpleNamespace(returncode=0, stdout="Logged in using ChatGPT", stderr="")
        with patch.object(b.subprocess, "run", side_effect=signed_in):
            self.assertTrue(b.chatgpt_subscription_login("fake-codex"))
        def key_login(*a, **kw):
            return SimpleNamespace(returncode=0, stdout="Logged in using an API key", stderr="")
        with patch.object(b.subprocess, "run", side_effect=key_login):
            self.assertFalse(b.chatgpt_subscription_login("fake-codex"))
        def error(*a, **kw):
            return SimpleNamespace(returncode=1, stdout="", stderr="login required")
        with patch.object(b.subprocess, "run", side_effect=error):
            self.assertFalse(b.chatgpt_subscription_login("fake-codex"))

    def test_resume_explicitly_preserves_read_only(self):
        sid = "0199a213-81c0-7800-8aa1-bbab2a035a53"
        cmd = b.build_command("codex", "developer-1", sid)
        self.assertEqual(cmd[cmd.index("--sandbox")+1], "read-only")
        self.assertNotIn("--dangerously-bypass-approvals-and-sandbox", cmd)

    def test_missing_cli_does_not_start(self):
        with patch.object(b, "codex_executable", return_value=None):
            self.assertEqual(b.execute(b.ROLES, 5, 30)["status"], "codex_cli_not_installed")

    def test_five_turns_persist_per_role_and_no_auto_repeat(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(b, "ROOT", Path(root)), patch.object(b, "STATE", Path(root)/"state.json"), patch.object(b, "LOCK", Path(root)/"lock"):
                calls = []
                def invoker(executable, role, timeout, session=None):
                    calls.append(role)
                    return {"status": "completed", "thread_id": "0199a213-81c0-7800-8aa1-bbab2a035a53",
                            "answer_sha256": "f"*64, "usage": {"input_tokens": 100, "output_tokens": 20},
                            "returncode": 0}
                outcome = b.execute(b.ROLES, 5, 30, invoker=invoker, executable="fake")
                self.assertEqual(outcome["calls"], 5)
                self.assertEqual(calls, list(b.ROLES))
                self.assertEqual(b.read_state()["runs"], 5)
                self.assertFalse(b.LOCK.exists())
                self.assertEqual(len(b.read_state()["roles"]), 5)

    def test_failures_stop_further_roles(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(b, "ROOT", Path(root)), patch.object(b, "STATE", Path(root)/"state.json"), patch.object(b, "LOCK", Path(root)/"lock"):
                calls = []
                def invoker(executable, role, timeout, session=None):
                    calls.append(role)
                    return {"status": "failed"}
                outcome = b.execute(b.ROLES, 5, 30, invoker=invoker, executable="fake")
                self.assertEqual(outcome["calls"], 1)
                self.assertEqual(calls, ["developer-1"])

    def test_lock_prevents_concurrent_sessions(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(b, "ROOT", Path(root)), patch.object(b, "STATE", Path(root)/"state.json"), patch.object(b, "LOCK", Path(root)/"lock"):
                b.LOCK.write_text("other operator")
                result = b.execute(b.ROLES, 5, 30, executable="fake")
                self.assertEqual(result["status"], "lock_exists_manual_inspection")
                self.assertTrue(b.LOCK.exists())

    def test_cli_dry_run_never_consumes_subscription(self):
        output = io.StringIO()
        with patch.object(b, "codex_executable", return_value=None):
            with contextlib.redirect_stdout(output):
                self.assertEqual(b.main([]), 0)
        data = json.loads(output.getvalue())
        self.assertFalse(data["codex_cli_found"])
        self.assertEqual(data["mode"], "dry-run")
        self.assertFalse(data["paid_api_keys_read"])

    def test_bounded_turn_limits(self):
        with self.assertRaises(ValueError):
            b.execute(b.ROLES, 0, 30, executable="fake")
        with self.assertRaises(ValueError):
            b.execute(b.ROLES, 25, 30, executable="fake")


if __name__ == "__main__":
    unittest.main()
