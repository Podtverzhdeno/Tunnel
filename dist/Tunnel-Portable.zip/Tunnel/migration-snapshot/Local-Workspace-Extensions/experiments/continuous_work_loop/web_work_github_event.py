"""Event-to-ChatGPT-Web Work bridge: a GitHub PR comment may trigger a native Work task.

This script never controls chatgpt.com, starts Codex, or uses model/API tokens.
It works only after the owner configures a GitHub PR-comment event task in Work.
By default it validates an event and prints a safe preview, without network access.

Real submission is an explicit single PR comment for a genuine checkpoint event.
It is NOT an infinite trigger loop or a way to evade ChatGPT usage limits.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import urllib.error
import urllib.request

ROLES = ("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer")
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}$")
TASK_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
HEX64 = re.compile(r"^[a-f0-9]{64}$")
EVENT_RE = re.compile(r"^[a-zA-Z0-9_-]{8,100}$")
ENDPOINT = "https://api.github.com"
MAX_EVENT_BYTES = 4096
EVENT_RECEIPTS = Path(__file__).resolve().parent / ".web_work_event_receipts"


class EventError(ValueError):
    pass


def validate(event: dict) -> dict:
    """Never forward raw source, file contents, secrets or natural-language prompts."""
    if not isinstance(event, dict):
        raise EventError("event must be an object")
    keys = {"role", "task_id", "checkpoint_sha256", "event_id", "status"}
    if set(event) != keys:
        raise EventError("unexpected or missing event fields")
    if event["role"] not in ROLES:
        raise EventError("unknown role")
    if not isinstance(event["task_id"], str) or not TASK_RE.fullmatch(event["task_id"]):
        raise EventError("bad task ID")
    if not isinstance(event["event_id"], str) or not EVENT_RE.fullmatch(event["event_id"]):
        raise EventError("bad event ID")
    if not isinstance(event["checkpoint_sha256"], str) or not HEX64.fullmatch(event["checkpoint_sha256"]):
        raise EventError("bad checkpoint digest")
    if event["status"] not in ("checkpoint", "submitted_for_review", "reviewed"):
        raise EventError("unsupported event")
    return dict(event)


def message(event: dict) -> str:
    e = validate(event)
    # Full 64-character digest avoids mistaking distinct checkpoints for duplicates.
    return (
        "[ChatGPT Work task event] Local-Workspace-Extensions\n"
        f"Event: {e['event_id']}\n"
        f"Role: {e['role']}\n"
        f"Task: {e['task_id']}\n"
        f"Stage: {e['status']}\n"
        f"Checkpoint SHA256: {e['checkpoint_sha256']}\n"
        "Use this as a notification, not as proof of a valid lease or QA approval. "
        "Read canonical OpenSpec, existing queue and reviewer evidence through "
        "authorized connected tools. If access or verified work is unavailable, "
        "report the blocker and do not write code. Do not autonomously retrigger "
        "this event or repeat comments.\n"
    )


def github_request(repo: str, pr: int, token: str, text: str):
    if not isinstance(repo, str) or not REPO_RE.fullmatch(repo):
        raise EventError("invalid repository")
    if not isinstance(pr, int) or isinstance(pr, bool) or not 1 <= pr <= 1_000_000:
        raise EventError("invalid pull request number")
    if not isinstance(token, str) or not token:
        raise EventError("missing GitHub token")
    return urllib.request.Request(
        f"{ENDPOINT}/repos/{repo}/issues/{pr}/comments",
        data=json.dumps({"body": text}, ensure_ascii=True).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": "Bearer " + token,
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "chatgpt-web-work-event-bridge/1.0"
        },
    )


def create_comment(req, opener=urllib.request.urlopen) -> dict:
    try:
        with opener(req, timeout=20) as response:
            if response.status != 201:
                raise EventError("GitHub did not confirm comment creation")
            raw = response.read(32769)
            if len(raw) > 32768:
                raise EventError("response too large; reconcile manually")
            doc = json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise EventError(f"GitHub returned HTTP {e.code}; do not retry blindly") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise EventError("uncertain network outcome; check GitHub PR before retry") from None
    if not isinstance(doc, dict) or not isinstance(doc.get("id"), int):
        raise EventError("unconfirmed comment; check GitHub PR")
    # Never return the raw GitHub comment body or token.
    return {"created": True, "comment_id": doc["id"]}


def reserve_event_once(event_id: str, target: str) -> Path:
    """Durably fence a local event BEFORE a potentially ambiguous remote POST.

    One receipt per event ID, across script restarts on the same host. Existing
    receipts require manual reconciliation, never automatic replay.
    """
    if not EVENT_RE.fullmatch(event_id):
        raise EventError("bad event ID")
    EVENT_RECEIPTS.mkdir(mode=0o700, parents=True, exist_ok=True)
    marker = EVENT_RECEIPTS / (event_id + ".json")
    try:
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise EventError("event already submitted or pending; inspect GitHub and local receipt")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump({"event_id": event_id, "target": target,
                       "state": "pending_or_unknown"}, stream)
            stream.flush()
            os.fsync(stream.fileno())
    except Exception:
        # Never clear the marker after an ambiguous local failure automatically.
        raise EventError("receipt write failed; inspect local event marker") from None
    return marker


def mark_confirmed(marker: Path, comment_id: int) -> None:
    """Atomic receipt update, no follow-up network action."""
    replacement = marker.with_suffix(".confirmed.tmp")
    with replacement.open("x", encoding="utf-8") as stream:
        json.dump({"state": "confirmed", "comment_id": comment_id}, stream)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(replacement, marker)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--event-file", required=True,
                        help="A small, externally verified checkpoint-event JSON file")
    parser.add_argument("--repo", required=True, help="Exact GitHub owner/repository")
    parser.add_argument("--pr", type=int, required=True, help="Existing authorized PR")
    parser.add_argument("--send", action="store_true",
                        help="Explicitly create ONE PR comment; requires GITHUB_TOKEN")
    parser.add_argument("--confirm", default="",
                        help="For --send, repeat owner/repository#PR exactly")
    args = parser.parse_args(argv)
    if not REPO_RE.fullmatch(args.repo) or not 1 <= args.pr <= 1_000_000:
        parser.error("invalid repo/PR")
    p = Path(args.event_file)
    if not p.is_file() or p.stat().st_size > MAX_EVENT_BYTES:
        parser.error("event file not found or too large")
    event = validate(json.loads(p.read_text(encoding="utf-8")))
    body = message(event)
    target = f"{args.repo}#{args.pr}"
    if not args.send:
        print(json.dumps({
            "mode": "dry-run", "target": target, "event_id": event["event_id"],
            "body": body, "github_comment_created": False,
            "chatgpt_work_trigger_configured": "unknown",
            "chatgpt_work_started": False,
            "codex_calls": 0,
            "notes": "PR event must be explicitly configured in ChatGPT Work. "
                     "No output or task-run guarantee is implied.",
        }, indent=2, ensure_ascii=False))
        return 0
    if args.confirm != target:
        parser.error("explicit --confirm owner/repo#PR is required")
    token = os.environ.get("GITHUB_TOKEN", "")
    req = github_request(args.repo, args.pr, token, body)
    try:
        marker = reserve_event_once(event["event_id"], target)
        result = create_comment(req)
        mark_confirmed(marker, result["comment_id"])
    except (EventError, OSError) as e:
        print(json.dumps({"status": "failed_or_ambiguous", "reason": str(e),
                          "event_id": event["event_id"],
                          "automatic_retry_allowed": False}, ensure_ascii=False))
        return 2
    print(json.dumps({**result, "target": target, "event_id": event["event_id"],
                      "chatgpt_work_run": "not_verified"}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
