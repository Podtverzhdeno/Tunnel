import contextlib
import io
import json
import unittest
from unittest.mock import patch

from live_canary import main, plan, requested_budget
from openai_response_adapter import (
    ApiSettings, OpenAIResponsesAdapter, ProviderFailure, Result,
    build_payload, parse_response, scoped_prompt,
)

SNAPSHOT = {"role": "developer-1", "task": "P123", "spec_sha": "a" * 64}


def fake_response(status="completed", inp=600, out=200):
    return {
        "id": "resp_fixture_001",
        "status": status,
        "usage": {"input_tokens": inp, "output_tokens": out},
        "output": [{"type": "message", "content": [
            {"type": "output_text", "text": "A bounded planning proposal, not accepted QA."}
        ]}],
    }


class ResponsesAdapterTests(unittest.TestCase):
    def test_scoped_prompt_rejects_untrusted_role_and_ids(self):
        with self.assertRaises(ValueError):
            scoped_prompt({"role": "owner-admin", "task": "P123", "spec_sha": "a"*64}, 1)
        with self.assertRaises(ValueError):
            scoped_prompt({"role": "developer-1", "task": "../secrets", "spec_sha": "a"*64}, 1)
        with self.assertRaises(ValueError):
            scoped_prompt({"role": "developer-1", "task": "P123", "spec_sha": "unverified"}, 1)

    def test_payload_is_text_only_and_no_external_tools(self):
        payload = build_payload(SNAPSHOT, 1, 2000, 256, ApiSettings())
        self.assertEqual(payload["model"], "gpt-6.1-sol")
        self.assertFalse(payload["store"])
        self.assertFalse(payload["background"])
        self.assertEqual(payload["tools"], [])
        self.assertEqual(payload["max_output_tokens"], 256)
        self.assertNotIn("response_id", payload)
        with self.assertRaises(ValueError):
            build_payload(SNAPSHOT, 1, 256, 256, ApiSettings())

    def test_injected_mock_transport_no_network(self):
        events = []
        def transport(payload, key, timeout):
            events.append((payload, key, timeout))
            return fake_response()
        adapter = OpenAIResponsesAdapter(ApiSettings(), "test-key-not-real", transport)
        reply = adapter(SNAPSHOT, 1, 2000, 256)
        self.assertEqual((reply.status, reply.input_tokens, reply.output_tokens), ("completed", 600, 200))
        self.assertIsNone(reply.evidence_digest)
        self.assertEqual(adapter.last_result.response_id, "resp_fixture_001")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0][2], 120)

    def test_api_text_is_never_qa_evidence(self):
        result = parse_response(fake_response())
        self.assertIsNotNone(result.text_digest)
        self.assertIsNone(result.reply.evidence_digest)
        self.assertNotIn("A bounded planning", repr(result))

    def test_incomplete_and_failed_states(self):
        self.assertEqual(parse_response(fake_response("incomplete")).reply.status, "incomplete")
        self.assertEqual(parse_response(fake_response("failed")).reply.status, "failed")
        with self.assertRaises(ProviderFailure):
            parse_response(fake_response("in_progress"))

    def test_bad_usage_fails_closed(self):
        for value in (True, -1, "300"):
            with self.assertRaises(ProviderFailure):
                parse_response(fake_response(inp=value))

    def test_missing_usage_is_unknown(self):
        doc = fake_response()
        doc.pop("usage")
        answer = parse_response(doc)
        self.assertIsNone(answer.reply.input_tokens)
        self.assertIsNone(answer.reply.output_tokens)

    def test_invalid_config(self):
        for model in ("http://malicious", "gpt-5.6", "", "gpt-6.1-sol/path"):
            with self.assertRaises(ValueError):
                ApiSettings(model=model)
        with self.assertRaises(ValueError):
            ApiSettings(timeout_seconds=1)

    def test_cli_default_is_no_network_no_secrets(self):
        buffer = io.StringIO()
        with patch.dict("os.environ", {"OPENAI_API_KEY": ""}):
            with contextlib.redirect_stdout(buffer):
                code = main(["--role", "developer-3"])
        self.assertEqual(code, 0)
        data = json.loads(buffer.getvalue())
        self.assertEqual(data["api_calls_permitted_in_dry_run"], 0)
        self.assertTrue(data["within_budget"])
        self.assertEqual(data["role"], "developer-3")
        self.assertNotIn("Authorization", json.dumps(data))

    def test_paid_flag_requires_key(self):
        with patch.dict("os.environ", {"OPENAI_API_KEY": ""}):
            with self.assertRaises(SystemExit) as error:
                main(["--execute-paid"])
        self.assertEqual(error.exception.code, 2)

    def test_budget_cannot_be_negative_or_unbounded(self):
        for text in ("NaN", "-1", "1", "0", "Infinity"):
            with self.assertRaises(Exception):
                requested_budget(text)
        self.assertEqual(requested_budget("0.02"), 20_000_000)

    def test_not_enough_budget_rejects_paid_mode_without_key_access(self):
        with patch.dict("os.environ", {"OPENAI_API_KEY": ""}):
            with self.assertRaises(SystemExit):
                main(["--execute-paid", "--max-usd", "0.001"])

    def test_role_is_fixed_to_five(self):
        with self.assertRaises(SystemExit):
            with contextlib.redirect_stderr(io.StringIO()):
                main(["--role", "arbitrary-admin"])

    def test_transport_request_must_have_usage_and_cannot_infer_from_text(self):
        adapter = OpenAIResponsesAdapter(ApiSettings(), "dummy", lambda p, k, t: {"status": "completed", "output": []})
        reply = adapter(SNAPSHOT, 1, 2000, 256)
        self.assertIsNone(reply.input_tokens)
        self.assertIsNone(reply.output_tokens)


if __name__ == "__main__":
    unittest.main()
