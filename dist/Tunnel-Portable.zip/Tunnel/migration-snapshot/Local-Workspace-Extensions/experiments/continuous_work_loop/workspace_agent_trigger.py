"""Official ChatGPT Workspace Agents API trigger: opt-in, one event per invocation.

Requires workspace-admin provisioned access token and a published API trigger.
No chatgpt.com UI automation and no text extraction. Default is offline dry-run.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import urllib.error
import urllib.request
import uuid

ORIGIN = "https://api.chatgpt.com"
TRIGGER_RE = re.compile(r"^agtch_[A-Za-z0-9_-]{1,100}$")
RUN_RE = re.compile(r"^apirun_[A-Za-z0-9_-]{1,100}$")
EVENT_RE = re.compile(r"^[A-Za-z0-9_-]{8,120}$")
CONV_RE = re.compile(r"^[A-Za-z0-9_-]{1,120}$")
ROLES = ("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer")
VALID_STATUSES = {"queued", "in_progress", "suspended", "completed", "failed"}


class WorkspaceTriggerFailure(RuntimeError):
    pass


def payload(role: str, task: str, conversation_key: str) -> dict:
    if role not in ROLES:
        raise ValueError("unsupported role")
    if not CONV_RE.fullmatch(task) or not CONV_RE.fullmatch(conversation_key):
        raise ValueError("invalid identifiers")
    return {
        "conversation_key": conversation_key,
        "input": (
            f"Role: {role}. Task: {task}. Open only explicitly authorized project "
            "documentation and the verified task checkpoint through connected tools "
            "if those tools are available. Continue at most one approved safe task step; "
            "do not grant yourself permissions, invent progress or bypass limits. "
            "If no valid lease/permission/task exists, return a precise blocker."
        ),
    }


def build_request(trigger_id: str, role: str, task: str,
                  conversation_key: str, event_id: str,
                  token: str) -> urllib.request.Request:
    if not TRIGGER_RE.fullmatch(trigger_id):
        raise ValueError("invalid API trigger ID")
    if not EVENT_RE.fullmatch(event_id):
        raise ValueError("idempotency event ID required")
    if not token:
        raise ValueError("Workspace Agent token missing")
    body = json.dumps(payload(role, task, conversation_key)).encode("utf-8")
    return urllib.request.Request(
        ORIGIN + "/v1/workspace_agents/" + trigger_id + "/trigger",
        data=body, method="POST",
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
            "Idempotency-Key": event_id,
            "OpenAI-Beta": "workspace_agent_runs=v1",
        },
    )


def interpret_trigger_response(status_code: int, document: dict) -> dict:
    if status_code != 202 or not isinstance(document, dict):
        raise WorkspaceTriggerFailure("trigger not accepted; do not blindly retry")
    url = document.get("conversation_url")
    run_id = document.get("agent_trigger_run_id")
    if not isinstance(url, str) or not url.startswith("https://chatgpt.com/c/"):
        raise WorkspaceTriggerFailure("invalid response conversation URL")
    if run_id is not None and (not isinstance(run_id, str) or not RUN_RE.fullmatch(run_id)):
        raise WorkspaceTriggerFailure("malformed run ID")
    return {"accepted": True, "conversation_url": url, "run_id": run_id,
            "text_response_available_via_api": False}


def build_status_request(trigger_id: str, run_id: str,
                         token: str) -> urllib.request.Request:
    if not TRIGGER_RE.fullmatch(trigger_id) or not RUN_RE.fullmatch(run_id) or not token:
        raise ValueError("invalid status query")
    return urllib.request.Request(
        ORIGIN + f"/v1/workspace_agents/{trigger_id}/runs/{run_id}",
        headers={"Authorization": "Bearer " + token},
        method="GET",
    )


def interpret_status(document: dict) -> dict:
    if not isinstance(document, dict):
        raise WorkspaceTriggerFailure("unexpected run status document")
    status = document.get("status")
    if status not in VALID_STATUSES:
        raise WorkspaceTriggerFailure("unknown status; manual inspection required")
    return {"status": status, "terminal": status in ("completed", "failed"),
            "verified_code_changes": None,
            "note": "Run status is not independent proof of code changes"}


def perform(request: urllib.request.Request, opener=urllib.request.urlopen) -> tuple[int, dict]:
    try:
        with opener(request, timeout=30) as response:
            raw = response.read(65537)
            if len(raw) > 65536:
                raise WorkspaceTriggerFailure("response too large")
            return response.status, json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise WorkspaceTriggerFailure(f"workspace API HTTP {e.code}; reconcile before retry") from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise WorkspaceTriggerFailure("ambiguous transport failure; do not retry blindly") from None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", choices=ROLES, default="developer-1")
    parser.add_argument("--task", default="approved-task-check")
    parser.add_argument("--conversation-key", default="multiagent-project-review")
    parser.add_argument("--trigger-id", default=os.environ.get("WORKSPACE_AGENT_TRIGGER_ID", ""))
    parser.add_argument("--event-id", help="Stable idempotency key for THIS verified event")
    parser.add_argument("--execute", action="store_true",
                        help="Actually invoke a published ChatGPT workspace agent")
    args = parser.parse_args(argv)
    data = payload(args.role, args.task, args.conversation_key)
    dry = {
        "mode": "dry-run" if not args.execute else "official_workspace_agent_trigger",
        "trigger_configured": bool(TRIGGER_RE.fullmatch(args.trigger_id)),
        "role": args.role, "task": args.task,
        "conversation_key": args.conversation_key,
        "idempotency_key_supplied": bool(args.event_id),
        "payload_preview": data,
        "api_calls": 0,
        "requires_admin_token": True,
        "response_text_available_via_api": False,
    }
    if not args.execute:
        print(json.dumps(dry, indent=2))
        return 0
    token = os.environ.get("WORKSPACE_AGENT_ACCESS_TOKEN", "")
    if not args.event_id or not token or not TRIGGER_RE.fullmatch(args.trigger_id):
        parser.error("Real invocation requires --event-id, published --trigger-id, and WORKSPACE_AGENT_ACCESS_TOKEN")
    req = build_request(args.trigger_id, args.role, args.task, args.conversation_key,
                        args.event_id, token)
    try:
        status_code, document = perform(req)
        reply = interpret_trigger_response(status_code, document)
    except WorkspaceTriggerFailure as error:
        print(json.dumps({"status": "failed_or_ambiguous", "reason": str(error),
                          "request_event_id": args.event_id}))
        return 2
    print(json.dumps({"mode": "official_workspace_agent_trigger",
                      "request_event_id": args.event_id, **reply}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
