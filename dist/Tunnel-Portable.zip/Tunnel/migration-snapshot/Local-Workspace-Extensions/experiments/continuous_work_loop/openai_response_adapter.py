"""Opt-in OpenAI Responses API adapter for the isolated continuous-loop spike.

No tool access, no repository content uploads, no remote calls from dry-run.
The adapter exposes a one-turn transport: it is NOT a coding agent or reviewer.
"""
from __future__ import annotations

import hashlib
import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Optional

from loop import Reply

ENDPOINT = "https://api.openai.com/v1/responses"
MODEL_RE = re.compile(r"^gpt-6(?:[.a-zA-Z0-9-]{0,40})$")
ROLE_RE = re.compile(r"^(?:developer-[1-4]|architect-reviewer)$")
TASK_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


class ProviderFailure(RuntimeError):
    """No potentially sensitive error body or credentials are emitted."""


class TransportFailure(ProviderFailure):
    """Ambiguous network result: caller must reconcile, never auto-retry."""


@dataclass(frozen=True)
class ApiSettings:
    model: str = "gpt-6.1-sol"
    effort: str = "medium"
    timeout_seconds: int = 120

    def __post_init__(self):
        if not MODEL_RE.fullmatch(self.model):
            raise ValueError("unsupported model format")
        if self.effort not in ("low", "medium", "high"):
            raise ValueError("unsupported effort")
        if not isinstance(self.timeout_seconds, int) or isinstance(self.timeout_seconds, bool) or not 5 <= self.timeout_seconds <= 300:
            raise ValueError("invalid timeout")


@dataclass(frozen=True)
class Result:
    reply: Reply
    response_id: Optional[str]
    text_digest: Optional[str]
    text: str = field(default="", repr=False)


def scoped_prompt(snapshot: dict, seq: int) -> tuple[str, str]:
    role = snapshot.get("role")
    task = snapshot.get("task")
    spec = snapshot.get("spec_sha")
    if not isinstance(role, str) or not ROLE_RE.fullmatch(role):
        raise ValueError("role not admitted")
    if not isinstance(task, str) or not TASK_RE.fullmatch(task):
        raise ValueError("task ID not admitted")
    if not isinstance(spec, str) or not re.fullmatch(r"[a-f0-9]{64}", spec):
        raise ValueError("bad spec SHA")
    if not isinstance(seq, int) or isinstance(seq, bool) or not 1 <= seq <= 100:
        raise ValueError("invalid sequence")
    system = (
        "You are an offline planning assistant inside an explicitly bounded API canary. "
        "Do not claim to have used any tools, accessed files, modified code, or approved a change. "
        "Do not request credentials. Keep answers brief. Output a concrete safe next step."
    )
    user = (
        f"Role: {role}; task: {task}; spec digest: {spec}; turn: {seq}. "
        "Propose one specific testable next step without accessing files or services. "
        "This is a transport-only canary, not a real implementation."
    )
    return system, user


def build_payload(snapshot: dict, seq: int, max_input: int, max_output: int, settings: ApiSettings) -> dict:
    if not isinstance(max_input, int) or not 256 <= max_input <= 16_000:
        raise ValueError("input ceiling out of range")
    if not isinstance(max_output, int) or not 16 <= max_output <= 4_096:
        raise ValueError("output ceiling out of range")
    system, user = scoped_prompt(snapshot, seq)
    payload = {
        "model": settings.model,
        "instructions": system,
        "input": user,
        "max_output_tokens": max_output,
        "reasoning": {"effort": settings.effort},
        "store": False,
        "background": False,
        "tools": [],
    }
    serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # Conservative local payload-length reservation. NOT exact API token counting.
    if len(serialized) + 128 > max_input:
        raise ValueError("conservative input byte budget exceeded")
    return payload


def extract_output_text(document: dict) -> str:
    pieces = []
    for item in document.get("output", []):
        if not isinstance(item, dict) or item.get("type") != "message":
            continue
        for part in item.get("content", []):
            if isinstance(part, dict) and part.get("type") == "output_text":
                text = part.get("text")
                if isinstance(text, str):
                    pieces.append(text)
    return "\n".join(pieces)[:20_000]


def parse_response(document: dict) -> Result:
    if not isinstance(document, dict):
        raise ProviderFailure("non-object response")
    status = document.get("status")
    mapping = {
        "completed": "completed", "incomplete": "incomplete",
        "failed": "failed", "cancelled": "cancelled",
    }
    if status not in mapping:
        raise ProviderFailure("unexpected response status: reconciliation required")
    usage = document.get("usage")
    inp, out = None, None
    if usage is not None:
        if not isinstance(usage, dict):
            raise ProviderFailure("invalid usage shape")
        inp, out = usage.get("input_tokens"), usage.get("output_tokens")
        for count in (inp, out):
            if not isinstance(count, int) or isinstance(count, bool) or count < 0:
                raise ProviderFailure("invalid provider usage")
    rid = document.get("id")
    if rid is not None and (not isinstance(rid, str) or not re.fullmatch(r"resp_[A-Za-z0-9_-]{1,128}", rid)):
        raise ProviderFailure("invalid response identifier")
    text = extract_output_text(document)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest() if text else None
    # Deliberately NO artifact evidence digest: text alone cannot prove code changes.
    return Result(Reply(mapping[status], inp, out, None), rid, digest, text)


def _https_request(payload: dict, api_key: str, timeout_seconds: int) -> dict:
    if not api_key or not isinstance(api_key, str):
        raise ProviderFailure("missing API credentials")
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        ENDPOINT, data=data, method="POST",
        headers={"Authorization": "Bearer " + api_key,
                 "Content-Type": "application/json",
                 "User-Agent": "local-work-loop-canary/1"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as response:
            if response.status != 200:
                raise ProviderFailure("unexpected HTTP status")
            body = response.read(1_000_001)
            if len(body) > 1_000_000:
                raise ProviderFailure("response exceeds maximum bytes")
            return json.loads(body.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # Do not print response bodies (provider or proxy may echo user data).
        raise ProviderFailure(f"OpenAI HTTP {exc.code}; may have been billed, reconcile") from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise TransportFailure("network outcome uncertain; do not retry blindly") from None
    except (ValueError, UnicodeError):
        raise ProviderFailure("invalid JSON or encoding from provider") from None


class OpenAIResponsesAdapter:
    def __init__(self, settings: ApiSettings, api_key: str,
                 requester: Optional[Callable[[dict, str, int], dict]] = None):
        self.settings = settings
        self._key = api_key
        self._requester = requester or _https_request
        self.last_result: Optional[Result] = None

    def __call__(self, snapshot: dict, seq: int, max_input: int, max_output: int) -> Reply:
        payload = build_payload(snapshot, seq, max_input, max_output, self.settings)
        document = self._requester(payload, self._key, self.settings.timeout_seconds)
        result = parse_response(document)
        self.last_result = result
        return result.reply
