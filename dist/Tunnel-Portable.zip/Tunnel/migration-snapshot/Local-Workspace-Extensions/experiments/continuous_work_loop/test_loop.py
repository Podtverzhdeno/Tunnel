"""Deterministic offline safety and continuity regression tests."""
import hashlib
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from loop import Limits, Reply, Supervisor, demonstration


def digest(name):
    return hashlib.sha256(name.encode("utf-8")).hexdigest()


class ContinuousWorkLoopTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "simulation.sqlite"
        self.calls = []
        self.allow = True
        self.valid = {digest("code-1"), digest("code-2"), digest("code-3")}
        self.sequence = [Reply("completed", 100, 50, digest("code-1")),
                         Reply("completed", 100, 50, digest("code-2"))]

    def make(self, limits=None):
        def provider(context, seq, max_in, max_out):
            self.calls.append((context["role"], context["task"], seq))
            return self.sequence[min(seq-1, len(self.sequence)-1)]
        supervisor = Supervisor(self.path, limits or Limits(max_turns=5),
                                lambda r: self.allow,
                                provider,
                                lambda r, d: d in self.valid)
        run_id = supervisor.start("developer-1", "P999", digest("spec"), 1)
        return supervisor, run_id

    def test_multi_turn_continues_and_stops_at_cap(self):
        manager, run = self.make(Limits(max_turns=3))
        self.assertEqual(manager.drive(run), "budget_exhausted")
        self.assertEqual(len(self.calls), 3)
        self.assertEqual(manager.state(run)["turns"], 3)
        self.assertEqual(manager.state(run)["input_tokens"], 300)
        self.assertEqual(manager.state(run)["output_tokens"], 150)
        self.assertEqual(manager.state(run)["cost_nanodollars"], 2_100_000)
        self.assertEqual(sum(x["evidence_verified"] for x in manager.turn_log(run)), 2)

    def test_restart_recovers_verified_progress(self):
        manager, run = self.make()
        self.assertEqual(manager.tick(run), "continue")
        after_restart = Supervisor(self.path, manager.limits, manager.authorize,
                                   manager.provider, manager.verify)
        self.assertEqual(after_restart.state(run)["turns"], 1)
        self.assertEqual(after_restart.tick(run), "continue")
        self.assertEqual(after_restart.state(run)["last_digest"], digest("code-2"))
        self.assertEqual([x[2] for x in self.calls], [1, 2])

    def test_no_progress_stops_instead_of_spamming_continue(self):
        self.sequence = [Reply("completed", 100, 10)]
        manager, run = self.make(Limits(max_no_progress=2))
        self.assertEqual(manager.drive(run), "no_verified_progress")
        self.assertEqual(len(self.calls), 2)
        self.assertEqual(manager.tick(run), "no_verified_progress")

    def test_model_evidence_claim_without_host_proof_is_not_progress(self):
        self.sequence = [Reply("completed", 80, 20, digest("forged"))]
        manager, run = self.make(Limits(max_no_progress=1))
        self.assertEqual(manager.tick(run), "no_verified_progress")
        self.assertEqual(manager.turn_log(run)[0]["evidence_verified"], 0)

    def test_duplicate_evidence_is_not_new_progress(self):
        self.sequence = [Reply("completed", 80, 20, digest("code-1"))]
        manager, run = self.make(Limits(max_no_progress=2))
        self.assertEqual(manager.drive(run), "no_verified_progress")
        self.assertEqual(sum(x["evidence_verified"] for x in manager.turn_log(run)), 1)
        self.assertEqual(len(self.calls), 3)

    def test_approval_pause_must_not_be_self_approved(self):
        self.sequence = [Reply("requires_action", 100, 20)]
        manager, run = self.make()
        self.assertEqual(manager.tick(run), "approval_needed")
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(manager.tick(run), "approval_needed")

    def test_revoked_permission_before_call(self):
        manager, run = self.make()
        self.allow = False
        self.assertEqual(manager.tick(run), "not_authorized_or_no_work")
        self.assertEqual(self.calls, [])

    def test_revoked_permission_during_call(self):
        manager, run = self.make()
        original = manager.provider
        def revoke(*args):
            value = original(*args)
            self.allow = False
            return value
        manager.provider = revoke
        self.assertEqual(manager.tick(run), "authorization_changed")
        self.assertEqual(manager.state(run)["turns"], 1)
        self.assertEqual(manager.turn_log(run)[0]["evidence_verified"], 0)

    def test_ambiguous_provider_exception_fails_closed(self):
        manager, run = self.make()
        def crash(*args):
            self.calls.append("remote maybe billed")
            raise ConnectionError("connection dropped")
        manager.provider = crash
        self.assertEqual(manager.tick(run), "reconciliation_needed")
        self.assertEqual(manager.tick(run), "reconciliation_needed")
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(manager.turn_log(run)[0]["state"], "in_flight")

    def test_crash_recovery_does_not_retry_inflight(self):
        manager, run = self.make()
        with closing(sqlite3.connect(self.path)) as c, c:
            c.execute("UPDATE runs SET status='in_flight' WHERE id=?", (run,))
            c.execute("INSERT INTO turns(run_id, seq, state) VALUES(?, 1, 'in_flight')", (run,))
        self.assertEqual(manager.tick(run), "in_flight")
        self.assertEqual(manager.recover(run), "reconciliation_needed")
        self.assertEqual(self.calls, [])

    def test_missing_provider_usage_is_unknown_not_zero(self):
        self.sequence = [Reply("completed", None, None, digest("code-1"))]
        manager, run = self.make()
        self.assertEqual(manager.tick(run), "usage_unknown")
        self.assertEqual(manager.turn_log(run)[0]["input_tokens"], None)
        self.assertEqual(manager.state(run)["input_tokens"], 0)
        self.assertEqual(manager.state(run)["turns"], 0)

    def test_untrusted_provider_over_cap_fails_closed(self):
        self.sequence = [Reply("completed", 5001, 100)]
        manager, run = self.make()
        self.assertEqual(manager.tick(run), "provider_limit_violation")
        self.assertEqual(len(self.calls), 1)

    def test_cost_reservation_prevents_call(self):
        manager, run = self.make(Limits(max_cost_nanodollars=1))
        self.assertEqual(manager.tick(run), "budget_exhausted")
        self.assertEqual(self.calls, [])

    def test_duplicate_run_id_refused(self):
        manager, run = self.make()
        with self.assertRaises(sqlite3.IntegrityError):
            manager.start("developer-2", "P123", digest("spec"), 1, run_id=run)

    def test_bad_id_and_invalid_provider_response(self):
        manager, run = self.make()
        with self.assertRaises(ValueError):
            manager.start("../escape", "P100", digest("spec"), 1)
        with self.assertRaises(ValueError):
            Reply("completed", -1, 3)
        with self.assertRaises(ValueError):
            Limits(max_turns=0)
        manager.provider = lambda *args: {"status": "completed"}
        self.assertEqual(manager.tick(run), "reconciliation_needed")

    def test_two_roles_independent(self):
        manager, run1 = self.make(Limits(max_turns=2))
        run2 = manager.start("architect-reviewer", "P998", digest("spec2"), 1)
        self.assertEqual(manager.tick(run1), "continue")
        self.assertEqual(manager.tick(run2), "continue")
        self.assertEqual(manager.state(run1)["turns"], 1)
        self.assertEqual(manager.state(run2)["turns"], 1)
        self.assertEqual(manager.state(run2)["role"], "architect-reviewer")

    def test_driver_bounded(self):
        manager, run = self.make(Limits(max_turns=20))
        self.assertEqual(manager.drive(run, max_local_turns=1), "driver_budget_reached")
        self.assertEqual(manager.state(run)["turns"], 1)
        with self.assertRaises(ValueError):
            manager.drive(run, max_local_turns=1000)

    def test_wall_clock_budget_before_provider(self):
        manager, run = self.make(Limits(max_wall_seconds=10))
        manager.clock = lambda: manager.state(run)["created_unix"] + 11
        self.assertEqual(manager.tick(run), "wall_time_exhausted")
        self.assertEqual(self.calls, [])

    def test_wall_clock_budget_during_provider(self):
        manager, run = self.make(Limits(max_wall_seconds=10))
        start_time = manager.state(run)["created_unix"]
        virtual_time = [start_time]
        manager.clock = lambda: virtual_time[0]
        orig_provider = manager.provider
        def long_response(*args):
            result = orig_provider(*args)
            virtual_time[0] += 11
            return result
        manager.provider = long_response
        self.assertEqual(manager.tick(run), "wall_time_exhausted")
        self.assertEqual(manager.state(run)["turns"], 1)
        self.assertEqual(len(self.calls), 1)

    def test_recovered_inflight_usage_is_not_claimed_complete(self):
        manager, run = self.make()
        with closing(sqlite3.connect(self.path)) as c, c:
            c.execute("UPDATE runs SET status='in_flight' WHERE id=?", (run,))
        self.assertEqual(manager.recover(run), "reconciliation_needed")
        self.assertEqual(manager.state(run)["usage_complete"], 0)

    def test_demo_never_uses_api(self):
        demo = demonstration()
        self.assertEqual(demo["mode"], "offline_fake_provider")
        self.assertEqual(demo["real_api_calls"], 0)
        self.assertEqual(demo["stop_reason"], "budget_exhausted")


if __name__ == "__main__":
    unittest.main()
