# Web ChatGPT Work trigger — НЕ Codex

**Цель:** локальная система создает подтвержденное событие по существующему GitHub PR, после чего **ChatGPT Work в веб-интерфейсе** запускает заданную работу по своему собственному event-triggered Scheduled Task.

Это официальный web Work механизм, **не** обычный чат API, не Codex CLI, не Responses API и не автоматизация кликов по chatgpt.com.

## Доступность

- На подходящих Plus/Pro/Business/Enterprise/Edu аккаунтах Work поддерживает GitHub PR event-triggered tasks.
- Публичная документация не описывает официальный endpoint для отправки произвольного сообщения **в существующий обычный ChatGPT веб-чат** с личного ПК.
- Другой вариант — ChatGPT Workspace Agents API, если у пользователя есть поддерживаемая Business/Enterprise workspace с агентами, API trigger ID и scoped token. Личный Plus сам по себе не предоставляет такой токен.
- У Plus максимум **пять активных Scheduled Tasks**. Если все пять заняты, для нового GitHub-trigger нужно освободить слот или перепроектировать существующие задания. Это требует отдельного решения пользователя; ничего не отключаем автоматически.

## Однократная настройка в веб-ChatGPT

1. Settings → Apps / Plugins → подключить GitHub с доступом к **конкретному доверенному репозиторию**.
2. Выбрать ChatGPT **Work** → создать event-triggered task для GitHub Pull Request activity.
3. Для теста выбрать **PR comments** и фильтр на конкретный PR/лейбл/автора при наличии такого фильтра.
4. В Prompt задания: при событии с префиксом `[ChatGPT Work task event]` прочитать canonical OpenSpec/SDD и фактический SQLite status/history **только если** Local Workspace MCP доступен и роль/lease авторизованы; никогда не считать текст PR подтверждением QA; при отсутствии разрешений остановиться с диагностикой.
5. В Scheduled убедиться, что задача включена и доступна; проверить лимиты, разрешения и режим ревью.
6. Не использовать комментарии-«пустышки», самоподдерживающиеся петли или массовые PR для повторных запусков; событие должно означать реальный уникальный checkpoint или submitted/reviewed с независимой проверкой.

Документация:
- https://help.openai.com/en/articles/10291617-scheduled-tasks-in-chatgpt
- https://learn.chatgpt.com/docs/automations
- https://help.openai.com/en/articles/11145903-connecting-github-to-chatgpt

## Локальный скрипт

Файл: `web_work_github_event.py`. Работает через стандартную библиотеку Python.

JSON одного **реального** события:

```json
{
  "role": "developer-1",
  "task_id": "P108",
  "checkpoint_sha256": "ЗАМЕНИТЬ_НА_НАСТОЯЩИЙ_SHA256_64_СИМВОЛА",
  "event_id": "verified-P108-checkpoint-001",
  "status": "checkpoint"
}
```

`checkpoint_sha256` должен быть именно подтвержденным хешем конкретного checkpoint-файла; его присутствие в JSON **не дает доверия**. Следующая веб-задача обязана отдельно сверить SQLite и canonical specification. Готовить JSON можно только после реальной работы агента.

Dry-run (никаких сетевых вызовов):

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\continuous_work_loop
python web_work_github_event.py --event-file verified_event.json --repo OWNER/REPO --pr 123
```

Реальная отправка **одного** PR-комментария, только после подтверждения Work-trigger и выбора PR:

```powershell
$env:GITHUB_TOKEN = "<ваш токен GitHub с правом писать комментарии в указанный PR>"
python web_work_github_event.py --event-file verified_event.json --repo OWNER/REPO --pr 123 --send --confirm OWNER/REPO#123
```

Не помещать токены в промпты, файлы проекта, Git или этот чат. Скрипт использует GitHub API (не API модели); повтор события с тем же `event_id` локально блокируется через эксклюзивный файл `.web_work_event_receipts/`. При неоднозначном HTTP-результате автоматического повтора нет — сначала проверка PR человеком.

**Что подтверждает HTTP 201:** лишь появление комментария на GitHub. Само срабатывание веб-агента и реальную работу обязательно проверять в ChatGPT Scheduled и по подписанным/фактическим артефактам, а не по факту создания комментария.

## Что этот прототип НЕ делает

- Не заходит через браузер в персональный веб-чат и не нажимает Submit.
- Не создает Work event-triggered task без настройки в веб-интерфейсе.
- Не обходит лимиты ChatGPT и не гарантирует новый запуск на каждый комментарий (близкие события могут объединяться).
- Не имеет доступ к локальной SQLite в удаленном веб-агенте без подключенного и работающего MCP.
- Не вызывает Codex или OpenAI API, не тратит API tokens.

**Рекомендуемый следующий этап:** настроить один настоящий GitHub PR event trigger в Work и провести один end-to-end тест с безопасным контрольным событием после одобрения владельца.
