"""Offline Codex CLI resume option probe; no model invocation."""
import json, shutil, subprocess
exe=shutil.which("codex") or shutil.which("codex.cmd") or shutil.which("codex.exe")
result={"cli_found":bool(exe),"resume_help_ok":False,"json_option":False,"sandbox_option":False,"flags":[]}
if exe:
    try:
        r=subprocess.run([exe,"exec","--sandbox","read-only","resume","--help"],capture_output=True,text=True,timeout=15,encoding="utf-8",errors="replace",shell=False)
        result["resume_help_ok"]=r.returncode==0
        h=r.stdout+"\n"+r.stderr
        result["json_option"]="--json" in h
        result["sandbox_option"]="--sandbox" in h
        result["flags"]=[v for v in ("--json","--sandbox","--dangerously-bypass-approvals-and-sandbox","--skip-git-repo-check","--cd","-C") if v in h]
    except (OSError, subprocess.TimeoutExpired):
        result["error"]="unavailable"
print(json.dumps(result,sort_keys=True))
