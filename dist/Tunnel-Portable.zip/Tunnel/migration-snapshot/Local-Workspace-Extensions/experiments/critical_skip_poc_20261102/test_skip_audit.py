"""Deterministic, no-provider negative tests of critical SKIP handling."""
import dataclasses
import unittest

from skip_audit import Assessment, TestReceipt, Verdict, assess


SHA = "a" * 64
REQUIRED = {"windows_junction": True, "trusted_host_actor": True, "optional_metrics": False}


def make_receipts():
    return [
        TestReceipt("windows_junction", "windows", SHA, True, "PASS"),
        TestReceipt("trusted_host_actor", "windows", SHA, True, "PASS"),
        TestReceipt("optional_metrics", "windows", SHA, False, "PASS"),
    ]


def run(receipts, required=REQUIRED, os_name="windows", sha=SHA):
    return assess(receipts, mandatory=required, expected_os=os_name, expected_source_sha256=sha)


class SkipAuditTests(unittest.TestCase):
    def test_clean_pass(self):
        self.assertIs(run(make_receipts()).verdict, Verdict.PASS)

    def test_40_critical_negative_fixtures_never_pass(self):
        """At least 40 independent receipt variations including Windows/actor SKIPs."""
        for i in range(40):
            with self.subTest(i=i):
                receipts = make_receipts()
                idx = i % 2  # junction or trusted host actor
                bad = receipts[idx]
                fault = i % 5
                if fault == 0:
                    receipts[idx] = dataclasses.replace(bad, status="SKIP", skip_reason="OS ACL unavailable")
                elif fault == 1:
                    receipts[idx] = dataclasses.replace(bad, source_sha256="b" * 64)
                elif fault == 2:
                    receipts[idx] = dataclasses.replace(bad, operating_system="linux")
                elif fault == 3:
                    receipts.pop(idx)
                else:
                    receipts[idx] = dataclasses.replace(bad, job_exit_code=3)
                self.assertNotIn(run(receipts).verdict, {Verdict.PASS, Verdict.PASS_WITH_NONCRITICAL_SKIPS})

    def test_critical_skip_produces_incomplete(self):
        receipts = make_receipts()
        receipts[0] = dataclasses.replace(receipts[0], status="SKIP", skip_reason="not supported")
        r = run(receipts)
        self.assertIs(r.verdict, Verdict.INCOMPLETE)
        self.assertIn("CRITICAL_SKIP:windows_junction", r.reasons)

    def test_missing_required_test_not_vacuous_pass(self):
        self.assertIs(run([]).verdict, Verdict.INCOMPLETE)

    def test_declared_noncritical_skip_visible(self):
        receipts = make_receipts()
        receipts[2] = dataclasses.replace(receipts[2], status="SKIP", skip_reason="metrics optional")
        r = run(receipts)
        self.assertIs(r.verdict, Verdict.PASS_WITH_NONCRITICAL_SKIPS)
        self.assertEqual(r.observed_skips, ("optional_metrics",))

    def test_unexplained_noncritical_skip_incomplete(self):
        receipts = make_receipts()
        receipts[2] = dataclasses.replace(receipts[2], status="SKIP")
        self.assertIs(run(receipts).verdict, Verdict.INCOMPLETE)

    def test_failure_overrides_incompleteness(self):
        receipts = make_receipts()
        receipts[0] = dataclasses.replace(receipts[0], status="FAIL", job_exit_code=1)
        receipts.pop()
        self.assertIs(run(receipts).verdict, Verdict.FAIL)

    def test_duplicate_receipt_incomplete(self):
        receipts = make_receipts()
        receipts.append(receipts[0])
        self.assertIs(run(receipts).verdict, Verdict.INCOMPLETE)

    def test_unknown_test_incomplete(self):
        receipts = make_receipts()
        receipts.append(TestReceipt("unlisted", "windows", SHA, False, "PASS"))
        self.assertIs(run(receipts).verdict, Verdict.INCOMPLETE)

    def test_wrong_criticality_incomplete(self):
        receipts = make_receipts()
        receipts[0] = dataclasses.replace(receipts[0], critical=False)
        self.assertIs(run(receipts).verdict, Verdict.INCOMPLETE)

    def test_invalid_expected_hash_incomplete(self):
        self.assertIs(run(make_receipts(), sha="garbage").verdict, Verdict.INCOMPLETE)

    def test_invalid_required_contract_incomplete(self):
        self.assertIs(run(make_receipts(), required={"trusted_host_actor": "no"}).verdict, Verdict.INCOMPLETE)

    def test_unknown_status_incomplete(self):
        receipts = make_receipts()
        receipts[0] = dataclasses.replace(receipts[0], status="UNKNOWN")
        self.assertIs(run(receipts).verdict, Verdict.INCOMPLETE)

    def test_malformed_unhashable_fields_fail_closed(self):
        receipts = make_receipts()
        receipts[0] = dataclasses.replace(receipts[0], status=["PASS"])
        self.assertIs(run(receipts).verdict, Verdict.INCOMPLETE)
        self.assertIs(run(make_receipts(), os_name=["windows"]).verdict, Verdict.INCOMPLETE)

    def test_synthetic_receipts_do_not_create_host_attestation(self):
        self.assertIs(run(make_receipts()).verdict, Verdict.PASS)
        # PASS means internal consistency with caller-supplied fixtures only.
        # No claim of an authenticated MCP actor or observed production behavior.


if __name__ == "__main__":
    unittest.main()
