"""Offline fail-closed assessment of critical skipped tests (feature D2:F02).

The trusted required-test list and SHA/OS must come from an authorized
independent reviewer in any future integration. No live admission/approval.
"""
from dataclasses import dataclass
from enum import Enum
import re


SHA_RE = re.compile(r"^[0-9a-f]{64}$")


class Verdict(str, Enum):
    PASS = "PASS"
    PASS_WITH_NONCRITICAL_SKIPS = "PASS_WITH_NONCRITICAL_SKIPS"
    INCOMPLETE = "INCOMPLETE"
    FAIL = "FAIL"


@dataclass(frozen=True)
class TestReceipt:
    test_id: str
    operating_system: str
    source_sha256: str
    critical: bool
    status: str  # PASS | FAIL | SKIP
    skip_reason: str = ""
    job_exit_code: int = 0


@dataclass(frozen=True)
class Assessment:
    verdict: Verdict
    reasons: tuple[str, ...]
    observed_skips: tuple[str, ...]


def assess(
    receipts: list[TestReceipt],
    *,
    expected_source_sha256: str,
    expected_os: str,
    mandatory: dict[str, bool],
) -> Assessment:
    """Pure assessment; incomplete or suspicious receipts never produce PASS."""
    if (not isinstance(receipts, list)
            or not isinstance(expected_source_sha256, str)
            or not SHA_RE.fullmatch(expected_source_sha256)
            or not isinstance(expected_os, str)
            or expected_os not in {"windows", "linux", "macos"}
            or not isinstance(mandatory, dict)
            or not mandatory
            or len(mandatory) > 10000):
        return Assessment(Verdict.INCOMPLETE, ("INVALID_EVALUATION_CONTEXT",), ())
    if any(not isinstance(k, str) or not k or len(k) > 128 or type(v) is not bool
           for k, v in mandatory.items()):
        return Assessment(Verdict.INCOMPLETE, ("INVALID_MANDATORY_CONTRACT",), ())
    missing = set(mandatory)
    seen = set()
    reasons: list[str] = []
    skipped: list[str] = []
    fail = False
    for receipt in receipts:
        if not isinstance(receipt, TestReceipt):
            reasons.append("INVALID_RECEIPT")
            continue
        ident = receipt.test_id
        if not isinstance(ident, str) or ident not in mandatory:
            reasons.append("UNEXPECTED_TEST")
            continue
        if ident in seen:
            reasons.append("DUPLICATE_TEST:" + ident)
            continue
        seen.add(ident)
        missing.discard(ident)
        if (receipt.operating_system != expected_os
                or receipt.source_sha256 != expected_source_sha256
                or type(receipt.critical) is not bool
                or receipt.critical != mandatory[ident]
                or not isinstance(receipt.status, str)
                or receipt.status not in {"PASS", "FAIL", "SKIP"}
                or type(receipt.job_exit_code) is not int
                or not isinstance(receipt.skip_reason, str)):
            reasons.append("INVALID_OR_STALE_RECEIPT:" + ident)
            continue
        if receipt.job_exit_code != 0 or receipt.status == "FAIL":
            fail = True
            reasons.append("TEST_FAILED:" + ident)
        elif receipt.status == "SKIP":
            skipped.append(ident)
            if receipt.critical:
                reasons.append("CRITICAL_SKIP:" + ident)
            elif not receipt.skip_reason.strip():
                reasons.append("UNEXPLAINED_SKIP:" + ident)
    reasons.extend("MISSING_TEST:" + ident for ident in sorted(missing))
    if fail:
        verdict = Verdict.FAIL
    elif reasons:
        verdict = Verdict.INCOMPLETE
    elif skipped:
        verdict = Verdict.PASS_WITH_NONCRITICAL_SKIPS
    else:
        verdict = Verdict.PASS
    return Assessment(verdict, tuple(reasons), tuple(sorted(skipped)))
