"""Atomic, fenced component claims for parallel code-writing agents.

The semantic key must be produced by the planner's canonical component registry.
A claim protects a *key*, not all equivalent code under different names.
"""
from __future__ import annotations

import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path


class ClaimBusy(RuntimeError):
    pass


class StaleClaim(RuntimeError):
    pass


class ComponentClaims:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS component_claims (
                component_key TEXT PRIMARY KEY,
                owner TEXT NOT NULL,
                token INTEGER NOT NULL CHECK(token > 0),
                expires_at REAL NOT NULL
            )""")

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.db_path, timeout=10.0, isolation_level=None)
        try:
            db.execute("PRAGMA busy_timeout=10000")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _required(value: str, label: str):
        if not isinstance(value, str) or not value.strip() or len(value) > 256:
            raise ValueError(f"{label} must be nonempty and at most 256 characters")

    def acquire(self, key: str, owner: str, ttl: float = 120.0, *, now: float | None = None) -> int:
        self._required(key, "key")
        self._required(owner, "owner")
        if not 0 < ttl <= 86400:
            raise ValueError("ttl out of range")
        current = time.time() if now is None else now
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT owner, token, expires_at FROM component_claims WHERE component_key=?",
                (key,),
            ).fetchone()
            if row and row[2] > current:
                raise ClaimBusy(f"component claimed by {row[0]}")
            token = row[1] + 1 if row else 1
            db.execute(
                """INSERT INTO component_claims(component_key, owner, token, expires_at)
                VALUES(?, ?, ?, ?)
                ON CONFLICT(component_key) DO UPDATE SET
                  owner=excluded.owner, token=excluded.token, expires_at=excluded.expires_at""",
                (key, owner, token, current + ttl),
            )
            return token

    def renew(self, key: str, owner: str, token: int, ttl: float = 120.0, *, now: float | None = None):
        if not 0 < ttl <= 86400:
            raise ValueError("ttl out of range")
        current = time.time() if now is None else now
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            updated = db.execute(
                """UPDATE component_claims SET expires_at=?
                WHERE component_key=? AND owner=? AND token=? AND expires_at>?""",
                (current + ttl, key, owner, token, current),
            ).rowcount
            if updated != 1:
                raise StaleClaim("claim is no longer valid")

    def validate(self, key: str, owner: str, token: int, *, now: float | None = None) -> bool:
        current = time.time() if now is None else now
        with self._db() as db:
            row = db.execute(
                """SELECT 1 FROM component_claims
                WHERE component_key=? AND owner=? AND token=? AND expires_at>?""",
                (key, owner, token, current),
            ).fetchone()
            return row is not None

    def release(self, key: str, owner: str, token: int, *, now: float | None = None):
        current = time.time() if now is None else now
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            changed = db.execute(
                """UPDATE component_claims SET expires_at=?
                WHERE component_key=? AND owner=? AND token=? AND expires_at>?""",
                (current, key, owner, token, current),
            ).rowcount
            if changed != 1:
                raise StaleClaim("claim is no longer valid")
