import unittest

from media_rights_schema import validate_media_rights
class ReworkRegression(unittest.TestCase):
    def test_unpaired_unicode_surrogate_fails_closed(self):
        manifest={"assets":[{"source_path":"\ud800"}],
                  "scenes":[{"scene_id":"scene01","asset_ids":["asset"]}]}
        result=validate_media_rights(manifest)
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"],"INVALID_MANIFEST")
        self.assertFalse(result["publication_approved"])

    def test_windows_forbidden_path_characters_fail_closed(self):
        from test_media_rights_schema import asset, manifest
        for char in '<>:"|?*':
            with self.subTest(char=char):
                data = manifest(asset(source_path="clips/file" + char + "name.mp4"))
                result = validate_media_rights(data)
                self.assertFalse(result["ok"], result)
                self.assertEqual(result["error"], "INVALID_PATH", result)
                self.assertFalse(result["publication_approved"])
        for path in ("clips/normal name.mp4", "clips/сцена01.mp4"):
            with self.subTest(path=path):
                result = validate_media_rights(manifest(asset(source_path=path)))
                self.assertTrue(result["ok"], result)
                self.assertFalse(result["publication_approved"])


    def test_unicode_format_controls_cannot_disguise_media_path(self):
        from test_media_rights_schema import asset, manifest
        for char in ("\u202e", "\u202d", "\u200e", "\u200f", "\u2066", "\u2069", "\u200b"):
            with self.subTest(char=ord(char)):
                result = validate_media_rights(
                    manifest(asset(source_path="clips/photo" + char + "gpj.mp4")))
                self.assertFalse(result["ok"], result)
                self.assertEqual(result["error"], "INVALID_PATH", result)
                self.assertFalse(result["publication_approved"])
        for good in ("clips/сцена.mp4", "clips/東京.mp4", "clips/café.mp4"):
            with self.subTest(good=good):
                result = validate_media_rights(manifest(asset(source_path=good)))
                self.assertTrue(result["ok"], result)
                self.assertFalse(result["publication_approved"])


if __name__ == "__main__":
    unittest.main()
