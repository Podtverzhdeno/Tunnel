"""Offline media-rights metadata validation; never an approval of rights or rendering.

All license, holder and evidence fields are caller assertions. This module
performs no media/file reads and cannot verify ownership or issue a release.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import re
import unicodedata

_ASSET = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
_SCENE = re.compile(r"^scene[0-9]{2}$")
_SHA = re.compile(r"^[0-9a-fA-F]{64}$")
_CATEGORIES = {"CC0", "CC-BY", "CC-BY-SA", "PUBLIC_DOMAIN",
               "PROPRIETARY", "UNKNOWN"}
_RESERVED = re.compile(r"^(?:CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³]|CONIN\$|CONOUT\$)(?:\..*)?$", re.I)
_ASSET_KEYS = {"asset_id", "sha256", "source_path", "license_category",
               "rights_holder", "attribution", "expires_at", "reuse_allowed",
               "verified", "verification_evidence"}
_SCENE_KEYS = {"scene_id", "asset_ids"}


def _date(value):
    if value is None:
        return None
    if type(value) is not str or len(value) > 40:
        raise ValueError("INVALID_EXPIRY")
    try:
        t = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if t.tzinfo is None or t.utcoffset() is None:
            raise ValueError("INVALID_EXPIRY")
        return t.astimezone(timezone.utc)
    except (ValueError, OverflowError) as exc:
        raise ValueError("INVALID_EXPIRY") from exc


def _path(value):
    if type(value) is not str or not value or len(value) > 260:
        return False
    if value.startswith(("/", "\\")) or any(ch in value for ch in ':"<>|?*'):
        return False
    # Reject bidi overrides and other invisible format controls: such names
    # can visually disguise a media extension even without path traversal.
    if any(unicodedata.category(ch) in ("Cc", "Cf") for ch in value):
        return False
    parts = value.replace("\\", "/").split("/")
    if any(not part or part in (".", "..") or
           part.endswith((".", " ")) or _RESERVED.fullmatch(part)
           for part in parts):
        return False
    return True


def validate_media_rights(manifest, *, now_utc="2026-11-01T00:00:00Z"):
    """Validate a bounded six-scene rights manifest without granting release."""
    base = {"publication_approved": False, "render_approved": False,
            "host_attested": False, "provenance": "caller_supplied_unverified"}
    try:
        now = _date(now_utc)
        if now is None:
            raise ValueError("INVALID_EXPIRY")
        if type(manifest) is not dict or set(manifest) != {"assets", "scenes"}:
            raise ValueError("INVALID_MANIFEST")
        assets, scenes = manifest["assets"], manifest["scenes"]
        if type(assets) is not list or type(scenes) is not list:
            raise ValueError("INVALID_MANIFEST")
        if not 1 <= len(assets) <= 512 or not 1 <= len(scenes) <= 6:
            raise ValueError("INVALID_COUNT")
        try:
            payload = json.dumps(manifest, ensure_ascii=False, allow_nan=False).encode("utf-8", errors="strict")
        except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
            raise ValueError("INVALID_MANIFEST") from exc
        if len(payload) > 262144:
            raise ValueError("INPUT_TOO_LARGE")
        by_asset = {}
        results = []
        for a in assets:
            if type(a) is not dict or set(a) != _ASSET_KEYS:
                raise ValueError("INVALID_ASSET_FIELDS")
            aid = a["asset_id"]
            if type(aid) is not str or not _ASSET.fullmatch(aid):
                raise ValueError("INVALID_ASSET_ID")
            if aid in by_asset:
                raise ValueError("DUPLICATE_ASSET")
            sha = a["sha256"]
            if type(sha) is not str or not _SHA.fullmatch(sha):
                raise ValueError("INVALID_SHA256")
            if not _path(a["source_path"]):
                raise ValueError("INVALID_PATH")
            category = a["license_category"]
            if type(category) is not str or category not in _CATEGORIES:
                raise ValueError("INVALID_LICENSE")
            for key in ("rights_holder", "attribution", "verification_evidence"):
                value = a[key]
                if value is not None and (type(value) is not str or len(value) > 512):
                    raise ValueError("INVALID_METADATA")
            if type(a["reuse_allowed"]) is not bool or type(a["verified"]) is not bool:
                raise ValueError("INVALID_BOOLEAN")
            expiry = _date(a["expires_at"])
            if a["verified"]:
                status, reason = "BLOCKED", "UNTRUSTED_VERIFIED_FLAG"
            elif expiry is not None and expiry <= now:
                status, reason = "BLOCKED", "LICENSE_EXPIRED"
            elif not a["reuse_allowed"]:
                status, reason = "BLOCKED", "REUSE_RESTRICTED"
            elif category == "UNKNOWN" or not a["rights_holder"]:
                status, reason = "UNKNOWN", "RIGHTS_UNCONFIRMED"
            elif category in {"CC-BY", "CC-BY-SA"} and not a["attribution"]:
                status, reason = "BLOCKED", "ATTRIBUTION_MISSING"
            else:
                status, reason = "UNKNOWN", "CLAIM_ONLY_NO_TRUSTED_RIGHTS_RECEIPT"
            by_asset[aid] = status
            results.append({"asset_id": aid, "status": status, "reason": reason,
                            "source_sha256": sha.lower()})
        scene_results = []
        seen = set()
        for s in scenes:
            if type(s) is not dict or set(s) != _SCENE_KEYS:
                raise ValueError("INVALID_SCENE")
            sid = s["scene_id"]
            ids = s["asset_ids"]
            if type(sid) is not str or not _SCENE.fullmatch(sid) or sid in seen:
                raise ValueError("INVALID_OR_DUPLICATE_SCENE")
            seen.add(sid)
            if type(ids) is not list or not ids or len(ids) > 512:
                raise ValueError("INVALID_SCENE_ASSETS")
            if any(type(aid) is not str or aid not in by_asset for aid in ids):
                raise ValueError("UNKNOWN_SCENE_ASSET")
            if len(ids) != len(set(ids)):
                raise ValueError("DUPLICATE_SCENE_ASSET")
            blocked = any(by_asset[aid] == "BLOCKED" for aid in ids)
            scene_results.append({"scene_id": sid,
                                  "status": "BLOCKED" if blocked else "UNKNOWN",
                                  "reason": ("BLOCKED_ASSET" if blocked else
                                             "NO_TRUSTED_PUBLICATION_APPROVAL")})
        return {**base, "ok": True, "assets": sorted(results, key=lambda x: x["asset_id"]),
                "scenes": sorted(scene_results, key=lambda x: x["scene_id"]),
                "all_rights_verified": False}
    except (ValueError, TypeError, OverflowError, RecursionError) as exc:
        code = str(exc)
        known = {"INVALID_EXPIRY", "INVALID_MANIFEST", "INVALID_COUNT",
                 "INPUT_TOO_LARGE", "INVALID_ASSET_FIELDS", "INVALID_ASSET_ID",
                 "DUPLICATE_ASSET", "INVALID_SHA256", "INVALID_PATH",
                 "INVALID_LICENSE", "INVALID_METADATA", "INVALID_BOOLEAN",
                 "INVALID_SCENE", "INVALID_OR_DUPLICATE_SCENE",
                 "INVALID_SCENE_ASSETS", "UNKNOWN_SCENE_ASSET",
                 "DUPLICATE_SCENE_ASSET"}
        return {**base, "ok": False, "error": code if code in known else "INVALID_INPUT",
                "assets": [], "scenes": [], "all_rights_verified": False}
