"""Bounded, lossless normalizer for *reported* provider token receipts.

This is pure offline analysis of caller-supplied data. It cannot authenticate a
provider receipt or ChatGPT scheduled run; never infer unknown usage as zero.
No network, filesystem access, SQLite, pricing or host authorization.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import re

_MAX_EVENTS = 512
_MAX_BYTES = 262144
_MAX_COUNTER = 2**63 - 1
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")
_ROLE = re.compile(r"^developer-[1-4]$|^architect-reviewer$")
_TASK = re.compile(r"^P[0-9]{3,5}$")
_COUNTERS = ("input_tokens", "output_tokens", "cached_input_tokens",
             "reasoning_output_tokens")
_META = ("role", "task_id", "run_id", "model")
_RECEIPT_KEYS = frozenset((*_META, "usage_id", "provider", "timestamp",
                            "source", *_COUNTERS))
_RUN_KEYS = frozenset((*_META, "timestamp"))
_SOURCES = frozenset({"agent_reported_provider_usage_unverified",
                      "provider_reported_unverified"})


def _timestamp(value):
    if type(value) is not str or len(value) > 40:
        raise ValueError("INVALID_TIMESTAMP")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError("INVALID_TIMESTAMP")
        return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    except (ValueError, OverflowError) as exc:
        raise ValueError("INVALID_TIMESTAMP") from exc


def _metadata(obj, expected_keys):
    if type(obj) is not dict or set(obj) != expected_keys:
        raise ValueError("INVALID_FIELDS")
    for key in _META:
        val = obj[key]
        if type(val) is not str or not val or len(val) > 128:
            raise ValueError("INVALID_ID")
        if key == "role":
            if not _ROLE.fullmatch(val):
                raise ValueError("INVALID_ROLE")
        elif key == "task_id":
            if not _TASK.fullmatch(val):
                raise ValueError("INVALID_TASK")
        elif key == "model":
            if not val[0].isalnum() or any(not (ch.isalnum() or ch in "._:-") for ch in val):
                raise ValueError("INVALID_ID")
        elif not _ID.fullmatch(val):
            raise ValueError("INVALID_ID")
    return tuple(obj[k] for k in _META)


def _sum_checked(a, b):
    if a > _MAX_COUNTER - b:
        raise ValueError("COUNTER_OVERFLOW")
    return a + b


def normalize_metric_series(receipts, expected_runs=()):
    """Return sorted per-call receipts and per-run aggregates, or a fail-closed error.

    expected_runs represents independently enumerated runs, NOT usage evidence.
    Its missing receipts yield null counts with coverage UNKNOWN, never zero.
    """
    try:
        if type(receipts) not in (list, tuple) or type(expected_runs) not in (list, tuple):
            raise ValueError("INVALID_COLLECTION")
        if len(receipts) > _MAX_EVENTS or len(expected_runs) > _MAX_EVENTS:
            raise ValueError("TOO_MANY_EVENTS")
        raw = json.dumps({"receipts": receipts, "expected_runs": expected_runs},
                         ensure_ascii=False, allow_nan=False)
        if len(raw.encode("utf-8")) > _MAX_BYTES:
            raise ValueError("INPUT_TOO_LARGE")
        by_usage = {}
        by_run = {}
        providers_by_group = {}
        expected = {}
        for row in expected_runs:
            meta = _metadata(row, _RUN_KEYS)
            stamp = _timestamp(row["timestamp"])
            run_id = meta[2]
            identity = meta[:3]
            if run_id in by_run and by_run[run_id] != identity:
                raise ValueError("AMBIGUOUS_RUN")
            by_run[run_id] = identity
            key = meta
            if key in expected and expected[key] != stamp:
                raise ValueError("CONFLICTING_RUN")
            expected[key] = stamp
        for row in receipts:
            meta = _metadata(row, _RECEIPT_KEYS)
            for key in ("usage_id", "provider"):
                if type(row[key]) is not str or not _ID.fullmatch(row[key]):
                    raise ValueError("INVALID_ID")
            if row["source"] not in _SOURCES:
                raise ValueError("UNVERIFIED_OR_FORGED_SOURCE")
            stamp = _timestamp(row["timestamp"])
            for key in _COUNTERS:
                val = row[key]
                if type(val) is not int or val < 0 or val > _MAX_COUNTER:
                    raise ValueError("INVALID_COUNTER")
            if (row["cached_input_tokens"] > row["input_tokens"] or
                    row["reasoning_output_tokens"] > row["output_tokens"]):
                raise ValueError("INVALID_SUBSET")
            identity = meta[:3]
            if meta[2] in by_run and by_run[meta[2]] != identity:
                raise ValueError("AMBIGUOUS_RUN")
            by_run[meta[2]] = identity
            # Per-run output has no provider field: mixing providers would
            # silently misattribute token totals. Reject rather than merge.
            prior_provider = providers_by_group.get(meta)
            if prior_provider is not None and prior_provider != row["provider"]:
                raise ValueError("AMBIGUOUS_PROVIDER")
            providers_by_group[meta] = row["provider"]
            canonical = dict(row)
            canonical["timestamp"] = stamp
            uid = row["usage_id"]
            if uid in by_usage:
                if by_usage[uid] != canonical:
                    raise ValueError("CONFLICTING_USAGE_ID")
                continue
            by_usage[uid] = canonical
        events = sorted(by_usage.values(), key=lambda r: (
            r["timestamp"], r["role"], r["task_id"], r["run_id"],
            r["model"], r["usage_id"]))
        groups = {}
        for row in events:
            key = tuple(row[k] for k in _META)
            if key not in groups:
                groups[key] = {k: 0 for k in _COUNTERS}
            for counter in _COUNTERS:
                groups[key][counter] = _sum_checked(groups[key][counter], row[counter])
        runs = []
        for key in sorted(set(groups) | set(expected)):
            counts = groups.get(key)
            runs.append({
                **dict(zip(_META, key)),
                "coverage": "REPORTED_UNVERIFIED" if counts is not None else "UNKNOWN",
                "provider_usage_status": ("reported_provider_usage_unverified"
                                          if counts is not None else "no_token_usage_metadata"),
                **({k: counts[k] if counts is not None else None for k in _COUNTERS}),
            })
        return {
            "ok": True,
            "events": events,
            "runs": runs,
            "unique_receipt_count": len(events),
            "missing_usage_run_count": sum(r["coverage"] == "UNKNOWN" for r in runs),
            "provider_receipt_authenticated": False,
            "host_actor_authenticated": False,
            "provenance": "caller_supplied_provider_usage_unverified",
        }
    except (ValueError, TypeError, UnicodeError, OverflowError, RecursionError) as exc:
        code = str(exc)
        if code not in {
            "INVALID_COLLECTION", "TOO_MANY_EVENTS", "INPUT_TOO_LARGE",
            "INVALID_FIELDS", "INVALID_ID", "INVALID_ROLE", "INVALID_TASK",
            "INVALID_TIMESTAMP", "INVALID_COUNTER", "INVALID_SUBSET",
            "COUNTER_OVERFLOW", "CONFLICTING_USAGE_ID", "AMBIGUOUS_RUN",
            "CONFLICTING_RUN", "AMBIGUOUS_PROVIDER", "UNVERIFIED_OR_FORGED_SOURCE",
        }:
            code = "INVALID_INPUT"
        return {"ok": False, "error": code, "events": [], "runs": [],
                "provider_receipt_authenticated": False,
                "host_actor_authenticated": False}
