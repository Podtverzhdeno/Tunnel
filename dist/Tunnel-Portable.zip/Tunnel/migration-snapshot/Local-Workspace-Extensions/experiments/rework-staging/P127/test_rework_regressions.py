import unittest

from agent_metrics_series import normalize_metric_series
from test_agent_metrics_series import receipt, run
class ReworkRegression(unittest.TestCase):
    def test_empty_model_returns_structured_failure(self):
        row={"role":"developer-4","task_id":"P127","run_id":"run-001",
             "model":"","timestamp":"2026-11-02T00:00:00Z"}
        result=normalize_metric_series([],expected_runs=[row])
        self.assertEqual(result["ok"],False)
        self.assertEqual(result["error"],"INVALID_ID")
    def test_unpaired_surrogate_returns_structured_failure(self):
        for source in ([{"text":"\ud800"}],[]):
            result=normalize_metric_series(source,expected_runs=[{"model":"\ud800"}] if not source else ())
            self.assertFalse(result["ok"])
            self.assertEqual(result["error"],"INVALID_INPUT")

    def test_cross_provider_same_run_is_rejected_not_aggregated(self):
        rows = [receipt(), receipt(usage_id="usage-002", provider="other")]
        for received in (rows, list(reversed(rows))):
            result = normalize_metric_series(received, expected_runs=[run()])
            self.assertFalse(result["ok"], result)
            self.assertEqual(result["error"], "AMBIGUOUS_PROVIDER")
            self.assertEqual(result["runs"], [])

    def test_two_receipts_from_same_provider_remain_aggregated(self):
        rows = [receipt(), receipt(usage_id="usage-002", input_tokens=30)]
        result = normalize_metric_series(rows)
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["runs"][0]["input_tokens"], 130)


if __name__ == "__main__":
    unittest.main()
