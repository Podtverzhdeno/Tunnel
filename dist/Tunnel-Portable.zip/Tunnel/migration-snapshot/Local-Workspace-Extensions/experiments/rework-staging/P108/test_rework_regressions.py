import unittest
from test_actor_grant_contract import ActorGrantContractTests
class ReworkRegression(unittest.TestCase):
    def test_namespaced_executor_does_not_look_like_safe_tool(self):
        f=ActorGrantContractTests();f.setUp()
        for tool in ("local_workspace.run_script", "local_workspace.run_command",
                     "plugin.run_script", "local-workspace.run-script",
                     "local-workspace-run-command", "tools.docker-exec",
                     "plugin.python-exec"):
            with self.subTest(tool=tool):
                request=dict(f.request,tool=tool)
                grant=dict(f.grant,tool=tool)
                registry={**f.registry,tool:"R0"}
                out=f.evaluate(request=request,grant=grant,registry=registry)
                self.assertEqual(out["decision"],"DENY",out)
                self.assertEqual(out["reason"],"UNRESTRICTED_EXECUTOR",out)

    def test_nested_process_executor_aliases_are_denied(self):
        fixture = ActorGrantContractTests()
        fixture.setUp()
        for tool in ("subprocess.run", "subprocess.call", "os.system",
                     "child-process.exec", "process.spawn", "shell.run"):
            with self.subTest(tool=tool):
                request = dict(fixture.request, tool=tool)
                grant = dict(fixture.grant, tool=tool)
                registry = {**fixture.registry, tool: "R0"}
                outcome = fixture.evaluate(request=request, grant=grant,
                                           registry=registry)
                self.assertEqual(outcome["decision"], "DENY", outcome)
                self.assertEqual(outcome["reason"], "UNRESTRICTED_EXECUTOR",
                                 outcome)
                self.assertFalse(outcome["execution_authorized"])

    def test_windows_forbidden_path_symbols_are_denied(self):
        fixture = ActorGrantContractTests()
        fixture.setUp()
        for ch in '<>:"|?*':
            with self.subTest(char=ch):
                request = dict(fixture.request, args={"path": "src/fi" + ch + "le.py"})
                result = fixture.evaluate(request=request)
                self.assertEqual(result["decision"], "DENY", result)
                self.assertEqual(result["reason"], "UNSAFE_ARGUMENT_PATH", result)

    def test_unicode_paths_remain_eligible_only(self):
        from actor_grant_contract import normalized_args_sha256
        fixture = ActorGrantContractTests()
        fixture.setUp()
        for path in ("src/сцена.py", "src/東京.py", "src/café.py"):
            with self.subTest(path=path):
                args = {"path": path}
                request = dict(fixture.request, args=args)
                grant = dict(fixture.grant, args_sha256=normalized_args_sha256(args))
                result = fixture.evaluate(request=request, grant=grant)
                self.assertEqual(result["decision"], "ELIGIBLE_UNVERIFIED", result)
                self.assertFalse(result["execution_authorized"])

    def test_similar_names_are_not_executor_aliases(self):
        fixture = ActorGrantContractTests()
        fixture.setUp()
        for tool in ("tools.run_script_audit", "plugin.myrun_script",
                     "tools.command_runner", "task.safe-execution-check"):
            with self.subTest(tool=tool):
                request = dict(fixture.request, tool=tool)
                grant = dict(fixture.grant, tool=tool)
                registry = {**fixture.registry, tool: "R0"}
                outcome = fixture.evaluate(request=request, grant=grant, registry=registry)
                self.assertEqual(outcome["decision"], "ELIGIBLE_UNVERIFIED", outcome)
                self.assertFalse(outcome["execution_authorized"])


if __name__ == "__main__":
    unittest.main()

