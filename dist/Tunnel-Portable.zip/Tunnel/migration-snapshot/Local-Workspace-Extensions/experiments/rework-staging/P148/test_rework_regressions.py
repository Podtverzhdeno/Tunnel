import unittest
from test_queue_starvation_diagnostics import task,snap,role
from queue_starvation_diagnostics import classify_queue_snapshot
class ReworkRegression(unittest.TestCase):
    def test_done_accepted_dependency_with_drift_cannot_unlock_successor(self):
        for drift in ("source_sha_matches","spec_sha_matches"):
            with self.subTest(drift=drift):
                upstream=task("P105","done",**{drift:False})
                successor=task("P148",dependencies=["P105"])
                result=classify_queue_snapshot(snap(
                    [upstream,successor],[{"role":"developer-2","host_authorized":True}]))
                self.assertEqual(role(result)["classification"],"missing_dependency",result)
                self.assertFalse(result["host_actor_authenticated"])

    def test_submitted_source_and_spec_drift_precede_review_waiting(self):
        for status in ("review", "reviewing"):
            for flag in ("source_sha_matches", "spec_sha_matches"):
                with self.subTest(status=status, flag=flag):
                    stale = task("P148", status, **{flag: False})
                    result = classify_queue_snapshot(snap(
                        [stale], [{"role": "developer-2", "host_authorized": True}]))
                    item = role(result)
                    self.assertEqual(item["classification"], "stale_source", result)
                    self.assertEqual(item["safe_next_action"],
                                     "request_reviewer_source_reconciliation", result)
                    self.assertFalse(result["may_mutate"])

    def test_clean_review_still_waits_and_ready_task_wins(self):
        for status in ("review", "reviewing"):
            with self.subTest(status=status):
                pending = task("P147", status)
                result = classify_queue_snapshot(snap([pending]))
                self.assertEqual(role(result)["classification"], "review_waiting")
                ready = task("P148")
                result = classify_queue_snapshot(snap(
                    [pending, ready], [{"role": "developer-2", "host_authorized": True}]))
                self.assertEqual(role(result)["classification"], "ready")
                self.assertEqual(role(result)["task_id"], "P148")


if __name__ == "__main__":
    unittest.main()
