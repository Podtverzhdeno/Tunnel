"""Advisory, offline classification of untrusted task text (P111).

This module cannot authenticate actors, approve tools, or secure an MCP host.
It intentionally never returns an authorization decision such as ALLOW.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any

MAX_INPUT_BYTES = 16_384
MAX_LINES = 256
MAX_REASONS = 12

# Bounded, fixed patterns. They are heuristics, not a security enforcement point.
_CLAUSE_SPLIT = re.compile(
    r"[;:!?\n\r]+|(?<!\s)\.(?=\s+\w)|\b(?:but|however|and\s+then|then|однако|но|а\s+потом|затем)\b"
    r"|(?:,|\band\b)\s*(?=(?:please\s+)?(?:run|execute|git|delete|remove|call|запусти|удали|вызови)\b)",
    re.IGNORECASE,
)
_NEGATED = re.compile(
    r"^(?:do\s+not|don't|never|must\s+not|should\s+not|"
    r"не\s+надо|не\s+следует|никогда\s+не|нельзя|запрещено|не)\b",
    re.IGNORECASE,
)
_NEGATED_END = re.compile(r"\b(?:is\s+(?:prohibited|forbidden|not\s+allowed)|запрещ[её]н[оы]?|не\s+разрешено)\s*$", re.I)
_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("INSTRUCTION_OVERRIDE", re.compile(
        r"\b(?:ignore|disregard|override|bypass|forget|игнорируй|"
        r"обойди|отмени|забудь)\b.{0,70}\b(?:previous|prior|system|developer|"
        r"instructions?|rules?|policy|scope|sandbox|spec|предыдущие|системные|инструкции|"
        r"правила|политику|ограничения)\b", re.I)),
    ("ACTOR_IMPERSONATION", re.compile(
        r"\b(?:you\s+are|act\s+as|pretend\s+to\s+be|become|"
        r"ты\s+теперь|считай\s+себя|представься|выступай\s+как)\b"
        r".{0,70}\b(?:architect[ -]?reviewer|reviewer|administrator|admin|"
        r"trusted\s+host|owner|root|архитектор|ревьюер|администратор|"
        r"владелец)\b", re.I)),
    ("FORGED_APPROVAL", re.compile(
        r"\b(?:reviewer|architect|owner|host|ревьюер|архитектор|владелец)\b"
        r".{0,50}\b(?:approved|authorized|granted|одобрил|разрешил|подтвердил)\b"
        r".{0,55}\b(?:proceed|execute|run|merge|deploy|skip|выполняй|"
        r"запускай|пропусти|делай)\b", re.I)),
    ("PRIVILEGED_EXECUTION", re.compile(
        r"^(?:(?:please|now|immediately|kindly)\s+|"
        r"(?:you\s+(?:must|should|can|need\s+to))\s+|"
        r"(?:нужно|надо|срочно|пожалуйста)\s+)?"
        r"(?:run|execute|invoke|call|start|launch|use|запусти|выполни|"
        r"вызови|используй)\s+(?:(?:the|a|команду)\s+)?"
        r"(?:shell|powershell|pwsh|cmd|bash|terminal|"
        r"(?:[a-z][a-z0-9_-]*[._-])*(?:run[_-]script|run[_-]command)(?![a-z0-9_-])|"
        r"docker|sudo|python(?:3)?(?:\s+-c|\s+[^\s]+\.py\b)|"
        r"py(?:\s+-c|\s+[^\s]+\.py\b)|rm\s+-rf|"
        r"скрипт|терминал|оболочку|командную\s+строку)\b", re.I)),
    ("GIT_MUTATION", re.compile(
        r"^(?:(?:please|now|you\s+must|you\s+should|пожалуйста|срочно)\s+)?"
        r"(?:(?:run|execute)\s+git\s+(?:push|commit|reset|clean)|(?:run|execute)\s+git\s+-C\s+\S+\s+(?:push|commit|reset|clean)|git\s+-C\s+\S+\s+(?:push|commit|reset|clean)|git\s+(?:push|commit|reset|clean)|force\s+push|"
        r"push\s+(?:to|the|this)|merge\s+(?:into|to)|"
        r"запушь|отправь\s+в\s+main|сделай\s+push)\b", re.I)),
    ("DESTRUCTIVE_ACTION", re.compile(
        r"^(?:(?:please|now|you\s+must|пожалуйста|срочно)\s+)?"
        r"(?:delete|remove|erase|wipe|destroy|удали|сотри|уничтожь|очисти)\b"
        r".{0,65}\b(?:files?|folders?|directories|repository|repo|database|"
        r"logs?|файлы|файл|папку|папки|репозиторий|базу|логи)\b", re.I)),
    ("SCOPE_OVERRIDE", re.compile(
        r"\b(?:write|edit|modify|read|access|change|"
        r"запиши|измени|прочитай|открой)\b.{0,65}"
        r"\b(?:outside|beyond|without|вне|за\s+пределами|мимо)\b"
        r".{0,35}\b(?:sandbox|scope|workspace|project|песочниц|области|"
        r"проекта|каталога)\b", re.I)),
    ("PRIVILEGE_ESCALATION", re.compile(
        r"\b(?:grant|give|enable|allow|elevate|разреши|дай|выдай|включи)\b"
        r".{0,50}\b(?:admin|root|privileges?|permissions?|"
        r"unrestricted|доступ|права|привилегии|админ)\b", re.I)),
    ("DESTRUCTIVE_ACTION", re.compile(
        r"^(?:rm\s+-rf\b|del\s+/s\b|rmdir\s+/s\b)", re.I)),
    ("SECRET_EXFILTRATION", re.compile(
        r"^(?:(?:please|now|you\s+must|пожалуйста)\s+)?"
        r"(?:send|upload|publish|leak|reveal|отправь|выложи|раскрой)\b"
        r".{0,55}\b(?:api\s*keys?|tokens?|passwords?|credentials?|secrets?|"
        r"пароли|токены|секреты|ключи)\b", re.I)),
    ("QA_BYPASS", re.compile(
        r"\b(?:skip|bypass|ignore|disable|пропусти|обойди|отключи|игнорируй)\b"
        r".{0,45}\b(?:tests?|review|approval|qa|checks?|"
        r"тесты|тестирование|ревью|проверку|согласование)\b", re.I)),
)

def _result(decision: str, reasons: list[str], byte_count: int) -> dict[str, Any]:
    return {
        "decision": decision,
        "reason_codes": sorted(set(reasons))[:MAX_REASONS],
        "input_bytes": byte_count,
        "trusted_input": False,
        "host_enforcement": False,
        "grants_authority": False,
    }

def classify_untrusted_text(text: str | bytes) -> dict[str, Any]:
    """Return advisory DENY/REVIEW; never execute, authorize or echo input.

    A REVIEW result is *not* an approval: all tool calls require independent
    host-side policy. This conservative heuristic can miss paraphrases.
    """
    if type(text) not in (str, bytes):
        return _result("DENY", ["INVALID_INPUT_TYPE"], 0)
    if isinstance(text, bytes):
        size = len(text)
        if size > MAX_INPUT_BYTES:
            return _result("DENY", ["INPUT_TOO_LARGE"], size)
        try:
            decoded = text.decode("utf-8", "strict")
        except UnicodeDecodeError:
            return _result("DENY", ["INVALID_UTF8"], size)
    else:
        try:
            raw = text.encode("utf-8", "strict")
        except UnicodeEncodeError:
            return _result("DENY", ["INVALID_UNICODE"], 0)
        size = len(raw)
        if size > MAX_INPUT_BYTES:
            return _result("DENY", ["INPUT_TOO_LARGE"], size)
        decoded = text
    if any(ord(c) < 32 and c not in "\n\r\t" for c in decoded):
        return _result("DENY", ["INVALID_CONTROL"], size)
    if decoded.count("\n") + decoded.count("\r") + 1 > MAX_LINES:
        return _result("DENY", ["TOO_MANY_LINES"], size)
    normalized = unicodedata.normalize("NFKC", decoded).casefold()
    normalized = "".join(c for c in normalized if unicodedata.category(c) != "Cf")
    reasons: list[str] = []
    for clause in _CLAUSE_SPLIT.split(normalized):
        clause = clause.strip(" \t\"'\\`>*-•")
        if not clause:
            continue
        # A plain prohibition is documentation, not a request for privilege.
        # Splitting on adversarial contrast clauses preserves later commands.
        if _NEGATED.match(clause) or _NEGATED_END.search(clause):
            continue
        for code, pattern in _PATTERNS:
            if pattern.search(clause):
                reasons.append(code)
    return _result("DENY" if reasons else "REVIEW",
                   reasons if reasons else ["UNTRUSTED_TEXT_REQUIRES_HOST_POLICY"],
                   size)

__all__ = ["classify_untrusted_text", "MAX_INPUT_BYTES", "MAX_LINES"]
