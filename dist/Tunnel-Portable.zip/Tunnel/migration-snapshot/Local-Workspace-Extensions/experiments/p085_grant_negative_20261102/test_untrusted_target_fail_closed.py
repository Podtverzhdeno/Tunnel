"""Independent negative witness for P085 grant target type confusion.

Synthetic HMAC key, synthetic in-memory target and no side effects.
This test does not issue credentials or act on coordinator review state.
"""
import hashlib
import hmac
import sys
from dataclasses import replace
from pathlib import Path
import unittest

HOST = Path(__file__).resolve().parents[2] / "mcp-host-source"
sys.path.insert(0, str(HOST))
from workspace_mcp.review_grants import (
    AUDIENCE, ISSUER, SCHEMA, GrantDenied, ReviewTarget, canonical, verify,
)

KEY = b"offline-test-only-p085-hmac-key-not-production"
NOW = 1793600000
SHA = "a" * 64
BUNDLE = "b" * 64
ACTOR = "owner:reviewer"


def envelope():
    payload = {
        "schema": SCHEMA, "issuer": ISSUER, "audience": AUDIENCE,
        "nonce": "c" * 32, "actor_id": ACTOR, "workspace": "projects",
        "task_id": "P152", "action": "accept", "revision": 4,
        "spec_sha256": SHA, "source_bundle_sha256": BUNDLE,
        "issued_at": NOW - 5, "expires_at": NOW + 30,
    }
    return {"payload": payload, "mac": hmac.new(KEY, canonical(payload), hashlib.sha256).hexdigest()}


def target():
    return ReviewTarget("projects", "P152", 4, SHA, BUNDLE, True, False, "user:dev2")


class TargetTrustTests(unittest.TestCase):
    def test_valid_control(self):
        result = verify(envelope(), KEY, authenticated_actor=ACTOR, target=target(), now=NOW)
        self.assertEqual(result["action"], "accept")

    def test_non_boolean_lease_active_must_fail_closed(self):
        for bad in (1, "true", ["true"], {"value": True}):
            with self.subTest(bad=repr(bad)):
                with self.assertRaises(GrantDenied):
                    verify(envelope(), KEY, authenticated_actor=ACTOR,
                           target=replace(target(), review_lease_active=bad), now=NOW)

    def test_non_boolean_merge_pending_must_fail_closed(self):
        for bad in (0, "", None, [], {}):
            with self.subTest(bad=repr(bad)):
                with self.assertRaises(GrantDenied):
                    verify(envelope(), KEY, authenticated_actor=ACTOR,
                           target=replace(target(), merge_intent_pending=bad), now=NOW)

    def test_non_integer_revision_must_fail_closed(self):
        with self.assertRaises(GrantDenied):
            verify(envelope(), KEY, authenticated_actor=ACTOR,
                   target=replace(target(), revision=4.0), now=NOW)

    def test_missing_author_actor_must_fail_closed(self):
        for bad in (None, "", [], {}):
            with self.subTest(bad=repr(bad)):
                with self.assertRaises(GrantDenied):
                    verify(envelope(), KEY, authenticated_actor=ACTOR,
                           target=replace(target(), author_actor_id=bad), now=NOW)


if __name__ == "__main__":
    unittest.main()
