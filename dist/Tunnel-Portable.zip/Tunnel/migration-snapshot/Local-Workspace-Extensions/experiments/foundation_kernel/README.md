# Foundation kernel — reference technology for resilient agent execution

**Status: isolated experimental implementation, 2026-11-02.** Not wired into
live `agent_team.py`, its SQLite state, the scheduled five-agent system,
the PressBuilder renderer or the actual MCP host. No owner approval for a
canonical rollout is implied. This module never executes agent code, calls an
LLM, grants permissions, accepts a PR, or retries external effects.

## Fundamental primitives implemented

| Technology | Module | Invariant |
|---|---|---|
| Deterministic event protocol | `transition.py` | Only whitelisted step transitions; malformed epochs and evidence hashes are rejected |
| Persistent transaction journal | `journal.py` | SQLite WAL/FULL; `BEGIN IMMEDIATE` and unique per-run request IDs |
| Lease generation fencing | `transition.py` | A released lease may only be re-acquired at a strictly greater epoch; a stale epoch cannot append |
| Crash/unknown-effect recovery | `journal.py` | An `INTENT` has **uncertain effects**, and neither a crash nor timeout authorizes replay |
| Hash chain + deterministic replay | `journal.py` | All events for one run are replayed and checked against hashes and cached state **before** new events |
| Immutable evidence store | `evidence_store.py` | Content-addressed bounded JSON; create-only, bytewise verification, no silent repair |
| End-to-end evidence crosswalk | `replay_audit.py` | Every `RESULT`, `RECONCILED_RESULT`, `QA_OBSERVED` receipt resolves to actual content whose `source_sha` matches the step's `PLAN` digest |

### Execution states

```text
NEW --PLAN(spec_sha)--> PLANNED --LEASE(epoch=n)--> LEASED
                               ^                      |
                               |--- RELEASE (safe) ----|
                               |
                               +-- CANCEL --> CANCELLED

LEASED --INTENT (write BEFORE side effect)--> UNCERTAIN
UNCERTAIN --RESULT(receipt_sha)--> RESULT_DOCUMENTED
UNCERTAIN --RECONCILIATION--> RECONCILIATION_REQUIRED
RECONCILIATION_REQUIRED --RECONCILED_RESULT(receipt_sha)--> RESULT_DOCUMENTED
RESULT_DOCUMENTED --QA_OBSERVED(report_sha)--> QA_OBSERVED
```

The protocol deliberately has no `ACCEPTED` or `DEPLOYED` event:
the only authoritative acceptance decision must remain with the independent
reviewer and a **host-enforced** actor/permission boundary. A `lease_epoch`
is only a consistency fence here, **not cryptographically verified authority**.

### Safety and failure semantics

1. A repeated `request_id` with the exact same event returns the original
   record; reuse with different arguments fails `IDEMPOTENCY_CONFLICT`.
2. A crash after `INTENT` means `RECONCILE_EXTERNAL_SIDE_EFFECT_BEFORE_RETRY`,
   **not** immediate re-execution. The correct external action depends on a
   trusted tool/worker's real-world idempotency and receipt protocol.
3. A receipt's SHA-256 only proves consistency **with local bytes**, not who
   wrote it, whether the outside action happened or whether a reviewer approved
   it. Cryptographic receipts and an isolated signed-command gate
   are implemented elsewhere in this experimental folder, but **live host
   identity, enforced permissions, and independent effect attestation are not**.
4. Append is transactional and checks the previous run history via bounded
   replay. A failure/inconsistency aborts, without modifying the real queue.
   History verification costs O(N) per append; this is **not yet** a scalable
   production event store for arbitrarily large runs.
5. All events use fixed JSON contracts, UUID-like bounded string IDs,
   epoch fencing, and short structured payloads. Secret-like keys are rejected
   but arbitrary free-form values cannot be guaranteed redacted.
6. Evidence documents are limited to 128 KiB; a partial/modified existing
   file is rejected, not overwritten. SQLite event runs are bounded by 10,000
   verified records; larger runs need an external anchored checkpoint design.
7. The SQLite file name must be `execution_journal_<slug>.sqlite3` within an
   explicitly selected local directory. The evidence store uses its own
   `evidence_immutable/` directory. Use a dedicated fixture or isolated
   sandbox, **never the active coordinator database**.
8. Hash chaining is not cryptographic nonrepudiation: a local attacker with
   write rights can replace both history and hashes. A signed/anchored ledger
   is a separate host-identity security milestone.

## Running tests

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\foundation_kernel
python -m unittest discover -v
```

All tests operate in temporary directories. They cover restart, racing
acquires, duplicate requests, forged claims, malformed data, hash tampering,
path traversal, evidence-source mismatch and missing/changed receipts.

### Non-normative usage example (isolated temp directory)

```python
from tempfile import TemporaryDirectory
from journal import Journal
from evidence_store import EvidenceStore
from replay_audit import audit_run

spec = "a" * 64
with TemporaryDirectory() as root:
    with Journal(root, "execution_journal_demo.sqlite3") as journal:
        store = EvidenceStore(root)
        journal.append("run-1", "scene-1", "q1", "PLAN", 0, spec)
        journal.append("run-1", "scene-1", "q2", "LEASE", 1)
        journal.append("run-1", "scene-1", "q3", "INTENT", 1)
        evidence = store.put("worker_receipt", spec, {"observation": "demo"})
        journal.append("run-1", "scene-1", "q4", "RESULT", 1,
                       evidence["sha256"])
        print(audit_run(journal, store, "run-1"))
```

This is a **local fixture**, not proof of any real worker execution.

## Durable outbox/inbox and delivery reconciliation (2026-11-02)

New experiment-only modules:

- `durable_mailbox.py` — SQLite transactional outbox/inbox with per-message
  payload SHA-256, unique request-ID idempotency, attempt-epoch fencing,
  bounded queues and a durable record of uncertain send/process operations.
  `BEGIN IMMEDIATE` is used for each mutation, and request outcomes are
  persisted in the same SQLite transaction as the associated state change.
- `mailbox_audit.py` — **read-only** consistency validation across the
  existing `Journal`, sender mailbox, receiver mailbox and `EvidenceStore`.
  It checks that a send has a matching earlier journal `INTENT` referencing
  the exact message ID, payload digest and epoch; validates received payload
  SHA and the local provenance binding for reported ACK/worker receipts.
- `test_durable_mailbox.py`, `test_mailbox_audit.py` — negative/restart,
  concurrency, replay, digest-drift and injected SQLite-failure tests.

The outbox state machine is:

```text
STAGED --begin_send() committed BEFORE network request--> SEND_UNCERTAIN
SEND_UNCERTAIN --report_ack(untrusted_local_receipt)--> ACK_REPORTED
```

The inbox state machine is:

```text
RECEIVED --begin_processing() committed BEFORE effect--> PROCESS_UNCERTAIN
PROCESS_UNCERTAIN --report_result(untrusted_local_receipt)--> RESULT_REPORTED
```

`SEND_UNCERTAIN` and `PROCESS_UNCERTAIN` **never** automatically return to
their previous state, even after a crash, timeout, missed message or expired
lease. The only retry candidate is work that has never crossed the durable
uncertainty boundary; the actual trusted dispatcher must establish this fact.
A repeated request with the same ID returns the original stored response;
an ID reused with changed arguments fails. Inbox duplicate arrivals with an
identical payload are recorded as duplicates without rerunning any effect.
Conflicting payloads, stale epochs and second send/process attempts fail closed.

**Backpressure:** at most 10,000 rows per inbox/outbox, 50,000 recorded
requests, 1,000 rows per status snapshot and 500 send records per correlated
audit (smaller audit limits allowed). At the quota boundary all *new*
operations fail closed; idempotent replays and existing-message lookups can
still succeed when their corresponding storage limits allow. Retention and
compaction with externally anchored checkpoints are NOT implemented.

**Critical safety limitations:**

- None of these modules actually invoke a network transport, worker, model,
  filesystem mutation or operating-system command. Their `begin_send` and
  `begin_processing` methods only persist **pre-effect intent**.
- Local SQLite stores do **not** share a single atomic transaction with each
  other or with the `Journal`. A crash between writing journal `INTENT`
  and outbox `SEND_UNCERTAIN` can create a mismatch, detected by the
  read-only audit. **Do not resolve this by guessing a retry.** A future
  production design should co-locate journal and outbox intent in one
  transaction or use a verified saga reconciliation protocol.
- `report_ack` and `report_result` accept a local SHA pointer, not a
  trusted cryptographic signature. `ACK_REPORTED` and
  `RESULT_REPORTED` are **not delivered/accepted/executed proof**.
  Cross-store matching is subject to TOCTOU, and a locally fabricated
  evidence file cannot establish worker authenticity or owner approval.
- `request_id` is an idempotency key, NOT an authenticated actor identity;
  `epoch` is local consistency fencing, NOT an externally enforced lease.
  This code MUST NOT be exposed as mutating MCP tools.
- The outbox request ledger is durable but not independently signed;
  database-write-capable attackers can alter its state. Do not treat local
  evidence consistency or SQL WAL durability as Byzantine fault tolerance.

Demo-only snippet from `experiments/foundation_kernel` (isolated database):

```python
from tempfile import TemporaryDirectory
from durable_mailbox import DurableMailbox

with TemporaryDirectory() as root:
    with DurableMailbox(root) as box:
        spec_payload_hash = "b" * 64
        box.stage("request-1","message-1","run-1","scene-1",
                  "worker-1",spec_payload_hash)
        box.begin_send("request-2","message-1","attempt-1",epoch=1)
        print(box.snapshot())   # SEND_UNCERTAIN; no network request was sent
```

Deployment to scheduled agents remains **pending normative approval,
host actor authentication and independent reviewer acceptance**.

## Atomic journal INTENT + outbox (single SQLite transaction)

**Implemented in the isolated reference kernel:** `atomic_dispatch.py`,
with `test_atomic_dispatch.py` regression and real process-crash tests.
Unlike the earlier cross-database `durable_mailbox.py` demonstration,
this component shares **one SQLite connection and one database** with
`journal.py`, including a single `BEGIN IMMEDIATE ... COMMIT` boundary.

```text
Journal PLAN + LEASE (already committed by a separate authorized actor)
                │
                ▼
AtomicDispatch.stage_intent(...)
 ┌────────────── ONE SQLite transaction ────────────────────┐
 │ 1. Replay/verify existing run and bidirectional link audit│
 │ 2. Append journal INTENT via Journal._append_locked(...)  │
 │ 3. Insert atomic_outbox(message_id, event_id, SHA, epoch) │
 │ 4. COMMIT both rows together, or ROLLBACK both            │
 └───────────────────────────────────────────────────────────┘
                │
                ▼
AtomicDispatch.mark_send_uncertain(...)
   - persists pre-send ambiguity, no actual network send
   - strictly one-way phase, checks exact epoch and audit
   - refuses a second attempt or automatic retry
```

**Guarantees actually checked:** both inserts commit or both roll back;
a SQLite trigger failure at either insert cannot leave half an intent;
a hard `os._exit(73)` in a disposable child process after the journal
INSERT but before outbox INSERT restores the original two-event journal;
`os._exit(77)` after COMMIT but before an API response permits a
bit-for-bit idempotent replay. Concurrent attempts with the same request
converge on one record; different intents for the same step do not
both succeed. All checks operate in temporary SQLite fixtures only.

`Journal.append` was refactored to preserve its original single-event
transaction interface while introducing internal
`Journal._append_locked`, which *requires* an already-open SQLite
transaction and does NOT commit. It is not an authenticated entrypoint.

### Exact limits and boundaries

- `INTENT_STAGED` is a **persisted planned intent**, not a network
  delivery. `SEND_UNCERTAIN` means the transport may be called by a
  future host-authenticated dispatcher, so no retry is authorized from
  that state. Neither method invokes external side effects.
- Single-database atomicity is now guaranteed **only for the stage
  operation within this prototype**. Live agent queue, hosted MCP,
  external worker, and receiver inbox still use other data stores.
  There is no distributed exactly-once claim.
- A hash-chained local record is not a signature; local write access can
  rewrite both bytes and digests. Actual peer identity, grants, and
  independent reviewer acceptance remain outside this prototype.
- Staging verifies the full existing journal and all atomic links
  for its run before writing. Runs with more than 500 atomic messages
  fail closed during preflight; the global reference storage cap is
  10,000 outbox rows. This O(N) replay per stage needs checkpoint-based
  compaction before production scaling.
- `AtomicDispatch.audit_run` gives `can_publish=false`, even when all
  hashes match. No execution, production installation, transport
  activation, live SQLite editing, scheduler changes or owner approval
  is performed.

### Test-only example

```python
from tempfile import TemporaryDirectory
from journal import Journal
from atomic_dispatch import AtomicDispatch

with TemporaryDirectory() as root:
    with Journal(root, "execution_journal_demo.sqlite3") as journal:
        journal.append("run-1","step-1","plan-1","PLAN",0,"a"*64)
        journal.append("run-1","step-1","lease-1","LEASE",1)
        dispatcher=AtomicDispatch(journal)
        print(dispatcher.stage_intent(
            "run-1","step-1","request-1","message-1",
            "worker-1","b"*64,1
        ))
        print(dispatcher.audit_run("run-1"))
```

**Production prerequisites:** canonical owner-reviewed OpenSpec/SDD,
separate authenticated actor credentials, enforcement of existing
host lease tokens, transport idempotency contract, verified ACK/result
receipts, independent worker review and a staged canary rollout.

## Signed worker receipts and durable anti-replay (experimental)

The Ed25519 proof-of-possession contract now has three components:

- `signed_receipts.py` validates an exact canonical JSON envelope against a
  **pre-pinned public key grant**, refusing unknown/revoked keys, unauthorized
  worker/role/scope/kind, future/expired receipts, duplicate keys, and invalid
  signatures. The signed payload binds `run_id`, `step_id`,
  `request_id`, `input_sha`, `source_sha`, `evidence_sha`, `epoch`
  and an expiry. No signing or private-key storage API exists in production.
- `receipt_ledger.py` uses a standalone SQLite WAL/FULL database to record
  only signature-verified, content-addressed local evidence claims with
  unique receipt IDs and unique `(run_id, step_id, kind, epoch)` tuples.
  Replays of identical receipts are idempotent; mutated replays, conflicting
  parallel writers and expired/revoked signatures are rejected.
- `worker_attestation.py` cross-checks a worker's signed receipt **against
  trusted local state**, deriving the expected source SHA from the journal
  `PLAN` event and input digest, message destination, epoch, request ID
  from `atomic_outbox`. A locally valid signature from a different job
  cannot be substituted. Only `SEND_UNCERTAIN` outbox entries are eligible
  for correlation, not staged-but-unsent intents.

The crypto backend is the existing external `cryptography` library
(Ed25519); **no home-grown signature implementation** and no dependency
installation is performed. Tests generate ephemeral Ed25519 keypairs in
memory. The host must deliver production public key grants from a separate
authenticated trust authority. A key supplied by an untrusted agent is
not a trust anchor and cannot grant permissions. The `now` argument must
also be supplied by a trusted host clock, not the worker.

The receipt is an **attestation claim signed by a locally trusted key**,
not proof the worker did the work: timestamps, key possession and signed
hashes do not independently prove effects, licensing, reviewer acceptance
or deployment readiness. All successful responses explicitly set
`external_effect_verified=false`, `host_permission_enforced=false`,
`can_accept_or_deploy=false`. The receipt and outbox are on **different
SQLite connections**, so verification plus ledger admission is subject to
TOCTOU and does not provide atomic cross-database acceptance. Production
requires a trusted host-side enforcement boundary, durable ingress
authentication, public-key lifecycle/revocation distribution, independently
verified worker receipts, and a separate reviewer acceptance decision.

Tests: `test_signed_receipts.py`, `test_receipt_ledger.py` and
`test_worker_attestation.py`, run under `python -m unittest discover`
from `experiments/foundation_kernel`.

## Signed host command authorization and capability gate (experimental)

New isolated components:

- `host_auth.py` — Ed25519 verification for a **distinct, domain-separated**
  command schema, pinned `HostGrant` / `HostPolicy`, fixed principal +
  role + project scope + run/step + lease epoch, exact action/argument hash,
  policy revision, 32-character nonce and a 90-second maximum signing window.
  Unknown, revoked, incorrectly scoped or wrong-role keys are denied.
  The `HostPolicy` lookup is immutable from the point of construction.
- `host_gate.py` — a **reference protected entrypoint** exposing exactly
  `STAGE_INTENT` and `MARK_SEND_UNCERTAIN`. The signed request is validated
  before opening a SQLite transaction. The nonce+request ID replay claim,
  journal INTENT and atomic outbox update commit **together** under
  `BEGIN IMMEDIATE`. Errors roll back every row.
- `test_host_gate.py` — signatures, role escalation, revocation, grant
  version, cross-project replay, invalid arguments, nonce/request reuse,
  grant separation, contention and SQL trigger failure-injection. Actual
  **disposable child-process crashes** are injected before and after COMMIT,
  verifying rollback before and durable replay-denial after.
- `test_host_e2e.py` — an isolated three-actor contract: signed developer
  intent → separately signed dispatcher pre-send fence → signed worker
  receipt bound to source/input digest via `worker_attestation.py`.
  It never sends messages or performs a worker's side effect.

Security invariants and non-goals:

1. **Host-issued authority only.** A client may provide a signed
   `principal_id`, `role`, and `key_id`, but the verifier accepts them
   only if the signature matches a **pre-pinned** public key whose grant
   contains exactly that role, run, step, scope, lease epoch, policy revision,
   and capability. A self-generated key is not trusted.
2. **Nonces never replay.** Reusing the same `request_id` or a
   `(key_id, nonce)` pair is denied, even after process restart. This differs
   from the underlying idempotent outbox operation deliberately: replay of
   signed *privilege* cannot accidentally re-execute it. Read-only
   reconciliation must be used after a lost response.
3. **Three-row transaction.** Authorization claim, journal INTENT and outbox
   message either all commit or all roll back. For
   `MARK_SEND_UNCERTAIN`, authorization and the outbox state transition
   share the same transaction. A failure never burns an auth nonce while
   leaving a partially staged action.
4. **No powerful tool dispatch.** There is no `execute`, `git_push`,
   `shell`, `accept_review`, `merge` or `deploy` action, even for
   a key whose claimed role is `architect-reviewer`.
5. **Trusted clock and policy required.** The caller of the reference
   gateway supplies the trusted wall-clock time and grant set out of band.
   A production host must protect both and recheck policy revocation
   consistently across workers. Keys are created only in memory in
   offline tests, never saved to a workspace file.
6. **Not production host enforcement.** The running Local Workspace MCP
   transport and its general `run_script` / `run_command` tools do not
   pass through this gate. Local Python code can still call
   `AtomicDispatch` directly; modules in one Python interpreter cannot
   form a security boundary against an attacker with arbitrary code
   execution. Production host enforcement requires an isolated broker
   process, a restricted MCP tool registry and all mutating paths routed
   exclusively through the broker, with no privileged bypass.
7. **Not real-world attestations.** `SEND_UNCERTAIN` remains ambiguous,
   and a signed worker receipt is still a claim. Signature success neither
   proves side effects nor grants reviewer acceptance or release permission.
   Host lease tokens, authenticated transport connections, lifecycle-managed
   grants and external-effect reconciliation remain pending.

Quick focused tests:

```powershell
cd C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions\\experiments\\foundation_kernel
python -m unittest test_host_gate test_host_e2e -q
```

This is an isolated implementation milestone, **not a canonical OpenSpec
implementation or an owner-approved deployment to five scheduled agents**.

## Standalone broker + MCP boundary test harness (not live)

The previous in-process `HostDispatchGate` now has a real
**out-of-process test transport**:

- `broker_stdio.py` — bounded JSONL stdio service. It loads an exact
  SHA-256-pinned public-key grant policy, then owns a test-specific SQLite
  journal/outbox/auth gate. It exposes only health, signed stage-intent
  and signed pre-send fencing. It never makes a network call, executes shell,
  Git, deployment, review acceptance or owner approval.
- `broker_mcp_bridge.py` — standalone MCP stdio JSON-RPC frontend that
  exposes **only three MCP tools**, invokes the broker in a child process
  without a shell, and passes through errors without privilege escalation.
  This file is NOT registered in the connected Local Workspace App.
- `test_broker_stdio.py` and `test_broker_mcp_bridge.py` — end-to-end
  tests of child-process restarts, persistent nonce replay defense,
  independent developer/dispatcher grants, policy pinning/revocation,
  malicious JSON, frame limits and MCP tools/list/tools/call behavior.

See [BROKER_BOUNDARY.md](BROKER_BOUNDARY.md) for a strict threat model
and explicit **production-blocking requirements**, especially OS-level
broker identity, protection from the existing unrestricted Local Workspace
script/command tools and a dedicated owner-approved MCP canary profile.

**A subprocess launched under the same Windows user is not, by itself, a
security boundary**. Until a separate restricted OS identity, trusted key
distribution and real MCP host registry enforcement are implemented,
this remains an isolated architectural proof, not live host enforcement.

## Issuer-signed policies, anti-rollback and Windows preflight

Two additional **read-only or offline** security milestones have been
implemented without changing the installed MCP host:

- `signed_policy.py`: Ed25519 issuer signature over a domain-separated
  grant-policy manifest, exact SHA-256 of the public grant file,
  30-day maximum signing lifetime, strict numeric `revision`, and
  strict `issued_utc`/`expires_utc`. Unknown/altered/expired policy
  fails closed. `SignedPolicyFloor` persists the highest revision and
  issuer public key hash **in the broker's existing SQLite journal**.
  Lower revisions, different issuers and conflicting same-revision
  policy hashes are blocked. `HostDispatchGate` checks the current
  floor and policy expiry in the same SQLite transaction as signed
  commands and outbox mutations.
- `windows_isolation.py`: read-only Win32 token SID and ACL inspection.
  `broker_os_preflight.py` checks expected distinct broker/agent SIDs,
  protected state/policy/code file ownership and write ACEs, including
  parent directories. Unsupported ACL forms fail closed. It does **not**
  modify ACLs, create Windows accounts, alter the user's server,
  remove privileges from the currently connected MCP, or authenticate
  the stdio parent. The current same-SID environment is **not
  production-isolated**. The preflight always returns
  `ready_for_production=false` even if filesystem checks pass.

`broker_stdio.py` and `broker_mcp_bridge.py` now default to the
**issuer-signed policy** mode; the earlier `--expected-policy-sha256`
alone is insufficient to start the broker. The explicit
`--legacy-unsigned-policy-for-tests` flag exists **only for disposable
legacy test fixtures**. This option is not a secure production mode.
Production still needs OS-protected provisioning of the issuer public
key, separate broker account, independently authenticated IPC parent
and a restricted actual MCP registry. A separately supplied issuer
public key on the CLI alone is *not* proof of a trusted root.

Tests: `test_signed_policy.py`, `test_windows_isolation.py`; no
key material is persisted except ephemeral **public** test grants.
See [BROKER_BOUNDARY.md](BROKER_BOUNDARY.md) for mandatory deployment gates.

## Signed command reconciliation after lost responses

`broker_reconcile.py` implements a **read-only**, Ed25519-authorized
`QUERY_COMMAND_STATUS` capability. The standalone broker exposes it
as `query_command_status`, and the isolated MCP adapter exposes
`broker_query_command_status`. A query names the original
`target_request_id` and `message_id`, while carrying a separate
signed `request_id` and verified principal / scope / step / epoch.

- The query uses a consistent local SQLite read transaction and performs
  a journal + atomic outbox integrity audit. It can confirm that the
  signed stage command has a durable claim and a matching outbox intent,
  or that a signed pre-send fence is recorded for that message.
- The host gate now persists `host_gate_command_targets` as part of
  the **same transaction** as the auth nonce claim and the state
  transition. This table records exact action ↔ message linkage for
  both mutation kinds; failures roll back the journal, outbox and all
  auth records together. Old records that lack a target binding do
  **not** silently acquire evidence of a verified send: they return
  `MARK_REQUEST_COMMITTED_MESSAGE_LINK_UNVERIFIED`.
- `NO_DURABLE_CLAIM_FOUND` is deliberately **not** interpreted as
  safe-to-retry. A lost response, timeout or crash may have unknown
  external effects, so every query returns
  `automatic_retry_permitted=false`, `external_effect_verified=false`
  and never marks a task accepted/deployed. Query nonces are not
  persisted because queries do not change state. The host must apply
  request-rate limits independently.
- A correctly signed query for another principal's committed request
  fails closed. An unknown claim only returns a conservative absence
  under that principal's pre-provisioned run/step capability. Revoked,
  expired or wrong-epoch credentials are denied by the normal host
  signature/policy checker.
- Stage and mark queries report the outbox **phase** as local
  information; `SEND_UNCERTAIN` never proves network delivery or
  successful worker execution. An audit cannot protect against
  same-user direct SQLite rewriting or malicious replacement of the
  broker binary.

Tests: `test_broker_reconcile.py` plus additional cross-process
tests in `test_broker_stdio.py`, `test_broker_mcp_bridge.py`,
`test_host_gate.py` and policy-expiry tests in
`test_signed_policy.py`. Neither the currently connected MCP host
nor the live five-agent task queue has been changed.

## Windows named-pipe broker with mutual OS token checks (isolated)

**Implemented in the current authorized workspace, not in live MCP:**

- `win_pipe_ipc.py` — native Win32 `CreateNamedPipeW` with an explicit
  protected DACL (SYSTEM, broker SID, one client SID; **no** Everyone,
  Administrators or default named-pipe DACL); 
  `FILE_FLAG_FIRST_PIPE_INSTANCE` to reject simultaneous name owners,
  `PIPE_REJECT_REMOTE_CLIENTS`, message-mode framing (16 KiB max).
  Before calling any application handler, the server reads a bounded
  message, calls `ImpersonateNamedPipeClient`, obtains the **actual thread
  token SID** using `OpenThreadToken`/`GetTokenInformation`, then
  immediately `RevertToSelf`. A mismatch or failed impersonation
  **denies the request**; failure to revert terminates the process.
- The client now verifies the **real server process SID before sending**
  using `GetNamedPipeServerProcessId` →
  `OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION)` →
  `OpenProcessToken(TOKEN_QUERY)` → `GetTokenInformation(TokenUser)`.
  `expected_server_sid` is mandatory and must be pinned by the trusted
  launcher, not copied from agent text. The server must independently
  check that its own process SID matches the pinned `broker_sid`.
- `broker_named_pipe.py` combines this transport with the issuer-signed
  policy, monotonic policy floor, host command signatures, journal and
  atomic outbox. **Secure mode is the default:** it denies same-SID
  broker/agent configuration and requires a conservative read-only Windows
  ACL inspection of the code, policy, bundle, journal and their directories
  before serving. The explicit `--offline-same-sid-fixture` switch is
  reserved for disposable test directories and reports no OS isolation.
  No Windows account, ACL, service or connected MCP registration is created.
- `broker_pipe_mcp_bridge.py` reuses the restricted JSON-RPC
  `tools/list`/`tools/call` contract with **exactly four** tools,
  connecting to an already running Windows pipe broker rather than
  launching a new subprocess per request. It has no command/Git/owner
  approval/deploy APIs. The expected broker SID and pipe name still require
  trusted host provisioning.
- `test_win_pipe_ipc.py` and `test_broker_named_pipe.py` exercise
  **real Windows child processes**, real kernel token impersonation,
  token-based server identification, wrong-SID rejection before handler
  invocation, issuer-policy denial, signed request enforcement,
  per-command durable anti-replay, atomic staging, read-only reconciliation,
  and the end-to-end MCP → pipe → broker → SQLite route.

This materially improves over the earlier stdio subprocess-only prototype
but **does not itself establish production OS separation**. The functional
tests deliberately run two processes under the **same account** and assert
that this is `SAME_SID_TEST_ONLY`, not an isolated service. To claim real
OS separation, the owner must separately provision a restricted Windows
service identity, protect ALL relevant code/config/state files from the
agent identity, make the launcher/pinned SID and issuer key immutable to
the agent, and remove broad host MCP script/command capabilities from
that agent. Administrators, same-user code execution, PID/token lifetime
races, denial-of-service by idle pipe clients and host compromise remain
outside the proof. The server handles a bounded number of connections
and currently has no independent per-client watchdog. Signed worker
receipts still do not prove real-world side effects.

Use only disposable fixture tests; do **not** give the live coordinator's
database to `broker_named_pipe.py`:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\foundation_kernel
python -m unittest test_win_pipe_ipc test_broker_named_pipe -v
```

### Bounded native pipe I/O and deterministic timeout recovery

`win_pipe_overlapped.py` now uses **native Windows overlapped I/O**
(`FILE_FLAG_OVERLAPPED`, `CreateEventW`, `WaitForSingleObject`,
`CancelIoEx` and `GetOverlappedResult`) instead of unbounded synchronous
`ConnectNamedPipe`, `ReadFile` and `WriteFile`. The current defaults
are 3,000 ms for server connection, 1,600 ms for server read/write
and 2,500 ms for client response read. Tests may request smaller
strictly bounded server deadlines (100–5,000 ms).

On a timeout, the request is **not** passed to the signed handler.
The outstanding native operation is cancelled and drained before its
memory can be released. If cancellation itself cannot complete, the
dedicated broker process exits with code 124 rather than risking a
use-after-free; a trusted supervisor is still required before production
and the caller must reconcile uncertain effects instead of retrying.

Real Windows regression tests cover an idle client that connects but
never sends bytes, a server with no connecting client, impersonation,
server SID verification, signed commands, nonce replay, broker restart
and MCP → pipe → broker → SQLite. These tests use only disposable
same-SID fixtures and cannot certify OS-level isolation.

See [BROKER_BOUNDARY.md](BROKER_BOUNDARY.md) for production blockers,
[QA_NATIVE_PIPE_2026-11-02.md](QA_NATIVE_PIPE_2026-11-02.md) for historical
snapshot evidence, and [QA_OVERLAPPED_IPC_2026-11-02.md](QA_OVERLAPPED_IPC_2026-11-02.md)
for the subsequent timeout implementation and regression results.

## Durable bounded broker supervisor (isolated development)

`broker_supervisor.py` is a fixed-launcher **prototype** for Windows
`broker_named_pipe.py`. It neither registers with the live MCP server nor
runs scheduled agent code. It adds:

- **Exclusive local single-instance guard:** a Windows `msvcrt.locking`
  file lock, held for the full parent lifetime. The agent account can
  still edit same-account files; only a separate protected Windows
  service identity makes this a true security boundary.
- **Durable restart budget:** `broker_supervisor_attempts.sqlite3` in the
  explicitly selected fixture root, SQLite WAL and synchronous FULL.
  Every attempt is committed as `PENDING` **before** child spawn. The
  final status is committed after exit. An interrupted supervisor leaves
  a budget-consuming pending attempt, never an invisible restart.
  The sliding-window breaker persists across supervisor restarts,
  rejects wall-clock rollback and has a finite append-only capacity.
- **Fixed child entrypoint:** the supervisor can only spawn the adjacent
  `broker_named_pipe.py` via a fixed Python executable and named,
  validated flags. No arbitrary shell, Git, network, file selection by a
  signed worker, generic command dispatcher, or automatic task replay.
  The issuer-signed policy/grants are validated **before spawning**.
  The child repeats its own issuer-policy and host SID checks.
- **Bounded process watchdog:** one native child per listener; timeout
  kills the child and records a conservative failure. Abnormal exit may
  start a fresh listener with bounded exponential cooldown; a security/
  policy startup denial halts. No attempt can resurrect an old request
  or infer external-effect success from an OS exit status.
- **Safe recovery:** after a response loss or crash, a properly authorized
  agent must use signed, read-only `QUERY_COMMAND_STATUS` to inspect the
  journal/outbox, then independently reconcile actual external effects
  before any new action. `SEND_UNCERTAIN` never authorizes retry.
- **Two distinct test layers:** `test_broker_supervisor.py` simulates
  child crashes, budget exhaustion, invalid signing and error denial;
  separate real Windows subprocess tests prove sequential broker listener
  restarts, signed staging, signed read-only reconciliation and durable
  no-replay over Named Pipe.

`--offline-same-sid-fixture` is explicitly **test-only**, not real
Windows isolation. The parent must eventually be installed under a
dedicated protected Windows service account, and the connected agent
MCP tool registry must stop exposing unrestricted script/command tools.
Per-operation watchdogs alone also do not provide a protected service
manager or external-effect attestation. The supervisor itself has a
bounded number of sessions per invocation; it is not a perpetual Windows
service yet.

See [QA_SUPERVISOR_2026-11-02.md](QA_SUPERVISOR_2026-11-02.md)
for reviewed test evidence and remaining production blockers.

## Production integration prerequisites (not performed)

- Obtain a canonical OpenSpec/SDD change and independent review, rather than
  treating this experiment as permission to modify `agent_team.py`.
- Enforce host-side authenticated agent identities, scoped capabilities, and
  independent reviewer authority. Preserve existing lease token fencing.
- Define signed receipts from the actual worker/tool and durable outbox/inbox
  reconciliation; distinguish at-least-once messaging from exactly-once
  effects. Never auto-retry external unknown effects.
- Add retention, compaction with anchored checkpoints, backup/restore,
  cross-process crash-injection at transaction boundaries, and measured
  performance for the realistic five-agent workload.
- Admit integration via normal non-overlapping work items and independent
  tests. No changes to current agent sandboxes or task statuses in this work.
