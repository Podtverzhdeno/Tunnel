# Broker Supervisor — независимый QA-отчёт

**Дата:** 2026-11-02  
**Область:** `Local-Workspace-Extensions/experiments/foundation_kernel/`  
**Статус:** isolated experimental implementation; production release **BLOCKED**.

## Реализовано

1. `broker_supervisor.py`: отдельный Windows supervisor запускает **только** соседний `broker_named_pipe.py` с фиксированными флагами и `shell=False`. Перед запуском проверяет подписанную Ed25519 политику и ожидаемые SID.
2. Неблокирующий Windows file lock `msvcrt.locking` предотвращает одновременное существование двух экземпляров supervisor для одного тестового каталога.
3. `broker_supervisor_attempts.sqlite3`: SQLite WAL/FULL фиксирует `PENDING` до запуска дочернего процесса, затем `FINISHED` с ограниченным кодом статуса. Краш supervisor оставляет попытку `PENDING` и **не** возвращает потраченный слот.
4. Долговечный лимит частоты рестартов: окно времени, максимум попыток, запрет отката часов, лимит аудита, ограниченный cooldown.
5. Watchdog дочернего процесса: ограниченное время ожидания, `kill` при превышении, ограниченный объём stdout; некорректный результат и нарушение безопасности приводят к остановке или явно классифицированной аварии.
6. Для временного сбоя запускается **новый listener**, а не прежняя команда. Никакого `run_script`, Git, deploy, acceptance, повторной отправки или автоматического разрешения внешних эффектов supervisor не выполняет.
7. `broker_named_pipe.py` теперь выдаёт безопасные фиксированные коды ошибок транспорта, чтобы supervisor отличал `PIPE_CONNECT_TIMEOUT` от отказа проверки личности/политики.
8. `test_broker_supervisor.py` использует SQLite в `TemporaryDirectory`, ключи Ed25519 только в памяти, настоящие дочерние Windows-процессы и отдельный путь чистых unit-тестов цикла рестартов.

## Точные SHA-256 исходников

| Файл | SHA-256 |
|---|---|
| `broker_supervisor.py` | `a9c72a289b063c21ff053736269c2e7518a35a2f515e625f5a19491907ec0bf8` |
| `test_broker_supervisor.py` | `52ede0c1f93c883a851c6af4b6e18a1b3a61030cae3b80c83441b287be867692` |
| `broker_named_pipe.py` | `8f594dd4a55d884165cfb7756eccd834e53e1e8fd807e0af52f5e57496168f4b` |

## Фактически выполненные проверки

| Запуск | Наблюдаемый результат | Job ID |
|---|---|---|
| `python -m unittest test_broker_supervisor -q` | 21 tests, **OK**, 1 skipped | `e6a17fd0981a4206b3d76f15fe8a0ac3` |
| `python -m unittest discover -q` из `foundation_kernel` | 362 tests, **OK**, 2 skipped | `23d18573006647e8b021840f9776d0c9` |
| `python -m unittest discover -q` из корня `Local-Workspace-Extensions` | 1323 tests, **OK**, 35 skipped | `79ba3f3f23bb4882ac02aab550a494bb` |
| `python spec_check.py` | **PASS**, 11 capabilities, 99 requirements, 128 scenarios, 58 SDD tasks, 108 OpenSpec tasks | `0325bccaf24f4d499fcf2578be5a0c6e` |
| `python sdd_roadmap_check.py` | **PASS**, 58 roadmap tasks, 116 outputs | `e7ccb74e4d3a40df8f1108528a716799` |

Структурные проверки OpenSpec/SDD не являются подтверждением промышленного внедрения. Тесты не открывают производственную очередь или исходный MCP.

## Обязательная негативная матрица

| Сценарий | Подтверждение |
|---|---|
| Два параллельных supervisor | File lock отклоняет второй |
| Падение Python-процесса (exit 17) | Классификация `CHILD_PROCESS_CRASHED` |
| Падение → новый listener | Повторяется только процесс-приёмник, исходная команда не пересоздаётся |
| Серия падений | SQLite circuit breaker прекращает повторные запуски |
| Краш самого supervisor | `PENDING` остаётся и расходует бюджет |
| Часы идут назад | `SUPERVISOR_CLOCK_ROLLBACK`, fail closed |
| Нарушение политики или SID | Немедленный stop, без цикла рестартов |
| Дочерний процесс завис | Watchdog прекращает процесс |
| Потерян ответ на `STAGE_INTENT` | Следующий listener принимает только отдельный подписанный QUERY, не повторяет INTENT |
| Самоподписанная или изменённая issuer policy | Запуск отклонён |
| Два подписанных последовательных IPC-запроса через рестарт | Сохраняются журнал, nonce и вывод `recorded` без новой мутации |

## Строгая инженерная оценка (9 измерений)

| Измерение | Итог и остаточный риск |
|---|---|
| Security | Подписи, SID, fixed child, same-SID production denial; **один Windows SID в fixture, реальная OS изоляция не доказана** |
| Reliability | Проверены crash, restart, SQLite pending, circuit breaker, watchdog; Windows service recovery и аварийное выключение питания не проверялись |
| Architecture | Supervisor независим от брокера и live MCP, не изменяет протокол агента |
| Scalability | До 12 listener-сессий на запуск и ограниченный бюджет; нет нагрузочной проверки и service orchestration |
| Correctness | 21/21 тест supervisor (1 skipped); полные 362/1323 пройдены с указанными skips |
| Maintainability | Явные error codes, отдельные бюджет и классификация, тестовые hooks не доступны из CLI |
| Performance | Есть ограниченные дедлайны, но нет измерений P95/P99 и долговременной нагрузки |
| Observability | Структурированные безопасные состояния, WAL audit; нет production metric exporter или оповещений |
| Spec traceability | Структурные spec проверки зелёные, но canonical owner-approved release и проверенный host bridge отсутствуют |

## Условия допуска к production

**NO-GO:** отдельная Windows service account с защищёнными ACL к коду/ключам/SQLite, доверенный неизменяемый launcher с закреплённым issuer public key, уменьшение прав текущего MCP, проверка SID между **разными** учётными записями, реальная Windows Service recovery и нагрузочные/аварийные тесты, внешние receipts для эффектов, независимый архитектурный security review и явное согласование владельцем.

**Принцип:** supervisor восстанавливает доступность broker, но не «доделывает» работу агента автоматически после неизвестного внешнего эффекта. Для этого требуется независимая сверка состояния и новая авторизация.
