"""Adversarial unit and actual child-process tests for durable broker supervisor.

No live automation, MCP registry, Windows accounts, ACL edits or network.
Only temp SQLite and ephemeral Ed25519 private keys in Python memory.
"""
from __future__ import annotations
import base64
import hashlib
import json
import os
import secrets
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 backend required") from exc

try:
    from .broker_supervisor import (
        AttemptLedger, SupervisorError, classify, run_fixed_child, run_sessions,
        single_instance, _command,
    )
    from .signed_policy import DOMAIN as POLICY_DOMAIN, SCHEMA as POLICY_SCHEMA
    from .host_auth import DOMAIN as HOST_DOMAIN, SCHEMA as HOST_SCHEMA
    from .broker_stdio import PROTOCOL
    from .transition import canonical
    from .journal import Journal
    from .windows_isolation import current_user_sid
    from .win_pipe_ipc import request_once
except ImportError:
    from broker_supervisor import (
        AttemptLedger,SupervisorError,classify,run_fixed_child,run_sessions,
        single_instance,_command,
    )
    from signed_policy import DOMAIN as POLICY_DOMAIN, SCHEMA as POLICY_SCHEMA
    from host_auth import DOMAIN as HOST_DOMAIN, SCHEMA as HOST_SCHEMA
    from broker_stdio import PROTOCOL
    from transition import canonical
    from journal import Journal
    from windows_isolation import current_user_sid
    from win_pipe_ipc import request_once


class SupervisorBudgetTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.ledger=AttemptLedger(self.root,window_seconds=60,
                                  max_window_attempts=2)
        self.addCleanup(lambda: self.ledger.close())

    def test_budget_is_persistent_across_restart(self):
        one=self.ledger.acquire(1000)
        self.ledger.finish(one,"CHILD_PROCESS_CRASHED",9)
        two=self.ledger.acquire(1001)
        self.ledger.finish(two,"CLEAN_SESSION",0)
        self.ledger.close()
        self.ledger=AttemptLedger(self.root,window_seconds=60,
                                  max_window_attempts=2)
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_CIRCUIT_OPEN"):
            self.ledger.acquire(1002)
        # Expired window is allowed; audit history is still append-only.
        third=self.ledger.acquire(1061)
        self.ledger.finish(third,"CLEAN_SESSION",0)
        self.assertEqual(self.ledger.report()["attempts"],3)

    def test_pending_attempt_from_crash_still_consumes_budget(self):
        pending=self.ledger.acquire(2000)
        self.ledger.close()
        self.ledger=AttemptLedger(self.root,window_seconds=60,
                                  max_window_attempts=1)
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_CIRCUIT_OPEN"):
            self.ledger.acquire(2001)
        self.assertEqual(self.ledger.report()["pending"],1)

    def test_clock_rollback_denied_instead_of_clearing_budget(self):
        self.ledger.acquire(3000)
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_CLOCK_ROLLBACK"):
            self.ledger.acquire(2999)
        self.assertEqual(self.ledger.report()["attempts"],1)

    def test_record_finishes_once_only(self):
        ident=self.ledger.acquire(4000)
        self.ledger.finish(ident,"CLEAN_SESSION",0)
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_ATTEMPT_ALREADY_SETTLED"):
            self.ledger.finish(ident,"CHILD_PROCESS_CRASHED",124)
        self.assertEqual(self.ledger.report()["completed"],1)

    def test_malformed_policy_revisions_and_attempt_clock_denied(self):
        for value in (True,0,-1,1.5,"2000",None):
            with self.subTest(value=value):
                with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_CLOCK_INVALID"):
                    self.ledger.acquire(value)
        self.assertEqual(self.ledger.report()["attempts"],0)

    def test_noncanonical_completion_status_denied(self):
        ident=self.ledger.acquire(4000)
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_COMPLETION_INVALID"):
            self.ledger.finish(ident,"launch /etc/passwd",0)
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_COMPLETION_INVALID"):
            self.ledger.finish(ident,"",0)
        self.ledger.finish(ident,"CHILD_START_FAILED",None)

    def test_sqlite_inserts_are_atomic_under_competing_attempts(self):
        other=AttemptLedger(self.root,window_seconds=60,max_window_attempts=2)
        try:
            self.ledger.acquire(5000)
            other.acquire(5000)
            with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_CIRCUIT_OPEN"):
                self.ledger.acquire(5000)
            self.assertEqual(other.report()["attempts"],2)
        finally:
            other.close()

    def test_schema_version_mismatch_fails_closed(self):
        self.ledger.db.execute(
            "UPDATE supervisor_meta SET schema='v0' WHERE singleton=1")
        with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_LEDGER_SCHEMA_MISMATCH"):
            AttemptLedger(self.root)

    def test_symlink_root_rejected(self):
        alias=self.root.parent/(secrets.token_hex(9))
        try:
            alias.symlink_to(self.root,target_is_directory=True)
        except (OSError,NotImplementedError):
            self.skipTest("symlinks unavailable in this Windows user context")
        try:
            with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_ROOT_LINK_DENIED"):
                AttemptLedger(alias)
        finally:
            alias.unlink(missing_ok=True)

    def test_supervision_crash_then_clean_restarts_listener_only(self):
        responses=iter([
            ("CHILD_PROCESS_CRASHED",17),
            ("CLEAN_SESSION",0),
        ])
        starts=[]
        emitted=[]
        delays=[]
        def runner(args,*,max_seconds):
            starts.append((tuple(args),max_seconds))
            return next(responses)
        result=run_sessions(
            self.ledger,["fixed-broker-executable"],sessions=2,
            child_seconds=5,runner=runner,
            emit=emitted.append,now=lambda:7000,sleep=delays.append)
        self.assertEqual(result["last_reason"],"CLEAN_SESSION")
        self.assertEqual(result["listeners_started_this_run"],2)
        self.assertEqual(len(starts),2)
        self.assertEqual(starts[0],starts[1])
        self.assertFalse(result["automatic_command_replay_permitted"])
        self.assertEqual(self.ledger.report()["completed"],2)
        self.assertEqual(len(delays),1)
        self.assertEqual(
            [x["event"] for x in emitted],
            ["BROKER_LISTENER_STARTING","BROKER_LISTENER_EXITED",
             "BROKER_LISTENER_STARTING","BROKER_LISTENER_EXITED",
             "SUPERVISOR_STOPPED"])

    def test_supervision_repeated_crashes_open_durable_circuit(self):
        called=[]
        def runner(args,*,max_seconds):
            called.append(1)
            return "CHILD_PROCESS_CRASHED",17
        result=run_sessions(
            self.ledger,["fixed"],sessions=5,child_seconds=4,
            runner=runner,emit=lambda _:None,now=lambda:8000,
            sleep=lambda _:None)
        self.assertEqual(result["last_reason"],"SUPERVISOR_CIRCUIT_OPEN")
        self.assertEqual(len(called),2)
        self.assertEqual(self.ledger.report()["attempts"],2)
        self.assertEqual(self.ledger.report()["pending"],0)
        self.assertFalse(result["automatic_command_replay_permitted"])

    def test_supervision_security_error_blocks_without_restart(self):
        called=[]
        def runner(args,*,max_seconds):
            called.append(1)
            return "STARTUP_OR_SECURITY_DENIED",3
        result=run_sessions(
            self.ledger,["fixed"],sessions=5,child_seconds=4,
            runner=runner,emit=lambda _:None,now=lambda:9000)
        self.assertEqual(len(called),1)
        self.assertEqual(result["last_reason"],"STARTUP_OR_SECURITY_DENIED")
        self.assertEqual(self.ledger.report()["attempts"],1)

    def test_supervision_runner_exception_does_not_leak_pending_lease(self):
        result=run_sessions(
            self.ledger,["fixed"],sessions=5,child_seconds=4,
            runner=lambda _args,**kw: 1/0,
            emit=lambda _:None,now=lambda:10000)
        self.assertEqual(result["last_reason"],"CHILD_RUNNER_FAILED")
        self.assertEqual(self.ledger.report()["pending"],0)
        self.assertEqual(self.ledger.report()["attempts"],1)

    def test_classifies_only_complete_proof_of_clean_session(self):
        start=b'{"ok":true,"starting":true}\n'
        finish=b'{"ok":true,"completed":1,"peer_token_verified":true}\n'
        self.assertEqual(classify(0,start+finish),"CLEAN_SESSION")
        self.assertEqual(classify(0,start),"CHILD_PROCESS_CRASHED")
        self.assertEqual(classify(3,start+b'{"ok":false,"error":"PIPE_CONNECT_TIMEOUT"}\n'),
                         "TRANSIENT_PIPE_FAILURE")
        self.assertEqual(classify(3,start+b'{"ok":false,"error":"SIGNED_NAMED_PIPE_BROKER_DENIED"}\n'),
                         "STARTUP_OR_SECURITY_DENIED")
        self.assertEqual(classify(124,b"",timed_out=True),"CHILD_WATCHDOG_TIMEOUT")
        self.assertEqual(classify(9,b"broken"),"CHILD_STATUS_INVALID")

    def test_crashed_python_child_is_classified_without_restart_replay(self):
        reason,code=run_fixed_child(
            [sys.executable,"-c","import os;os._exit(17)"],
            max_seconds=5)
        self.assertEqual(reason,"CHILD_PROCESS_CRASHED")
        self.assertEqual(code,17)

    def test_hung_child_killed_at_supervisor_deadline(self):
        start=time.monotonic()
        reason,code=run_fixed_child(
            [sys.executable,"-c","import time;time.sleep(60)"],
            max_seconds=3)
        self.assertEqual(reason,"CHILD_WATCHDOG_TIMEOUT")
        self.assertLess(time.monotonic()-start,7)

    @unittest.skipUnless(sys.platform=="win32","native file lock only")
    def test_single_instance_lock_prevents_second_supervisor(self):
        with single_instance(self.root):
            with self.assertRaisesRegex(SupervisorError,"SUPERVISOR_ALREADY_RUNNING"):
                with single_instance(self.root):
                    pass
        with single_instance(self.root):
            pass


@unittest.skipUnless(sys.platform=="win32","Windows named pipe only")
class SupervisorProcessIntegrationTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.sid=current_user_sid()
        self.suffix=secrets.token_hex(12)
        self.issuer=Ed25519PrivateKey.generate()
        self.dev=Ed25519PrivateKey.generate()
        self.policy_path=self.root/"public-grants.json"
        self.bundle_path=self.root/"signed-bundle.json"
        public=self.dev.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.issuer_hex=self.issuer.public_key().public_bytes(
            Encoding.Raw,PublicFormat.Raw).hex()
        self.now=datetime.now(timezone.utc).replace(microsecond=0)
        public_grants={
            "schema":"foundation-pinned-policy-v1","scope":"project-fixture",
            "grants":[{
                "principal_id":"developer-1","role":"developer",
                "key_id":"dev-key","public_key_b64":base64.b64encode(public).decode(),
                "scope":"project-fixture","run_id":"run-1","step_id":"step-1",
                "epoch":1,"policy_revision":1,
                "capabilities":["STAGE_INTENT","QUERY_COMMAND_STATUS"],
                "revoked":False,
            }],
        }
        content=canonical(public_grants)
        self.policy_path.write_bytes(content)
        bundle={
            "schema":POLICY_SCHEMA,"issuer_id":"test-issuer",
            "revision":1,
            "policy_sha256":hashlib.sha256(content).hexdigest(),
            "issued_utc":(self.now-timedelta(minutes=1)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(self.now+timedelta(hours=1)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
        }
        bundle["signature_b64"]=base64.b64encode(
            self.issuer.sign(POLICY_DOMAIN+canonical(bundle))).decode()
        self.bundle_path.write_bytes(canonical(bundle))
        with Journal(self.root,"execution_journal_broker.sqlite3") as j:
            j.append("run-1","step-1","plan","PLAN",0,"a"*64)
            j.append("run-1","step-1","lease","LEASE",1)

    def command(self,op):
        action="STAGE_INTENT" if op=="stage_intent" else "QUERY_COMMAND_STATUS"
        request_id="request-stage" if op=="stage_intent" else "request-query"
        args=(
            {"message_id":"msg-1","destination":"worker-1","payload_sha":"b"*64}
            if op=="stage_intent" else
            {"message_id":"msg-1","target_request_id":"request-stage"}
        )
        doc={
            "schema":HOST_SCHEMA,"principal_id":"developer-1",
            "role":"developer","key_id":"dev-key","policy_revision":1,
            "scope":"project-fixture","run_id":"run-1","step_id":"step-1",
            "epoch":1,"request_id":request_id,"nonce":("a" if op=="stage_intent"
                            else "b")*32,"action":action,
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":(self.now-timedelta(seconds=3)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(self.now+timedelta(seconds=69)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
        }
        auth={"document":doc,"signature_b64":base64.b64encode(
            self.dev.sign(HOST_DOMAIN+canonical(doc))).decode()}
        return {"protocol":PROTOCOL,"op":op,"auth":auth,
                "run_id":"run-1","step_id":"step-1","request_id":request_id,
                "epoch":1,**args}

    def argv(self, *, sessions=2,max_attempts=3,seconds=9,fixture=True):
        cmd=[
            sys.executable,
            str(Path(__file__).resolve().parent/"broker_supervisor.py"),
            "--root",str(self.root),"--policy",str(self.policy_path),
            "--signed-policy-bundle",str(self.bundle_path),
            "--trusted-issuer-public-hex",self.issuer_hex,
            "--pipe-suffix",self.suffix,
            "--broker-sid",self.sid,"--client-sid",self.sid,
            "--sessions",str(sessions),"--max-attempts",str(max_attempts),
            "--child-seconds",str(seconds),
        ]
        if fixture:
            cmd.append("--offline-same-sid-fixture")
        return cmd

    def spawn(self,**kwargs):
        return subprocess.Popen(
            self.argv(**kwargs),cwd=Path(__file__).resolve().parent,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL)

    def read_one_json(self,child):
        line=child.stdout.readline()
        self.assertTrue(line,child.stderr.read().decode(errors="replace")
                        if child.poll() is not None else "no startup event")
        return json.loads(line)

    def close(self,child,timeout=18):
        try:
            child.wait(timeout=timeout)
            rest=child.stdout.read()
            errors=child.stderr.read()
            return child.returncode,[
                json.loads(x) for x in rest.splitlines()],errors
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    def test_supervisor_two_sessions_survive_and_never_replay_command(self):
        child=self.spawn(sessions=2)
        try:
            start=self.read_one_json(child)
            self.assertEqual(start["event"],"BROKER_LISTENER_STARTING")
            first=json.loads(request_once(
                self.suffix,canonical(self.command("stage_intent")),
                expected_server_sid=self.sid))
            self.assertTrue(first["ok"],first)
            left=self.read_one_json(child)
            self.assertEqual(left["event"],"BROKER_LISTENER_EXITED")
            self.assertEqual(left["reason"],"CLEAN_SESSION")
            next_start=self.read_one_json(child)
            self.assertEqual(next_start["event"],"BROKER_LISTENER_STARTING")
            query=json.loads(request_once(
                self.suffix,canonical(self.command("query_command_status")),
                expected_server_sid=self.sid))
            self.assertTrue(query["ok"],query)
            self.assertTrue(query["result"]["recorded"])
            self.assertFalse(query["result"]["automatic_retry_permitted"])
            code,remaining,stderr=self.close(child)
            self.assertEqual(code,0,stderr.decode(errors="replace"))
            self.assertEqual(remaining[-1]["event"],"SUPERVISOR_STOPPED")
            with Journal(self.root,"execution_journal_broker.sqlite3") as j:
                self.assertEqual(j.verify("run-1")["events_examined"],3)
                count=j.db.execute(
                    "SELECT count(*) FROM host_gate_claims").fetchone()[0]
                self.assertEqual(count,1)
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    def test_same_sid_production_supervisor_fails_closed(self):
        result=subprocess.run(self.argv(fixture=False),
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              timeout=6,check=False)
        self.assertEqual(result.returncode,3)
        self.assertIn(b"SUPERVISOR_DENIED",result.stdout)
        with Journal(self.root,"execution_journal_broker.sqlite3") as j:
            self.assertEqual(j.verify("run-1")["events_examined"],2)

    def test_forged_issuer_policy_cannot_start_supervisor(self):
        doc=json.loads(self.bundle_path.read_bytes())
        doc["signature_b64"]=base64.b64encode(
            Ed25519PrivateKey.generate().sign(b"invalid")).decode()
        self.bundle_path.write_bytes(canonical(doc))
        result=subprocess.run(self.argv(),stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE,timeout=7,check=False)
        self.assertEqual(result.returncode,3)
        self.assertIn(b"SUPERVISOR_DENIED",result.stdout)
        with Journal(self.root,"execution_journal_broker.sqlite3") as j:
            self.assertEqual(j.verify("run-1")["events_examined"],2)

    def test_connection_timeout_consumes_budget_durably(self):
        # Two idle listeners consume exactly two budget slots, then the
        # persisted circuit opens on a new invocation within 300 seconds.
        result=subprocess.run(self.argv(sessions=2,max_attempts=2,seconds=7),
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              timeout=15,check=False)
        self.assertEqual(result.returncode,2,
                         result.stderr.decode(errors="replace"))
        events=[json.loads(x) for x in result.stdout.splitlines()]
        self.assertEqual(sum(x["event"]=="BROKER_LISTENER_STARTING"
                             for x in events),2)
        self.assertEqual(events[-1]["event"],"SUPERVISOR_STOPPED")
        self.assertFalse(events[-1]["automatic_command_replay_permitted"])
        second=subprocess.run(self.argv(sessions=1,max_attempts=2,seconds=7),
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              timeout=5,check=False)
        out=[json.loads(x) for x in second.stdout.splitlines()]
        self.assertEqual(second.returncode,2)
        self.assertEqual(out[-1]["last_reason"],"SUPERVISOR_CIRCUIT_OPEN")
        with Journal(self.root,"execution_journal_broker.sqlite3") as j:
            self.assertEqual(j.verify("run-1")["events_examined"],2)

if __name__=="__main__":
    unittest.main()
