"""Native Windows named-pipe SID and ACL tests; no live MCP modification.

The positive functional test deliberately runs same-user *only* in a
disposable fixture and MUST NOT be treated as production OS isolation.
"""
from __future__ import annotations
import os
import secrets
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

try:
    from .win_pipe_ipc import (
        MAX_FRAME, PipeAccessError, _name, security_sddl,
        request_once, serve_one, peer_sid_after_read,
    )
    from .windows_isolation import current_user_sid
except ImportError:
    from win_pipe_ipc import (
        MAX_FRAME, PipeAccessError, _name, security_sddl,
        request_once, serve_one, peer_sid_after_read,
    )
    from windows_isolation import current_user_sid

class PipeContractTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)

    def test_randomized_name_requires_exact_24_hex(self):
        for invalid in ("","abc","X"*24,"../escape","0"*25,"g"*24):
            with self.subTest(invalid=invalid):
                with self.assertRaisesRegex(PipeAccessError,"PIPE_NAME_INVALID"):
                    _name(invalid)
        self.assertTrue(_name("a"*24).endswith("a"*24))

    def test_explicit_dacl_does_not_allow_everyone_or_administrators(self):
        broker="S-1-5-21-111-222-333-444"
        client="S-1-5-21-111-222-333-555"
        sddl=security_sddl(broker,client)
        self.assertEqual(sddl,
            "D:P(A;;GA;;;SY)(A;;GA;;;"+broker+")(A;;GRGW;;;"+client+")")
        self.assertNotIn(";;;WD",sddl)
        self.assertNotIn(";;;BA",sddl)
        self.assertNotIn(";;;AN",sddl)

    def test_invalid_sid_denied_before_dacl_creation(self):
        for bad in ("", "../", "BUILTIN\\Users", "S-1-a-4", "0"):
            with self.subTest(bad=bad):
                with self.assertRaises(PipeAccessError):
                    security_sddl(bad,"S-1-5-18")

    def test_outsize_client_frame_denied(self):
        with self.assertRaisesRegex(PipeAccessError,"PIPE_CLIENT_PAYLOAD_INVALID"):
            request_once("a"*24,b"x"*(MAX_FRAME+1),
                         expected_server_sid="S-1-5-18")

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_peer_sid_mismatch_rejected_before_handler(self):
        sid=current_user_sid()
        outsider="S-1-5-19" if sid!="S-1-5-19" else "S-1-5-18"
        suffix=secrets.token_hex(12)
        marker=Path(self.temp_dir.name)/"unsafe-marker.txt"
        script=(
            "import sys\n"
            "from pathlib import Path\n"
            "from win_pipe_ipc import serve_one,PipeAccessError\n"
            "def forbidden(_):\n"
            "  Path(sys.argv[3]).write_text('handler-called')\n"
            "  return b'UNSAFE'\n"
            "print('STARTING',flush=True)\n"
            "try:\n"
            "  serve_one(suffix=sys.argv[1],broker_sid=sys.argv[2],"
            "client_sid=sys.argv[4],handler=forbidden)\n"
            "except PipeAccessError as exc:\n"
            "  print(str(exc),flush=True)\n"
        )
        child=subprocess.Popen(
            [sys.executable,"-c",script,suffix,sid,str(marker),outsider],
            cwd=Path(__file__).resolve().parent,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.DEVNULL)
        try:
            self.assertEqual(child.stdout.readline().strip(),b"STARTING")
            with self.assertRaisesRegex(PipeAccessError,"PIPE_READ_FAILED"):
                request_once(suffix,b"payload",expected_server_sid=sid)
            child.wait(timeout=8)
            self.assertIn(b"PIPE_CLIENT_IDENTITY_DENIED",child.stdout.read())
            self.assertFalse(marker.exists())
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_client_denies_untrusted_server_before_sending(self):
        sid=current_user_sid()
        wrong="S-1-5-19" if sid!="S-1-5-19" else "S-1-5-18"
        suffix=secrets.token_hex(12)
        script=(
            "import sys\n"
            "from win_pipe_ipc import serve_one,PipeAccessError\n"
            "print('STARTING',flush=True)\n"
            "try:\n"
            "  serve_one(suffix=sys.argv[1],broker_sid=sys.argv[2],"
            "client_sid=sys.argv[2],handler=lambda _:b'UNSAFE')\n"
            "except PipeAccessError as exc:\n"
            "  print(str(exc),flush=True)\n"
        )
        child=subprocess.Popen(
            [sys.executable,"-c",script,suffix,sid],
            cwd=Path(__file__).resolve().parent,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.DEVNULL)
        try:
            self.assertEqual(child.stdout.readline().strip(),b"STARTING")
            with self.assertRaisesRegex(PipeAccessError,"PIPE_SERVER_IDENTITY_DENIED"):
                request_once(suffix,b"must-not-send",expected_server_sid=wrong)
            child.wait(timeout=8)
            self.assertIn(b"PIPE_READ_FAILED",child.stdout.read())
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_idle_connected_client_expires_without_running_handler(self):
        """Real hostile client opens a handle but never sends any bytes."""
        import time
        import win_pipe_ipc as pipe
        sid=current_user_sid()
        suffix=secrets.token_hex(12)
        marker=Path(self.temp_dir.name)/"should-not-exist"
        source=(
            "import sys\n"
            "from pathlib import Path\n"
            "from win_pipe_ipc import serve_one,PipeAccessError\n"
            "def handler(data):\n"
            "  Path(sys.argv[3]).write_bytes(b'UNSAFE')\n"
            "  return b'UNSAFE'\n"
            "print('STARTING',flush=True)\n"
            "try:\n"
            "  serve_one(suffix=sys.argv[1],broker_sid=sys.argv[2],"
            "client_sid=sys.argv[2],handler=handler,"
            "read_timeout_ms=350,accept_timeout_ms=1200)\n"
            "except PipeAccessError as exc:\n"
            "  print(str(exc),flush=True)\n"
        )
        child=subprocess.Popen(
            [sys.executable,"-c",source,suffix,sid,str(marker)],
            cwd=Path(__file__).resolve().parent,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.DEVNULL)
        handle=None
        try:
            self.assertEqual(child.stdout.readline().strip(),b"STARTING")
            kernel=pipe._kernel()
            deadline=time.monotonic()+2
            while not kernel.WaitNamedPipeW(pipe._name(suffix),100):
                if time.monotonic()>=deadline:
                    self.fail("PIPE_UNAVAILABLE_FOR_IDLE_TEST")
            handle=kernel.CreateFileW(
                pipe._name(suffix),0xC0000000,0,None,3,
                pipe.FILE_FLAG_OVERLAPPED|0x00100000|0x00020000,None)
            self.assertTrue(handle and handle!=pipe.INVALID_HANDLE)
            child.wait(timeout=5)
            self.assertIn(b"PIPE_READ_TIMEOUT",child.stdout.read())
            self.assertFalse(marker.exists())
        finally:
            if handle and handle!=pipe.INVALID_HANDLE:
                pipe._kernel().CloseHandle(handle)
            if child.poll() is None:
                child.kill();child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_unconnected_pipe_expires_without_running_handler(self):
        """Server cannot be pinned forever without any client connection."""
        sid=current_user_sid()
        suffix=secrets.token_hex(12)
        source=(
            "import sys\n"
            "from win_pipe_ipc import serve_one,PipeAccessError\n"
            "print('STARTING',flush=True)\n"
            "try:\n"
            "  serve_one(suffix=sys.argv[1],broker_sid=sys.argv[2],"
            "client_sid=sys.argv[2],handler=lambda _: b'UNSAFE',"
            "read_timeout_ms=300,accept_timeout_ms=300)\n"
            "except PipeAccessError as exc:\n"
            "  print(str(exc),flush=True)\n"
        )
        child=subprocess.Popen(
            [sys.executable,"-c",source,suffix,sid],
            cwd=Path(__file__).resolve().parent,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,stdin=subprocess.DEVNULL)
        try:
            self.assertEqual(child.stdout.readline().strip(),b"STARTING")
            child.wait(timeout=5)
            stdout=child.stdout.read()
            stderr=child.stderr.read()
            self.assertIn(b"PIPE_CONNECT_TIMEOUT",stdout,
                          "child rc="+str(child.returncode)+
                          " stderr="+stderr.decode(errors="replace"))
        finally:
            if child.poll() is None:
                child.kill();child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_unbounded_or_malformed_deadline_is_denied(self):
        sid=current_user_sid()
        for value in (0,-1,True,5001,1.5,"300",None):
            with self.subTest(timeout=value):
                with self.assertRaisesRegex(PipeAccessError,"PIPE_TIMEOUT_LIMIT_INVALID"):
                    serve_one(
                        suffix=secrets.token_hex(12),broker_sid=sid,
                        client_sid=sid,handler=lambda _:b"NEVER",
                        accept_timeout_ms=value)
                with self.assertRaisesRegex(PipeAccessError,"PIPE_TIMEOUT_LIMIT_INVALID"):
                    serve_one(
                        suffix=secrets.token_hex(12),broker_sid=sid,
                        client_sid=sid,handler=lambda _:b"NEVER",
                        read_timeout_ms=value)

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_server_refuses_wrong_broker_token(self):
        sid=current_user_sid()
        with self.assertRaisesRegex(PipeAccessError,"PIPE_BROKER_TOKEN_MISMATCH"):
            serve_one(suffix=secrets.token_hex(12),
                      broker_sid="S-1-5-18" if sid!="S-1-5-18" else "S-1-5-19",
                      client_sid=sid,handler=lambda b: b"safe")

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_real_named_pipe_impersonates_last_message_and_identifies_sid(self):
        """Actual Win32 IPC between this unittest and a disposable child."""
        sid=current_user_sid()
        self.assertTrue(sid.startswith("S-1-"))
        suffix=secrets.token_hex(12)
        path=Path(__file__).resolve().parent
        script=(
            "import sys, json\n"
            "from win_pipe_ipc import serve_one\n"
            "from windows_isolation import current_user_sid\n"
            "sid=current_user_sid()\n"
            "print('STARTING',flush=True)\n"
            "reply=serve_one(suffix=sys.argv[1],broker_sid=sid,"
            "client_sid=sid,handler=lambda data:b'ACK:'+data)\n"
            "print(json.dumps(reply),flush=True)\n"
        )
        child=subprocess.Popen(
            [sys.executable,"-c",script,suffix],cwd=path,
            stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        try:
            line=child.stdout.readline().strip()
            self.assertEqual(line,b"STARTING",
                child.stderr.read().decode(errors="replace") if child.poll() is not None else "no stdout")
            value=request_once(suffix,b"hello-signed-request",
                               expected_server_sid=sid)
            self.assertEqual(value,b"ACK:hello-signed-request")
            child.wait(timeout=8)
            stdout=child.stdout.read().decode("utf-8")
            self.assertEqual(child.returncode,0,child.stderr.read().decode(errors="replace"))
            self.assertIn('"os_peer_token_checked": true',stdout)
            self.assertIn('"windows_service_isolated": false',stdout)
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    @unittest.skipUnless(sys.platform=="win32","Windows named pipes only")
    def test_real_same_sid_is_not_production_isolation(self):
        from windows_isolation import preflight_isolation
        sid=current_user_sid()
        result=preflight_isolation(broker_sid=sid,agent_sid=sid,
                                   protected_paths=[])
        self.assertFalse(result["filesystem_preflight_passed"])
        self.assertFalse(result["ready_for_production"])
        self.assertIn("BROKER_AND_AGENT_SHARE_SID",result["findings"])

if __name__=="__main__":
    unittest.main()
