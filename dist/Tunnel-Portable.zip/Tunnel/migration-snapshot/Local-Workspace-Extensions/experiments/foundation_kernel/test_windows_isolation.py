"""Read-only Windows OS-boundary preflight tests; never mutates ACLs."""
from __future__ import annotations

import importlib
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

try:
    from .windows_isolation import (
        WindowsIsolationError, current_user_sid, inspect_acl, preflight_isolation,
        SID, SYSTEM_SID,
    )
except ImportError:
    from windows_isolation import (
        WindowsIsolationError, current_user_sid, inspect_acl, preflight_isolation,
        SID, SYSTEM_SID,
    )

BROKER="S-1-5-21-100-200-300-1001"
AGENT="S-1-5-21-100-200-300-1002"
OTHER="S-1-5-21-100-200-300-1003"

class WindowsIsolationTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root=Path(temp.name)
        self.policy=root/"policy.json"
        self.journal=root/"journal.sqlite3"
        self.policy.write_text("{}",encoding="utf8")
        self.journal.write_bytes(b"fixture")
        self.paths=(self.policy,self.journal)
        self.module=importlib.import_module(preflight_isolation.__module__)

    def run_with(self, *, actual=BROKER,owner=BROKER,writers=None,
                 broker=BROKER,agent=AGENT,paths=None):
        if writers is None:
            writers=[BROKER,SYSTEM_SID]
        with patch.object(self.module,"current_user_sid",return_value=actual),\
             patch.object(self.module,"inspect_acl",return_value={
                 "owner_sid":owner,"write_allowed_sids":writers,
                 "acl_ace_count":2,"is_directory":False,
                 "acl_interpretation":"CONSERVATIVE_BASIC_ACES_ONLY",
             }) as inspected:
            report=preflight_isolation(
                broker_sid=broker,agent_sid=agent,
                protected_paths=self.paths if paths is None else paths)
        return report,inspected.call_count

    def test_read_only_allow_ace_is_detected_without_execute(self):
        # FILE_READ_DATA (or LIST_DIRECTORY), GENERIC_READ and GENERIC_ALL
        # expose content. No FILE_EXECUTE ACE is required for that leak.
        allowed=(0x00000001,0x80000000,0x10000000,
                 0x00000001|0x00000020)
        for mask in allowed:
            with self.subTest(mask=hex(mask)):
                self.assertTrue(self.module._data_read_allowed(mask))
        for mask in (0,0x00000020,0x00020000,0x20000000,0x40000000):
            with self.subTest(not_read=hex(mask)):
                self.assertFalse(self.module._data_read_allowed(mask))

    def test_matching_broker_sid_and_strict_acl_only_passes_filesystem(self):
        report,count=self.run_with()
        self.assertTrue(report["filesystem_preflight_passed"])
        self.assertFalse(report["ready_for_production"])
        self.assertFalse(report["ipc_parent_authenticated"])
        self.assertFalse(report["live_mcp_privileged_tools_removed"])
        self.assertEqual(count,3) # 2 files and their shared directory

    def test_same_agent_and_broker_sid_blocks(self):
        report,_=self.run_with(agent=BROKER)
        self.assertFalse(report["filesystem_preflight_passed"])
        self.assertIn("BROKER_AND_AGENT_SHARE_SID",report["findings"])

    def test_token_mismatch_blocks(self):
        report,_=self.run_with(actual=OTHER)
        self.assertIn("BROKER_PROCESS_TOKEN_MISMATCH",report["findings"])

    def test_untrusted_owner_blocks(self):
        report,_=self.run_with(owner=AGENT)
        self.assertIn("UNTRUSTED_PROTECTED_PATH_OWNER",report["findings"])

    def test_agent_write_permission_blocks(self):
        report,_=self.run_with(writers=[BROKER,AGENT])
        self.assertIn("UNTRUSTED_WRITE_ACE",report["findings"])

    def test_everyone_write_permission_blocks(self):
        report,_=self.run_with(writers=["S-1-1-0"])
        self.assertIn("UNTRUSTED_WRITE_ACE",report["findings"])

    def test_administrator_group_write_permission_blocks(self):
        report,_=self.run_with(writers=["S-1-5-32-544"])
        self.assertIn("UNTRUSTED_WRITE_ACE",report["findings"])

    def test_only_system_owner_allowed_when_nonbroker(self):
        report,_=self.run_with(owner=SYSTEM_SID)
        self.assertTrue(report["filesystem_preflight_passed"])
        self.assertFalse(report["ready_for_production"])

    def test_token_query_error_blocks(self):
        with patch.object(self.module,"current_user_sid",
                          side_effect=WindowsIsolationError("WINDOWS_TOKEN_QUERY_DENIED")),\
             patch.object(self.module,"inspect_acl",return_value={
                 "owner_sid":BROKER,"write_allowed_sids":[BROKER]
             }):
            result=preflight_isolation(
                broker_sid=BROKER,agent_sid=AGENT,protected_paths=self.paths)
        self.assertFalse(result["filesystem_preflight_passed"])
        self.assertIn("WINDOWS_TOKEN_QUERY_DENIED",result["findings"])

    def test_acl_inspection_error_blocks(self):
        with patch.object(self.module,"current_user_sid",return_value=BROKER),\
             patch.object(self.module,"inspect_acl",
                          side_effect=WindowsIsolationError("WINDOWS_ACE_TYPE_UNSUPPORTED")):
            result=preflight_isolation(
                broker_sid=BROKER,agent_sid=AGENT,protected_paths=self.paths)
        self.assertFalse(result["filesystem_preflight_passed"])
        self.assertIn("WINDOWS_ACE_TYPE_UNSUPPORTED",result["findings"])

    def test_untrusted_or_missing_sid_blocks(self):
        report,_=self.run_with(broker="not-a-sid",agent="")
        self.assertIn("BROKER_SID_NOT_PINNED",report["findings"])
        self.assertIn("AGENT_SID_NOT_PINNED",report["findings"])

    def test_single_path_incomplete(self):
        report,count=self.run_with(paths=(self.policy,))
        self.assertIn("PROTECTED_PATHS_INCOMPLETE",report["findings"])

    def test_direct_string_not_interpreted_as_path_sequence(self):
        report,_=self.run_with(paths=str(self.policy))
        self.assertIn("PROTECTED_PATHS_INVALID",report["findings"])

    def test_no_permission_changes_are_performed(self):
        before=(self.policy.read_bytes(),self.journal.read_bytes())
        self.run_with()
        self.assertEqual(before,(self.policy.read_bytes(),self.journal.read_bytes()))

    @unittest.skipUnless(sys.platform=="win32","Win32 process token required")
    def test_cli_fails_closed_when_broker_and_agent_share_sid(self):
        import json
        import subprocess
        sid=current_user_sid()
        script=Path(__file__).resolve().parent/"broker_os_preflight.py"
        before=self.policy.read_bytes()
        proc=subprocess.run(
            [sys.executable,str(script),
             "--broker-sid",sid,"--agent-sid",sid,
             "--protected-path",str(self.policy),
             "--protected-path",str(self.journal)],
            capture_output=True,timeout=8,check=False)
        self.assertEqual(proc.returncode,2,proc.stderr.decode(errors="replace"))
        report=json.loads(proc.stdout)
        self.assertFalse(report["ready_for_production"])
        self.assertFalse(report["filesystem_preflight_passed"])
        self.assertIn("BROKER_AND_AGENT_SHARE_SID",report["findings"])
        self.assertEqual(before,self.policy.read_bytes())

    @unittest.skipUnless(sys.platform=="win32","Win32 process token required")
    def test_cli_rejects_unpinned_sid_and_writes_nothing(self):
        import json
        import subprocess
        script=Path(__file__).resolve().parent/"broker_os_preflight.py"
        proc=subprocess.run(
            [sys.executable,str(script),
             "--broker-sid","not-a-sid","--agent-sid","also-invalid",
             "--protected-path",str(self.policy),
             "--protected-path",str(self.journal)],
            capture_output=True,timeout=8,check=False)
        self.assertEqual(proc.returncode,2)
        result=json.loads(proc.stdout)
        self.assertIn("BROKER_SID_NOT_PINNED",result["findings"])
        self.assertFalse(result["ready_for_production"])

    @unittest.skipUnless(sys.platform=="win32","Win32 identity only")
    def test_real_process_sid_is_valid(self):
        actual=current_user_sid()
        self.assertRegex(actual,SID)
        self.assertTrue(actual.startswith("S-1-"))

    @unittest.skipUnless(sys.platform=="win32","Win32 identity only")
    def test_current_account_is_not_claimed_isolated_from_itself(self):
        sid=current_user_sid()
        report=preflight_isolation(
            broker_sid=sid,agent_sid=sid,protected_paths=self.paths)
        self.assertFalse(report["filesystem_preflight_passed"])
        self.assertFalse(report["ready_for_production"])
        self.assertIn("BROKER_AND_AGENT_SHARE_SID",report["findings"])

if __name__=="__main__":
    unittest.main()
