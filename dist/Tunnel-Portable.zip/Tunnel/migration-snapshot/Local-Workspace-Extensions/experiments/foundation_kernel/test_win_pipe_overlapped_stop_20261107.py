"""P085 reusable overlapped IPC stop/deadline contract (no live service).

The fake-kernel tests never create a privileged pipe. No install, queue,
credentials, ACLs or grant operations occur.
"""
from __future__ import annotations

import ctypes
import unittest
from unittest.mock import Mock, patch

try:
    from . import win_pipe_overlapped as ov
except ImportError:
    import win_pipe_overlapped as ov


class OverlappedStopSafetyTests(unittest.TestCase):
    def test_invalid_connect_timeout_rejected_before_io_submission(self):
        kernel=Mock()
        for bad in (True, 0, -1, 30001, None, "3000"):
            with self.subTest(bad=bad), patch.object(ov,"configure",return_value=kernel):
                with self.assertRaisesRegex(ov.TimedPipeError,"PIPE_DEADLINE_INVALID"):
                    ov.connect(kernel,321,timeout_ms=bad)
        kernel.ConnectNamedPipe.assert_not_called()
        kernel.CreateEventW.assert_not_called()

    def test_invalid_read_write_timeout_rejected_before_io_submission(self):
        kernel=Mock()
        with patch.object(ov,"configure",return_value=kernel):
            for act in (lambda:ov.read(kernel,321,4,timeout_ms=0),
                        lambda:ov.write(kernel,321,b"a",timeout_ms=0)):
                with self.assertRaisesRegex(ov.TimedPipeError,"PIPE_DEADLINE_INVALID"):
                    act()
        kernel.ReadFile.assert_not_called()
        kernel.WriteFile.assert_not_called()
        kernel.CreateEventW.assert_not_called()

    def test_stop_before_connect_does_not_allocate_event_or_native_io(self):
        kernel=Mock()
        with patch.object(ov,"configure",return_value=kernel):
            with self.assertRaisesRegex(ov.TimedPipeError,"PIPE_STOP_REQUESTED"):
                ov.connect(kernel,321,stop_requested=lambda:True)
        kernel.CreateEventW.assert_not_called()
        kernel.ConnectNamedPipe.assert_not_called()

    def test_stop_during_pending_connect_cancels_and_drains_exact_operation(self):
        kernel=Mock()
        kernel.WaitForSingleObject.return_value=ov.WAIT_TIMEOUT
        kernel.GetOverlappedResult.return_value=False
        operation=ov.OVERLAPPED()
        checks=[False,False,True]
        def stopped():
            return checks.pop(0)
        with patch.object(ov.ctypes,"get_last_error",return_value=ov.PENDING),\
             patch.object(ov,"_drain_cancel") as drain:
            with self.assertRaisesRegex(ov.TimedPipeError,"PIPE_STOP_REQUESTED"):
                ov._finish(kernel,321,operation,False,
                           ms=2000,kind="CONNECT",stop_requested=stopped)
        drain.assert_called_once()
        self.assertEqual(drain.call_args.args[1],321)
        self.assertIs(drain.call_args.args[2],operation)
        self.assertEqual(drain.call_args.args[3],"CONNECT")

    def test_stop_after_complete_read_is_not_reported_as_success(self):
        kernel=Mock()
        kernel.GetOverlappedResult.return_value=True
        def result(handle,op,count,wait):
            ctypes.cast(count,ctypes.POINTER(ov.wt.DWORD)).contents.value=3
            return True
        kernel.GetOverlappedResult.side_effect=result
        with self.assertRaisesRegex(ov.TimedPipeError,"PIPE_STOP_REQUESTED"):
            ov._finish(kernel,321,ov.OVERLAPPED(),True,
                       ms=1000,kind="READ",stop_requested=lambda:True)

    def test_framed_reader_can_request_exact_bytes_without_overread(self):
        kernel=Mock()
        lengths=[]
        def capture(h,buffer,size,written,overlapped):
            lengths.append(size)
            ctypes.memmove(buffer,b"abcd",min(size,4))
            ctypes.cast(written,ctypes.POINTER(ov.wt.DWORD)).contents.value=min(size,4)
            return True
        kernel.ReadFile.side_effect=capture
        with patch.object(ov,"configure",return_value=kernel),\
             patch.object(ov,"_event",return_value=111),\
             patch.object(ov,"_finish",return_value=4):
            self.assertEqual(ov.read(kernel,321,4,exact_length=True),b"abcd")
            ov.read(kernel,321,4)
        self.assertEqual(lengths,[4,5])

    def test_invalid_stop_callback_is_rejected_before_native_io(self):
        kernel=Mock()
        with patch.object(ov,"configure",return_value=kernel):
            with self.assertRaisesRegex(ov.TimedPipeError,"PIPE_STOP_CALLBACK_INVALID"):
                ov.connect(kernel,321,stop_requested="yes")
        kernel.ConnectNamedPipe.assert_not_called()
        kernel.CreateEventW.assert_not_called()


if __name__=="__main__":
    unittest.main()
