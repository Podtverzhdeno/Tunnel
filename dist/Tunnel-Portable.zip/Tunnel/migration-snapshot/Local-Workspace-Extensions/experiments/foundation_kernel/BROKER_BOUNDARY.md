# Experimental broker — boundary, threat model and rollout criteria

**Status:** implemented and subprocess/MCP-protocol tested, **NOT connected**
to the live `Local Workspace MCP`, the five scheduled agents, or production
file access. This is a development prototype and no real worker command
is executed.

## Implemented transport (restricted by design)

- `broker_stdio.py` owns a test-only `Journal`, `AtomicDispatch` and
  `HostDispatchGate` in its **own Python process**. It reads bounded JSONL
  requests from stdin, emits one JSON reply per request, and never executes
  scripts, shells, Git, network transfers, PR merges, deployment or owner
  approvals. It does **not** fabricate `PLAN` or `LEASE` records.
- **Updated default:** unsigned SHA-only grant policies are now **denied**
  by default. `signed_policy.py` verifies an Ed25519 issuer signature
  (domain-separated from command and worker signatures), exact policy SHA,
  bounded issuance/expiry and numeric policy revision. `SignedPolicyFloor`
  stores the highest accepted revision and issuer-key digest **in the same
  SQLite database as broker INTENT/outbox**, preventing policy rollback and
  same-revision equivocation across restarts. The mutation gate rechecks
  that floor **inside the transaction** and rejects expired policy sessions.
  The `--legacy-unsigned-policy-for-tests` option remains solely for the
  existing offline compatibility tests. It must not be used for production.
- The separate policy file contains **only public** Ed25519 keys, roles,
  run/step/epoch capabilities and revocation flags. The separately pinned
  issuer public key must come from a trusted OS-protected launcher; a
  caller-supplied issuer key is **not** a trust anchor. No signing private
  key is written by the implementation or stored in the repository.
- `broker_mcp_bridge.py` is a **standalone stdio MCP JSON-RPC adapter**,
  exposing exactly four tools: `broker_health`, `broker_stage_intent`,
  `broker_mark_send_uncertain`, and `broker_query_command_status`.
  Each tool call invokes the broker in a separate
  `subprocess.run(..., shell=False)` child with strict size and timeout
  budgets. Child output is decoded and wrapped as an MCP `tools/call`
  content item. Unknown MCP tools and methods are rejected. The status
  tool verifies a signed, scoped QUERY capability and performs no writes,
  retries or external actions; it explicitly refuses to interpret an
  absent record as permission to repeat an uncertain effect.
- Raw broker requests are limited to 16 KiB and 512 frames per process.
  MCP frames are limited to 64 KiB and 512 messages. Duplicate JSON
  keys, nonfinite numbers, malformed UTF-8, unexpected fields, unsigned
  calls, unauthorized keys, tampered policy and wrong signed argument
  digests are rejected without attempting any execution.
- The Ed25519 host policy verifies **pre-issued** principal identity,
  role, project scope, run/step, policy revision, lease epoch and capability
  (`STAGE_INTENT` vs. `MARK_SEND_UNCERTAIN`). A per-key nonce and
  per-request ID are committed in the **same SQLite transaction** as the
  journal INTENT/outbox state. A lost response cannot silently duplicate
  a mutation: repeats are rejected and require read-only reconciliation.
- No persistent socket listener or externally discoverable port is opened
  by the standalone implementation. No installation, registration, tunnel
  restart, permission change or deployment has been performed.

## Why this is **not yet** an OS-enforced host security boundary

The connected Local Workspace MCP still offers broad tools including
`run_script` and `run_command` in the `projects` root with the user's OS
privileges. A caller who can execute arbitrary Python or write the broker
database/policy file as the **same Windows account** can bypass any
in-process or same-user authorization guard. This is not mitigated by
Ed25519 on commands, hash chains, JSON schema or a subprocess alone.
Furthermore, a caller controlling startup parameters could replace both
the pin and the public keys, and a same-user attacker could rewrite SQLite
or the Python implementation.

A read-only Windows SID/DACL preflight is now implemented in
`windows_isolation.py` and `broker_os_preflight.py`: it obtains the
**actual broker process token SID** through Win32 APIs, checks the declared
broker and agent SIDs are distinct, reads **actual** file/directory owners
and basic allow ACEs, and blocks agent/group/Everyone/Administrators write
grants. Unrecognized ACE types fail closed. No ACL modification or user
account creation occurs. In the current same-user setup this preflight
properly refuses to certify isolation. `ready_for_production` is
**always false** because an ACL inspection cannot verify IPC parent
authentication, live MCP tool registry reduction, or independent effects.

### Experimental Windows Named Pipe transport (now implemented)

The separate **uninstalled** native pipe prototype consists of
`win_pipe_ipc.py`, `broker_named_pipe.py` and
`broker_pipe_mcp_bridge.py`:

- The pipe server applies a protected Win32 DACL for SYSTEM, the broker
  SID and one allowed client SID; rejects remote pipe clients; uses
  `FILE_FLAG_FIRST_PIPE_INSTANCE`; limits frames to 16 KiB.
- After receiving a complete frame the server impersonates its client,
  reads `TokenUser` from the Windows thread token, reverts immediately,
  and *only then* permits the signed broker to handle the request.
  Failure to impersonate, read the token, match the pinned SID or revert
  fails closed. No sensitive filesystem work is performed while impersonating.
- The client, **before sending any request**, calls
  `GetNamedPipeServerProcessId`, opens the actual server process token
  and compares its SID against the pinned broker identity. This protects
  against a malicious server providing a convincing unsigned response.
- The isolated MCP adapter exposes only health, signed staging,
  signed pre-send fence and signed read-only reconciliation. The tests
  demonstrate real Windows process-to-process connections, signed policy,
  durable stage, lost-response recovery and server/client SID mismatch
  rejection. Neither side uses general Windows command execution.

The default `broker_named_pipe.py` mode **refuses same-SID** agent and
broker configurations and requires a read-only ACL preflight of the code
and state. The `--offline-same-sid-fixture` mode exists only for
test-local files and explicitly reports NO OS isolation. It must never
be included in a production launcher. A caller who can edit the launcher
or supply arbitrary pinned SIDs can still defeat this prototype. Real
different-account ACL tests, **independent process-level watchdogs**,
process PID lifetime hardening, publisher signature verification and
service installation are **not completed**. Individual Connect/Read/Write
operations now use bounded Win32 overlapped I/O and cancellation, with
hard process termination if an outstanding cancellation cannot safely
drain; this is not equivalent to a hardened supervising service.
The currently connected Local Workspace tools
still grant broad script/command access, which cannot be safely
claimed to be constrained by this standalone broker.

This experimental named-pipe endpoint is NOT a listener on an external
TCP port; it is an OS IPC object, opened only in disposable tests. No
change was made to running MCP registration, tunnel, Windows service
accounts, filesystem ACLs or the five-agent coordinator.

A production-ready design requires **all** of the following before
connecting the adapter:

1. Launch the broker under a **separate Windows service account** (or
   genuinely isolated container/VM with protected host mounts), with
   exclusive write access to its journal/outbox, policy file and startup
   configuration. The agent/MCP caller must not possess those permissions.
2. Provision public key grants and immutable policy revision through a
   trusted host path. Grant issuance, key rotation, revocation and renewal
   require a separate authenticated owner workflow. All signing private
   keys reside outside the repository and agent-accessible filesystem.
3. Configure the **actual** MCP server registry to expose the restricted
   broker calls only for appropriately authenticated identities. Remove
   unrestricted `run_command`, `run_script`, arbitrary file writes and
   direct SQLite access from those agent identities. Maintain a separately
   controlled owner/admin plane for debugging.
4. Authenticate the broker IPC peer independently of request content.
   Protect executable and config files from edits by the agent account;
   add Windows ACL and process-token tests. In the current implementation,
   stdio by itself does **not** authenticate its parent process.
5. Enforce accepted host lease ownership against the existing canonical
   coordinator, not merely an epoch number in a pinned test fixture.
   Never synthesize `PLAN`, `LEASE`, approval, QA evidence, source digests,
   new capability grants or a key's revocation status from agent text.
6. Add **trusted** transport delivery/result receipts and reconciliation
   for `SEND_UNCERTAIN`. Neither this broker nor the MCP adapter sends
   anything over the network. An accepted cryptographic worker receipt
   only validates a signature, not that an effect actually happened.
7. Apply rate limits, startup and lock contention budgets, backup/restore
   and anchored integrity checks to the real environment. Test high
   concurrency, denial-of-service, power-cut recovery, Windows ACL escapes
   and key compromise before any production rollout.
8. Obtain owner-approved canonical OpenSpec/SDD changes and independent
   review. The current experiment is an implementation reference, not
   permission to modify production tools or the active five-agent queue.

## Threat/verification matrix

| Threat / failure | Prototype test evidence | Remaining limitation |
|---|---|---|
| Forged command / role escalation | Ed25519 signature, pinned key grants, role+scope tests | Host must pin policy with OS ACL |
| Unsigned or self-issued key | Fail closed; no dynamic key enrollment | Admin key lifecycle not implemented |
| Changed policy bytes | SHA-256 startup pin mismatch blocks broker | Startup parameters must be protected |
| Replayed nonce or request ID | Durable SQLite unique constraints, restart test | Same-user SQLite edits can defeat it |
| Interrupted transaction | Atomic INTENT/outbox/auth claim; injected failures | External side effects remain ambiguous |
| Invalid or oversized JSON | Bounded strict decoder; fatal frame errors | Resource limits at OS level needed |
| Bypassing authorization from another MCP tool | **Not protected in live host** | Remove or segregate privileged tools |
| External effect / worker receipt fraud | Not performed by broker; signed receipt module is separate | Independent result attestation needed |

## Local verification (fixtures only)

Use the existing unittest suites:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\foundation_kernel
python -m unittest test_broker_stdio test_broker_mcp_bridge -v
python -m unittest discover -q
```

No signing-key files, real project state or live MCP configuration are
required by these tests. Each test creates disposable temp SQLite files
and memory-only Ed25519 keys. **Never use live `.agent-team` databases
as a broker fixture.**

## Next ordered engineering milestones

1. Host-controlled key provisioning and policy versioning (no self-issuance).
2. OS-isolated broker identity + Windows ACL enforcement with negative tests.
3. Strictly limited MCP registry wiring in a **separate canary profile**,
   retaining current functionality for the owner.
4. Read-only state reconciliation tool for lost signed request responses.
5. Authenticated host lease proof and worker receipt chain.
6. Canary QA, independent review, explicit owner-approved deployment.

**Gate:** do not claim host-enforced isolation or deployment readiness
until 1–6 are evidenced end to end on the actual host.
