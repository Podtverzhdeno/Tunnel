"""Subprocess end-to-end tests for isolated stdio authorization broker.

Only disposable temp directories and ephemeral Ed25519 keys.
Does not connect to MCP, host tunnel, live SQLite, network or real agents.
"""
from __future__ import annotations
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime,timezone,timedelta

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend missing") from exc

try:
    from .transition import canonical
    from .journal import Journal
    from .host_auth import DOMAIN,SCHEMA
    from .broker_stdio import PROTOCOL,POLICY_SCHEMA
except ImportError:
    from transition import canonical
    from journal import Journal
    from host_auth import DOMAIN,SCHEMA
    from broker_stdio import PROTOCOL,POLICY_SCHEMA

SPEC="a"*64
INPUT="b"*64
SCOPE="project-broker"

def pubkey(key):
    return base64.b64encode(
        key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
    ).decode("ascii")

class BrokerStdioTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.policy_path=self.root/"fixture-pinned-policy.json"
        self.dev=Ed25519PrivateKey.generate()
        self.dispatcher=Ed25519PrivateKey.generate()
        self.policy={
            "schema":POLICY_SCHEMA,"scope":SCOPE,
            "grants":[self.grant(self.dev,"dev-key","developer",
                                 "dev-1",["STAGE_INTENT","QUERY_COMMAND_STATUS"]),
                      self.grant(self.dispatcher,"dispatcher-key",
                                 "dispatcher","dispatcher-1",
                                 ["MARK_SEND_UNCERTAIN","QUERY_COMMAND_STATUS"])],
        }
        self.write_policy()
        with Journal(self.root,"execution_journal_broker.sqlite3") as journal:
            journal.append("run-1","step-1","plan","PLAN",0,SPEC)
            journal.append("run-1","step-1","lease","LEASE",1)
        self.now=datetime.now(timezone.utc).replace(microsecond=0)

    @staticmethod
    def grant(key,key_id,role,principal_id,capabilities):
        return {
            "key_id":key_id,"role":role,"principal_id":principal_id,
            "scope":SCOPE,"run_id":"run-1","step_id":"step-1",
            "epoch":1,"policy_revision":1,
            "public_key_b64":pubkey(key),
            "capabilities":capabilities,"revoked":False,
        }

    def write_policy(self):
        self.policy_path.write_bytes(canonical(self.policy))
        self.policy_sha=hashlib.sha256(self.policy_path.read_bytes()).hexdigest()

    def signed(self,op, *, request_id=None,nonce=None,who=None,mod=None):
        if op=="stage_intent":
            args={"message_id":"message-1","destination":"worker-1",
                  "payload_sha":INPUT}
            key,role,key_id,principal=self.dev,"developer","dev-key","dev-1"
            req="request-stage"
            n="a"*32
            action="STAGE_INTENT"
        elif op=="mark_send_uncertain":
            args={"message_id":"message-1","attempt_id":"attempt-1"}
            key,role,key_id,principal=(
                self.dispatcher,"dispatcher","dispatcher-key","dispatcher-1")
            req="request-mark"
            n="b"*32
            action="MARK_SEND_UNCERTAIN"
        elif op=="query_command_status":
            args={"message_id":"message-1","target_request_id":"request-stage"}
            key,role,key_id,principal=self.dev,"developer","dev-key","dev-1"
            req="request-query"
            n="c"*32
            action="QUERY_COMMAND_STATUS"
        else:
            raise AssertionError(op)
        if who=="dev":
            key,role,key_id,principal=self.dev,"developer","dev-key","dev-1"
        if who=="dispatcher":
            key,role,key_id,principal=(
                self.dispatcher,"dispatcher","dispatcher-key","dispatcher-1")
        req=request_id or req
        n=nonce or n
        issued=(self.now-timedelta(seconds=4)).strftime("%Y-%m-%dT%H:%M:%SZ")
        expires=(self.now+timedelta(seconds=48)).strftime("%Y-%m-%dT%H:%M:%SZ")
        doc={
            "schema":SCHEMA,"principal_id":principal,"role":role,
            "key_id":key_id,"policy_revision":1,
            "scope":SCOPE,"run_id":"run-1","step_id":"step-1","epoch":1,
            "request_id":req,"nonce":n,"action":action,
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":issued,"expires_utc":expires,
        }
        if mod:
            doc.update(mod)
        auth={"document":doc,"signature_b64":base64.b64encode(
            key.sign(DOMAIN+canonical(doc))).decode("ascii")}
        return {"protocol":PROTOCOL,"op":op,"auth":auth,
                "run_id":"run-1","step_id":"step-1","request_id":req,
                "epoch":1,**args}

    def call(self,requests,*,policy_sha=None,raw=False):
        argv=[
            sys.executable,str(Path(__file__).resolve().parent/"broker_stdio.py"),
            "--root",str(self.root),"--policy",str(self.policy_path),
            "--expected-policy-sha256",policy_sha or self.policy_sha,
            "--legacy-unsigned-policy-for-tests",
        ]
        if raw:
            payload=requests
        else:
            payload=b"".join(
                json.dumps(r,sort_keys=True,separators=(",",":")).encode("utf-8")+b"\n"
                for r in requests)
        proc=subprocess.run(argv,input=payload,stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,timeout=12,check=False)
        output=[
            json.loads(line) for line in proc.stdout.splitlines()
        ]
        return proc,output

    def state(self):
        with Journal(self.root,"execution_journal_broker.sqlite3") as journal:
            return journal.verify("run-1")

    def test_query_lost_response_after_new_subprocess(self):
        first,one=self.call([self.signed("stage_intent")])
        self.assertTrue(one[0]["ok"],one)
        before=self.state()["events_examined"]
        child,out=self.call([self.signed("query_command_status")])
        self.assertEqual(child.returncode,0,child.stderr.decode(errors="replace"))
        self.assertTrue(out[0]["ok"],out)
        state=out[0]["result"]
        self.assertTrue(state["recorded"])
        self.assertEqual(state["outbox_phase"],"INTENT_STAGED")
        self.assertFalse(state["automatic_retry_permitted"])
        self.assertFalse(state["changes_written"])
        self.assertEqual(self.state()["events_examined"],before)

    def test_missing_query_claim_is_not_retry_permission(self):
        child,out=self.call([self.signed("query_command_status")])
        self.assertEqual(child.returncode,0)
        self.assertTrue(out[0]["ok"])
        self.assertFalse(out[0]["result"]["recorded"])
        self.assertFalse(out[0]["result"]["automatic_retry_permitted"])

    def test_query_wrong_principal_fails_closed(self):
        self.call([self.signed("stage_intent")])
        child,out=self.call([self.signed("query_command_status",who="dispatcher")])
        self.assertEqual(child.returncode,0)
        self.assertFalse(out[0]["ok"])
        self.assertEqual(out[0]["error"],"RECONCILE_TARGET_NOT_AUTHORIZED")

    def test_health_only_no_tool_leak(self):
        proc,out=self.call([{"protocol":PROTOCOL,"op":"health"}])
        self.assertEqual(proc.returncode,0,proc.stderr.decode(errors="replace"))
        self.assertEqual(len(out),1)
        self.assertTrue(out[0]["ready"])
        self.assertFalse(out[0]["mcp_connected"])
        self.assertFalse(out[0]["unrestricted_tool_access_removed"])

    def test_staged_and_marked_in_separate_processes(self):
        first,out=self.call([self.signed("stage_intent")])
        self.assertEqual(first.returncode,0,first.stderr.decode(errors="replace"))
        self.assertTrue(out[0]["ok"],out)
        self.assertEqual(out[0]["result"]["authenticated_role"],"developer")
        self.assertFalse(out[0]["result"]["live_mcp_host_enforced"])
        self.assertEqual(self.state()["events_examined"],3)
        second,result=self.call([self.signed("mark_send_uncertain")])
        self.assertEqual(second.returncode,0,second.stderr.decode(errors="replace"))
        self.assertTrue(result[0]["ok"],result)
        self.assertEqual(result[0]["result"]["phase"],"SEND_UNCERTAIN")
        self.assertFalse(result[0]["result"]["transport_invoked"])
        self.assertFalse(result[0]["result"]["automatic_retry_permitted"])

    def test_two_commands_in_one_stream(self):
        _,result=self.call([self.signed("stage_intent"),
                            self.signed("mark_send_uncertain")])
        self.assertEqual(len(result),2)
        self.assertTrue(all(r["ok"] for r in result),result)
        self.assertEqual(self.state()["events_examined"],3)

    def test_replay_after_restart_denied_no_second_intent(self):
        self.call([self.signed("stage_intent")])
        _,output=self.call([self.signed("stage_intent")])
        self.assertFalse(output[0]["ok"])
        self.assertEqual(output[0]["error"],
                         "HOST_REQUEST_OR_NONCE_ALREADY_CONSUMED")
        self.assertEqual(self.state()["events_examined"],3)

    def test_unsigned_command_denied_before_state_change(self):
        cmd=self.signed("stage_intent")
        cmd["auth"]={}
        _,output=self.call([cmd])
        self.assertFalse(output[0]["ok"])
        self.assertEqual(self.state()["events_examined"],2)

    def test_dispatcher_cannot_stage_dev_task(self):
        _,output=self.call([self.signed("stage_intent",who="dispatcher")])
        self.assertEqual(output[0]["error"],"HOST_CAPABILITY_DENIED")
        self.assertEqual(self.state()["events_examined"],2)

    def test_developer_cannot_mark_send(self):
        self.call([self.signed("stage_intent")])
        _,output=self.call([self.signed("mark_send_uncertain",who="dev")])
        self.assertEqual(output[0]["error"],"HOST_CAPABILITY_DENIED")

    def test_self_issued_key_denied(self):
        req=self.signed("stage_intent")
        other=Ed25519PrivateKey.generate()
        req["auth"]["document"]["key_id"]="selfissued"
        req["auth"]["signature_b64"]=base64.b64encode(
            other.sign(DOMAIN+canonical(req["auth"]["document"]))
        ).decode("ascii")
        _,output=self.call([req])
        self.assertEqual(output[0]["error"],"HOST_KEY_UNKNOWN_OR_REVOKED")

    def test_revocation_in_pinned_policy(self):
        self.policy["grants"][0]["revoked"]=True
        self.write_policy()
        _,output=self.call([self.signed("stage_intent")])
        self.assertEqual(output[0]["error"],"HOST_KEY_UNKNOWN_OR_REVOKED")
        self.assertEqual(self.state()["events_examined"],2)

    def test_modified_policy_denied_by_digest_pin(self):
        digest=self.policy_sha
        self.policy["grants"][0]["revoked"]=True
        self.write_policy()
        proc,result=self.call([self.signed("stage_intent")],policy_sha=digest)
        self.assertEqual(proc.returncode,3)
        self.assertEqual(result,[{"ok":False,"error":"BROKER_STARTUP_DENIED"}])
        self.assertEqual(self.state()["events_examined"],2)

    def test_duplicate_json_fields_denied(self):
        raw=b'{"protocol":"foundation-broker-stdio-v1","op":"health","op":"stage_intent"}\n'
        proc,output=self.call(raw,raw=True)
        self.assertEqual(proc.returncode,0)
        self.assertEqual(output,[{"ok":False,"error":"DUPLICATE_JSON_FIELD"}])

    def test_oversized_frame_fail_closed_and_stop(self):
        raw=b'{"large":"' + b"x"*17000 + b'"}\n'
        proc,result=self.call(raw,raw=True)
        self.assertEqual(proc.returncode,2)
        self.assertEqual(result[0]["error"],"BROKER_FRAME_TOO_LARGE_OR_UNTERMINATED")
        self.assertEqual(self.state()["events_examined"],2)

    def test_unterminated_frame_fail_closed(self):
        proc,result=self.call(b'{"protocol":"foundation-broker-stdio-v1","op":"health"}',
                              raw=True)
        self.assertEqual(proc.returncode,2)
        self.assertEqual(result[0]["error"],"BROKER_FRAME_TOO_LARGE_OR_UNTERMINATED")

    def test_unknown_op_cannot_execute_code(self):
        _,result=self.call([{"protocol":PROTOCOL,"op":"run_command",
                             "command":"powershell","args":["whoami"]}])
        self.assertEqual(result[0]["error"],"BROKER_OPERATION_DENIED")

    def test_payload_with_extra_fields_denied(self):
        cmd=self.signed("stage_intent")
        cmd["owner_approval"]=True
        _,result=self.call([cmd])
        self.assertEqual(result[0]["error"],"BROKER_FIELDS_INVALID")
        self.assertEqual(self.state()["events_examined"],2)

    def test_wrong_run_in_signed_command_rejected(self):
        cmd=self.signed("stage_intent")
        cmd["run_id"]="run-other"
        _,result=self.call([cmd])
        self.assertEqual(result[0]["error"],"HOST_COMMAND_CONTEXT_MISMATCH")
        self.assertEqual(self.state()["events_examined"],2)

    def test_missing_policy_file_fails_startup(self):
        self.policy_path.unlink()
        proc,result=self.call([{"protocol":PROTOCOL,"op":"health"}])
        self.assertEqual(proc.returncode,3)
        self.assertEqual(result[0]["error"],"BROKER_STARTUP_DENIED")

    def test_initialization_never_creates_plan_lease(self):
        self.assertEqual(self.state()["events_examined"],2)
        _,result=self.call([{"protocol":PROTOCOL,"op":"health"}])
        self.assertTrue(result[0]["ok"])
        self.assertEqual(self.state()["events_examined"],2)

    def test_malformed_request_does_not_kill_following_valid_health(self):
        raw=b'not-json\n'+json.dumps(
            {"protocol":PROTOCOL,"op":"health"}).encode()+b"\n"
        proc,result=self.call(raw,raw=True)
        self.assertEqual(proc.returncode,0)
        self.assertEqual(result[0]["error"],"INVALID_JSON")
        self.assertTrue(result[1]["ok"])

if __name__=="__main__":
    unittest.main()
