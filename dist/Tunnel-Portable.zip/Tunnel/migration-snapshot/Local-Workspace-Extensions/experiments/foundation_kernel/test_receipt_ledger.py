"""Signed receipt ledger tests: duplicate, restart, concurrency, evidence drift."""
from __future__ import annotations
import base64
import tempfile
import threading
import sqlite3
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
from unittest.mock import patch

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend is not installed") from exc

try:
    from .transition import canonical
    from .signed_receipts import SCHEMA,PublicKeyGrant,TrustStore,ReceiptError
    from .evidence_store import EvidenceStore
    from .receipt_ledger import ReceiptLedger,ReceiptLedgerError
except ImportError:
    from transition import canonical
    from signed_receipts import SCHEMA,PublicKeyGrant,TrustStore,ReceiptError
    from evidence_store import EvidenceStore
    from receipt_ledger import ReceiptLedger,ReceiptLedgerError

NOW=datetime(2026,11,2,12,0,0,tzinfo=timezone.utc)
SPEC="a"*64
INPUT="c"*64

class ReceiptLedgerTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.store=EvidenceStore(self.root)
        self.evidence=self.store.put("worker_receipt",SPEC,{"exit_code":0})
        self.key=Ed25519PrivateKey.generate()
        public=self.key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.grant=PublicKeyGrant("key-1",public,"worker-1","worker",
                                  "project-1",frozenset({"WORKER_RESULT"}))
        self.trust=TrustStore((self.grant,))
        self.doc=dict(schema=SCHEMA,receipt_id="receipt-1",run_id="run-1",
                      step_id="step-1",request_id="request-1",
                      worker_id="worker-1",key_id="key-1",role="worker",
                      scope="project-1",kind="WORKER_RESULT",source_sha=SPEC,input_sha=INPUT,
                      evidence_sha=self.evidence["sha256"],epoch=1,
                      issued_utc="2026-11-02T11:59:00Z",
                      expires_utc="2026-11-02T12:04:00Z")
        self.ledger=ReceiptLedger(self.root)
        self.addCleanup(lambda: self.ledger.close())

    def signed(self,**updates):
        document={**self.doc,**updates}
        return {"document":document,
                "signature_b64":base64.b64encode(
                    self.key.sign(canonical(document))).decode("ascii")}

    def admit(self,receipt=None,**expected):
        return self.ledger.admit(
            self.signed() if receipt is None else receipt,
            self.trust,self.store,now=NOW,run_id="run-1",
            step_id="step-1",request_id="request-1",
            source_sha=SPEC,input_sha=INPUT,evidence_sha=self.evidence["sha256"],
            kind="WORKER_RESULT",epoch=1,scope="project-1",
            **expected)

    def test_valid_admission_no_authorization_claim(self):
        result=self.admit()
        self.assertTrue(result["signature_verified"])
        self.assertFalse(result["can_accept_or_deploy"])
        self.assertFalse(result["external_effect_verified"])
        self.assertFalse(result["host_identity_authenticated"])
        self.assertEqual(len(self.ledger.summary()["receipts"]),1)

    def test_exact_duplicate_receipt_idempotent(self):
        a=self.admit()
        b=self.admit()
        self.assertFalse(a["idempotent_replay"])
        self.assertTrue(b["idempotent_replay"])
        self.assertEqual(len(self.ledger.summary()["receipts"]),1)

    def test_changed_receipt_same_id_rejected(self):
        self.admit()
        different=self.signed(issued_utc="2026-11-02T11:59:01Z")
        with self.assertRaisesRegex(ReceiptLedgerError,"RECEIPT_ID_REPLAY_CONFLICT"):
            self.admit(different)

    def test_new_receipt_id_same_operation_rejected(self):
        self.admit()
        different=self.signed(receipt_id="receipt-2")
        with self.assertRaisesRegex(ReceiptLedgerError,"RECEIPT_OPERATION_ALREADY_CLAIMED"):
            self.admit(different)

    def test_missing_evidence_denied_before_sql(self):
        p=self.store.root/self.evidence["sha256"][:2]/(
            self.evidence["sha256"]+".json")
        p.unlink()
        with self.assertRaisesRegex(ReceiptLedgerError,"EVIDENCE_LOCAL_BINDING_INVALID"):
            self.admit()
        self.assertEqual(self.ledger.summary()["receipts"],[])

    def test_evidence_tamper_denied_before_sql(self):
        p=self.store.root/self.evidence["sha256"][:2]/(
            self.evidence["sha256"]+".json")
        p.write_bytes(b"bad")
        with self.assertRaisesRegex(ReceiptLedgerError,"EVIDENCE_LOCAL_BINDING_INVALID"):
            self.admit()
        self.assertEqual(self.ledger.summary()["receipts"],[])

    def test_wrong_evidence_source_sha_denied(self):
        other=self.store.put("worker_receipt","f"*64,{"exit_code":0})
        d=self.signed(evidence_sha=other["sha256"])
        with self.assertRaisesRegex(ReceiptLedgerError,"EVIDENCE_LOCAL_BINDING_INVALID"):
            self.ledger.admit(
                d,self.trust,self.store,now=NOW,run_id="run-1",
                step_id="step-1",request_id="request-1",source_sha=SPEC,
                input_sha=INPUT,evidence_sha=other["sha256"],kind="WORKER_RESULT",
                epoch=1,scope="project-1")

    def test_signature_tampered_denied_before_sql(self):
        signed=self.signed()
        signed["signature_b64"]=signed["signature_b64"][::-1]
        with self.assertRaises(ReceiptError):
            self.admit(signed)
        self.assertEqual(self.ledger.summary()["receipts"],[])

    def test_revoked_key_cannot_replay(self):
        self.admit()
        revoked=PublicKeyGrant("key-1",self.grant.public_key,
            "worker-1","worker","project-1",
            frozenset({"WORKER_RESULT"}),revoked=True)
        self.trust=TrustStore((revoked,))
        with self.assertRaisesRegex(ReceiptError,"TRUST_KEY_UNKNOWN_OR_REVOKED"):
            self.admit()

    def test_expired_key_receipt_not_replayable(self):
        self.admit()
        self.ledger.close()
        self.ledger=ReceiptLedger(self.root)
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_EXPIRED"):
            self.ledger.admit(self.signed(),self.trust,self.store,
                now=NOW+timedelta(hours=1),run_id="run-1",step_id="step-1",
                request_id="request-1",source_sha=SPEC,input_sha=INPUT,
                evidence_sha=self.evidence["sha256"],
                kind="WORKER_RESULT",epoch=1,scope="project-1")

    def test_restart_preserves_dedupe(self):
        self.admit()
        self.ledger.close()
        self.ledger=ReceiptLedger(self.root)
        self.assertTrue(self.admit()["idempotent_replay"])
        self.assertEqual(len(self.ledger.summary()["receipts"]),1)

    def test_different_step_epoch_allowed(self):
        self.admit()
        other=self.signed(receipt_id="receipt-2",step_id="step-2",
                          epoch=2,request_id="request-2")
        result=self.ledger.admit(
            other,self.trust,self.store,now=NOW,run_id="run-1",
            step_id="step-2",request_id="request-2",
            source_sha=SPEC,input_sha=INPUT,evidence_sha=self.evidence["sha256"],
            kind="WORKER_RESULT",epoch=2,scope="project-1")
        self.assertTrue(result["ok"])
        self.assertEqual(len(self.ledger.summary()["receipts"]),2)

    def test_racing_workers_same_receipt_only_one_insert(self):
        barrier=threading.Barrier(2)
        results=[]
        problems=[]
        def worker():
            try:
                with ReceiptLedger(self.root) as ledger:
                    barrier.wait(timeout=6)
                    results.append(ledger.admit(
                        self.signed(),self.trust,self.store,now=NOW,
                        run_id="run-1",step_id="step-1",
                        request_id="request-1",source_sha=SPEC,input_sha=INPUT,
                        evidence_sha=self.evidence["sha256"],
                        kind="WORKER_RESULT",epoch=1,scope="project-1"))
            except Exception as exc: problems.append(str(exc))
        a=threading.Thread(target=worker)
        b=threading.Thread(target=worker)
        a.start();b.start();a.join(8);b.join(8)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(problems,[])
        self.assertEqual(len(results),2)
        self.assertEqual(sum(not x["idempotent_replay"] for x in results),1)

    def test_sql_trigger_failure_rolls_back(self):
        self.ledger.db.execute(
            "CREATE TRIGGER deny_insert BEFORE INSERT ON receipt_claims "
            "BEGIN SELECT RAISE(ABORT,'injected crash'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            self.admit()
        self.assertEqual(self.ledger.summary()["receipts"],[])
        self.ledger.db.execute("DROP TRIGGER deny_insert")
        self.assertTrue(self.admit()["ok"])

    def test_storage_capacity_rejected_with_idempotent_replay(self):
        from importlib import import_module
        module=import_module(ReceiptLedger.__module__)
        self.admit()
        with patch.object(module,"MAX_RECEIPTS",1):
            self.assertTrue(self.admit()["idempotent_replay"])
            with self.assertRaisesRegex(ReceiptLedgerError,"CAPACITY_REACHED"):
                self.ledger.admit(
                    self.signed(receipt_id="receipt-2",step_id="step-2"),
                    self.trust,self.store,now=NOW,run_id="run-1",
                    step_id="step-2",request_id="request-1",source_sha=SPEC,
                    input_sha=INPUT,evidence_sha=self.evidence["sha256"],
                    kind="WORKER_RESULT",epoch=1,scope="project-1")

    def test_foreign_database_not_opened(self):
        self.ledger.close()
        file=self.root/"verified_receipt_ledger_v1.sqlite3"
        file.unlink()
        conn=sqlite3.connect(file)
        try:
            conn.execute("CREATE TABLE random_table (id INT)")
            conn.commit()
        finally:
            conn.close()
        with self.assertRaisesRegex(ReceiptLedgerError,"EXISTING_UNRECOGNIZED_LEDGER"):
            ReceiptLedger(self.root)

if __name__=="__main__":
    unittest.main()
