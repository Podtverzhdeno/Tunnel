"""Real Win32 named-pipe broker + signed policy + SQLite tests.

Uses ONLY temporary files, in-memory Ed25519 keys and a separate child
process under the SAME Windows SID. The positive fixture explicitly does not
demonstrate production OS privilege separation. No MCP host configuration.
"""
from __future__ import annotations

import base64
import hashlib
import json
import secrets
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 backend unavailable") from exc

try:
    from .transition import canonical
    from .signed_policy import DOMAIN as POLICY_DOMAIN, SCHEMA as POLICY_SCHEMA
    from .host_auth import DOMAIN as HOST_DOMAIN,SCHEMA as HOST_SCHEMA
    from .journal import Journal
    from .win_pipe_ipc import request_once
    from .windows_isolation import current_user_sid
except ImportError:
    from transition import canonical
    from signed_policy import DOMAIN as POLICY_DOMAIN, SCHEMA as POLICY_SCHEMA
    from host_auth import DOMAIN as HOST_DOMAIN,SCHEMA as HOST_SCHEMA
    from journal import Journal
    from win_pipe_ipc import request_once
    from windows_isolation import current_user_sid

BROKER_PROTO="foundation-broker-stdio-v1"
SOURCE="a"*64
PAYLOAD="b"*64

@unittest.skipUnless(sys.platform=="win32","Win32 SID-authenticated pipe only")
class NamedPipeSignedBrokerTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.suffix=secrets.token_hex(12)
        self.sid=current_user_sid()
        self.owner=Ed25519PrivateKey.generate()
        self.agent=Ed25519PrivateKey.generate()
        pub=self.agent.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.owner_hex=self.owner.public_key().public_bytes(
            Encoding.Raw,PublicFormat.Raw).hex()
        self.policy_path=self.root/"test-policy.json"
        self.bundle_path=self.root/"test-bundle.json"
        self.policy={
            "schema":"foundation-pinned-policy-v1",
            "scope":"sandbox-1",
            "grants":[{
                "principal_id":"dev-1","role":"developer",
                "key_id":"dev-key","public_key_b64":base64.b64encode(pub).decode(),
                "scope":"sandbox-1","run_id":"run-1","step_id":"step-1",
                "epoch":1,"policy_revision":1,
                "capabilities":["STAGE_INTENT","QUERY_COMMAND_STATUS"],
                "revoked":False,
            }],
        }
        policy_bytes=canonical(self.policy)
        self.policy_path.write_bytes(policy_bytes)
        clock=datetime.now(timezone.utc).replace(microsecond=0)
        self.now=clock
        signed={
            "schema":POLICY_SCHEMA,"issuer_id":"offline-owner-key",
            "revision":1,
            "issued_utc":(clock-timedelta(seconds=20)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(clock+timedelta(hours=1)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "policy_sha256":hashlib.sha256(policy_bytes).hexdigest(),
        }
        signed["signature_b64"]=base64.b64encode(
            self.owner.sign(POLICY_DOMAIN+canonical(signed))).decode()
        self.bundle_path.write_bytes(canonical(signed))
        self.db_name="execution_journal_broker.sqlite3"
        with Journal(self.root,self.db_name) as db:
            db.append("run-1","step-1","plan","PLAN",0,SOURCE)
            db.append("run-1","step-1","lease","LEASE",1)

    def argv(self,max_connections=1,*,fixture=True,issuer_hex=None):
        argv=[
            sys.executable,
            str(Path(__file__).resolve().parent/"broker_named_pipe.py"),
            "--root",str(self.root),
            "--policy",str(self.policy_path),
            "--signed-policy-bundle",str(self.bundle_path),
            "--trusted-issuer-public-hex",issuer_hex or self.owner_hex,
            "--broker-sid",self.sid,"--client-sid",self.sid,
            "--pipe-suffix",self.suffix,
            "--max-connections",str(max_connections),
        ]
        if fixture:
            argv.append("--offline-same-sid-fixture")
        return argv

    def launch(self,max_connections=1):
        child=subprocess.Popen(
            self.argv(max_connections),cwd=Path(__file__).resolve().parent,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL)
        line=child.stdout.readline()
        try:
            first=json.loads(line)
        except Exception:
            child.kill()
            out,err=child.communicate(timeout=5)
            self.fail("BROKER_CHILD_STARTUP_NOT_JSON: "+
                      (line+out+err)[:1500].decode(errors="replace"))
        if not first.get("starting"):
            child.kill()
            child.communicate(timeout=5)
            self.fail("BROKER_CHILD_DID_NOT_START: "+str(first))
        self.assertEqual(first["mode"],"SAME_SID_TEST_ONLY")
        self.assertFalse(first["os_isolated"])
        return child

    def send(self,payload):
        response=request_once(
            self.suffix,canonical(payload),expected_server_sid=self.sid)
        return json.loads(response.decode("utf-8"))

    def health(self):
        return {"protocol":BROKER_PROTO,"op":"health"}

    def stage(self):
        args={"message_id":"msg-1","destination":"worker-1",
              "payload_sha":PAYLOAD}
        return self.signed("STAGE_INTENT","request-stage","1"*32,args,
                           "stage_intent")

    def query(self):
        args={"message_id":"msg-1","target_request_id":"request-stage"}
        return self.signed("QUERY_COMMAND_STATUS","request-query","2"*32,
                           args,"query_command_status")

    def signed(self,action,request_id,nonce,args,op):
        doc={
            "schema":HOST_SCHEMA,"principal_id":"dev-1","role":"developer",
            "key_id":"dev-key","policy_revision":1,"scope":"sandbox-1",
            "run_id":"run-1","step_id":"step-1","epoch":1,
            "request_id":request_id,"nonce":nonce,"action":action,
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":(self.now-timedelta(seconds=4)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(self.now+timedelta(seconds=65)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
        }
        auth={"document":doc,"signature_b64":base64.b64encode(
            self.agent.sign(HOST_DOMAIN+canonical(doc))).decode()}
        return {
            "protocol":BROKER_PROTO,"op":op,"auth":auth,
            "run_id":"run-1","step_id":"step-1","request_id":request_id,
            "epoch":1,**args,
        }

    def close_child(self,child,connections=1):
        try:
            code=child.wait(timeout=8)
            rest=child.stdout.read().decode("utf-8",errors="replace")
            error=child.stderr.read().decode("utf-8",errors="replace")
            self.assertEqual(code,0,error[:1000])
            result=json.loads(rest.strip())
            self.assertEqual(result["completed"],connections)
            self.assertTrue(result["peer_token_verified"])
            self.assertFalse(result["production_mcp_enforced"])
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)
            child.stdout.close()
            child.stderr.close()

    def call_mcp_pipe(self,requests,*,expected_sid=None):
        script=Path(__file__).resolve().parent/"broker_pipe_mcp_bridge.py"
        argv=[
            sys.executable,str(script),
            "--pipe-suffix",self.suffix,
            "--expected-server-sid",expected_sid or self.sid,
        ]
        payload=b"".join(canonical(request)+b"\n" for request in requests)
        process=subprocess.run(
            argv,input=payload,stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,timeout=18,check=False)
        return process,[json.loads(line) for line in process.stdout.splitlines()]

    @staticmethod
    def mcp_request(name, data, ident):
        return {
            "jsonrpc":"2.0","id":ident,"method":"tools/call",
            "params":{"name":name,"arguments":{
                k:v for k,v in data.items() if k not in {"protocol","op"}}},
        }

    def test_real_mcp_bridge_over_pinned_named_pipe_with_reconciliation(self):
        server=self.launch(max_connections=2)
        try:
            requests=[
                {"jsonrpc":"2.0","id":1,"method":"tools/list"},
                self.mcp_request("broker_stage_intent",self.stage(),2),
                self.mcp_request("broker_query_command_status",self.query(),3),
            ]
            result,responses=self.call_mcp_pipe(requests)
            self.assertEqual(result.returncode,0,result.stderr.decode(errors="replace"))
            self.assertEqual(len(responses),3)
            tools={x["name"] for x in responses[0]["result"]["tools"]}
            self.assertEqual(tools,{
                "broker_health","broker_stage_intent",
                "broker_mark_send_uncertain",
                "broker_query_command_status",
            })
            self.assertFalse(responses[1]["result"]["isError"],responses)
            self.assertFalse(responses[2]["result"]["isError"],responses)
            query=json.loads(
                responses[2]["result"]["content"][0]["text"])["result"]
            self.assertTrue(query["recorded"])
            self.assertTrue(query["message_link_verified"])
            self.assertFalse(query["automatic_retry_permitted"])
            self.assertFalse(query["changes_written"])
        finally:
            self.close_child(server,connections=2)
        with Journal(self.root,self.db_name) as journal:
            self.assertEqual(journal.verify("run-1")["events_examined"],3)

    def test_mcp_pipe_replay_after_restart_is_not_dispatched_twice(self):
        first=self.launch()
        try:
            result,replies=self.call_mcp_pipe([
                self.mcp_request("broker_stage_intent",self.stage(),1)
            ])
            self.assertFalse(replies[0]["result"]["isError"],replies)
        finally:
            self.close_child(first)
        second=self.launch()
        try:
            result,replies=self.call_mcp_pipe([
                self.mcp_request("broker_stage_intent",self.stage(),2)
            ])
            self.assertTrue(replies[0]["result"]["isError"],replies)
            text=json.loads(replies[0]["result"]["content"][0]["text"])
            self.assertEqual(text["error"],"HOST_REQUEST_OR_NONCE_ALREADY_CONSUMED")
        finally:
            self.close_child(second)

    def test_pipe_mcp_refuses_unpinned_server_before_command(self):
        expected="S-1-5-19" if self.sid!="S-1-5-19" else "S-1-5-18"
        server=self.launch()
        try:
            process,replies=self.call_mcp_pipe(
                [self.mcp_request("broker_stage_intent",self.stage(),1)],
                expected_sid=expected)
            self.assertEqual(process.returncode,0)
            self.assertTrue(replies[0]["result"]["isError"])
            response=json.loads(replies[0]["result"]["content"][0]["text"])
            self.assertEqual(response["error"],"PIPE_MCP_PEER_OR_PROTOCOL_DENIED")
            server.wait(timeout=8)
            self.assertEqual(server.returncode,3)
        finally:
            if server.poll() is None: server.kill();server.communicate(timeout=5)
            server.stdout.close()
            server.stderr.close()
        with Journal(self.root,self.db_name) as db:
            self.assertEqual(db.verify("run-1")["events_examined"],2)

    def test_health_through_real_named_pipe_and_signed_policy(self):
        child=self.launch()
        try:
            result=self.send(self.health())
            self.assertTrue(result["ok"],result)
            self.assertFalse(result["mcp_connected"] if "mcp_connected" in result else
                             result["external_effects_performed"])
        finally:
            self.close_child(child)

    def test_mutation_has_auth_and_sqlite_atomicity(self):
        child=self.launch()
        try:
            reply=self.send(self.stage())
            self.assertTrue(reply["ok"],reply)
            self.assertEqual(reply["result"]["authenticated_role"],"developer")
            self.assertFalse(reply["result"]["live_mcp_host_enforced"])
        finally:
            self.close_child(child)
        with Journal(self.root,self.db_name) as db:
            report=db.verify("run-1")
            self.assertEqual(report["events_examined"],3)
            row=db.db.execute(
                "SELECT message_id,phase FROM atomic_outbox").fetchone()
            self.assertEqual(row,("msg-1","INTENT_STAGED"))
            count=db.db.execute(
                "SELECT count(*) FROM host_gate_claims").fetchone()[0]
            self.assertEqual(count,1)

    def test_query_after_broker_restarts_no_second_mutation(self):
        child=self.launch()
        try: self.assertTrue(self.send(self.stage())["ok"])
        finally: self.close_child(child)
        child=self.launch()
        try:
            reply=self.send(self.query())
            self.assertTrue(reply["ok"],reply)
            found=reply["result"]
            self.assertTrue(found["recorded"])
            self.assertFalse(found["changes_written"])
            self.assertFalse(found["automatic_retry_permitted"])
            self.assertTrue(found["message_link_verified"])
        finally: self.close_child(child)
        with Journal(self.root,self.db_name) as db:
            self.assertEqual(db.verify("run-1")["events_examined"],3)

    def test_replayed_command_after_restart_is_denied(self):
        child=self.launch()
        try: self.assertTrue(self.send(self.stage())["ok"])
        finally: self.close_child(child)
        child=self.launch()
        try:
            second=self.send(self.stage())
            self.assertFalse(second["ok"])
            self.assertEqual(second["error"],
                             "HOST_REQUEST_OR_NONCE_ALREADY_CONSUMED")
        finally: self.close_child(child)

    def test_unauthorized_issuer_causes_startup_denial(self):
        fake=Ed25519PrivateKey.generate().public_key().public_bytes(
            Encoding.Raw,PublicFormat.Raw).hex()
        proc=subprocess.run(self.argv(issuer_hex=fake),capture_output=True,
                            timeout=8,check=False)
        self.assertEqual(proc.returncode,3)
        self.assertFalse(json.loads(proc.stdout)["ok"])
        with Journal(self.root,self.db_name) as db:
            self.assertEqual(db.verify("run-1")["events_examined"],2)

    def test_default_broker_denies_same_sid_even_with_signed_policy(self):
        proc=subprocess.run(self.argv(fixture=False),capture_output=True,
                            timeout=8,check=False)
        self.assertEqual(proc.returncode,3)
        self.assertFalse(json.loads(proc.stdout)["ok"])

    def test_unsigned_or_wrong_command_signature_denied(self):
        request=self.stage()
        request["auth"]["signature_b64"]=base64.b64encode(
            Ed25519PrivateKey.generate().sign(
                HOST_DOMAIN+canonical(request["auth"]["document"]))
        ).decode()
        child=self.launch()
        try:
            reply=self.send(request)
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"],"HOST_SIGNATURE_INVALID")
        finally: self.close_child(child)
        with Journal(self.root,self.db_name) as db:
            self.assertEqual(db.verify("run-1")["events_examined"],2)

if __name__=="__main__":
    unittest.main()
