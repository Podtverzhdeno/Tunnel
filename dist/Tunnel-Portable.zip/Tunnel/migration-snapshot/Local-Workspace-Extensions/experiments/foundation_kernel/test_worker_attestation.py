"""Signed worker attestation crosswalk tests. No real worker/API use."""
from __future__ import annotations
import base64
import tempfile
import unittest
from datetime import datetime,timezone
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend is not installed") from exc

try:
    from .transition import canonical
    from .journal import Journal
    from .atomic_dispatch import AtomicDispatch
    from .evidence_store import EvidenceStore
    from .receipt_ledger import ReceiptLedger, ReceiptLedgerError
    from .signed_receipts import SCHEMA, PublicKeyGrant, TrustStore, ReceiptError
    from .worker_attestation import admit_worker_receipt, WorkerAttestationError
except ImportError:
    from transition import canonical
    from journal import Journal
    from atomic_dispatch import AtomicDispatch
    from evidence_store import EvidenceStore
    from receipt_ledger import ReceiptLedger, ReceiptLedgerError
    from signed_receipts import SCHEMA, PublicKeyGrant, TrustStore, ReceiptError
    from worker_attestation import admit_worker_receipt, WorkerAttestationError

NOW=datetime(2026,11,2,12,0,tzinfo=timezone.utc)
SPEC="a"*64
INPUT="b"*64

class WorkerAttestationTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.j=Journal(self.root,"execution_journal_attest.sqlite3")
        self.addCleanup(self.j.close)
        self.dispatch=AtomicDispatch(self.j)
        self.ledger=ReceiptLedger(self.root)
        self.addCleanup(self.ledger.close)
        self.store=EvidenceStore(self.root)
        self.evidence=self.store.put("worker_result",SPEC,{"exit_code":0})
        self.key=Ed25519PrivateKey.generate()
        pub=self.key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.trust=TrustStore((PublicKeyGrant(
            "key-1",pub,"worker-1","worker","project-1",
            frozenset({"WORKER_RESULT"})),))
        self.j.append("run-1","step-1","plan-1","PLAN",0,SPEC)
        self.j.append("run-1","step-1","lease-1","LEASE",1)
        self.dispatch.stage_intent(
            "run-1","step-1","request-1","message-1","worker-1",INPUT,1)
        self.doc=dict(schema=SCHEMA,receipt_id="receipt-1",run_id="run-1",
            step_id="step-1",request_id="request-1",worker_id="worker-1",
            key_id="key-1",role="worker",scope="project-1",kind="WORKER_RESULT",
            source_sha=SPEC,input_sha=INPUT,evidence_sha=self.evidence["sha256"],
            epoch=1,issued_utc="2026-11-02T11:59:00Z",
            expires_utc="2026-11-02T12:04:00Z")

    def sign(self,**updated):
        doc={**self.doc,**updated}
        return {"document":doc,"signature_b64":base64.b64encode(
            self.key.sign(canonical(doc))).decode("ascii")}

    def admit(self,receipt=None,message_id="message-1",scope="project-1"):
        return admit_worker_receipt(
            self.dispatch,self.ledger,self.store,self.trust,
            message_id=message_id,receipt=receipt if receipt is not None else self.sign(),
            trusted_scope=scope,now=NOW)

    def activate(self):
        self.dispatch.mark_send_uncertain("message-1","attempt-1",1)

    def test_staged_but_not_send_uncertain_cannot_have_worker_result(self):
        with self.assertRaisesRegex(WorkerAttestationError,"MESSAGE_NOT_SENT_OR_UNCERTAIN"):
            self.admit()
        self.assertEqual(self.ledger.summary()["receipts"],[])

    def test_signed_result_crosswalk_and_no_deploy_permission(self):
        self.activate()
        result=self.admit()
        self.assertTrue(result["signature_verified"])
        self.assertTrue(result["signed_input_bound_to_atomic_outbox"])
        self.assertTrue(result["signed_source_bound_to_journal_plan"])
        self.assertFalse(result["can_accept_or_deploy"])
        self.assertFalse(result["external_effect_verified"])
        self.assertFalse(result["host_permission_enforced"])

    def test_duplicate_signed_result_is_idempotent(self):
        self.activate()
        self.admit()
        self.assertTrue(self.admit()["idempotent_replay"])

    def test_signed_result_with_wrong_input_sha_rejected(self):
        self.activate()
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
            self.admit(self.sign(input_sha="f"*64))
        self.assertEqual(self.ledger.summary()["receipts"],[])

    def test_signed_result_with_other_request_id_rejected(self):
        self.activate()
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
            self.admit(self.sign(request_id="request-else"))

    def test_signed_result_with_other_spec_sha_rejected(self):
        self.activate()
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
            self.admit(self.sign(source_sha="f"*64))

    def test_signed_result_with_wrong_epoch_rejected(self):
        self.activate()
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
            self.admit(self.sign(epoch=2))

    def test_worker_not_matching_destination_rejected(self):
        self.activate()
        with self.assertRaisesRegex(WorkerAttestationError,"WORKER_DESTINATION_MISMATCH"):
            self.admit(self.sign(worker_id="other-worker"))

    def test_valid_signature_of_wrong_scope_rejected(self):
        self.activate()
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
            self.admit(scope="other-project")

    def test_message_lookup_prevents_cross_project_attestation(self):
        self.activate()
        with self.assertRaisesRegex(WorkerAttestationError,"ATOMIC_OUTBOX_MESSAGE_NOT_FOUND"):
            self.admit(message_id="another-message")

    def test_tampered_outbox_blocks_verified_receipt(self):
        self.activate()
        self.j.db.execute("UPDATE atomic_outbox SET payload_sha='z' WHERE message_id='message-1'")
        with self.assertRaisesRegex(WorkerAttestationError,"JOURNAL_OR_ATOMIC_LINK_INVALID"):
            self.admit()

    def test_tampered_journal_blocks_verified_receipt(self):
        self.activate()
        self.j.db.execute("UPDATE heads SET entry_sha='broken'")
        with self.assertRaisesRegex(WorkerAttestationError,"JOURNAL_OR_ATOMIC_LINK_INVALID"):
            self.admit()

    def test_missing_evidence_blocks_verified_receipt(self):
        self.activate()
        path=self.store.root/self.evidence["sha256"][:2]/(
            self.evidence["sha256"]+".json")
        path.unlink()
        with self.assertRaisesRegex(ReceiptLedgerError,"EVIDENCE_LOCAL_BINDING_INVALID"):
            self.admit()

    def test_second_receipt_for_same_operation_cannot_double_count(self):
        self.activate()
        self.admit()
        with self.assertRaisesRegex(ReceiptLedgerError,"RECEIPT_OPERATION_ALREADY_CLAIMED"):
            self.admit(self.sign(receipt_id="receipt-2"))

if __name__=="__main__":
    unittest.main()
