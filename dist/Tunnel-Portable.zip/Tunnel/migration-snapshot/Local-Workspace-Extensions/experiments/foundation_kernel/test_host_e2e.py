"""Three independent signing identities: developer, dispatcher and worker.

Cross-component *offline* integration. Not an MCP host policy, network
dispatch, external worker invocation, or reviewer acceptance.
"""
import base64
import hashlib
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend unavailable") from exc

try:
    from .transition import canonical
    from .journal import Journal
    from .atomic_dispatch import AtomicDispatch
    from .host_auth import DOMAIN, SCHEMA, HostPolicy, HostGrant, HostAuthError
    from .host_gate import HostDispatchGate, HostGateError
    from .signed_receipts import (SCHEMA as RECEIPT_SCHEMA, PublicKeyGrant,
                                  TrustStore, ReceiptError)
    from .evidence_store import EvidenceStore
    from .receipt_ledger import ReceiptLedger
    from .worker_attestation import admit_worker_receipt, WorkerAttestationError
except ImportError:
    from transition import canonical
    from journal import Journal
    from atomic_dispatch import AtomicDispatch
    from host_auth import DOMAIN, SCHEMA, HostPolicy, HostGrant, HostAuthError
    from host_gate import HostDispatchGate, HostGateError
    from signed_receipts import (SCHEMA as RECEIPT_SCHEMA, PublicKeyGrant,
                                 TrustStore, ReceiptError)
    from evidence_store import EvidenceStore
    from receipt_ledger import ReceiptLedger
    from worker_attestation import admit_worker_receipt, WorkerAttestationError

NOW=datetime(2026,11,2,12,0,tzinfo=timezone.utc)
SOURCE="a"*64
INPUT="b"*64
SCOPE="project-alpha"

def keybytes(key):
    return key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)

class EndToEndAuthTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.journal=Journal(self.root,"execution_journal_three_roles.sqlite3")
        self.addCleanup(self.journal.close)
        self.dispatch=AtomicDispatch(self.journal)
        self.dev=Ed25519PrivateKey.generate()
        self.sender=Ed25519PrivateKey.generate()
        self.worker=Ed25519PrivateKey.generate()
        self.policy=HostPolicy((
            HostGrant("dev-1","developer","dev-key",keybytes(self.dev),
                      SCOPE,"run-1","step-1",1,1,
                      frozenset({"STAGE_INTENT"})),
            HostGrant("sender-1","dispatcher","sender-key",keybytes(self.sender),
                      SCOPE,"run-1","step-1",1,1,
                      frozenset({"MARK_SEND_UNCERTAIN"})),
        ))
        self.gate=HostDispatchGate(self.dispatch,self.policy)
        self.trust=TrustStore((PublicKeyGrant(
            "worker-key",keybytes(self.worker),"worker-1","worker",
            SCOPE,frozenset({"WORKER_RESULT"})),))
        self.evidence_store=EvidenceStore(self.root)
        self.evidence=self.evidence_store.put(
            "worker_result",SOURCE,{"test":"offline-e2e","passed":True})
        self.receipts=ReceiptLedger(self.root)
        self.addCleanup(self.receipts.close)
        self.journal.append("run-1","step-1","plan","PLAN",0,SOURCE)
        self.journal.append("run-1","step-1","lease","LEASE",1)

    def auth(self, who, operation, request_id, nonce, args):
        key, principal, role, key_id = (
            (self.dev,"dev-1","developer","dev-key") if who=="dev" else
            (self.sender,"sender-1","dispatcher","sender-key")
        )
        doc={
            "schema":SCHEMA,"principal_id":principal,"role":role,
            "key_id":key_id,"policy_revision":1,"scope":SCOPE,
            "run_id":"run-1","step_id":"step-1","epoch":1,
            "request_id":request_id,"nonce":nonce,"action":operation,
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":"2026-11-02T11:59:45Z",
            "expires_utc":"2026-11-02T12:00:45Z",
        }
        return {
            "document":doc,
            "signature_b64":base64.b64encode(
                key.sign(DOMAIN+canonical(doc))).decode("ascii"),
        }

    def stage(self, who="dev"):
        args={"message_id":"message-1","destination":"worker-1",
              "payload_sha":INPUT}
        token=self.auth(who,"STAGE_INTENT","auth-stage","1"*32,args)
        return self.gate.stage_intent(
            token,now=NOW,scope=SCOPE,
            run_id="run-1",step_id="step-1",request_id="auth-stage",
            epoch=1,**args)

    def mark(self, who="sender"):
        args={"message_id":"message-1","attempt_id":"attempt-1"}
        token=self.auth(who,"MARK_SEND_UNCERTAIN","auth-mark","2"*32,args)
        return self.gate.mark_send_uncertain(
            token,now=NOW,scope=SCOPE,
            run_id="run-1",step_id="step-1",request_id="auth-mark",
            epoch=1,**args)

    def worker_receipt(self, **modifications):
        document={
            "schema":RECEIPT_SCHEMA,
            "receipt_id":"receipt-1","run_id":"run-1","step_id":"step-1",
            "request_id":"auth-stage","worker_id":"worker-1",
            "key_id":"worker-key","role":"worker","scope":SCOPE,
            "kind":"WORKER_RESULT","source_sha":SOURCE,"input_sha":INPUT,
            "evidence_sha":self.evidence["sha256"],"epoch":1,
            "issued_utc":"2026-11-02T11:59:30Z",
            "expires_utc":"2026-11-02T12:01:30Z",
        }
        document.update(modifications)
        return {
            "document":document,
            "signature_b64":base64.b64encode(
                self.worker.sign(canonical(document))).decode("ascii"),
        }

    def attest(self, document=None):
        return admit_worker_receipt(
            self.dispatch,self.receipts,self.evidence_store,self.trust,
            message_id="message-1",
            receipt=self.worker_receipt() if document is None else document,
            trusted_scope=SCOPE,now=NOW)

    def test_valid_three_roles_signed_end_to_end(self):
        staged=self.stage()
        marked=self.mark()
        observed=self.attest()
        self.assertEqual(staged["authenticated_role"],"developer")
        self.assertEqual(marked["authenticated_role"],"dispatcher")
        self.assertTrue(observed["signature_verified"])
        self.assertTrue(observed["signed_input_bound_to_atomic_outbox"])
        self.assertTrue(observed["signed_source_bound_to_journal_plan"])
        self.assertFalse(observed["external_effect_verified"])
        self.assertFalse(observed["can_accept_or_deploy"])
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],2)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],3)

    def test_developer_cannot_use_dispatcher_capability(self):
        self.stage()
        with self.assertRaisesRegex(HostAuthError,"HOST_CAPABILITY_DENIED"):
            self.mark(who="dev")
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_dispatcher_cannot_stage_task(self):
        with self.assertRaisesRegex(HostAuthError,"HOST_CAPABILITY_DENIED"):
            self.stage(who="sender")
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)

    def test_unsigned_worker_receipt_not_accepted(self):
        self.stage()
        self.mark()
        receipt=self.worker_receipt()
        receipt["signature_b64"]=base64.b64encode(
            Ed25519PrivateKey.generate().sign(canonical(receipt["document"]))
        ).decode("ascii")
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_SIGNATURE_INVALID"):
            self.attest(receipt)
        self.assertEqual(self.receipts.summary()["receipts"],[])

    def test_worker_result_bound_to_original_payload(self):
        self.stage()
        self.mark()
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
            self.attest(self.worker_receipt(input_sha="f"*64))
        self.assertEqual(self.receipts.summary()["receipts"],[])

    def test_worker_cannot_attest_before_send_fence(self):
        self.stage()
        with self.assertRaisesRegex(WorkerAttestationError,"MESSAGE_NOT_SENT_OR_UNCERTAIN"):
            self.attest()

    def test_after_commit_duplicate_command_denied_but_receipt_query_idempotent(self):
        self.stage()
        self.mark()
        self.assertFalse(self.attest()["idempotent_replay"])
        self.assertTrue(self.attest()["idempotent_replay"])
        with self.assertRaisesRegex(HostGateError,"ALREADY_CONSUMED"):
            self.stage()

if __name__=="__main__":
    unittest.main()
