"""Cross-component evidence/journal E2E without live coordinator access."""
import tempfile
import unittest
from pathlib import Path

try:
    from .journal import Journal
    from .evidence_store import EvidenceStore
    from .replay_audit import audit_run
except ImportError:
    from journal import Journal
    from evidence_store import EvidenceStore
    from replay_audit import audit_run

SOURCE="a"*64
UNRELATED="b"*64

class AuditTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.journal=Journal(self.root,"execution_journal_e2e.sqlite3")
        self.addCleanup(self.journal.close)
        self.store=EvidenceStore(self.root)
        self.journal.append("run-1","step-1","r1","PLAN",0,SOURCE)
        self.journal.append("run-1","step-1","r2","LEASE",1)
        self.journal.append("run-1","step-1","r3","INTENT",1)

    def attach_result(self,source=SOURCE):
        receipt=self.store.put("worker_receipt",source,{"exit_code":0,"observed":"done"})
        self.journal.append("run-1","step-1","r4","RESULT",1,receipt["sha256"])
        return receipt

    def test_valid_receipt_is_consistent_but_not_accepted(self):
        self.attach_result()
        report=audit_run(self.journal,self.store,"run-1")
        self.assertTrue(report["ok"])
        self.assertEqual(report["evidence_receipts_validated"],1)
        self.assertEqual(report["decision"],"LOCAL_EVIDENCE_CONSISTENT")
        self.assertFalse(report["can_accept"])
        self.assertFalse(report["external_effects_attested"])

    def test_missing_receipt_blocks(self):
        self.journal.append("run-1","step-1","r4","RESULT",1,UNRELATED)
        report=audit_run(self.journal,self.store,"run-1")
        self.assertFalse(report["ok"])
        self.assertEqual(report["findings"][0]["reason"],"EVIDENCE_MISSING_OR_INVALID")

    def test_wrong_source_blocks(self):
        self.attach_result(UNRELATED)
        report=audit_run(self.journal,self.store,"run-1")
        self.assertFalse(report["ok"])
        self.assertEqual(report["findings"][0]["reason"],"SOURCE_DIGEST_MISMATCH")

    def test_qa_observation_bound_to_same_spec(self):
        self.attach_result()
        review=self.store.put("qa_review",SOURCE,{"tests_passed":26,"reviewed":False})
        self.journal.append("run-1","step-1","r5","QA_OBSERVED",1,review["sha256"])
        report=audit_run(self.journal,self.store,"run-1")
        self.assertEqual(report["evidence_receipts_validated"],2)
        self.assertFalse(report["can_accept"])

    def test_tampered_receipt_blocks(self):
        receipt=self.attach_result()
        p=self.store.root/receipt["sha256"][:2]/(receipt["sha256"]+".json")
        p.write_bytes(p.read_bytes()+b"tamper")
        self.assertFalse(audit_run(self.journal,self.store,"run-1")["ok"])

    def test_drifted_journal_blocks_before_evidence(self):
        self.attach_result()
        self.journal.db.execute("UPDATE heads SET entry_sha=?", ("f"*64,))
        report=audit_run(self.journal,self.store,"run-1")
        self.assertEqual(report["reason"],"JOURNAL_INVALID")
        self.assertFalse(report["can_accept"])

    def test_intent_alone_is_ambiguous(self):
        report=audit_run(self.journal,self.store,"run-1")
        self.assertTrue(report["ok"])
        self.assertEqual(report["evidence_receipts_validated"],0)
        self.assertFalse(report["can_retry_external_effect"])
        self.assertEqual(report["steps"]["step-1"]["state"],"UNCERTAIN")

if __name__=="__main__":
    unittest.main()
