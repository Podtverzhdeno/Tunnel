"""Crash injection and atomic journal/outbox consistency tests (offline only)."""
from __future__ import annotations

import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

try:
    from .journal import Journal, JournalError
    from .atomic_dispatch import AtomicDispatch, AtomicDispatchError
    from .transition import ProtocolError
except ImportError:
    from journal import Journal, JournalError
    from atomic_dispatch import AtomicDispatch, AtomicDispatchError
    from transition import ProtocolError

SPEC = "a" * 64
PAYLOAD = "b" * 64

class AtomicDispatchTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.j = Journal(self.root, "execution_journal_atomic.sqlite3")
        self.addCleanup(lambda:self.j.close())
        self.d = AtomicDispatch(self.j)
        self.j.append("run-1", "step-1", "p1", "PLAN", 0, SPEC)
        self.j.append("run-1", "step-1", "p2", "LEASE", 1)

    def stage(self, request_id="req-1", message_id="msg-1",
              payload_sha=PAYLOAD, epoch=1, step_id="step-1"):
        return self.d.stage_intent(
            "run-1",step_id,request_id,message_id,"worker-1",payload_sha,epoch)

    def test_happy_path_atomically_stages_both_rows(self):
        result=self.stage()
        self.assertTrue(result["ok"])
        self.assertFalse(result["transport_invoked_by_kernel"])
        self.assertEqual(result["external_effect_status"],"NOT_SENT_BY_KERNEL")
        self.assertEqual(result["phase"],"INTENT_STAGED")
        self.assertEqual(self.j.verify("run-1")["steps"]["step-1"]["state"],"UNCERTAIN")
        audit=self.d.audit_run("run-1")
        self.assertTrue(audit["ok"])
        self.assertEqual(audit["messages"],1)
        self.assertFalse(audit["can_publish"])

    def test_duplicate_request_replays_original(self):
        a=self.stage()
        b=self.stage()
        self.assertTrue(b["idempotent_replay"])
        self.assertEqual(a["event_id"],b["event_id"])
        self.assertEqual(self.j.verify("run-1")["events_examined"],3)

    def test_reuse_same_request_with_different_message_rejected(self):
        self.stage()
        with self.assertRaisesRegex(AtomicDispatchError,"IDEMPOTENCY_OR_MESSAGE_CONFLICT"):
            self.stage(message_id="msg-2")
        self.assertTrue(self.d.audit_run("run-1")["ok"])

    def test_reuse_message_with_different_request_rejected(self):
        self.stage()
        with self.assertRaisesRegex(AtomicDispatchError,"IDEMPOTENCY_OR_MESSAGE_CONFLICT"):
            self.stage(request_id="req-2")

    def test_reuse_message_different_payload_rejected(self):
        self.stage()
        with self.assertRaisesRegex(AtomicDispatchError,"IDEMPOTENCY_OR_MESSAGE_CONFLICT"):
            self.stage(request_id="req-2",payload_sha="c"*64)

    def test_journal_only_event_rolls_back_when_outbox_insert_fails(self):
        self.j.db.execute("""
            CREATE TRIGGER fail_atomic BEFORE INSERT ON atomic_outbox
            BEGIN SELECT RAISE(ABORT,'outbox crash injection'); END
        """)
        with self.assertRaises(sqlite3.IntegrityError):
            self.stage()
        self.assertEqual(self.j.verify("run-1")["events_examined"],2)
        self.assertEqual(self.j.verify("run-1")["steps"]["step-1"]["state"],"LEASED")
        self.assertEqual(
            self.j.db.execute("SELECT count(*) FROM atomic_outbox").fetchone()[0],0)
        self.j.db.execute("DROP TRIGGER fail_atomic")
        self.assertEqual(self.stage()["phase"],"INTENT_STAGED")

    def test_intent_trigger_rollback_does_not_create_outbox(self):
        self.j.db.execute("""
            CREATE TRIGGER fail_intent BEFORE INSERT ON events
            WHEN NEW.kind='INTENT'
            BEGIN SELECT RAISE(ABORT,'intent failure injection'); END
        """)
        with self.assertRaises(sqlite3.IntegrityError):
            self.stage()
        self.assertEqual(self.j.verify("run-1")["events_examined"],2)
        self.assertEqual(
            self.j.db.execute("SELECT count(*) FROM atomic_outbox").fetchone()[0],0)

    def test_journal_reopen_preserves_atomic_intent(self):
        self.stage()
        self.j.close()
        self.j=Journal(self.root,"execution_journal_atomic.sqlite3")
        self.d=AtomicDispatch(self.j)
        self.assertTrue(self.d.audit_run("run-1")["ok"])
        self.assertTrue(self.stage()["idempotent_replay"])

    def test_replay_after_pre_send_fence_never_claims_no_effect(self):
        self.stage()
        self.d.mark_send_uncertain("msg-1","attempt-1",1)
        replay=self.stage()
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(replay["phase"],"SEND_UNCERTAIN")
        self.assertEqual(replay["external_effect_status"],"UNKNOWN")
        self.assertFalse(replay["transport_invoked_by_kernel"])

    def test_unknown_state_does_not_retry(self):
        self.stage()
        first=self.d.mark_send_uncertain("msg-1","attempt-1",1)
        self.assertEqual(first["phase"],"SEND_UNCERTAIN")
        self.assertFalse(first["automatic_retry_permitted"])
        with self.assertRaisesRegex(AtomicDispatchError,"SEND_FENCED_OR_UNCERTAIN"):
            self.d.mark_send_uncertain("msg-1","attempt-2",2)
        self.assertEqual(self.d.audit_run("run-1")["uncertain_effects"],1)

    def test_send_epoch_is_fenced(self):
        self.stage()
        with self.assertRaisesRegex(AtomicDispatchError,"SEND_FENCED_OR_UNCERTAIN"):
            self.d.mark_send_uncertain("msg-1","attempt-1",2)
        self.assertTrue(self.d.audit_run("run-1")["ok"])

    def test_corrupt_event_link_blocks_audit_and_send(self):
        self.stage()
        self.j.db.execute("UPDATE atomic_outbox SET intent_event_id=2")
        report=self.d.audit_run("run-1")
        self.assertFalse(report["ok"])
        self.assertIn("INVALID_EVENT_LINK",report["findings"][0])
        with self.assertRaisesRegex(AtomicDispatchError,"ATOMIC_AUDIT_BLOCKED"):
            self.d.mark_send_uncertain("msg-1","attempt-1",1)

    def test_orphaned_atomic_journal_intent_is_detected(self):
        payload={"message_id":"msg-1","destination":"worker-1",
                 "payload_sha":PAYLOAD,"atomic_dispatch":1}
        self.j.append("run-1","step-1","req-1","INTENT",1,payload=payload)
        audit=self.d.audit_run("run-1")
        self.assertFalse(audit["ok"])
        self.assertIn("ORPHAN_ATOMIC_INTENT",audit["findings"])
        with self.assertRaisesRegex(AtomicDispatchError,"PREEXISTING_ATOMIC_DISPATCH_DIVERGED"):
            self.stage()
        self.assertFalse(self.j.db.execute("SELECT 1 FROM atomic_outbox").fetchone())

    def test_tampered_journal_blocks_staging(self):
        self.j.db.execute("UPDATE heads SET entry_sha='broken' WHERE run_id='run-1'")
        with self.assertRaisesRegex(AtomicDispatchError,"PREEXISTING_ATOMIC_DISPATCH_DIVERGED"):
            self.stage()
        self.assertFalse(self.j.db.execute("SELECT 1 FROM atomic_outbox").fetchone())

    def test_limit_does_not_consume_journal_intent(self):
        with patch.object(__import__(AtomicDispatch.__module__,fromlist=["MAX_OUTBOX"]),
                          "MAX_OUTBOX",0):
            with self.assertRaisesRegex(AtomicDispatchError,"ATOMIC_OUTBOX_CAPACITY_REACHED"):
                self.stage()
        self.assertEqual(self.j.verify("run-1")["events_examined"],2)

    def test_invalid_message_identifier_rejected(self):
        for bad in ("../escape","","bad space","x"*97):
            with self.subTest(bad=bad):
                with self.assertRaises(ProtocolError):
                    self.stage(message_id=bad)

    def test_wrong_epoch_and_boolean_denied(self):
        for bad in (0,True,2**31, -1):
            with self.subTest(value=bad):
                with self.assertRaises(AtomicDispatchError):
                    self.stage(epoch=bad)
        with self.assertRaises(ProtocolError):
            self.stage(epoch=2)

    def test_independent_second_step_same_run(self):
        self.j.append("run-1","step-2","p3","PLAN",0,SPEC)
        self.j.append("run-1","step-2","p4","LEASE",3)
        self.stage()
        self.stage("req-2","msg-2",epoch=3,step_id="step-2")
        self.assertEqual(self.d.audit_run("run-1")["messages"],2)

    def test_concurrent_same_message_one_commit(self):
        barrier=threading.Barrier(2)
        results=[]
        errors=[]
        def contender():
            try:
                with Journal(self.root,"execution_journal_atomic.sqlite3") as journal:
                    local=AtomicDispatch(journal)
                    barrier.wait(timeout=8)
                    results.append(local.stage_intent(
                        "run-1","step-1","req-1","msg-1","worker-1",PAYLOAD,1))
            except Exception as exc:
                errors.append(str(exc))
        a=threading.Thread(target=contender)
        b=threading.Thread(target=contender)
        a.start();b.start();a.join(10);b.join(10)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(errors,[])
        self.assertEqual(len(results),2)
        self.assertEqual(sum(not x["idempotent_replay"] for x in results),1)
        self.assertEqual(self.d.audit_run("run-1")["messages"],1)
        self.assertEqual(self.j.verify("run-1")["events_examined"],3)

    def test_failed_second_step_keeps_first(self):
        self.stage()
        self.j.append("run-1","step-2","p3","PLAN",0,SPEC)
        self.j.append("run-1","step-2","p4","LEASE",1)
        with self.assertRaisesRegex(AtomicDispatchError,"IDEMPOTENCY_OR_MESSAGE_CONFLICT"):
            self.stage("req-2","msg-1",step_id="step-2")
        self.assertEqual(self.j.verify("run-1")["steps"]["step-2"]["state"],"LEASED")
        self.assertEqual(self.d.audit_run("run-1")["messages"],1)

    def test_os_process_crash_after_journal_intent_is_rolled_back(self):
        """Hard process termination between the two SQL inserts.

        The OS kills only a disposable Python child, never the MCP server.
        The child's open SQLite transaction must be rolled back by SQLite.
        """
        import subprocess
        import sys
        code = (
            "import os,sys\n"
            "from journal import Journal\n"
            "from atomic_dispatch import AtomicDispatch\n"
            "journal=Journal(sys.argv[1],'execution_journal_atomic.sqlite3')\n"
            "dispatch=AtomicDispatch(journal)\n"
            "original=journal._append_locked\n"
            "def killed(*args,**kwargs):\n"
            "    original(*args,**kwargs)\n"
            "    os._exit(73)\n"
            "journal._append_locked=killed\n"
            "dispatch.stage_intent('run-1','step-1','req-kill','msg-kill',"
            "'worker-1','b'*64,1)\n"
        )
        result=subprocess.run(
            [sys.executable,"-c",code,str(self.root)],
            cwd=Path(__file__).resolve().parent,
            timeout=8,stdin=subprocess.DEVNULL,
            capture_output=True,check=False)
        self.assertEqual(result.returncode,73,result.stderr.decode(errors="replace"))
        self.assertEqual(self.j.verify("run-1")["events_examined"],2)
        self.assertFalse(self.j.db.execute("SELECT 1 FROM atomic_outbox").fetchone())
        self.assertEqual(self.stage()["phase"],"INTENT_STAGED")

    def test_preexisting_outbox_tamper_denies_unrelated_new_task(self):
        self.stage()
        self.j.append("run-1","step-2","p3","PLAN",0,SPEC)
        self.j.append("run-1","step-2","p4","LEASE",2)
        self.j.db.execute("UPDATE atomic_outbox SET destination='changed'")
        with self.assertRaisesRegex(
            AtomicDispatchError,"PREEXISTING_ATOMIC_DISPATCH_DIVERGED"):
            self.stage("req-2","msg-2",epoch=2,step_id="step-2")
        self.assertEqual(self.j.verify("run-1")["steps"]["step-2"]["state"],"LEASED")

    def test_staged_replay_is_blocked_if_outbox_phase_is_corrupt(self):
        self.stage()
        self.j.db.execute("UPDATE atomic_outbox SET phase='SEND_UNCERTAIN'")
        self.assertFalse(self.d.audit_run("run-1")["ok"])
        with self.assertRaisesRegex(
            AtomicDispatchError,"PREEXISTING_ATOMIC_DISPATCH_DIVERGED"):
            self.stage()

    def test_journal_append_still_commits_independently(self):
        self.j.append("run-1","step-2","p3","PLAN",0,SPEC)
        self.assertFalse(self.j.db.in_transaction)
        self.assertEqual(self.j.verify("run-1")["steps"]["step-2"]["state"],"PLANNED")

    def test_locked_append_refuses_operation_outside_transaction(self):
        with self.assertRaisesRegex(JournalError,"JOURNAL_TRANSACTION_REQUIRED"):
            self.j._append_locked("run-1","step-1","r1","INTENT",1)

    def test_crash_after_commit_loses_response_but_replay_is_safe(self):
        """Committed INTENT+outbox must survive a lost process response."""
        import subprocess
        import sys
        code=(
            "import os,sys\n"
            "from journal import Journal\n"
            "from atomic_dispatch import AtomicDispatch\n"
            "with Journal(sys.argv[1],'execution_journal_atomic.sqlite3') as journal:\n"
            "    result=AtomicDispatch(journal).stage_intent("
            "'run-1','step-1','req-1','msg-1','worker-1','b'*64,1)\n"
            "    if not result['ok']: raise RuntimeError('NOT_COMMITTED')\n"
            "    os._exit(77)\n"
        )
        completed=subprocess.run(
            [sys.executable,"-c",code,str(self.root)],
            cwd=Path(__file__).resolve().parent,timeout=8,
            stdin=subprocess.DEVNULL,capture_output=True,check=False)
        self.assertEqual(completed.returncode,77,
                         completed.stderr.decode(errors="replace"))
        replay=self.stage()
        self.assertTrue(replay["idempotent_replay"])
        self.assertTrue(self.d.audit_run("run-1")["ok"])
        self.assertEqual(self.j.verify("run-1")["events_examined"],3)

    def test_concurrent_distinct_intents_same_step_only_one_commits(self):
        barrier=threading.Barrier(2)
        completed=[]
        failures=[]
        def competing(i):
            try:
                with Journal(self.root,"execution_journal_atomic.sqlite3") as journal:
                    d=AtomicDispatch(journal)
                    barrier.wait(timeout=8)
                    completed.append(d.stage_intent(
                        "run-1","step-1",f"r-{i}",f"m-{i}","worker-1",PAYLOAD,1))
            except (AtomicDispatchError,ProtocolError) as exc:
                failures.append(str(exc))
        a=threading.Thread(target=competing,args=(1,))
        b=threading.Thread(target=competing,args=(2,))
        a.start();b.start();a.join(10);b.join(10)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(len(completed),1)
        self.assertEqual(len(failures),1)
        self.assertEqual(self.d.audit_run("run-1")["messages"],1)
        self.assertEqual(self.j.verify("run-1")["events_examined"],3)

    def test_audit_is_bounded(self):
        self.stage()
        with self.assertRaisesRegex(AtomicDispatchError,"ATOMIC_AUDIT_LIMIT_INVALID"):
            self.d.audit_run("run-1",0)
        self.assertTrue(self.d.audit_run("run-1",1)["ok"])

if __name__=="__main__":
    unittest.main()
