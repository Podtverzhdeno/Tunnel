# Native Windows Named Pipe Broker — QA evidence
Date: 2026-11-02
Scope: `Local-Workspace-Extensions/experiments/foundation_kernel/`
Status: **ISOLATED EXPERIMENT — NOT PRODUCTION-READY; NOT OWNER-APPROVED**

## Exact changed source evidence

| File | SHA-256 |
|---|---|
| `win_pipe_ipc.py` | `015433ab19493cd5c352fc4a9c1fc0a1d36891baea3844ccab71551bce00b39a` |
| `broker_named_pipe.py` | `2adcc654f220bac9d37837c298abda700606f7600c38dafa9cd5bcd2d3253823` |
| `broker_pipe_mcp_bridge.py` | `7f07fb296c8f1b0272a4b78ffee93223b6d45a4e68d0ab72a9f708927baba952` |
| `test_win_pipe_ipc.py` | `5e570de047bc27edd5792bdb2f3a1c77e3ceb87f7a4d6f3d7354c3c9920b2a15` |
| `test_broker_named_pipe.py` | `33b3f1fe9ab24cab6b703ee035a1b0a0b5500f19d40e5026561f7eeb186bf914` |

This is a point-in-time record, not a verified independent signature.

## Observed test runs (Windows, isolated fixture)

- `python -m unittest test_win_pipe_ipc test_broker_named_pipe -q` —
  **19 tests, OK**, job `db9374077b054cfbadbcfdf725259311`.
- `python -m unittest discover -q` from `experiments/foundation_kernel` —
  **338 tests, OK, 1 skipped**, job `fe529bfac696434694b33d22b3cc1112`.
- `python -m unittest discover -q` from `Local-Workspace-Extensions` —
  **1212 tests, 31 skipped, 1 FAILED**, jobs
  `3e87915323e94d2592822a8b041c2332`,
  `89a500c0c4cd4139810b4c54bbcc4ac9`.
  Failure is outside the foundation kernel:
  `test_automation_duration_analysis.DurationAnalysisTests.test_real_report_requires_more_samples`
  expects `new_completed_or_failed_samples == 0`, but the
  live report contains **1** additional sample. The focused rerun
  `c7657a7e06464a3ab62639af05b556d0` reproduced this exact failure.
  The test is coupled to mutable real experiment data; **do not** claim a
  green project-wide test suite or silently rewrite live evidence to zero.
  The unrelated test/module and live report were not modified here.
- `python spec_check.py` from project root — **ok**:
  11 capabilities, 99 requirements, 128 scenarios, 58 SDD tasks, 108 OpenSpec tasks;
  only structural checks, not canonical approval.
- `python sdd_roadmap_check.py` from project root — **ok**:
  58 roadmap tasks, 116 outputs; read-only structural validation.

## Behavior actually exercised

1. Windows protected named-pipe DACL (no default Everyone/Admin ACE), first-instance flag,
   local-only pipe, bounded message frames.
2. Real Windows client process impersonation after reading a complete frame;
   token SID compared to pre-provisioned expected client SID before handler execution.
3. Real server process PID retrieval and access token SID comparison on client
   **before** sending a request. Negative test rejects the wrong server SID.
4. Signed issuer policy, revocation/expiry/revision floor through existing kernel.
5. Signed agent command and capability-check inside broker, atomic journal/outbox
   and nonce claim. No network dispatch or worker side effect.
6. Signed status query through MCP → native named pipe → broker → SQLite.
   Lost-response recovery is read-only; never retries ambiguous effects.
7. Process restart preserves nonce/replay rejection and committed INTENT.
8. Default secure-mode startup **denies same-SID** broker+agent configuration.
   Positive Windows IPC fixtures use `--offline-same-sid-fixture`, which
   explicitly is **not OS separation**.
9. Live Local Workspace tools, Windows services, SID accounts, ACLs, tunnel,
   agent queue and canonical specs were not modified.

## Strict 9-dimension review

| Dimension | Assessment |
|---|---|
| Security | Win32 token-based peer checks and explicit DACL implemented. OS service separation, protected launcher/issuer trust, group token nuances, admin bypass and endpoint watchdog still unverified. |
| Reliability | SQLite transaction/idempotency inherited and tested across process restarts. A client that connects but stops sending can still block the synchronous server; production timeout/overlapped I/O pending. |
| Architecture | Broker sidecar, restricted MCP adapter, signed policy and journal composed without adding unrestricted MCP methods. No canary registration. |
| Scalability | Sequential bounded pipe connections, maximum 32 per server lifetime. No production concurrency/throughput measurements or worker pool. |
| Correctness | 19 focused real-Windows tests and full 338-test foundation suite pass; project-wide unrelated live-data assertion fails and remains disclosed. |
| Maintainability | Single-purpose modules, stdlib ctypes Win32 FFI and deterministic offline fixtures. Win32 API ABI changes/complexity require additional audit. |
| Performance | Bounded 16 KiB frames; no measured SLO/throughput, not production tuned. |
| Observability | Explicit status + denied modes, structural QA report and stable source hashes. No production audit pipeline or incident alerting. |
| Spec traceability | Only experimental reference design. Canonical OpenSpec/SDD checks pass structurally, but no accepted change/owner authorization for production integration. |

**Release gate: BLOCKED.** Required before production: dedicated Windows
service identity and protected code/data/launcher; protected pinned issuer
root; actual MCP registry privilege reduction; independent security review;
peer-token validation across **different** Windows accounts; IPC watchdog
and resource limits; key rotation/revocation and adversarial load; external
effect attestation and independent reviewer acceptance.
