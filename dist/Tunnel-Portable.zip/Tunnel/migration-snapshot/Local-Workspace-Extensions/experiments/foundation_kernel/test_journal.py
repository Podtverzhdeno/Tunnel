"""Adversarial and restart tests for isolated durable journal; stdlib only."""
import json
import sqlite3
import tempfile
import threading
import unittest
from datetime import datetime, timezone
from pathlib import Path

try:
    from .journal import Journal, JournalError
    from .transition import ProtocolError, Step, next_step
except ImportError:
    from journal import Journal, JournalError
    from transition import ProtocolError, Step, next_step

DIGEST = "a" * 64
RESULT = "b" * 64

class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.j = Journal(self.root, "execution_journal_testing.sqlite3",
                         clock=lambda: datetime(2026,11,2,4,0,tzinfo=timezone.utc))
        self.addCleanup(lambda: self.j.close())

    def emit(self, kind, index, epoch=0, evidence=None,
             run="run-1", step="step-1", payload=None):
        return self.j.append(run, step, f"req-{index}", kind, epoch,
                             evidence_sha=evidence, payload=payload)

    def leased(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.emit("LEASE", 2, epoch=1)

    def uncertain(self):
        self.leased()
        return self.emit("INTENT", 3, epoch=1,
                         payload={"operation":"external-effect-pending"})

    def test_genesis_plan_and_valid_replay(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        v = self.j.verify("run-1")
        self.assertTrue(v["ok"])
        self.assertEqual(v["steps"]["step-1"]["state"], "PLANNED")
        self.assertFalse(v["identity_and_evidence_authenticated"])

    def test_intent_is_not_replay_safe(self):
        self.uncertain()
        report=self.j.recovery("run-1")
        self.assertEqual(
            report["steps"]["step-1"]["safe_next_action"],
            "RECONCILE_EXTERNAL_SIDE_EFFECT_BEFORE_RETRY")
        self.assertFalse(report["automatic_external_retry_permitted"])

    def test_receipt_and_qa_do_not_auto_accept(self):
        self.uncertain()
        self.emit("RESULT", 4, 1, RESULT)
        self.emit("QA_OBSERVED", 5, 1, DIGEST)
        v=self.j.verify("run-1")
        self.assertEqual(v["steps"]["step-1"]["state"], "QA_OBSERVED")
        self.assertEqual(v["steps"]["step-1"]["safe_next_action"],
                         "INDEPENDENT_REVIEW_REQUIRED")
        self.assertNotIn("accepted", json.dumps(v).lower())

    def test_intent_reconciliation_path(self):
        self.uncertain()
        self.emit("RECONCILIATION", 4, 1)
        self.emit("RECONCILED_RESULT", 5, 1, RESULT)
        v=self.j.verify("run-1")
        self.assertTrue(v["ok"])
        self.assertEqual(v["steps"]["step-1"]["state"],"RESULT_DOCUMENTED")

    def test_duplicate_request_returns_original(self):
        a=self.emit("PLAN", 1, evidence=DIGEST, payload={"hello":"мир"})
        b=self.emit("PLAN", 1, evidence=DIGEST, payload={"hello":"мир"})
        self.assertTrue(b["idempotent_replay"])
        self.assertEqual(a["event_id"],b["event_id"])
        self.assertEqual(self.j.verify("run-1")["events_examined"], 1)

    def test_duplicate_request_different_event_is_conflict(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        with self.assertRaisesRegex(JournalError, "IDEMPOTENCY_CONFLICT"):
            self.emit("LEASE", 1, epoch=1)

    def test_invalid_transition_does_not_write(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        with self.assertRaisesRegex(ProtocolError, "FENCED_EPOCH_MISMATCH"):
            self.emit("RESULT", 2, 0, RESULT)
        self.assertEqual(self.j.verify("run-1")["events_examined"],1)

    def test_stale_epoch_denied(self):
        self.leased()
        with self.assertRaisesRegex(ProtocolError, "FENCED_EPOCH_MISMATCH"):
            self.emit("INTENT", 3, 2)
        self.assertEqual(self.j.verify("run-1")["steps"]["step-1"]["state"],"LEASED")

    def test_release_then_incremented_epoch(self):
        self.leased()
        self.emit("RELEASE", 3, 1)
        with self.assertRaisesRegex(ProtocolError, "STALE_OR_INVALID_LEASE"):
            self.emit("LEASE", 4, 1)
        self.emit("LEASE", 5, 2)
        self.assertEqual(self.j.verify("run-1")["steps"]["step-1"]["epoch"],2)

    def test_restart_preserves_journal(self):
        self.uncertain()
        self.j.close()
        self.j=Journal(self.root,"execution_journal_testing.sqlite3")
        self.assertTrue(self.j.verify("run-1")["ok"])
        self.assertFalse(self.j.recovery("run-1")["automatic_external_retry_permitted"])

    def test_two_steps_interleaved_per_run(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.emit("PLAN", 2, evidence=DIGEST, step="step-2")
        self.emit("LEASE", 3, epoch=1, step="step-2")
        v=self.j.verify("run-1")
        self.assertEqual(v["events_examined"],3)
        self.assertEqual(v["steps"]["step-1"]["state"],"PLANNED")
        self.assertEqual(v["steps"]["step-2"]["state"],"LEASED")

    def test_interleaved_independent_runs(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.emit("PLAN", 2, evidence=DIGEST, run="run-2")
        self.assertTrue(self.j.verify("run-1")["ok"])
        self.assertTrue(self.j.verify("run-2")["ok"])

    def test_forged_role_field_is_advisory_only(self):
        self.emit("PLAN", 1, evidence=DIGEST,
                  payload={"role":"architect", "claimed_approval":True})
        v=self.j.verify("run-1")
        self.assertFalse(v["identity_and_evidence_authenticated"])

    def test_secret_key_rejected_before_write(self):
        for payload in [{"token":"unsafe"}, {"meta":{"password":"bad"}}]:
            with self.subTest(payload=payload):
                with self.assertRaisesRegex(ProtocolError, "SECRET_KEY"):
                    self.emit("PLAN", 1, evidence=DIGEST, payload=payload)
        self.assertEqual(self.j.recovery("run-1")["action"],"MANUAL_INSPECTION")

    def test_empty_or_bad_run_ids_rejected(self):
        for run in ("", "../escape", "bad space", "/"*80):
            with self.subTest(run=run):
                with self.assertRaisesRegex(ProtocolError, "RUN_ID_INVALID"):
                    self.emit("PLAN", 1, evidence=DIGEST, run=run)

    def test_missing_evidence_sha_is_denied(self):
        with self.assertRaisesRegex(ProtocolError, "EVIDENCE_DIGEST_INVALID"):
            self.emit("PLAN", 1)
        self.assertFalse(self.j.verify("run-1")["ok"])

    def test_corrupt_payload_detected(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.j.db.execute("UPDATE events SET payload_json='{} ' WHERE id=1")
        self.assertFalse(self.j.verify("run-1")["ok"])

    def test_corrupt_hash_detected(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.j.db.execute("UPDATE events SET entry_sha=? WHERE id=1",("c"*64,))
        v=self.j.verify("run-1")
        self.assertFalse(v["ok"])

    def test_corrupt_head_detected(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.j.db.execute("UPDATE heads SET entry_sha=?", ("f"*64,))
        self.assertFalse(self.j.verify("run-1")["ok"])
        with self.assertRaisesRegex(JournalError, "EXISTING_JOURNAL_DIVERGED"):
            self.emit("LEASE", 2, epoch=1)

    def test_corrupt_step_state_detected(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.j.db.execute("UPDATE steps SET state='ACCEPTED'")
        self.assertEqual(self.j.verify("run-1")["error"],"STEP_STATE_CACHE_DIVERGED")

    def test_limits_prevent_unbounded_scan(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.emit("LEASE", 2, epoch=1)
        self.assertEqual(self.j.verify("run-1",max_events=1)["error"],
                         "VERIFY_LIMIT_EXCEEDED")

    def test_cancel_does_not_authorize_new_work(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        self.emit("CANCEL", 2)
        with self.assertRaises(ProtocolError):
            self.emit("LEASE", 3, epoch=1)

    def test_foreign_existing_db_is_refused(self):
        foreign = self.root / "execution_journal_foreign.sqlite3"
        con=sqlite3.connect(foreign)
        con.execute("CREATE TABLE unrelated(id INTEGER)")
        con.close()
        with self.assertRaisesRegex(JournalError, "EXISTING_UNRELATED_DATABASE"):
            Journal(self.root,foreign.name)

    def test_path_confinement(self):
        for name in ("../foo.sqlite3","other.sqlite3","execution_journal_../../p.sqlite3"):
            with self.subTest(name=name):
                with self.assertRaisesRegex(JournalError,"JOURNAL_NAME_INVALID"):
                    Journal(self.root,name)

    def test_simultaneous_acquire_only_one_succeeds(self):
        self.emit("PLAN", 1, evidence=DIGEST)
        barrier=threading.Barrier(2)
        results=[]
        errors=[]
        def contender(epoch):
            try:
                with Journal(self.root,"execution_journal_testing.sqlite3") as local:
                    barrier.wait()
                    results.append(local.append("run-1","step-1",f"claim-{epoch}",
                                                "LEASE",epoch))
            except (JournalError,ProtocolError) as exc:
                errors.append(str(exc))
        a=threading.Thread(target=contender,args=(1,))
        b=threading.Thread(target=contender,args=(2,))
        a.start();b.start();a.join(8);b.join(8)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(len(results),1)
        self.assertEqual(len(errors),1)
        self.assertTrue(self.j.verify("run-1")["ok"])

    def test_no_unsafe_retry_after_intent(self):
        self.uncertain()
        for kind in ("LEASE","INTENT","CANCEL","RELEASE"):
            with self.subTest(kind=kind):
                with self.assertRaises(ProtocolError):
                    self.emit(kind,8,2)

if __name__=="__main__":
    unittest.main()
