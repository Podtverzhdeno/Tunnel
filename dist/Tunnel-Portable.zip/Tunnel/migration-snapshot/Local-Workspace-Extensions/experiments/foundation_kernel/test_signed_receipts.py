"""Ed25519 negative tests. Keys are generated only in-memory for fixtures."""
import base64
import copy
import tempfile
import unittest
from datetime import datetime, timezone, timedelta

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend is not installed") from exc

try:
    from .signed_receipts import (SCHEMA, PublicKeyGrant, TrustStore, ReceiptError,
                                  verify_signed_receipt)
    from .transition import canonical
except ImportError:
    from signed_receipts import (SCHEMA, PublicKeyGrant, TrustStore, ReceiptError,
                                 verify_signed_receipt)
    from transition import canonical

NOW=datetime(2026,11,2,12,0,0,tzinfo=timezone.utc)
SPEC="a"*64
INPUT="c"*64
EVIDENCE="b"*64

class SignedReceiptTests(unittest.TestCase):
    def setUp(self):
        self.secret=Ed25519PrivateKey.generate()
        self.public=self.secret.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        self.grant=PublicKeyGrant(
            key_id="fixture-key-v1",public_key=self.public,worker_id="worker-1",
            role="worker",scope="project-1",permitted_kinds=frozenset({"WORKER_RESULT"}))
        self.trust=TrustStore((self.grant,))
        self.document=dict(schema=SCHEMA,receipt_id="receipt-1",run_id="run-1",
            step_id="step-1",request_id="request-1",worker_id="worker-1",
            key_id="fixture-key-v1",role="worker",scope="project-1",
            kind="WORKER_RESULT",source_sha=SPEC,input_sha=INPUT,evidence_sha=EVIDENCE,
            epoch=1,issued_utc="2026-11-02T11:59:30Z",
            expires_utc="2026-11-02T12:01:30Z")
        self.expected=dict(now=NOW,run_id="run-1",step_id="step-1",
            request_id="request-1",source_sha=SPEC,input_sha=INPUT,evidence_sha=EVIDENCE,
            kind="WORKER_RESULT",epoch=1,scope="project-1")

    def sign(self, doc=None):
        doc=copy.deepcopy(self.document if doc is None else doc)
        return {"document":doc,"signature_b64":base64.b64encode(
            self.secret.sign(canonical(doc))).decode("ascii")}

    def verify(self, receipt=None, **overrides):
        return verify_signed_receipt(self.sign() if receipt is None else receipt,
            self.trust,**(self.expected | overrides))

    def test_valid_signed_receipt(self):
        r=self.verify()
        self.assertTrue(r["signature_verified"])
        self.assertEqual(r["verified_key_id"],self.grant.key_id)
        self.assertFalse(r["permission_to_approve_or_deploy"])
        self.assertFalse(r["mcp_actor_authenticated"])
        self.assertFalse(r["external_effect_verified"])

    def test_tamper_after_signature_denied(self):
        signed=self.sign()
        signed["document"]["evidence_sha"]="c"*64
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_SIGNATURE_INVALID"):
            self.verify(signed,evidence_sha="c"*64)

    def test_other_private_key_signature_denied(self):
        bad=self.sign()
        bad["signature_b64"]=base64.b64encode(
            Ed25519PrivateKey.generate().sign(canonical(bad["document"]))
        ).decode("ascii")
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_SIGNATURE_INVALID"):
            self.verify(bad)

    def test_unknown_key_id_denied(self):
        doc=dict(self.document,key_id="unknown-key")
        with self.assertRaisesRegex(ReceiptError,"TRUST_KEY_UNKNOWN_OR_REVOKED"):
            self.verify(self.sign(doc))

    def test_revoked_key_denied_even_if_signature_valid(self):
        grant=PublicKeyGrant(key_id="fixture-key-v1",public_key=self.public,
            worker_id="worker-1",role="worker",scope="project-1",
            permitted_kinds=frozenset({"WORKER_RESULT"}),revoked=True)
        self.trust=TrustStore((grant,))
        with self.assertRaisesRegex(ReceiptError,"TRUST_KEY_UNKNOWN_OR_REVOKED"):
            self.verify()

    def test_wrong_role_or_scope_denied(self):
        for change in ({"role":"architect"},{"scope":"project-2"},
                       {"worker_id":"worker-2"}):
            with self.subTest(change=change):
                with self.assertRaises(ReceiptError):
                    self.verify(self.sign(dict(self.document,**change)),
                                **({"scope":"project-2"} if "scope" in change else {}))

    def test_not_permitted_kind_denied(self):
        doc=dict(self.document,kind="DELIVERY_ACK")
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_KEY_SCOPE_DENIED"):
            self.verify(self.sign(doc),kind="DELIVERY_ACK")

    def test_expected_context_mismatch_denied(self):
        for key,value in (("run_id","run-2"),("step_id","step-2"),
                          ("request_id","another-request"),("epoch",2),
                          ("evidence_sha","d"*64),("source_sha","c"*64),("input_sha","d"*64)):
            with self.subTest(key=key):
                with self.assertRaisesRegex(ReceiptError,"RECEIPT_CONTEXT_MISMATCH"):
                    self.verify(**{key:value})

    def test_expired_receipt_rejected(self):
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_EXPIRED"):
            self.verify(now=NOW+timedelta(minutes=5))

    def test_future_issued_receipt_rejected(self):
        doc=dict(self.document,issued_utc="2026-11-02T12:02:00Z",
                 expires_utc="2026-11-02T12:04:00Z")
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_FROM_FUTURE"):
            self.verify(self.sign(doc))

    def test_overlong_validity_window_rejected(self):
        doc=dict(self.document,expires_utc="2026-11-02T12:40:00Z")
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_VALIDITY_WINDOW_INVALID"):
            self.verify(self.sign(doc))

    def test_naive_clock_denied(self):
        with self.assertRaisesRegex(ReceiptError,"TRUSTED_CLOCK_REQUIRED"):
            self.verify(now=NOW.replace(tzinfo=None))

    def test_redundant_or_missing_fields_denied(self):
        for doc in ({**self.document,"approved":True},
                    {k:v for k,v in self.document.items() if k!="role"}):
            with self.subTest(doc=doc):
                with self.assertRaisesRegex(ReceiptError,"RECEIPT_SCHEMA_FIELDS_INVALID"):
                    self.verify(self.sign(doc))

    def test_non_integer_epoch_denied(self):
        for bad in (True,1.0,"1",0,-1):
            with self.subTest(bad=bad):
                doc=dict(self.document,epoch=bad)
                with self.assertRaisesRegex(ReceiptError,"RECEIPT_EPOCH_INVALID"):
                    self.verify(self.sign(doc))

    def test_unpadded_or_invalid_base64_denied(self):
        for text in ("invalid!", "abcd", "=", "", "a"*129):
            with self.subTest(s=text):
                doc=self.sign()
                doc["signature_b64"]=text
                with self.assertRaisesRegex(ReceiptError,"RECEIPT_SIGNATURE_FORMAT_INVALID"):
                    self.verify(doc)

    def test_signature_cannot_authenticate_changed_trust_store(self):
        other=Ed25519PrivateKey.generate().public_key().public_bytes(
            Encoding.Raw,PublicFormat.Raw)
        self.trust=TrustStore((PublicKeyGrant(
            key_id=self.grant.key_id,public_key=other,worker_id=self.grant.worker_id,
            role="worker",scope="project-1",permitted_kinds=frozenset({"WORKER_RESULT"})),))
        with self.assertRaisesRegex(ReceiptError,"RECEIPT_SIGNATURE_INVALID"):
            self.verify()

    def test_duplicate_trust_key_or_public_bytes_denied(self):
        a=self.grant
        duplicate=PublicKeyGrant(key_id="other-key",public_key=self.public,
            worker_id="worker-2",role="worker",scope="project-2",
            permitted_kinds=frozenset({"WORKER_RESULT"}))
        with self.assertRaisesRegex(ReceiptError,"TRUST_DUPLICATE_KEY_OR_ID"):
            TrustStore((a,duplicate))

    def test_boolean_revoked_not_accepted_as_other_type(self):
        grant=PublicKeyGrant(key_id="fixture-key-v1",public_key=self.public,
            worker_id="worker-1",role="worker",scope="project-1",
            permitted_kinds=frozenset({"WORKER_RESULT"}),revoked=1)
        with self.assertRaisesRegex(ReceiptError,"TRUST_REVOCATION_TYPE_INVALID"):
            TrustStore((grant,))

    def test_backend_missing_fails_closed(self):
        from unittest.mock import patch
        from importlib import import_module
        module=import_module(verify_signed_receipt.__module__)
        with patch.object(module,"Ed25519PublicKey",None):
            with self.assertRaisesRegex(ReceiptError,"ED25519_BACKEND_UNAVAILABLE"):
                self.verify()

    def test_hash_input_does_not_embed_private_key(self):
        receipt=self.sign()
        self.assertNotIn("private_key",str(receipt))
        self.assertNotIn("secret",str(receipt))
        self.assertEqual(len(base64.b64decode(receipt["signature_b64"])),64)

if __name__=="__main__":
    unittest.main()
