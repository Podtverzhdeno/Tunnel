"""Signed policy issuer, monotonic rollback protection and subprocess tests.

Private issuer and worker keys exist only inside disposable test fixtures.
No real owner approval, signing key files, Windows ACL changes or live MCP.
"""
from __future__ import annotations
import base64
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 library not installed") from exc

try:
    from .transition import canonical
    from .signed_policy import (
        DOMAIN, SCHEMA, SignedPolicyFloor, PolicySignatureError,
        verify_signed_policy, verify_current_floor_locked,
    )
    from .journal import Journal
    from .host_auth import DOMAIN as COMMAND_DOMAIN, SCHEMA as COMMAND_SCHEMA
    from .atomic_dispatch import AtomicDispatch
    from .host_auth import HostGrant, HostPolicy
    from .host_gate import HostDispatchGate
except ImportError:
    from transition import canonical
    from signed_policy import (
        DOMAIN, SCHEMA, SignedPolicyFloor, PolicySignatureError,
        verify_signed_policy, verify_current_floor_locked,
    )
    from journal import Journal
    from host_auth import DOMAIN as COMMAND_DOMAIN, SCHEMA as COMMAND_SCHEMA
    from atomic_dispatch import AtomicDispatch
    from host_auth import HostGrant, HostPolicy
    from host_gate import HostDispatchGate

NOW=datetime.now(timezone.utc).replace(microsecond=0)
INPUT="b"*64
SPEC="a"*64

class SignedPolicyTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.policy_file=self.root/"signed-policy-data.json"
        self.bundle_file=self.root/"signed-policy-bundle.json"
        self.owner=Ed25519PrivateKey.generate()
        self.owner_pub=self.owner.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.public_hex=self.owner_pub.hex()
        self.agent=Ed25519PrivateKey.generate()
        worker_pub=self.agent.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.policy={
            "schema":"foundation-pinned-policy-v1",
            "scope":"project-alpha",
            "grants":[{
                "principal_id":"agent-1","role":"developer","key_id":"agent-key",
                "public_key_b64":base64.b64encode(worker_pub).decode(),
                "scope":"project-alpha","run_id":"run-1","step_id":"step-1",
                "epoch":1,"policy_revision":1,
                "capabilities":["STAGE_INTENT"],"revoked":False,
            }],
        }
        self.put_policy()
        self.put_bundle(1)
        self.journal=Journal(self.root,"execution_journal_broker.sqlite3")
        self.addCleanup(lambda:self.journal.close())
        self.journal.append("run-1","step-1","plan","PLAN",0,SPEC)
        self.journal.append("run-1","step-1","lease","LEASE",1)

    def put_policy(self):
        raw=canonical(self.policy)
        self.policy_file.write_bytes(raw)
        self.policy_sha=hashlib.sha256(raw).hexdigest()

    def put_bundle(self, rev, *, signed_key=None, issued=None, expires=None,
                   policy_sha=None, overrides=None):
        doc={
            "schema":SCHEMA,"issuer_id":"owner-root-1",
            "revision":rev,
            "issued_utc":(issued or (NOW-timedelta(minutes=1))).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(expires or (NOW+timedelta(hours=2))).strftime(
                "%Y-%m-%dT%H:%M:%SZ"),
            "policy_sha256":policy_sha or self.policy_sha,
        }
        if overrides:
            doc.update(overrides)
        signature=(signed_key or self.owner).sign(DOMAIN+canonical(doc))
        envelope={**doc,"signature_b64":base64.b64encode(signature).decode()}
        self.bundle_file.write_bytes(canonical(envelope))
        return envelope

    def verified(self, *, key=None, at=NOW):
        return verify_signed_policy(self.bundle_file,self.policy_file,
                                    key or self.public_hex,at)

    def floor(self):
        return SignedPolicyFloor(self.journal.db)

    def call(self, requests, *, flags=None):
        argv=[
            sys.executable,
            str(Path(__file__).resolve().parent/"broker_stdio.py"),
            "--root",str(self.root),"--policy",str(self.policy_file),
        ]
        if flags is None:
            argv.extend([
                "--signed-policy-bundle",str(self.bundle_file),
                "--trusted-issuer-public-hex",self.public_hex,
            ])
        else:
            argv.extend(flags)
        payload=b"".join(json.dumps(x,separators=(",",":")).encode()+b"\n"
                         for x in requests)
        result=subprocess.run(argv,input=payload,capture_output=True,
                              timeout=12,check=False)
        return result,[json.loads(x) for x in result.stdout.splitlines()]

    def signed_command(self, *, request_id="req-1",nonce="a"*32):
        args={"message_id":"msg-1","destination":"worker-1",
              "payload_sha":INPUT}
        doc={
            "schema":COMMAND_SCHEMA,
            "principal_id":"agent-1","role":"developer","key_id":"agent-key",
            "policy_revision":1,"scope":"project-alpha",
            "run_id":"run-1","step_id":"step-1","epoch":1,
            "request_id":request_id,"nonce":nonce,"action":"STAGE_INTENT",
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":(NOW-timedelta(seconds=4)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(NOW+timedelta(seconds=70)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        envelope={"document":doc,"signature_b64":base64.b64encode(
            self.agent.sign(COMMAND_DOMAIN+canonical(doc))).decode()}
        return {"protocol":"foundation-broker-stdio-v1","op":"stage_intent",
                "auth":envelope,"run_id":"run-1","step_id":"step-1",
                "request_id":request_id,"epoch":1,**args}

    def test_signed_bundle_verifies_exact_policy_digest(self):
        result=self.verified()
        self.assertTrue(result["signature_verified"])
        self.assertEqual(result["revision"],1)
        self.assertEqual(result["policy_sha"],self.policy_sha)
        self.assertFalse(result["issuer_provisioning_authenticated"])

    def test_unknown_issuer_rejected(self):
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_SIGNATURE_INVALID"):
            self.verified(key=Ed25519PrivateKey.generate().public_key().public_bytes(
                Encoding.Raw,PublicFormat.Raw).hex())

    def test_unsigned_policy_changes_rejected(self):
        self.policy["grants"][0]["revoked"]=True
        self.put_policy()
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_CONTENT_MISMATCH"):
            self.verified()

    def test_forged_issuer_signature_rejected(self):
        self.put_bundle(1,signed_key=Ed25519PrivateKey.generate())
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_SIGNATURE_INVALID"):
            self.verified()

    def test_expired_policy_rejected(self):
        self.put_bundle(1,issued=NOW-timedelta(days=2),
                        expires=NOW-timedelta(days=1))
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_EXPIRED_OR_NOT_ACTIVE"):
            self.verified()

    def test_not_yet_effective_policy_rejected(self):
        self.put_bundle(1,issued=NOW+timedelta(hours=1),
                        expires=NOW+timedelta(hours=2))
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_EXPIRED_OR_NOT_ACTIVE"):
            self.verified()

    def test_overlong_policy_window_rejected(self):
        self.put_bundle(1,issued=NOW,expires=NOW+timedelta(days=31))
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_WINDOW_INVALID"):
            self.verified()

    def test_invalid_revision_rejected(self):
        for rev in (0,True,1.2,-1):
            with self.subTest(rev=rev):
                self.put_bundle(rev)
                with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_REVISION_INVALID"):
                    self.verified()

    def test_unknown_fields_rejected(self):
        self.put_bundle(1,overrides={"godmode":True})
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_SCHEMA_INVALID"):
            self.verified()

    def test_duplicate_fields_rejected(self):
        self.bundle_file.write_bytes(
            b'{"schema":"broker-signed-policy-v1","schema":"incorrect"}')
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_JSON_INVALID"):
            self.verified()

    def test_issuer_key_format_rejected(self):
        with self.assertRaisesRegex(PolicySignatureError,"SIGNED_POLICY_ISSUER_KEY_INVALID"):
            self.verified(key="invalid")

    def test_policy_floor_is_idempotent(self):
        floor=self.floor()
        expected=floor.admit(self.verified())
        self.assertEqual(floor.admit(self.verified()),expected)
        self.journal.db.execute("BEGIN IMMEDIATE")
        try: verify_current_floor_locked(self.journal.db,expected)
        finally: self.journal.db.execute("ROLLBACK")

    def test_policy_floor_rejects_rollback(self):
        floor=self.floor()
        self.put_bundle(2)
        floor.admit(self.verified())
        self.put_bundle(1)
        with self.assertRaisesRegex(PolicySignatureError,"POLICY_FLOOR_ROLLBACK_DENIED"):
            floor.admit(self.verified())

    def test_policy_floor_rejects_equivocation_at_same_revision(self):
        floor=self.floor()
        floor.admit(self.verified())
        self.policy["grants"][0]["revoked"]=True
        self.put_policy()
        self.put_bundle(1)
        with self.assertRaisesRegex(PolicySignatureError,"POLICY_FLOOR_EQUIVOCATION_DENIED"):
            floor.admit(self.verified())

    def test_policy_floor_rejects_different_issuer(self):
        floor=self.floor()
        floor.admit(self.verified())
        other=Ed25519PrivateKey.generate()
        self.put_bundle(2,signed_key=other)
        other_key=other.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex()
        with self.assertRaisesRegex(PolicySignatureError,"POLICY_FLOOR_ISSUER_CHANGED"):
            floor.admit(self.verified(key=other_key))

    def test_policy_floor_blocks_previous_session_after_upgrade(self):
        floor=self.floor()
        active=floor.admit(self.verified())
        grant=self.policy["grants"][0]
        pub=base64.b64decode(grant["public_key_b64"])
        policy=HostPolicy((HostGrant(
            principal_id="agent-1",role="developer",key_id="agent-key",
            public_key=pub,scope="project-alpha",run_id="run-1",
            step_id="step-1",epoch=1,policy_revision=1,
            capabilities=frozenset({"STAGE_INTENT"})),))
        gate=HostDispatchGate(AtomicDispatch(self.journal),policy)
        gate.active_policy_floor=active
        self.put_bundle(2)
        floor.admit(self.verified())
        command=self.signed_command()
        with self.assertRaisesRegex(PolicySignatureError,
                                    "POLICY_FLOOR_CHANGED_DURING_SESSION"):
            gate.stage_intent(
                command["auth"],now=NOW,scope="project-alpha",
                run_id="run-1",step_id="step-1",request_id="req-1",
                epoch=1,message_id="msg-1",destination="worker-1",
                payload_sha=INPUT)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)

    def test_signed_broker_default_starts_without_legacy_switch(self):
        child,result=self.call([{"protocol":"foundation-broker-stdio-v1","op":"health"}])
        self.assertEqual(child.returncode,0,child.stderr.decode(errors="replace"))
        self.assertTrue(result[0]["ok"])
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)

    def test_signed_broker_can_stage_signed_command(self):
        child,result=self.call([self.signed_command()])
        self.assertEqual(child.returncode,0,child.stderr.decode(errors="replace"))
        self.assertTrue(result[0]["ok"],result)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],3)

    def test_unsigned_broker_default_fails_closed(self):
        result,out=self.call([{"protocol":"foundation-broker-stdio-v1","op":"health"}],
                             flags=["--expected-policy-sha256",self.policy_sha])
        self.assertEqual(result.returncode,3)
        self.assertEqual(out[0]["error"],"BROKER_STARTUP_DENIED")

    def test_signed_broker_rollback_after_upgrade_denied(self):
        self.put_bundle(2)
        child,result=self.call([{"protocol":"foundation-broker-stdio-v1","op":"health"}])
        self.assertEqual(child.returncode,0)
        self.assertTrue(result[0]["ok"])
        self.put_bundle(1)
        child,result=self.call([{"protocol":"foundation-broker-stdio-v1","op":"health"}])
        self.assertEqual(child.returncode,3)
        self.assertEqual(result[0]["error"],"BROKER_STARTUP_DENIED")

    def test_signed_broker_tampered_policy_blocks_startup(self):
        self.policy["grants"][0]["revoked"]=True
        self.put_policy()
        child,result=self.call([{"protocol":"foundation-broker-stdio-v1","op":"health"}])
        self.assertEqual(child.returncode,3)
        self.assertEqual(result[0]["error"],"BROKER_STARTUP_DENIED")

    def test_policy_session_expiry_blocks_later_mutation(self):
        floor=self.floor()
        active=floor.admit(self.verified())
        grant=self.policy["grants"][0]
        policy=HostPolicy((HostGrant(
            principal_id="agent-1",role="developer",key_id="agent-key",
            public_key=base64.b64decode(grant["public_key_b64"]),
            scope="project-alpha",run_id="run-1",step_id="step-1",
            epoch=1,policy_revision=1,
            capabilities=frozenset({"STAGE_INTENT"})),))
        gate=HostDispatchGate(AtomicDispatch(self.journal),policy)
        gate.active_policy_floor=active
        gate.active_policy_expiry_utc=NOW-timedelta(seconds=1)
        command=self.signed_command()
        with self.assertRaisesRegex(
            PolicySignatureError,"SIGNED_POLICY_EXPIRED_DURING_SESSION"):
            gate.stage_intent(
                command["auth"],now=NOW,scope="project-alpha",
                run_id="run-1",step_id="step-1",request_id="req-1",
                epoch=1,message_id="msg-1",destination="worker-1",
                payload_sha=INPUT)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)

    def test_signed_mcp_bridge_requires_issuer_proof(self):
        bridge=Path(__file__).resolve().parent/"broker_mcp_bridge.py"
        argv=[sys.executable,str(bridge),"--root",str(self.root),
              "--policy",str(self.policy_file),
              "--signed-policy-bundle",str(self.bundle_file),
              "--trusted-issuer-public-hex",self.public_hex]
        init={"jsonrpc":"2.0","id":1,"method":"tools/list"}
        call={"jsonrpc":"2.0","id":2,"method":"tools/call",
              "params":{"name":"broker_stage_intent",
                        "arguments":{k:v for k,v in self.signed_command().items()
                                     if k not in {"protocol","op"}}}}
        process=subprocess.run(
            argv,input=(canonical(init)+b"\n"+canonical(call)+b"\n"),
            capture_output=True,timeout=12,check=False)
        out=[json.loads(x) for x in process.stdout.splitlines()]
        self.assertEqual(process.returncode,0,process.stderr.decode(errors="replace"))
        self.assertEqual(len(out[0]["result"]["tools"]),4)
        self.assertFalse(out[1]["result"]["isError"],out)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],3)

    def test_signed_mcp_bridge_denies_modified_policy(self):
        bridge=Path(__file__).resolve().parent/"broker_mcp_bridge.py"
        argv=[sys.executable,str(bridge),"--root",str(self.root),
              "--policy",str(self.policy_file),
              "--signed-policy-bundle",str(self.bundle_file),
              "--trusted-issuer-public-hex",self.public_hex]
        self.policy["grants"][0]["revoked"]=True
        self.put_policy()
        message={"jsonrpc":"2.0","id":1,"method":"tools/call",
                 "params":{"name":"broker_stage_intent",
                           "arguments":{k:v for k,v in self.signed_command().items()
                                        if k not in {"protocol","op"}}}}
        process=subprocess.run(argv,input=canonical(message)+b"\n",
                               capture_output=True,timeout=12,check=False)
        out=[json.loads(x) for x in process.stdout.splitlines()]
        self.assertTrue(out[0]["result"]["isError"])
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)

    def test_pin_is_not_owner_approval(self):
        state=self.verified()
        self.assertFalse(state["issuer_provisioning_authenticated"])
        self.assertNotIn("private_key",json.dumps(state))

if __name__=="__main__":
    unittest.main()
