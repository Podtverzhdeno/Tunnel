"""Signed status reconciliation: recovery without replay of unknown effects.

All keys are ephemeral in-memory fixtures; all SQLite files are temporary.
"""
import base64
import hashlib
import tempfile
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 unavailable") from exc

try:
    from .transition import canonical
    from .journal import Journal
    from .atomic_dispatch import AtomicDispatch
    from .host_auth import HostGrant,HostPolicy,HostAuthError,DOMAIN,SCHEMA
    from .host_gate import HostDispatchGate
    from .broker_reconcile import reconcile_command,ReconciliationError
except ImportError:
    from transition import canonical
    from journal import Journal
    from atomic_dispatch import AtomicDispatch
    from host_auth import HostGrant,HostPolicy,HostAuthError,DOMAIN,SCHEMA
    from host_gate import HostDispatchGate
    from broker_reconcile import reconcile_command,ReconciliationError

NOW=datetime(2026,11,2,12,0,tzinfo=timezone.utc)
SPEC="a"*64
PAYLOAD="b"*64

def keybytes(key):
    return key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)

class ReconcileTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.j=Journal(self.root,"execution_journal_reconcile.sqlite3")
        self.addCleanup(lambda:self.j.close())
        self.dispatch=AtomicDispatch(self.j)
        self.dev=Ed25519PrivateKey.generate()
        self.worker=Ed25519PrivateKey.generate()
        self.policy=HostPolicy((
            HostGrant("dev-1","developer","dev-key",keybytes(self.dev),
                      "project-alpha","run-1","step-1",1,1,
                      frozenset({"STAGE_INTENT","QUERY_COMMAND_STATUS"})),
            HostGrant("dispatcher-1","dispatcher","send-key",keybytes(self.worker),
                      "project-alpha","run-1","step-1",1,1,
                      frozenset({"MARK_SEND_UNCERTAIN","QUERY_COMMAND_STATUS"})),
        ))
        self.gate=HostDispatchGate(self.dispatch,self.policy)
        self.j.append("run-1","step-1","plan","PLAN",0,SPEC)
        self.j.append("run-1","step-1","lease","LEASE",1)

    def signed(self,action,request_id,arguments,*,actor="dev",modifier=None):
        key,principal,role,keyid=(
            (self.dev,"dev-1","developer","dev-key")
            if actor=="dev" else
            (self.worker,"dispatcher-1","dispatcher","send-key"))
        document={
            "schema":SCHEMA,"principal_id":principal,"role":role,
            "key_id":keyid,"policy_revision":1,"scope":"project-alpha",
            "run_id":"run-1","step_id":"step-1","epoch":1,
            "request_id":request_id,"nonce":"c"*32,
            "action":action,"arguments_sha":hashlib.sha256(canonical(arguments)).hexdigest(),
            "issued_utc":"2026-11-02T11:59:50Z",
            "expires_utc":"2026-11-02T12:01:00Z",
        }
        if modifier: document.update(modifier)
        return {"document":document,"signature_b64":base64.b64encode(
            key.sign(DOMAIN+canonical(document))).decode("ascii")}

    def stage(self):
        params={"message_id":"msg-1","destination":"worker-1","payload_sha":PAYLOAD}
        envelope=self.signed("STAGE_INTENT","stage-request",params)
        return self.gate.stage_intent(envelope,now=NOW,scope="project-alpha",
            run_id="run-1",step_id="step-1",request_id="stage-request",
            epoch=1,**params)

    def mark(self):
        params={"message_id":"msg-1","attempt_id":"attempt-1"}
        envelope=self.signed("MARK_SEND_UNCERTAIN","mark-request",params,actor="send")
        return self.gate.mark_send_uncertain(envelope,now=NOW,scope="project-alpha",
            run_id="run-1",step_id="step-1",request_id="mark-request",
            epoch=1,**params)

    def query(self,target="stage-request",message="msg-1",*,actor="dev",
              request="query-1",envelope=None,when=NOW):
        args={"target_request_id":target,"message_id":message}
        if envelope is None:
            envelope=self.signed("QUERY_COMMAND_STATUS",request,args,actor=actor)
        return reconcile_command(
            self.gate,envelope=envelope,now=when,
            scope="project-alpha",run_id="run-1",step_id="step-1",
            request_id=request,epoch=1,
            target_request_id=target,message_id=message)

    def test_committed_stage_is_visible_without_mutation(self):
        self.stage()
        before=self.j.verify("run-1")["events_examined"]
        answer=self.query()
        self.assertTrue(answer["recorded"])
        self.assertTrue(answer["message_link_verified"])
        self.assertEqual(answer["outbox_phase"],"INTENT_STAGED")
        self.assertEqual(answer["reconciliation_state"],"STAGE_INTENT_RECORDED")
        self.assertFalse(answer["automatic_retry_permitted"])
        self.assertFalse(answer["changes_written"])
        self.assertEqual(self.j.verify("run-1")["events_examined"],before)
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_missing_claim_does_not_authorize_retry(self):
        state=self.query()
        self.assertFalse(state["recorded"])
        self.assertEqual(state["next_action"],"MANUAL_RECONCILIATION_REQUIRED")
        self.assertFalse(state["automatic_retry_permitted"])
        self.assertFalse(state["external_effect_verified"])

    def test_query_can_replay_safely_without_consuming_nonce(self):
        self.stage()
        a=self.query()
        b=self.query()
        self.assertEqual(a,b)
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_after_send_fence_reports_unknown_effect(self):
        self.stage()
        self.mark()
        result=self.query()
        self.assertEqual(result["outbox_phase"],"SEND_UNCERTAIN")
        self.assertFalse(result["external_effect_verified"])
        self.assertFalse(result["automatic_retry_permitted"])

    def test_dispatcher_query_confirms_durable_mark_link(self):
        self.stage()
        self.mark()
        result=self.query(target="mark-request",actor="send")
        self.assertTrue(result["recorded"])
        self.assertEqual(result["committed_action"],"MARK_SEND_UNCERTAIN")
        self.assertTrue(result["message_link_verified"])
        self.assertEqual(result["outbox_phase"],"SEND_UNCERTAIN")
        self.assertEqual(result["reconciliation_state"],"MARK_SEND_FENCE_RECORDED")
        self.assertFalse(result["automatic_retry_permitted"])
        self.assertFalse(result["external_effect_verified"])

    def test_legacy_mark_without_link_is_not_implicitly_trusted(self):
        self.stage()
        self.mark()
        self.j.db.execute(
            "DELETE FROM host_gate_command_targets WHERE request_id=?",
            ("mark-request",))
        report=self.query(target="mark-request",actor="send")
        self.assertTrue(report["recorded"])
        self.assertFalse(report["message_link_verified"])
        self.assertEqual(
            report["reconciliation_state"],
            "MARK_REQUEST_COMMITTED_MESSAGE_LINK_UNVERIFIED")

    def test_mark_link_tampering_fails_closed(self):
        self.stage()
        self.mark()
        self.j.db.execute(
            "UPDATE host_gate_command_targets SET message_id='alien' "
            "WHERE request_id='mark-request'")
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_SIGNED_TARGET_MISMATCH"):
            self.query(target="mark-request",actor="send")

    def test_mark_outbox_missing_after_claim_fails_closed(self):
        self.stage()
        self.mark()
        self.j.db.execute("UPDATE atomic_outbox SET phase='INTENT_STAGED'")
        with self.assertRaises(ReconciliationError):
            self.query(target="mark-request",actor="send")

    def test_cross_request_link_cannot_confirm_alternate_message(self):
        self.stage()
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_SIGNED_TARGET_MISMATCH"):
            self.query(target="stage-request",message="alien")

    def test_other_principal_cannot_read_request_even_with_valid_key(self):
        self.stage()
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_TARGET_NOT_AUTHORIZED"):
            self.query(actor="send")

    def test_developer_cannot_query_dispatcher_request(self):
        self.stage()
        self.mark()
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_TARGET_NOT_AUTHORIZED"):
            self.query(target="mark-request")

    def test_ungranted_query_capability_denied(self):
        grant=HostGrant("dev-1","developer","dev-key",keybytes(self.dev),
                        "project-alpha","run-1","step-1",1,1,
                        frozenset({"STAGE_INTENT"}))
        self.gate.policy=HostPolicy((grant,))
        with self.assertRaisesRegex(HostAuthError,"HOST_CAPABILITY_DENIED"):
            self.query()

    def test_wrong_message_not_allowed_to_confirm_stage(self):
        self.stage()
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_SIGNED_TARGET_MISMATCH"):
            self.query(message="other-message")

    def test_mutated_arguments_signature_denied(self):
        self.stage()
        e=self.signed("QUERY_COMMAND_STATUS","query-1",
                      {"target_request_id":"stage-request","message_id":"msg-1"})
        with self.assertRaisesRegex(HostAuthError,"HOST_COMMAND_CONTEXT_MISMATCH"):
            self.query(message="different",envelope=e)

    def test_signed_query_expiry_denied(self):
        self.stage()
        with self.assertRaisesRegex(HostAuthError,"HOST_REQUEST_EXPIRED"):
            self.query(when=NOW+timedelta(minutes=4))

    def test_tampered_journal_denies_status(self):
        self.stage()
        self.j.db.execute("UPDATE heads SET entry_sha='wrong'")
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_JOURNAL_DIVERGED"):
            self.query()

    def test_tampered_outbox_denies_status(self):
        self.stage()
        self.j.db.execute("UPDATE atomic_outbox SET payload_sha=?",("f"*64,))
        with self.assertRaisesRegex(
            ReconciliationError,"RECONCILE_JOURNAL_DIVERGED"):
            self.query()

    def test_reopen_and_reconcile_same_receipt_after_restart(self):
        self.stage()
        self.j.close()
        self.j=Journal(self.root,"execution_journal_reconcile.sqlite3")
        self.gate=HostDispatchGate(AtomicDispatch(self.j),self.policy)
        self.assertTrue(self.query()["recorded"])

    def test_wrong_epoch_denied_by_pinned_grant(self):
        self.stage()
        e=self.signed("QUERY_COMMAND_STATUS","query-1",
                      {"target_request_id":"stage-request","message_id":"msg-1"},
                      modifier={"epoch":2})
        with self.assertRaises(HostAuthError):
            self.query(envelope=e)

if __name__=="__main__":
    unittest.main()
