"""Isolated mailbox tests: crash, race, dedupe, fences, untrusted claims."""
from __future__ import annotations
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path

try:
    from .durable_mailbox import DurableMailbox, MailboxError, FILENAME
    from .transition import ProtocolError
except ImportError:
    from durable_mailbox import DurableMailbox, MailboxError, FILENAME
    from transition import ProtocolError

SHA = "a" * 64
OTHER = "b" * 64
RECEIPT = "c" * 64

class MailboxTests(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        self.root = Path(t.name)
        self.mailbox = DurableMailbox(self.root)
        self.addCleanup(lambda:self.mailbox.close())

    def stage(self, request="req-1", message="msg-1", digest=SHA):
        return self.mailbox.stage(request, message, "run-1", "scene-1",
                                  "worker-1", digest)

    def send(self):
        self.stage()
        return self.mailbox.begin_send("req-2","msg-1","attempt-1",1)

    def inbox(self):
        return self.mailbox.receive("req-3","worker-1","msg-1",SHA)

    def test_staged_message_is_durable(self):
        out=self.stage()
        self.assertEqual(out["phase"],"STAGED")
        self.assertFalse(out["authority_verified"])
        self.assertEqual(self.mailbox.snapshot()["outbox"][0]["phase"],"STAGED")

    def test_duplicate_stage_same_content_is_idempotent(self):
        a=self.stage()
        b=self.stage("req-2")
        self.assertTrue(b["already_staged"])
        self.assertFalse(b["idempotent_replay"])
        self.assertEqual(len(self.mailbox.snapshot()["outbox"]),1)

    def test_duplicate_request_returns_original_response(self):
        a=self.stage()
        b=self.stage()
        self.assertTrue(b["idempotent_replay"])
        self.assertEqual(b["message_id"],a["message_id"])

    def test_conflicting_stage_fails_closed(self):
        self.stage()
        with self.assertRaisesRegex(MailboxError,"MESSAGE_ID_CONFLICT"):
            self.stage("req-2",digest=OTHER)
        self.assertEqual(len(self.mailbox.snapshot()["outbox"]),1)

    def test_reused_request_with_different_args_fails(self):
        self.stage()
        with self.assertRaisesRegex(MailboxError,"REQUEST_IDEMPOTENCY_CONFLICT"):
            self.stage(message="msg-2")

    def test_uncertain_send_cannot_auto_retry(self):
        self.send()
        report=self.mailbox.snapshot()["outbox"][0]
        self.assertEqual(report["phase"],"SEND_UNCERTAIN")
        self.assertEqual(report["safe_next_action"],"RECONCILE_OR_VERIFY_EXTERNAL_ACK")
        with self.assertRaisesRegex(MailboxError,"SEND_REQUIRES_MANUAL_RECONCILIATION"):
            self.mailbox.begin_send("req-4","msg-1","attempt-2",2)

    def test_transactional_stage_rolls_back_on_history_error(self):
        self.mailbox.db.execute(
            "CREATE TRIGGER reject_request BEFORE INSERT ON requests "
            "BEGIN SELECT RAISE(ABORT, 'injected crash'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            self.stage()
        self.assertEqual(self.mailbox.snapshot()["outbox"],[])
        self.mailbox.db.execute("DROP TRIGGER reject_request")
        self.assertEqual(self.stage()["phase"],"STAGED")

    def test_transactional_send_rolls_back_on_history_error(self):
        self.stage()
        self.mailbox.db.execute(
            "CREATE TRIGGER reject_request BEFORE INSERT ON requests "
            "BEGIN SELECT RAISE(ABORT, 'injected crash'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            self.mailbox.begin_send("req-2","msg-1","attempt-1",1)
        self.assertEqual(self.mailbox.snapshot()["outbox"][0]["phase"],"STAGED")

    def test_outbox_backpressure_fails_closed(self):
        from unittest.mock import patch
        import importlib
        module=importlib.import_module(DurableMailbox.__module__)
        self.stage()
        with patch.object(module,"MAX_MAILBOX_ROWS",1):
            with self.assertRaisesRegex(MailboxError,"OUTBOX_CAPACITY_REACHED"):
                self.stage("req-2","msg-2")
            same=self.stage("req-3")
        self.assertTrue(same["already_staged"])
        self.assertEqual(len(self.mailbox.snapshot()["outbox"]),1)

    def test_inbox_backpressure_fails_closed(self):
        from unittest.mock import patch
        import importlib
        module=importlib.import_module(DurableMailbox.__module__)
        self.inbox()
        with patch.object(module,"MAX_MAILBOX_ROWS",1):
            with self.assertRaisesRegex(MailboxError,"INBOX_CAPACITY_REACHED"):
                self.mailbox.receive("req-4","worker-1","msg-2",SHA)
            repeat=self.mailbox.receive("req-5","worker-1","msg-1",SHA)
        self.assertTrue(repeat["duplicate_delivery"])

    def test_request_ledger_quota_still_allows_idempotent_replay(self):
        from unittest.mock import patch
        import importlib
        module=importlib.import_module(DurableMailbox.__module__)
        self.stage()
        with patch.object(module,"MAX_REQUEST_ROWS",1):
            self.assertTrue(self.stage()["idempotent_replay"])
            with self.assertRaisesRegex(MailboxError,"REQUEST_HISTORY_CAPACITY_REACHED"):
                self.stage("req-2","msg-2")
        self.assertEqual(len(self.mailbox.snapshot()["outbox"]),1)

    def test_concurrent_duplicate_inbox_delivery_is_single_row(self):
        barrier=threading.Barrier(2)
        completed=[]
        errors=[]
        def worker(i):
            try:
                with DurableMailbox(self.root) as other:
                    barrier.wait(timeout=5)
                    completed.append(other.receive(
                        f"req-in-{i}","worker-1","msg-1",SHA))
            except Exception as exc:
                errors.append(str(exc))
        a=threading.Thread(target=worker,args=(1,))
        b=threading.Thread(target=worker,args=(2,))
        a.start();b.start();a.join(8);b.join(8)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(errors,[])
        self.assertEqual(len(completed),2)
        self.assertEqual(sum(not x["duplicate_delivery"] for x in completed),1)
        self.assertEqual(len(self.mailbox.snapshot()["inbox"]),1)

    def test_attempts_are_fenced(self):
        self.send()
        with self.assertRaisesRegex(MailboxError,"ACK_ATTEMPT_FENCED_OR_INVALID"):
            self.mailbox.report_ack("req-4","msg-1",2,RECEIPT)
        with self.assertRaisesRegex(MailboxError,"EPOCH_INVALID"):
            self.mailbox.report_ack("req-4","msg-1",0,RECEIPT)

    def test_reported_ack_does_not_claim_delivery(self):
        self.send()
        out=self.mailbox.report_ack("req-4","msg-1",1,RECEIPT)
        self.assertEqual(out["phase"],"ACK_REPORTED")
        self.assertFalse(out["delivery_verified"])
        self.assertFalse(out["ack_authenticated"])
        with self.assertRaises(MailboxError):
            self.mailbox.report_ack("req-5","msg-1",1,RECEIPT)

    def test_duplicate_inbox_delivery_is_not_reprocessed(self):
        self.inbox()
        repeat=self.mailbox.receive("req-4","worker-1","msg-1",SHA)
        self.assertTrue(repeat["duplicate_delivery"])
        self.assertFalse(repeat["process_again_permitted"])
        self.assertEqual(len(self.mailbox.snapshot()["inbox"]),1)

    def test_conflicting_inbox_payload_rejected(self):
        self.inbox()
        with self.assertRaisesRegex(MailboxError,"INBOX_DUPLICATE_PAYLOAD_CONFLICT"):
            self.mailbox.receive("req-4","worker-1","msg-1",OTHER)

    def test_inbox_allows_distinct_consumers(self):
        self.inbox()
        out=self.mailbox.receive("req-4","worker-2","msg-1",SHA)
        self.assertFalse(out["duplicate_delivery"])
        self.assertEqual(len(self.mailbox.snapshot()["inbox"]),2)

    def test_processing_stores_uncertainty_before_effect(self):
        self.inbox()
        out=self.mailbox.begin_processing("req-4","worker-1","msg-1","attempt-1",1)
        self.assertEqual(out["phase"],"PROCESS_UNCERTAIN")
        self.assertFalse(out["worker_executed"])
        self.assertFalse(out["automatic_retry_permitted"])

    def test_process_crash_blocks_duplicate_processing(self):
        self.inbox()
        self.mailbox.begin_processing("req-4","worker-1","msg-1","attempt-1",1)
        retry=self.mailbox.receive("req-5","worker-1","msg-1",SHA)
        self.assertTrue(retry["duplicate_delivery"])
        self.assertEqual(retry["phase"],"PROCESS_UNCERTAIN")
        with self.assertRaisesRegex(MailboxError,"PROCESS_REQUIRES_MANUAL_RECONCILIATION"):
            self.mailbox.begin_processing("req-6","worker-1","msg-1","attempt-2",2)

    def test_result_attempt_epoch_is_fenced(self):
        self.inbox()
        self.mailbox.begin_processing("req-4","worker-1","msg-1","attempt-1",1)
        with self.assertRaisesRegex(MailboxError,"RESULT_ATTEMPT_FENCED_OR_INVALID"):
            self.mailbox.report_result("req-5","worker-1","msg-1",2,RECEIPT)

    def test_record_result_is_not_reviewed_or_authenticated(self):
        self.inbox()
        self.mailbox.begin_processing("req-4","worker-1","msg-1","attempt-1",1)
        out=self.mailbox.report_result("req-5","worker-1","msg-1",1,RECEIPT)
        self.assertEqual(out["phase"],"RESULT_REPORTED")
        self.assertFalse(out["receipt_authenticated"])
        self.assertFalse(out["effect_verified"])

    def test_restart_preserves_uncertain_send(self):
        self.send()
        self.mailbox.close()
        self.mailbox=DurableMailbox(self.root)
        self.assertEqual(self.mailbox.snapshot()["outbox"][0]["phase"],"SEND_UNCERTAIN")
        with self.assertRaises(MailboxError):
            self.mailbox.begin_send("req-5","msg-1","retry",2)

    def test_restart_preserves_uncertain_inbox(self):
        self.inbox()
        self.mailbox.begin_processing("req-4","worker-1","msg-1","attempt-1",1)
        self.mailbox.close()
        self.mailbox=DurableMailbox(self.root)
        self.assertEqual(self.mailbox.snapshot()["inbox"][0]["phase"],"PROCESS_UNCERTAIN")

    def test_no_implicit_network_or_worker_execution(self):
        self.send()
        self.inbox()
        self.assertFalse(self.mailbox.snapshot()["external_effects_executed"])
        self.assertFalse(self.mailbox.snapshot()["authenticated_actor_or_ack"])

    def test_missing_outbox_or_inbox_are_not_created_by_claim(self):
        with self.assertRaisesRegex(MailboxError,"OUTBOX_MESSAGE_MISSING"):
            self.mailbox.begin_send("req-x","missing","try-1",1)
        with self.assertRaisesRegex(MailboxError,"INBOX_MESSAGE_MISSING"):
            self.mailbox.begin_processing("req-y","worker-1","missing","try-1",1)
        self.assertEqual(self.mailbox.snapshot()["outbox"],[])

    def test_invalid_ids_and_sha_denied(self):
        for bad in ("", "../escape", "bad space", "a"*97):
            with self.subTest(bad=bad):
                with self.assertRaises(ProtocolError):
                    self.stage(message=bad)
        with self.assertRaises(ProtocolError):
            self.stage(digest="invalid")

    def test_boolean_epoch_denied(self):
        self.stage()
        with self.assertRaisesRegex(MailboxError,"EPOCH_INVALID"):
            self.mailbox.begin_send("req-2","msg-1","try-1",True)

    def test_snapshot_is_bounded(self):
        for k in range(8):
            self.stage(f"rq-{k}",f"msg-{k}")
        snap=self.mailbox.snapshot(3)
        self.assertTrue(snap["truncated"])
        self.assertEqual(len(snap["outbox"]),3)
        with self.assertRaisesRegex(MailboxError,"SNAPSHOT_LIMIT_INVALID"):
            self.mailbox.snapshot(1001)

    def test_unmarked_sqlite_database_denied(self):
        other=self.root/"execution_mailbox_v1.sqlite3"
        self.mailbox.close()
        other.unlink()
        con=sqlite3.connect(other)
        con.execute("CREATE TABLE foreign_data (x INT)")
        con.close()
        with self.assertRaisesRegex(MailboxError,"MAILBOX_UNRECOGNIZED_DATABASE"):
            DurableMailbox(self.root)

    def test_two_process_concurrent_send_only_one_wins(self):
        self.stage()
        barrier=threading.Barrier(2)
        successes=[]
        errors=[]
        def contender(i):
            try:
                with DurableMailbox(self.root) as other:
                    barrier.wait(timeout=5)
                    successes.append(other.begin_send(
                        f"req-{i+10}","msg-1",f"attempt-{i}",i+1))
            except (MailboxError,threading.BrokenBarrierError) as exc:
                errors.append(str(exc))
        a=threading.Thread(target=contender,args=(1,))
        b=threading.Thread(target=contender,args=(2,))
        a.start();b.start();a.join(8);b.join(8)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(len(successes),1)
        self.assertEqual(len(errors),1)

    def test_no_leak_of_payload_or_credentials_in_snapshot(self):
        self.stage()
        snap=str(self.mailbox.snapshot())
        self.assertNotIn(SHA,snap)
        self.assertNotIn("run-1",snap)

    def test_receive_does_not_implicitly_ack_outbox(self):
        self.stage()
        self.inbox()
        self.assertEqual(self.mailbox.snapshot()["outbox"][0]["phase"],"STAGED")

if __name__ == "__main__":
    unittest.main()
