"""MCP JSON-RPC stdio integration tests with the subprocess broker backend.

Every database is temporary; no connection to the installed MCP app.
"""
from __future__ import annotations
import base64
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend missing") from exc

try:
    from .transition import canonical
    from .journal import Journal
    from .host_auth import DOMAIN,SCHEMA
    from .broker_stdio import PROTOCOL,POLICY_SCHEMA
except ImportError:
    from transition import canonical
    from journal import Journal
    from host_auth import DOMAIN,SCHEMA
    from broker_stdio import PROTOCOL,POLICY_SCHEMA

class McpBrokerTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root=Path(temp.name)
        self.dev=Ed25519PrivateKey.generate()
        self.dispatcher=Ed25519PrivateKey.generate()
        self.policy_path=self.root/"policy.json"
        def grant(key,who,role,capability):
            return {
                "principal_id":who,"role":role,"key_id":who+"-key",
                "public_key_b64":base64.b64encode(
                    key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
                ).decode("ascii"),
                "scope":"scope-1","run_id":"run-1","step_id":"step-1",
                "epoch":1,"policy_revision":1,
                "capabilities":[capability,"QUERY_COMMAND_STATUS"],"revoked":False,
            }
        cfg={
            "schema":POLICY_SCHEMA,"scope":"scope-1",
            "grants":[grant(self.dev,"dev-1","developer","STAGE_INTENT"),
                      grant(self.dispatcher,"dispatcher-1","dispatcher",
                            "MARK_SEND_UNCERTAIN")],
        }
        data=canonical(cfg)
        self.policy_path.write_bytes(data)
        self.policy_sha=hashlib.sha256(data).hexdigest()
        with Journal(self.root,"execution_journal_broker.sqlite3") as j:
            j.append("run-1","step-1","plan","PLAN",0,"a"*64)
            j.append("run-1","step-1","lease","LEASE",1)
        self.now=datetime.now(timezone.utc).replace(microsecond=0)

    def auth_args(self,action="STAGE_INTENT",who=None):
        if action=="STAGE_INTENT":
            key=self.dev
            actor="dev-1"
            role="developer"
            args={"message_id":"msg-1","destination":"worker-1",
                  "payload_sha":"b"*64}
            req="req-stage"
            nonce="a"*32
        elif action=="MARK_SEND_UNCERTAIN":
            key=self.dispatcher
            actor="dispatcher-1"
            role="dispatcher"
            args={"message_id":"msg-1","attempt_id":"attempt-1"}
            req="req-mark"
            nonce="b"*32
        elif action=="QUERY_COMMAND_STATUS":
            key=self.dev
            actor="dev-1"
            role="developer"
            args={"message_id":"msg-1","target_request_id":"req-stage"}
            req="req-query"
            nonce="c"*32
        else:
            raise AssertionError(action)
        if who=="dev":
            key=self.dev
            actor="dev-1"
            role="developer"
        if who=="dispatcher":
            key=self.dispatcher
            actor="dispatcher-1"
            role="dispatcher"
        doc={
            "schema":SCHEMA,
            "principal_id":actor,"role":role,"key_id":actor+"-key",
            "scope":"scope-1","run_id":"run-1","step_id":"step-1",
            "epoch":1,"policy_revision":1,"request_id":req,
            "nonce":nonce,"action":action,
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":(self.now-timedelta(seconds=3)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expires_utc":(self.now+timedelta(seconds=50)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        signed={"document":doc,"signature_b64":base64.b64encode(
            key.sign(DOMAIN+canonical(doc))).decode("ascii")}
        return {
            "auth":signed,"run_id":"run-1","step_id":"step-1",
            "request_id":req,"epoch":1,**args,
        }

    @staticmethod
    def request(name,args=None,ident=1):
        return {"jsonrpc":"2.0","id":ident,"method":"tools/call",
                "params":{"name":name,"arguments":{} if args is None else args}}

    def invoke(self,messages,*,raw=False,digest=None):
        path=Path(__file__).resolve().parent/"broker_mcp_bridge.py"
        argv=[sys.executable,str(path),
              "--root",str(self.root),"--policy",str(self.policy_path),
              "--expected-policy-sha256",digest or self.policy_sha,
              "--legacy-unsigned-policy-for-tests"]
        payload=messages if raw else b"".join(
            json.dumps(x,separators=(",",":"),ensure_ascii=True).encode()+b"\n"
            for x in messages)
        proc=subprocess.run(argv,input=payload,stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,timeout=20,check=False)
        return proc,[json.loads(line) for line in proc.stdout.splitlines()]

    def state(self):
        with Journal(self.root,"execution_journal_broker.sqlite3") as j:
            return j.verify("run-1")

    def test_initialize_and_list_only_four_explicit_tools(self):
        proc,result=self.invoke([
            {"jsonrpc":"2.0","id":1,"method":"initialize","params":{}},
            {"jsonrpc":"2.0","method":"notifications/initialized"},
            {"jsonrpc":"2.0","id":2,"method":"tools/list"},
        ])
        self.assertEqual(proc.returncode,0)
        self.assertEqual(len(result),2)
        self.assertEqual(result[0]["result"]["protocolVersion"],"2025-11-25")
        names={item["name"] for item in result[1]["result"]["tools"]}
        self.assertEqual(names,{
            "broker_health","broker_stage_intent","broker_mark_send_uncertain",
            "broker_query_command_status"})
        self.assertNotIn("run_command",names)

    def test_signed_query_after_broker_reply_loss_never_retries(self):
        command=self.request("broker_stage_intent",self.auth_args(),1)
        _,first=self.invoke([command])
        self.assertFalse(first[0]["result"]["isError"],first)
        before=self.state()["events_examined"]
        query=self.request(
            "broker_query_command_status",
            self.auth_args("QUERY_COMMAND_STATUS"),2)
        _,result=self.invoke([query])
        self.assertFalse(result[0]["result"]["isError"],result)
        status=json.loads(result[0]["result"]["content"][0]["text"])["result"]
        self.assertTrue(status["recorded"])
        self.assertEqual(status["reconciliation_state"],"STAGE_INTENT_RECORDED")
        self.assertFalse(status["automatic_retry_permitted"])
        self.assertFalse(status["changes_written"])
        self.assertEqual(self.state()["events_examined"],before)

    def test_signed_query_absence_is_not_permission_to_retry(self):
        _,result=self.invoke([self.request(
            "broker_query_command_status",
            self.auth_args("QUERY_COMMAND_STATUS"))])
        self.assertFalse(result[0]["result"]["isError"],result)
        answer=json.loads(result[0]["result"]["content"][0]["text"])["result"]
        self.assertFalse(answer["recorded"])
        self.assertFalse(answer["automatic_retry_permitted"])
        self.assertEqual(self.state()["events_examined"],2)

    def test_signed_query_can_be_repeated_without_recording_itself(self):
        _,result=self.invoke([self.request(
            "broker_stage_intent",self.auth_args(),1)])
        self.assertFalse(result[0]["result"]["isError"],result)
        query=self.request("broker_query_command_status",
                           self.auth_args("QUERY_COMMAND_STATUS"),2)
        _,results=self.invoke([query,query])
        self.assertEqual(len(results),2)
        self.assertTrue(all(not x["result"]["isError"] for x in results))
        self.assertEqual(self.state()["events_examined"],3)

    def test_health_over_mcp(self):
        _,result=self.invoke([self.request("broker_health")])
        self.assertFalse(result[0]["result"]["isError"])
        value=json.loads(result[0]["result"]["content"][0]["text"])
        self.assertTrue(value["ready"])
        self.assertFalse(value["mcp_connected"])

    def test_stage_and_mark_through_two_broker_children(self):
        _,result=self.invoke([
            self.request("broker_stage_intent",self.auth_args(),1),
            self.request("broker_mark_send_uncertain",
                         self.auth_args("MARK_SEND_UNCERTAIN"),2),
        ])
        self.assertEqual(len(result),2)
        for entry in result:
            self.assertFalse(entry["result"]["isError"],entry)
        self.assertEqual(self.state()["events_examined"],3)
        self.assertFalse(json.loads(
            result[1]["result"]["content"][0]["text"]
        )["result"]["transport_invoked"])

    def test_broker_replay_denied_over_mcp(self):
        cmd=self.request("broker_stage_intent",self.auth_args())
        _,results=self.invoke([cmd,cmd])
        self.assertFalse(results[0]["result"]["isError"])
        self.assertTrue(results[1]["result"]["isError"])
        self.assertEqual(self.state()["events_examined"],3)

    def test_unsigned_authorization_denied(self):
        args=self.auth_args()
        args["auth"]={}
        _,result=self.invoke([self.request("broker_stage_intent",args)])
        self.assertTrue(result[0]["result"]["isError"])
        self.assertEqual(self.state()["events_examined"],2)

    def test_wrong_role_cannot_use_dispatcher_tool(self):
        args=self.auth_args("MARK_SEND_UNCERTAIN",who="dev")
        _,result=self.invoke([self.request("broker_mark_send_uncertain",args)])
        self.assertTrue(result[0]["result"]["isError"])

    def test_arbitrary_host_tool_cannot_be_called(self):
        _,result=self.invoke([self.request("run_command",
            {"command":"powershell","args":["whoami"]})])
        self.assertEqual(result[0]["error"]["code"],-32602)
        self.assertEqual(self.state()["events_examined"],2)

    def test_extra_tool_parameters_denied(self):
        args=self.auth_args()
        args["execute"]=True
        _,result=self.invoke([self.request("broker_stage_intent",args)])
        self.assertEqual(result[0]["error"]["code"],-32602)

    def test_unknown_method_denied(self):
        _,result=self.invoke([{"jsonrpc":"2.0","id":1,"method":"resources/read"}])
        self.assertEqual(result[0]["error"]["code"],-32601)

    def test_invalid_json_before_health_is_handled(self):
        raw=b'bad-json\n'+json.dumps(self.request("broker_health")).encode()+b"\n"
        proc,result=self.invoke(raw,raw=True)
        self.assertEqual(proc.returncode,0)
        self.assertEqual(result[0]["error"]["code"],-32700)
        self.assertFalse(result[1]["result"]["isError"])

    def test_tampered_pinned_policy_rejects_child(self):
        _,first=self.invoke([self.request("broker_health")])
        self.assertFalse(first[0]["result"]["isError"])
        self.policy_path.write_bytes(self.policy_path.read_bytes()+b" ")
        _,result=self.invoke([self.request("broker_stage_intent",
                                            self.auth_args())])
        self.assertTrue(result[0]["result"]["isError"])
        self.assertEqual(self.state()["events_examined"],2)

    def test_large_mcp_frame_terminates_not_execute(self):
        proc,result=self.invoke(b'{"long":"'+b"a"*70000+b'"}\n',raw=True)
        self.assertEqual(proc.returncode,2)
        self.assertEqual(result[0]["error"]["code"],-32700)

    def test_malformed_protocol_denied(self):
        _,result=self.invoke([{"jsonrpc":"1.0","id":1,"method":"tools/list"}])
        self.assertEqual(result[0]["error"]["code"],-32600)

    def test_second_process_preserves_event_and_nonce_history(self):
        first=self.request("broker_stage_intent",self.auth_args())
        self.invoke([first])
        _,result=self.invoke([first])
        self.assertTrue(result[0]["result"]["isError"])
        self.assertEqual(self.state()["events_examined"],3)

if __name__=="__main__":
    unittest.main()
