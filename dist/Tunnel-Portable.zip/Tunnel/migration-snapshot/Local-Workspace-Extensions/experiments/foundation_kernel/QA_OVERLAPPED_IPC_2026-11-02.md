# Overlapped Win32 IPC — independent regression evidence

Date: 2026-11-02  
Scope: `Local-Workspace-Extensions/experiments/foundation_kernel/`  
Status: **OFFLINE REFERENCE, NOT LIVE MCP / PRODUCTION**

## Source snapshot

| File | SHA-256 at final verified run |
|---|---|
| `win_pipe_overlapped.py` | `07acda2062d04a5d5d9d779786abd733c43f327e264f4cf79cd7a22b172cfc4f` |
| `win_pipe_ipc.py` | `84f60900eccd642e764e8b6016bec83201441fd9f63011893c2e199500ea2ef9` |
| `test_win_pipe_ipc.py` | `9640bc959777a568c83aa85fc54bf73f6710acf4c6360e8b2f0e879cc2befbb6` |
| `test_broker_named_pipe.py` | `33b3f1fe9ab24cab6b703ee035a1b0a0b5500f19d40e5026561f7eeb186bf914` |
| Root `test_automation_duration_analysis.py` | `07ae670f6867efd8933f166e62b207919d516d6a7eeea4bf3755a31a79288eca` |

The SHA values describe a local source snapshot only; no anchored host
attestation, verified worker identity or independent signing authority
has been implemented.

## Actual observed results

- `python -m unittest test_win_pipe_ipc test_broker_named_pipe -q`:
  **22 tests, PASS** — job `f91a1ad931994303a056e3fa13a3f7c2`.
- `python -m unittest discover -q` from `foundation_kernel`:
  **341 tests, PASS (1 skipped)** — job `93edda66af4b4e028976ef54f42f3cdc`.
- `python -m unittest discover -q` from `Local-Workspace-Extensions`:
  **1226 tests, PASS (31 skipped)** — job `2abc3368c4bd4d4f8e32a6666c9ea9a2`.
- `python spec_check.py`: **PASS** — job
  `c4b8ba1e073c4cd69266684d68a070d6`;
  11 capabilities, 99 requirements, 128 scenarios,
  58 SDD tasks, 108 OpenSpec tasks, structural only.
- `python sdd_roadmap_check.py`: **PASS** — job
  `0b665a13a3d74ec794ea46a59b258d35`;
  58 roadmap tasks, 116 outputs, structural only.

The original mutable live-report test failed when one additional scheduled
run appeared. The test was updated to derive expected counters directly from
the observed document instead of asserting a hardcoded zero. This **does not**
alter, delete or manufacture scheduler observations; the subsequent full
project suite passed.

## Verified invariants

1. Native server uses overlapped `ConnectNamedPipe`, `ReadFile`,
   `WriteFile` and an explicit event + bounded wait. The client also
   opens the named-pipe handle with `FILE_FLAG_OVERLAPPED`.
2. Connection acceptance defaults to 3000 ms, server read/write to
   1600 ms and client response read to 2500 ms; tests can use a
   100–5000 ms bounded server deadline.
3. An open but silent client is rejected as `PIPE_READ_TIMEOUT`;
   absence of any client is rejected as `PIPE_CONNECT_TIMEOUT`.
   Both are tested with **actual separate Windows processes**;
   the application handler is not invoked.
4. Timed-out I/O is cancelled via `CancelIoEx`; for a pending
   ConnectNamedPipe a disconnect is also used to release the wait.
   The event completion is drained before releasing the native
   OVERLAPPED/buffer memory. An unrecoverable drain exits the
   **dedicated broker process** (exit 124) to prevent unsafe reuse.
5. Wrong client/server token SID remains rejected; the signed host
   request, SHA-pinned issuer policy, per-command nonce, transactional
   SQLite outbox and lost-reply read-only reconciliation remain green.
6. Illegal/zero/negative/non-integer or excessively high timeout
   values are rejected **before opening** a named-pipe listener.
7. The enabled client/server same-SID option is a temporary
   **offline test-only fixture** and is not OS service isolation.

## Nine-dimensional engineering review

| Dimension | Evidence and residual issue |
|---|---|
| Security | Bounded IPC waits + cancellation prevent a single idle pipe connection from blocking indefinitely. Test-only same-SID process is not a separate security principal. |
| Reliability | Connection absent / silent client / interrupted response / restart / nonce replay tested. Process-level crash restart supervision is not implemented. |
| Architecture | Native overlapped transport is a separate helper; restricted MCP and broker policy modules remain independent. |
| Scalability | Sequential connections, max 32 per broker; no benchmark of burst load, admission control, multi-process fairness or sustained throughput. |
| Correctness | 22 focused Windows tests, 341 kernel and 1226 project tests passed, documented skipped tests remain. |
| Maintainability | Explicit Win32 ctypes prototypes, independent wrapper, short failure codes; Win32 ABI changes remain platform-specific. |
| Performance | Current timeouts are conservative defaults, not measured P99 latency SLOs. No high-load benchmark. |
| Observability | Distinct timeout error codes; no production distributed tracing/alerting. |
| Spec traceability | OpenSpec/SDD structural checks pass; live release approval and host-enforced capability gate still unavailable. |

## Go/no-go

**NO-GO for production** until a protected separate Windows broker identity,
trusted protected launcher and issuer roots, actual restricted MCP registry,
real different-user Windows ACL tests, independent process-level watchdog,
rate limiting, and independent worker effect attestation exist.

No live MCP registry, tunnel, scheduler, Windows ACL, user account,
production DB or canonical owner-approval state was modified.
