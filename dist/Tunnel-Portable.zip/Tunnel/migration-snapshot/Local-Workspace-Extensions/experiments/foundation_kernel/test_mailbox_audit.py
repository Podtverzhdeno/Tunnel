"""Cross-store crash and evidentiary consistency tests."""
from __future__ import annotations
import tempfile
import unittest
from pathlib import Path

try:
    from .journal import Journal
    from .durable_mailbox import DurableMailbox
    from .evidence_store import EvidenceStore
    from .mailbox_audit import audit_delivery
except ImportError:
    from journal import Journal
    from durable_mailbox import DurableMailbox
    from evidence_store import EvidenceStore
    from mailbox_audit import audit_delivery

SPEC="a"*64
PAYLOAD="b"*64

class DeliveryAuditTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root=Path(temp.name)
        (root/"send").mkdir()
        (root/"receive").mkdir()
        self.journal=Journal(root,"execution_journal_delivery.sqlite3")
        self.sender=DurableMailbox(root/"send")
        self.receiver=DurableMailbox(root/"receive")
        self.store=EvidenceStore(root)
        self.addCleanup(self.journal.close)
        self.addCleanup(self.sender.close)
        self.addCleanup(self.receiver.close)
        self.journal.append("run-1","step-1","j1","PLAN",0,SPEC)
        self.journal.append("run-1","step-1","j2","LEASE",1)
        self.sender.stage("s1","msg-1","run-1","step-1","worker-1",PAYLOAD)

    def intent(self, *, msg="msg-1", payload=PAYLOAD, epoch=1):
        self.journal.append("run-1","step-1","j3","INTENT",epoch,
                            payload={"message_id":msg,"payload_sha":payload})
        return self.sender.begin_send("s2","msg-1","a1",1)

    def accept(self, payload=PAYLOAD):
        return self.receiver.receive("r1","worker-1","msg-1",payload)

    def test_staged_is_safe_but_not_delivery_proof(self):
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertTrue(result["ok"])
        self.assertEqual(result["decision"],"STAGED_ONLY")
        self.assertFalse(result["can_approve"])

    def test_uncertain_send_with_lost_network_response(self):
        self.intent()
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertTrue(result["ok"])
        self.assertEqual(result["send_intents_seen"],1)
        self.assertFalse(result["can_replay_unknown_external_effect"])
        self.assertFalse(result["actor_authenticated"])

    def test_unlinked_intent_is_blocked(self):
        self.intent(msg="wrong-msg")
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(result["ok"])
        self.assertIn("MISSING_MATCHING_INTENT",result["findings"][0])

    def test_unlinked_payload_is_blocked(self):
        self.intent(payload="c"*64)
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(result["ok"])
        self.assertIn("MISSING_MATCHING_INTENT",result["findings"][0])

    def test_cross_inbox_payload_mismatch(self):
        self.intent()
        self.accept("c"*64)
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(result["ok"])
        self.assertIn("INBOX_PAYLOAD_MISMATCH",result["findings"][0])

    def test_ack_without_actual_inbox_receipt_blocks(self):
        self.intent()
        ack=self.store.put("ack",SPEC,{"status":"reported"})
        self.sender.report_ack("s3","msg-1",1,ack["sha256"])
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(result["ok"])
        self.assertIn("ACK_WITHOUT_INBOX",result["findings"][0])

    def test_local_ack_consistency_is_not_delivery_authorization(self):
        self.intent()
        self.accept()
        ack=self.store.put("ack",SPEC,{"status":"seen"})
        self.sender.report_ack("s3","msg-1",1,ack["sha256"])
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertTrue(result["ok"])
        self.assertEqual(result["reported_acks_with_local_evidence"],1)
        self.assertFalse(result["independent_worker_verified"])
        self.assertFalse(result["can_approve"])

    def test_invalid_local_ack_digest_blocks(self):
        self.intent()
        self.accept()
        ack=self.store.put("ack","f"*64,{"status":"seen"})
        self.sender.report_ack("s3","msg-1",1,ack["sha256"])
        result=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(result["ok"])
        self.assertIn("ACK_LOCAL_EVIDENCE_INVALID",result["findings"][0])

    def test_worker_result_must_reference_correct_spec(self):
        self.intent()
        self.accept()
        self.receiver.begin_processing("r2","worker-1","msg-1","act-1",1)
        result=self.store.put("result","c"*64,{"done":True})
        self.receiver.report_result("r3","worker-1","msg-1",1,result["sha256"])
        report=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(report["ok"])
        self.assertIn("WORKER_LOCAL_EVIDENCE_INVALID",report["findings"][0])

    def test_journal_tamper_is_denied_before_comparison(self):
        self.journal.db.execute("UPDATE heads SET entry_sha=?",("f"*64,))
        report=audit_delivery(self.journal,self.sender,self.receiver,
                              self.store,"run-1")
        self.assertFalse(report["ok"])
        self.assertIn("JOURNAL_INVALID",report["findings"][0])

    def test_bounded_audit(self):
        with self.assertRaisesRegex(ValueError,"DELIVERY_AUDIT_LIMIT_INVALID"):
            audit_delivery(self.journal,self.sender,self.receiver,
                           self.store,"run-1",limit=0)

if __name__=="__main__":
    unittest.main()
