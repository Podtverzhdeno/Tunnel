"""Evidence-store regression tests for immutable SHA-addressed receipts."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

try:
    from .evidence_store import EvidenceStore, EvidenceError, MAX_BYTES
except ImportError:
    from evidence_store import EvidenceStore, EvidenceError, MAX_BYTES

SHA="a"*64

class EvidenceTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.store=EvidenceStore(self.root)

    def test_immutable_receipt_created(self):
        r=self.store.put("test_result",SHA,{"passed":True,"cases":12})
        self.assertTrue(r["created"])
        self.assertFalse(r["authenticated"])
        v=self.store.verify(r["sha256"])
        self.assertEqual(v["source_sha"],SHA)
        self.assertFalse(v["source_authenticated"])

    def test_repeated_evidence_has_same_digest(self):
        r=self.store.put("review",SHA,{"note":"checked"})
        again=self.store.put("review",SHA,{"note":"checked"})
        self.assertFalse(again["created"])
        self.assertEqual(r["sha256"],again["sha256"])

    def test_different_source_has_different_digest(self):
        a=self.store.put("review",SHA,{"verdict":"PASS"})
        b=self.store.put("review","b"*64,{"verdict":"PASS"})
        self.assertNotEqual(a["sha256"],b["sha256"])

    def test_verification_is_read_only_when_absent(self):
        missing="b"*64
        self.assertFalse((self.store.root/missing[:2]).exists())
        self.assertEqual(self.store.verify(missing)["error"],"EVIDENCE_NOT_FOUND")
        self.assertFalse((self.store.root/missing[:2]).exists())

    def test_tampered_bytes_detected(self):
        r=self.store.put("test",SHA,{"result":"done"})
        target=self.store.root/r["sha256"][:2]/(r["sha256"]+".json")
        target.write_bytes(target.read_bytes()+b" ")
        self.assertEqual(self.store.verify(r["sha256"])["error"],"EVIDENCE_HASH_DIVERGED")
        with self.assertRaisesRegex(EvidenceError,"EVIDENCE_INTEGRITY_FAILURE"):
            self.store.put("test",SHA,{"result":"done"})

    def test_no_overwrite_different_existing_content(self):
        r=self.store.put("unit",SHA,{"x":1})
        target=self.store.root/r["sha256"][:2]/(r["sha256"]+".json")
        target.write_bytes(b"wrong")
        with self.assertRaises(EvidenceError):
            self.store.put("unit",SHA,{"x":1})
        self.assertEqual(target.read_bytes(),b"wrong")

    def test_secrets_rejected_even_nested(self):
        for document in ({"token":"abc"},{"nested":{"password":"my-pwd"}},
                         {"records":[{"api_key":"secret"}]}):
            with self.subTest(document=document):
                with self.assertRaisesRegex(EvidenceError,"SENSITIVE_FIELD_DENIED"):
                    self.store.put("test",SHA,document)

    def test_no_external_paths_or_traversal(self):
        for item in ("../x","./x","x", "y"*65):
            with self.subTest(item=item):
                with self.assertRaisesRegex(EvidenceError,"EVIDENCE_ID_INVALID"):
                    self.store.verify(item)

    def test_payload_must_be_json_object(self):
        with self.assertRaises(EvidenceError):
            self.store.put("test",SHA,["list"])
        with self.assertRaises(EvidenceError):
            self.store.put("test",SHA,{"bad":float("nan")})

    def test_missing_source_digest_fails(self):
        with self.assertRaises(ValueError):
            self.store.put("test","not-a-digest",{})

    def test_oversized_payload_denied(self):
        with self.assertRaisesRegex(EvidenceError,"EVIDENCE_TOO_LARGE"):
            self.store.put("test",SHA,{"text":"x"*(MAX_BYTES+1)})

    def test_source_and_approval_not_authenticated(self):
        r=self.store.put("review",SHA,{"claimed_actor":"architect","approved":True})
        v=self.store.verify(r["sha256"])
        self.assertTrue(v["ok"])
        self.assertFalse(v["authenticated"])

    def test_store_name_has_fixed_scope(self):
        self.assertEqual(self.store.root,self.root/"evidence_immutable")

    def test_reject_file_symlink(self):
        r=self.store.put("test",SHA,{"x":1})
        target=self.store.root/r["sha256"][:2]/(r["sha256"]+".json")
        target.unlink()
        external=self.root/"outside.json"
        external.write_text("unsafe",encoding="utf8")
        try: target.symlink_to(external)
        except (NotImplementedError,OSError): self.skipTest("Windows symlink privilege unavailable")
        with self.assertRaisesRegex(EvidenceError,"EVIDENCE_LINK_DENIED"):
            self.store.verify(r["sha256"])

if __name__=="__main__":
    unittest.main()
