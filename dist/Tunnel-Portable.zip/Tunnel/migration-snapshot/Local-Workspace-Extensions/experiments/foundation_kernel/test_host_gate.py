"""Adversarial tests of the isolated capability-enforced dispatch boundary.

Ephemeral Ed25519 keys only. Never accesses the live coordinator, host MCP,
secrets, tunnel, Git or actual network. No owner approval is simulated.
"""
from __future__ import annotations
import base64
import hashlib
import sqlite3
import tempfile
import threading
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
from unittest.mock import patch

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
except ImportError as exc:
    raise unittest.SkipTest("Ed25519 cryptography backend unavailable") from exc

try:
    from .transition import canonical, ProtocolError
    from .journal import Journal
    from .atomic_dispatch import AtomicDispatch
    from .host_auth import (DOMAIN, SCHEMA, HostAuthError, HostGrant,
                            HostPolicy, verify_host_command)
    from .host_gate import HostDispatchGate, HostGateError
except ImportError:
    from transition import canonical, ProtocolError
    from journal import Journal
    from atomic_dispatch import AtomicDispatch
    from host_auth import (DOMAIN, SCHEMA, HostAuthError, HostGrant,
                           HostPolicy, verify_host_command)
    from host_gate import HostDispatchGate, HostGateError

NOW=datetime(2026,11,2,12,0,tzinfo=timezone.utc)
SPEC="a"*64
PAYLOAD="b"*64

class HostGateTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name)
        self.journal=Journal(self.root,"execution_journal_hostgate.sqlite3")
        self.addCleanup(self.journal.close)
        self.dispatch=AtomicDispatch(self.journal)
        self.key=Ed25519PrivateKey.generate()
        self.public=self.key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        self.grant=HostGrant(
            principal_id="agent-dev1",role="developer",key_id="agent-dev1-key",
            public_key=self.public,scope="project-alpha",
            run_id="run-1",step_id="step-1",epoch=1,policy_revision=3,
            capabilities=frozenset({"STAGE_INTENT","MARK_SEND_UNCERTAIN"}),
        )
        self.policy=HostPolicy((self.grant,))
        self.gate=HostDispatchGate(self.dispatch,self.policy)
        self.journal.append("run-1","step-1","plan-1","PLAN",0,SPEC)
        self.journal.append("run-1","step-1","lease-1","LEASE",1)

    def signed(self, *, action="STAGE_INTENT", req="command-1",
               nonce="1"*32, args=None, overrides=None, key=None):
        if args is None:
            args=(
                {"message_id":"message-1","destination":"worker-1",
                 "payload_sha":PAYLOAD}
                if action=="STAGE_INTENT" else
                {"message_id":"message-1","attempt_id":"attempt-1"}
            )
        doc={
            "schema":SCHEMA,"principal_id":"agent-dev1","role":"developer",
            "key_id":"agent-dev1-key",
            "policy_revision":3,"scope":"project-alpha","run_id":"run-1",
            "step_id":"step-1","epoch":1,"request_id":req,"nonce":nonce,
            "action":action,
            "arguments_sha":hashlib.sha256(canonical(args)).hexdigest(),
            "issued_utc":"2026-11-02T11:59:45Z",
            "expires_utc":"2026-11-02T12:00:45Z",
        }
        if overrides:
            doc.update(overrides)
        signature=(key or self.key).sign(DOMAIN+canonical(doc))
        return {"document":doc,
                "signature_b64":base64.b64encode(signature).decode("ascii")}

    def stage(self, doc=None, *, req="command-1", nonce="1"*32, **kwargs):
        doc=self.signed(req=req,nonce=nonce) if doc is None else doc
        return self.gate.stage_intent(doc,now=NOW,scope="project-alpha",
            run_id="run-1",step_id="step-1",request_id=req,
            epoch=1,message_id="message-1",
            destination="worker-1",payload_sha=PAYLOAD,**kwargs)

    def mark(self, *, req="command-2", nonce="2"*32, doc=None):
        doc=(self.signed(action="MARK_SEND_UNCERTAIN",req=req,nonce=nonce)
             if doc is None else doc)
        return self.gate.mark_send_uncertain(
            doc,now=NOW,scope="project-alpha",
            run_id="run-1",step_id="step-1",
            request_id=req,epoch=1,
            message_id="message-1",attempt_id="attempt-1")

    def test_signature_grant_and_atomic_stage(self):
        result=self.stage()
        self.assertTrue(result["host_request_signature_verified"])
        self.assertTrue(result["host_capability_checked"])
        self.assertTrue(result["local_atomic_commit"])
        self.assertEqual(result["authenticated_principal_id"],"agent-dev1")
        self.assertFalse(result["live_mcp_host_enforced"])
        self.assertFalse(result["can_accept_review_or_deploy"])
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],3)

    def test_authorized_mark_after_stage(self):
        self.stage()
        result=self.mark()
        self.assertTrue(result["host_nonce_consumed"])
        self.assertFalse(result["transport_invoked"])
        self.assertFalse(result["automatic_retry_permitted"])
        self.assertEqual(result["external_effect_state"],"UNKNOWN")
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],2)

    def test_repeated_exact_command_denied(self):
        self.stage()
        with self.assertRaisesRegex(HostGateError,"ALREADY_CONSUMED"):
            self.stage()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_nonce_reuse_with_new_request_denied(self):
        self.stage()
        with self.assertRaisesRegex(HostGateError,"ALREADY_CONSUMED"):
            self.stage(self.signed(req="other-request",nonce="1"*32),
                       req="other-request")
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_request_id_reuse_with_new_nonce_denied(self):
        self.stage()
        with self.assertRaisesRegex(HostGateError,"ALREADY_CONSUMED"):
            self.stage(self.signed(req="command-1",nonce="3"*32),
                       req="command-1",nonce="3"*32)

    def test_no_signature_cannot_stage(self):
        with self.assertRaisesRegex(HostAuthError,"HOST_ENVELOPE_INVALID"):
            self.stage({})
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)

    def test_forged_signature_denied(self):
        with self.assertRaisesRegex(HostAuthError,"HOST_SIGNATURE_INVALID"):
            self.stage(self.signed(key=Ed25519PrivateKey.generate()))
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)

    def test_role_cannot_self_elevate(self):
        for tamper in (
            {"principal_id":"agent-architect"},
            {"role":"architect-reviewer"},
            {"scope":"project-other"},
            {"policy_revision":4},
            {"run_id":"run-2"},
            {"step_id":"step-2"},
            {"epoch":2},
        ):
            with self.subTest(tamper=tamper):
                with self.assertRaises(HostAuthError):
                    self.stage(self.signed(overrides=tamper))

    def test_untrusted_key_must_not_be_bootstrapped(self):
        with self.assertRaisesRegex(HostAuthError,"HOST_KEY_UNKNOWN_OR_REVOKED"):
            self.stage(self.signed(overrides={"key_id":"self-issued"}))

    def test_grant_cannot_claim_review_or_deployment(self):
        for forbidden in ("ACCEPT_REVIEW","DEPLOY","RUN_SHELL","GIT_PUSH"):
            with self.subTest(forbidden=forbidden):
                with self.assertRaisesRegex(HostAuthError,"HOST_ACTION_NOT_EXPOSED"):
                    verify_host_command(self.signed(),self.policy,now=NOW,
                        action=forbidden,run_id="run-1",
                        step_id="step-1",epoch=1,
                        request_id="command-1",scope="project-alpha",
                        arguments={})

    def test_wrong_arguments_hash_denied(self):
        args={"message_id":"message-1","destination":"worker-2","payload_sha":PAYLOAD}
        with self.assertRaisesRegex(HostAuthError,"HOST_COMMAND_CONTEXT_MISMATCH"):
            self.stage(self.signed(args=args))

    def test_expired_signature_denied(self):
        request=self.signed()
        with self.assertRaisesRegex(HostAuthError,"HOST_REQUEST_EXPIRED"):
            self.gate.stage_intent(request,now=NOW+timedelta(minutes=2),
                scope="project-alpha",run_id="run-1",step_id="step-1",
                request_id="command-1",epoch=1,message_id="message-1",
                destination="worker-1",payload_sha=PAYLOAD)

    def test_future_signature_denied(self):
        request=self.signed(overrides={
            "issued_utc":"2026-11-02T12:02:00Z",
            "expires_utc":"2026-11-02T12:02:45Z",
        })
        with self.assertRaisesRegex(HostAuthError,"HOST_REQUEST_FROM_FUTURE"):
            self.stage(request)

    def test_revoked_key_denied(self):
        revoked=HostGrant(
            self.grant.principal_id,self.grant.role,self.grant.key_id,self.public,
            self.grant.scope,self.grant.run_id,self.grant.step_id,
            1,3,self.grant.capabilities,True)
        self.gate.policy=HostPolicy((revoked,))
        with self.assertRaisesRegex(HostAuthError,"HOST_KEY_UNKNOWN_OR_REVOKED"):
            self.stage()

    def test_no_rights_to_send_without_capability(self):
        allowed=HostGrant(
            self.grant.principal_id,self.grant.role,self.grant.key_id,self.public,
            self.grant.scope,self.grant.run_id,self.grant.step_id,
            1,3,frozenset({"STAGE_INTENT"}))
        self.gate.policy=HostPolicy((allowed,))
        self.stage()
        with self.assertRaisesRegex(HostAuthError,"HOST_CAPABILITY_DENIED"):
            self.mark()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_old_policy_revision_denied(self):
        new=HostGrant(
            self.grant.principal_id,self.grant.role,self.grant.key_id,self.public,
            self.grant.scope,self.grant.run_id,self.grant.step_id,
            1,4,self.grant.capabilities)
        self.gate.policy=HostPolicy((new,))
        with self.assertRaisesRegex(HostAuthError,"HOST_CAPABILITY_DENIED"):
            self.stage()

    def test_crash_injection_outbox_insert_rolls_back_auth_and_intent(self):
        self.gate.db.execute("""
            CREATE TRIGGER fail_gate BEFORE INSERT ON atomic_outbox
            BEGIN SELECT RAISE(ABORT, 'forced failure'); END
        """)
        with self.assertRaises(sqlite3.IntegrityError):
            self.stage()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)
        self.gate.db.execute("DROP TRIGGER fail_gate")
        self.assertTrue(self.stage()["ok"])

    def test_crash_injection_auth_insert_rolls_back_outbox_and_intent(self):
        self.gate.db.execute("""
            CREATE TRIGGER fail_gate BEFORE INSERT ON host_gate_claims
            BEGIN SELECT RAISE(ABORT, 'forced failure'); END
        """)
        with self.assertRaises(sqlite3.IntegrityError):
            self.stage()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)
        self.assertFalse(self.gate.db.execute("SELECT 1 FROM atomic_outbox").fetchone())

    def test_failed_mark_does_not_consume_nonce(self):
        with self.assertRaisesRegex(HostGateError,"HOST_MESSAGE_NOT_FOUND"):
            self.mark()
        self.stage()
        self.assertTrue(self.mark()["ok"])
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],2)

    def test_unexpected_sender_epoch_denied_even_if_signed(self):
        self.journal.db.execute("UPDATE steps SET epoch=2 WHERE step_id='step-1'")
        with self.assertRaises(HostGateError):
            self.stage()

    def test_concurrent_same_command_exactly_one_commit(self):
        barrier=threading.Barrier(2)
        signed=self.signed()
        successes=[]
        errors=[]
        def attempt():
            try:
                with Journal(self.root,"execution_journal_hostgate.sqlite3") as j:
                    gate=HostDispatchGate(AtomicDispatch(j),self.policy)
                    barrier.wait(timeout=8)
                    successes.append(gate.stage_intent(
                        signed,now=NOW,scope="project-alpha",run_id="run-1",
                        step_id="step-1",request_id="command-1",
                        epoch=1,message_id="message-1",
                        destination="worker-1",payload_sha=PAYLOAD))
            except Exception as exc:
                errors.append(str(exc))
        a=threading.Thread(target=attempt)
        b=threading.Thread(target=attempt)
        a.start();b.start();a.join(10);b.join(10)
        self.assertFalse(a.is_alive() or b.is_alive())
        self.assertEqual(len(successes),1)
        self.assertEqual(len(errors),1)
        self.assertIn("ALREADY_CONSUMED",errors[0])
        self.assertEqual(self.journal.verify("run-1")["events_examined"],3)
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)

    def test_tampered_atomic_history_denies_even_valid_signature(self):
        self.stage()
        self.journal.db.execute(
            "UPDATE atomic_outbox SET payload_sha=? WHERE message_id=?",
            ("f"*64,"message-1"))
        with self.assertRaisesRegex(HostGateError,"HOST_ATOMIC_AUDIT_FAILED"):
            self.mark()

    def test_untrusted_clock_denied(self):
        with self.assertRaisesRegex(HostAuthError,"HOST_CLOCK_REQUIRED"):
            self.gate.stage_intent(
                self.signed(),now=NOW.replace(tzinfo=None),
                scope="project-alpha",run_id="run-1",step_id="step-1",
                request_id="command-1",epoch=1,message_id="message-1",
                destination="worker-1",payload_sha=PAYLOAD)

    def test_malformed_nonce_denied(self):
        with self.assertRaisesRegex(HostAuthError,"HOST_NONCE_INVALID"):
            self.stage(self.signed(overrides={"nonce":"123"}))

    def test_boolean_epoch_denied(self):
        with self.assertRaises(HostAuthError):
            self.gate.stage_intent(
                self.signed(),now=NOW,scope="project-alpha",run_id="run-1",
                step_id="step-1",request_id="command-1",
                epoch=True,message_id="message-1",
                destination="worker-1",payload_sha=PAYLOAD)

    def test_policy_rejects_duplicate_public_key(self):
        other=HostGrant(
            "another-agent","developer","other-key",self.public,"project-alpha",
            "run-2","step-2",1,3,frozenset({"STAGE_INTENT"}))
        with self.assertRaisesRegex(HostAuthError,"HOST_POLICY_DUPLICATE_KEY"):
            HostPolicy((self.grant,other))

    def test_signature_domain_prevents_cross_protocol_replay(self):
        doc=self.signed()
        doc["signature_b64"]=base64.b64encode(
            self.key.sign(canonical(doc["document"]))).decode("ascii")
        with self.assertRaisesRegex(HostAuthError,"HOST_SIGNATURE_INVALID"):
            self.stage(doc)

    def test_hard_process_crash_before_shared_commit_rolls_back_everything(self):
        """Kill a *disposable child*, after journal+outbox but before auth claim."""
        import subprocess
        import sys
        source=(
            "import os,sys,base64,hashlib\n"
            "from datetime import datetime,timezone\n"
            "from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey\n"
            "from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat\n"
            "from transition import canonical\n"
            "from journal import Journal\n"
            "from atomic_dispatch import AtomicDispatch\n"
            "from host_auth import DOMAIN,SCHEMA,HostGrant,HostPolicy\n"
            "from host_gate import HostDispatchGate\n"
            "with Journal(sys.argv[1],'execution_journal_hostgate.sqlite3') as j:\n"
            "  key=Ed25519PrivateKey.generate()\n"
            "  pub=key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)\n"
            "  grant=HostGrant('agent-dev1','developer','child-key',pub,'project-alpha',"
            "'run-1','step-1',1,3,frozenset({'STAGE_INTENT'}))\n"
            "  gate=HostDispatchGate(AtomicDispatch(j),HostPolicy((grant,)))\n"
            "  args={'message_id':'crash-message','destination':'worker-1','payload_sha':'b'*64}\n"
            "  doc={'schema':SCHEMA,'principal_id':'agent-dev1','role':'developer',"
            "'key_id':'child-key','policy_revision':3,'scope':'project-alpha',"
            "'run_id':'run-1','step_id':'step-1','epoch':1,"
            "'request_id':'crash-request','nonce':'f'*32,'action':'STAGE_INTENT',"
            "'arguments_sha':hashlib.sha256(canonical(args)).hexdigest(),"
            "'issued_utc':'2026-11-02T11:59:45Z','expires_utc':'2026-11-02T12:00:45Z'}\n"
            "  sig=base64.b64encode(key.sign(DOMAIN+canonical(doc))).decode()\n"
            "  gate.db.create_function('terminate_now',0,lambda:os._exit(73))\n"
            "  gate.db.execute('CREATE TEMP TRIGGER break_claim BEFORE INSERT ON "
            "main.host_gate_claims BEGIN SELECT terminate_now(); END')\n"
            "  gate.stage_intent({'document':doc,'signature_b64':sig},"
            "now=datetime(2026,11,2,12,0,tzinfo=timezone.utc),"
            "scope='project-alpha',run_id='run-1',step_id='step-1',"
            "request_id='crash-request',epoch=1,message_id='crash-message',"
            "destination='worker-1',payload_sha='b'*64)\n"
        )
        proc=subprocess.run([sys.executable,"-c",source,str(self.root)],
             cwd=Path(__file__).resolve().parent,timeout=8,
             stdin=subprocess.DEVNULL,capture_output=True,check=False)
        self.assertEqual(proc.returncode,73,proc.stderr.decode(errors="replace"))
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)
        self.assertFalse(self.gate.db.execute(
            "SELECT 1 FROM atomic_outbox").fetchone())
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)
        self.assertTrue(self.stage()["ok"])

    def test_hard_process_crash_after_commit_keeps_replay_guard(self):
        """Response loss cannot undo committed authorization or outbox."""
        import subprocess
        import sys
        source=(
            "import os,sys,base64,hashlib\n"
            "from datetime import datetime,timezone\n"
            "from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey\n"
            "from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat\n"
            "from transition import canonical\n"
            "from journal import Journal\n"
            "from atomic_dispatch import AtomicDispatch\n"
            "from host_auth import DOMAIN,SCHEMA,HostGrant,HostPolicy\n"
            "from host_gate import HostDispatchGate\n"
            "with Journal(sys.argv[1],'execution_journal_hostgate.sqlite3') as j:\n"
            "  key=Ed25519PrivateKey.generate()\n"
            "  pub=key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)\n"
            "  grant=HostGrant('agent-dev1','developer','child-key',pub,'project-alpha',"
            "'run-1','step-1',1,3,frozenset({'STAGE_INTENT'}))\n"
            "  gate=HostDispatchGate(AtomicDispatch(j),HostPolicy((grant,)))\n"
            "  args={'message_id':'crash-message','destination':'worker-1','payload_sha':'b'*64}\n"
            "  doc={'schema':SCHEMA,'principal_id':'agent-dev1','role':'developer',"
            "'key_id':'child-key','policy_revision':3,'scope':'project-alpha',"
            "'run_id':'run-1','step_id':'step-1','epoch':1,"
            "'request_id':'crash-request','nonce':'f'*32,'action':'STAGE_INTENT',"
            "'arguments_sha':hashlib.sha256(canonical(args)).hexdigest(),"
            "'issued_utc':'2026-11-02T11:59:45Z','expires_utc':'2026-11-02T12:00:45Z'}\n"
            "  sig=base64.b64encode(key.sign(DOMAIN+canonical(doc))).decode()\n"
            "  gate.stage_intent({'document':doc,'signature_b64':sig},"
            "now=datetime(2026,11,2,12,0,tzinfo=timezone.utc),"
            "scope='project-alpha',run_id='run-1',step_id='step-1',"
            "request_id='crash-request',epoch=1,message_id='crash-message',"
            "destination='worker-1',payload_sha='b'*64)\n"
            "  os._exit(79)\n"
        )
        proc=subprocess.run([sys.executable,"-c",source,str(self.root)],
             cwd=Path(__file__).resolve().parent,timeout=8,
             stdin=subprocess.DEVNULL,capture_output=True,check=False)
        self.assertEqual(proc.returncode,79,proc.stderr.decode(errors="replace"))
        self.assertEqual(self.journal.verify("run-1")["events_examined"],3)
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)
        self.assertTrue(self.gate.audit("run-1")["ok"])
        # New authority and another request cannot add a second INTENT.
        with self.assertRaisesRegex(ProtocolError,"INVALID_STEP_TRANSITION"):
            self.stage()

    def test_policy_is_read_only_mapping(self):
        with self.assertRaises(TypeError):
            self.policy._by_key["untrusted-key"]=self.grant

    def test_verified_response_has_pinned_role(self):
        self.assertEqual(self.stage()["authenticated_role"],"developer")

    def test_unknown_schema_fields_denied(self):
        doc=self.signed(overrides={"approval":"true"})
        with self.assertRaisesRegex(HostAuthError,"HOST_DOCUMENT_FIELDS_INVALID"):
            self.stage(doc)

    def test_oversized_timestamp_window_denied(self):
        doc=self.signed(overrides={"expires_utc":"2026-11-02T12:20:00Z"})
        with self.assertRaisesRegex(HostAuthError,"HOST_TIME_WINDOW_INVALID"):
            self.stage(doc)

    def test_cross_protocol_signature_replay_fails(self):
        doc=self.signed()
        doc["signature_b64"]=base64.b64encode(
            self.key.sign(b"agent-signed-worker-receipt-v1"+canonical(doc["document"]))
        ).decode("ascii")
        with self.assertRaisesRegex(HostAuthError,"HOST_SIGNATURE_INVALID"):
            self.stage(doc)

    def test_malformed_existing_schema_is_rejected(self):
        self.gate.db.execute("UPDATE host_gate_meta SET value='wrong'")
        with self.assertRaisesRegex(HostGateError,"HOST_GATE_PROTOCOL_MISMATCH"):
            HostDispatchGate(self.dispatch,self.policy)

    def test_separation_of_developer_and_dispatcher_keys(self):
        """Least privilege: one key stages, a different key fences sending."""
        self.stage()
        dispatcher_key=Ed25519PrivateKey.generate()
        dispatcher_pub=dispatcher_key.public_key().public_bytes(
            Encoding.Raw,PublicFormat.Raw)
        dev=HostGrant(
            "agent-dev1","developer",self.grant.key_id,self.public,
            "project-alpha","run-1","step-1",1,3,
            frozenset({"STAGE_INTENT"}))
        send=HostGrant(
            "agent-dispatch","dispatcher","dispatcher-key",dispatcher_pub,
            "project-alpha","run-1","step-1",1,3,
            frozenset({"MARK_SEND_UNCERTAIN"}))
        self.gate.policy=HostPolicy((dev,send))
        with self.assertRaisesRegex(HostAuthError,"HOST_CAPABILITY_DENIED"):
            self.mark()
        command=self.signed(
            action="MARK_SEND_UNCERTAIN",req="command-2",nonce="2"*32,
            key=dispatcher_key,
            overrides={"key_id":"dispatcher-key",
                       "principal_id":"agent-dispatch",
                       "role":"dispatcher"})
        result=self.mark(doc=command)
        self.assertEqual(result["authenticated_role"],"dispatcher")
        self.assertEqual(result["authenticated_principal_id"],"agent-dispatch")
        self.assertEqual(result["phase"],"SEND_UNCERTAIN")

    def test_capacity_failure_does_not_record_command_or_intent(self):
        from importlib import import_module
        module=import_module(HostDispatchGate.__module__)
        with patch.object(module,"MAX_CLAIMS",0):
            with self.assertRaisesRegex(HostGateError,"CAPACITY_REACHED"):
                self.stage()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)

    def test_missing_ed25519_backend_does_not_downgrade_auth(self):
        from importlib import import_module
        module=import_module(verify_host_command.__module__)
        with patch.object(module,"Ed25519PublicKey",None):
            with self.assertRaisesRegex(HostAuthError,"HOST_CRYPTO_BACKEND_UNAVAILABLE"):
                self.stage()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)

    def test_error_after_send_mark_does_not_consume_request(self):
        self.stage()
        self.gate.db.execute(
            "CREATE TRIGGER fail_send BEFORE UPDATE ON atomic_outbox "
            "BEGIN SELECT RAISE(ABORT,'refused'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            self.mark()
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],1)
        self.gate.db.execute("DROP TRIGGER fail_send")
        self.assertTrue(self.mark()["ok"])

    def test_cross_project_context_denied_even_with_valid_signature(self):
        wrong=self.signed(overrides={"scope":"other-project"})
        with self.assertRaisesRegex(HostAuthError,"HOST_COMMAND_CONTEXT_MISMATCH"):
            self.stage(wrong)
        self.assertEqual(self.gate.audit("run-1")["claims_for_run"],0)

    def test_claim_target_insertion_failure_rolls_back_entire_stage(self):
        self.gate.db.execute("""
            CREATE TRIGGER fail_target BEFORE INSERT ON host_gate_command_targets
            BEGIN SELECT RAISE(ABORT,'fault after claim and outbox'); END
        """)
        with self.assertRaises(sqlite3.IntegrityError):
            self.stage()
        self.assertEqual(self.journal.verify("run-1")["events_examined"],2)
        self.assertFalse(self.gate.db.execute(
            "SELECT 1 FROM atomic_outbox").fetchone())
        self.assertFalse(self.gate.db.execute(
            "SELECT 1 FROM host_gate_claims").fetchone())
        self.gate.db.execute("DROP TRIGGER fail_target")
        self.assertTrue(self.stage()["ok"])

    def test_signed_send_records_exact_message_target(self):
        self.stage()
        self.mark()
        stage=self.gate.db.execute(
            "SELECT action,message_id FROM host_gate_command_targets "
            "WHERE request_id='command-1'").fetchone()
        sent=self.gate.db.execute(
            "SELECT action,message_id FROM host_gate_command_targets "
            "WHERE request_id='command-2'").fetchone()
        self.assertEqual(stage,("STAGE_INTENT","message-1"))
        self.assertEqual(sent,("MARK_SEND_UNCERTAIN","message-1"))

    def test_live_host_not_modified(self):
        result=self.stage()
        self.assertFalse(result["live_mcp_host_enforced"])
        self.assertFalse(self.gate.audit("run-1")["host_permission_enforced_in_live_mcp"])

if __name__=="__main__":
    unittest.main()
