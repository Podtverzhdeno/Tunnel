"""Offline falsification tests for missing side-effect observations."""
import dataclasses
import unittest

from envelope import Coverage, Outcome, evaluate

SHA = "f" * 64
SCOPES = {"db_audit": "database:orders", "outbox": "outbox:orders"}


def baseline():
    return [
        Coverage("db_audit", SCOPES["db_audit"], SHA, 0, True, True),
        Coverage("outbox", SCOPES["outbox"], SHA, 0, True, True),
    ]


def check(rows, required=SCOPES, sha=SHA):
    return evaluate(rows, required_scopes=required, expected_source_sha256=sha)


class EffectEnvelopeTests(unittest.TestCase):
    def test_fully_verified_bounded_absence(self):
        r = check(baseline())
        self.assertIs(r.outcome, Outcome.ABSENCE_PROVEN)

    def test_40_negative_envelopes_fail_closed(self):
        for i in range(40):
            with self.subTest(case=i):
                data = baseline()
                idx = i % 2
                old = data[idx]
                variant = i % 8
                if variant == 0:
                    data.pop(idx)
                elif variant == 1:
                    data[idx] = dataclasses.replace(old, complete=False)
                elif variant == 2:
                    data[idx] = dataclasses.replace(old, independently_verified=False)
                elif variant == 3:
                    data[idx] = dataclasses.replace(old, source_sha256="0" * 64)
                elif variant == 4:
                    data[idx] = dataclasses.replace(old, scope="different:scope")
                elif variant == 5:
                    data[idx] = dataclasses.replace(old, event_count=-1)
                elif variant == 6:
                    data[idx] = dataclasses.replace(old, event_count="0")
                else:
                    data.append(old)
                self.assertIs(check(data).outcome, Outcome.UNVERIFIED)

    def test_confirmed_side_effect_refutes_absence(self):
        data = baseline()
        data[0] = dataclasses.replace(data[0], event_count=1)
        self.assertIs(check(data).outcome, Outcome.CONTRADICTED)

    def test_nonverified_events_do_not_claim_verified_contradiction(self):
        data = baseline()
        data[0] = dataclasses.replace(data[0], event_count=1, independently_verified=False)
        self.assertIs(check(data).outcome, Outcome.UNVERIFIED)

    def test_unexpected_observer_cannot_fill_missing(self):
        data = baseline()[1:]
        data.append(Coverage("unknown", "database:orders", SHA, 0, True, True))
        self.assertIs(check(data).outcome, Outcome.UNVERIFIED)

    def test_empty_contract_not_vacuously_proven(self):
        self.assertIs(check([], required={}).outcome, Outcome.UNVERIFIED)

    def test_stale_policy_sha_not_proven(self):
        self.assertIs(check(baseline(), sha="a" * 64).outcome, Outcome.UNVERIFIED)

    def test_malformed_event_count_bool_rejected(self):
        data = baseline()
        data[0] = dataclasses.replace(data[0], event_count=False)
        self.assertIs(check(data).outcome, Outcome.UNVERIFIED)

    def test_independent_proof_unknown(self):
        data = baseline()
        data[1] = dataclasses.replace(data[1], independently_verified="true")
        self.assertIs(check(data).outcome, Outcome.UNVERIFIED)

    def test_inconsistent_required_scope_fails(self):
        self.assertIs(check(baseline(), required={"db_audit": "orders", "outbox": "outbox:orders"}).outcome, Outcome.UNVERIFIED)

    def test_repeated_identical_evaluation(self):
        data = baseline()
        expected = check(data)
        self.assertEqual([check(data) for _ in range(50)], [expected] * 50)


if __name__ == "__main__":
    unittest.main()
