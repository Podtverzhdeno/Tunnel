"""Pure offline coverage-envelope validator (feature D2:F08).

A declaration of independent verification is synthetic here. This module has
no host identity, hardware attestation, network access, or production authority.
ABSENCE_PROVEN means *only* consistency with a supplied bounded contract.
"""
from dataclasses import dataclass
from enum import Enum
import re


_SHA = re.compile(r"^[0-9a-f]{64}$")


class Outcome(str, Enum):
    ABSENCE_PROVEN = "ABSENCE_PROVEN_WITHIN_DECLARED_SCOPE_ONLY"
    CONTRADICTED = "OBSERVED_EFFECT"
    UNVERIFIED = "UNVERIFIED"


@dataclass(frozen=True)
class Coverage:
    observer_id: str
    scope: str
    source_sha256: str
    event_count: int
    complete: bool
    independently_verified: bool


@dataclass(frozen=True)
class Verdict:
    outcome: Outcome
    reason: str


def evaluate(
    observations: list[Coverage],
    *,
    expected_source_sha256: str,
    required_scopes: dict[str, str],
) -> Verdict:
    """Require one complete validated observer per prescribed independent scope."""
    if (not isinstance(observations, list)
            or len(observations) > 10000
            or not isinstance(expected_source_sha256, str)
            or _SHA.fullmatch(expected_source_sha256) is None
            or not isinstance(required_scopes, dict)
            or not required_scopes
            or len(required_scopes) > 1000):
        return Verdict(Outcome.UNVERIFIED, "INVALID_COVERAGE_CONTRACT")
    if any(not isinstance(k, str) or not k or not isinstance(v, str) or not v
           for k, v in required_scopes.items()):
        return Verdict(Outcome.UNVERIFIED, "INVALID_OBSERVER_REQUIREMENTS")

    by_id: dict[str, Coverage] = {}
    for evidence in observations:
        if not isinstance(evidence, Coverage):
            return Verdict(Outcome.UNVERIFIED, "INVALID_OBSERVER")
        key = evidence.observer_id
        if not isinstance(key, str) or key not in required_scopes:
            return Verdict(Outcome.UNVERIFIED, "UNEXPECTED_OBSERVER")
        if key in by_id:
            return Verdict(Outcome.UNVERIFIED, "DUPLICATE_OBSERVER")
        if (evidence.scope != required_scopes[key]
                or evidence.source_sha256 != expected_source_sha256
                or type(evidence.event_count) is not int
                or not 0 <= evidence.event_count <= 10**9
                or type(evidence.complete) is not bool
                or type(evidence.independently_verified) is not bool):
            return Verdict(Outcome.UNVERIFIED, "INVALID_OR_STALE_EVIDENCE")
        by_id[key] = evidence

    if set(by_id) != set(required_scopes):
        return Verdict(Outcome.UNVERIFIED, "MISSING_OBSERVER")
    if any(ev.event_count > 0 and ev.independently_verified for ev in by_id.values()):
        return Verdict(Outcome.CONTRADICTED, "VERIFIED_EFFECT_RECORDED")
    if any(not ev.complete or not ev.independently_verified for ev in by_id.values()):
        return Verdict(Outcome.UNVERIFIED, "COVERAGE_OR_PROVENANCE_INCOMPLETE")
    return Verdict(Outcome.ABSENCE_PROVEN, "COVERAGE_COMPLETE_WITHIN_CONTRACT")
