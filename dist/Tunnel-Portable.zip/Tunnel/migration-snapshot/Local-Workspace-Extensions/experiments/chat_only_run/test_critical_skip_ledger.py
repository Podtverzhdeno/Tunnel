"""Adversarial fixtures for the offline F02 critical-SKIP ledger."""
from __future__ import annotations

import itertools
import unittest

from critical_skip_ledger import assess_critical_skips

SHA = "a" * 64
WINDOWS = [
    {"test_id": "windows.acl", "os": "windows", "critical": True},
    {"test_id": "windows.junction", "os": "windows", "critical": True},
    {"test_id": "mcp.host_actor", "os": "any", "critical": True},
    {"test_id": "telemetry.optional", "os": "windows", "critical": False},
]


def receipt(test_id, outcome="PASS", exit_code=0, reason=None):
    return {"test_id": test_id, "os": "windows", "source_sha256": SHA,
            "outcome": outcome, "skip_reason": reason, "job_exit": exit_code}


def assess(items, expected=None, source=SHA, target="windows"):
    return assess_critical_skips(expected if expected is not None else WINDOWS,
                                 items, target_os=target, source_sha256=source)


class CriticalSkipLedgerTests(unittest.TestCase):
    def setUp(self):
        self.clean = [receipt(row["test_id"]) for row in WINDOWS]

    def test_green_is_advisory_never_host_release(self):
        r = assess(self.clean)
        self.assertEqual(r["status"], "ADVISORY_PASS")
        self.assertTrue(r["advisory_only"])
        self.assertFalse(r["host_attested"])
        self.assertFalse(r["release_authorized"])

    def test_optional_skip_is_visible(self):
        receipts = self.clean[:3] + [receipt("telemetry.optional", "SKIP", 0, "no gpu")]
        r = assess(receipts)
        self.assertEqual(r["status"], "ADVISORY_PASS")
        self.assertEqual(r["skipped"], ["telemetry.optional"])

    def test_critical_windows_skips_fail_closed(self):
        for critical in ("windows.acl", "windows.junction", "mcp.host_actor"):
            with self.subTest(critical=critical):
                rows = [receipt(row["test_id"], "SKIP", 0, "not installed")
                        if row["test_id"] == critical else receipt(row["test_id"])
                        for row in WINDOWS]
                self.assertEqual(assess(rows)["status"], "INCOMPLETE")

    def test_missing_required_tests_fail_closed(self):
        self.assertEqual(assess(self.clean[1:])["status"], "INCOMPLETE")

    def test_nonzero_exit_and_actual_fail_are_fail(self):
        for code, outcome in ((1, "PASS"), (0, "FAIL"), (-9, "PASS")):
            with self.subTest(code=code, outcome=outcome):
                rows = self.clean[:1] + [receipt("windows.junction", outcome, code)] + self.clean[2:]
                self.assertEqual(assess(rows)["status"], "FAIL")

    def test_cross_os_cannot_certify_windows(self):
        for row in self.clean:
            row["os"] = "linux"
        self.assertEqual(assess(self.clean)["status"], "INCOMPLETE")

    def test_duplicate_and_unknown_receipts_fail_closed(self):
        self.assertEqual(assess(self.clean + [self.clean[0]])["status"], "INCOMPLETE")
        self.assertEqual(assess(self.clean + [receipt("unknown")])["status"], "INCOMPLETE")

    def test_missing_skip_reason_and_unknown_job_exit(self):
        rows = self.clean[:3] + [receipt("telemetry.optional", "SKIP")]
        self.assertEqual(assess(rows)["status"], "INCOMPLETE")
        rows = self.clean[:3] + [receipt("telemetry.optional", "SKIP", None, "missing")]
        self.assertEqual(assess(rows)["status"], "INCOMPLETE")

    def test_source_and_inventory_drift_fail_closed(self):
        stale = list(self.clean)
        stale[0] = dict(stale[0], source_sha256="b" * 64)
        self.assertEqual(assess(stale)["status"], "INCOMPLETE")
        self.assertEqual(assess(self.clean, source="invalid")["status"], "INVALID_INPUT")
        self.assertEqual(assess(self.clean, expected=WINDOWS + [WINDOWS[0]])["status"],
                         "INVALID_INPUT")

    def test_no_vacuous_all_green(self):
        optional = [{"test_id": "x", "os": "windows", "critical": False}]
        self.assertEqual(assess([receipt("x")], expected=optional)["status"], "INCOMPLETE")

    def test_40_negative_combinations_never_report_pass(self):
        # 5 distinct coverage failures x 8 variant values = 40 synthetic cases.
        variants = list(itertools.product(("windows.acl", "windows.junction"),
                                          ("SKIP", "FAIL", "MISSING", "UNKNOWN_EXIT")))
        tested = 0
        for critical, failure in variants:
            for tamper in ("none", "stale_sha", "extra_row", "duplicate_row", "unknown_optional"):
                rows = [dict(row) for row in self.clean]
                index = next(i for i, row in enumerate(rows) if row["test_id"] == critical)
                if failure == "MISSING":
                    rows.pop(index)
                elif failure == "UNKNOWN_EXIT":
                    rows[index]["job_exit"] = None
                else:
                    rows[index]["outcome"] = failure
                    rows[index]["skip_reason"] = "no permission" if failure == "SKIP" else None
                if tamper == "stale_sha":
                    rows[0]["source_sha256"] = "b" * 64
                elif tamper == "extra_row":
                    rows.append(receipt("unregistered.test"))
                elif tamper == "duplicate_row":
                    rows.append(dict(rows[0]))
                elif tamper == "unknown_optional":
                    rows[-1]["job_exit"] = None
                result = assess(rows)
                self.assertNotEqual(result["status"], "ADVISORY_PASS")
                self.assertFalse(result["release_authorized"])
                tested += 1
        self.assertEqual(tested, 40)

    def test_unhashable_untrusted_values_fail_closed(self):
        self.assertEqual(assess(self.clean, target=[])["status"], "INVALID_INPUT")
        bad_expected = [dict(row) for row in WINDOWS]
        bad_expected[0]["os"] = []
        self.assertEqual(assess(self.clean, expected=bad_expected)["status"], "INVALID_INPUT")
        bad_receipts = [dict(row) for row in self.clean]
        bad_receipts[0]["outcome"] = []
        self.assertEqual(assess(bad_receipts)["status"], "INCOMPLETE")

    def test_bounded_payload_and_bad_types(self):
        self.assertEqual(assess([{}])["status"], "INCOMPLETE")
        self.assertEqual(assess(self.clean, expected=WINDOWS * 200)["status"], "INVALID_INPUT")
        bogus = list(self.clean)
        bogus[0] = dict(bogus[0], job_exit=True)
        self.assertEqual(assess(bogus)["status"], "INCOMPLETE")


if __name__ == "__main__":
    unittest.main()
