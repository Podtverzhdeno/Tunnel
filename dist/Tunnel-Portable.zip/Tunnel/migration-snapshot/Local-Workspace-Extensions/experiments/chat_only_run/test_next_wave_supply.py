"""Next candidate batch tests; no mutation of active SQLite task queue."""
import unittest
from pathlib import Path

from queue_supply_plan import load_candidates
from supply_plan_fixture import plan

ITEMS = load_candidates(Path(__file__).with_name("queue_supply_candidates_next.json"))
PREDECESSORS = ("P104", "P105", "P106", "P107")
STATE = {
    id_: {"task_id": id_, "status": "done",
          "role_hint": "developer-1", "deliverables": "[]"}
    for id_ in PREDECESSORS
}
TRUST = {id_: "recorded_pass" for id_ in PREDECESSORS}


class NextWaveTests(unittest.TestCase):
    def test_four_distinct_roles_canonically_scoped_and_no_overlap(self):
        result = plan(ITEMS, STATE, TRUST)
        self.assertEqual(len(result["ready"]), 4)
        self.assertEqual(result["blocked"], [])
        self.assertFalse(result["queue_mutated"])
        self.assertFalse(result["owner_approval_granted"])
        self.assertEqual(
            {r["role"] for r in result["ready"]},
            {"developer-1", "developer-2", "developer-3", "developer-4"})
        self.assertEqual(
            {r["id"] for r in result["ready"]},
            {"P150", "P151", "P152", "P153"})

    def test_no_untrusted_done_without_acceptance_receipt(self):
        result = plan(ITEMS, STATE, {})
        self.assertEqual(result["ready"], [])
        self.assertEqual(len(result["blocked"]), 4)
        self.assertTrue(all(
            any(x.startswith("DEPENDENCY_QA_NOT_VERIFIED_") for x in r["blockers"])
            for r in result["blocked"]))

    def test_existing_live_id_never_reseeded(self):
        s = dict(STATE, P151={
            "task_id": "P151", "status": "review", "role_hint": "developer-2",
            "deliverables": '["usage_calibration_evidence.py"]'})
        result = plan(ITEMS, s, TRUST)
        row = next(r for r in result["blocked"] if r["id"] == "P151")
        self.assertIn("ALREADY_IN_LIVE_QUEUE", row["blockers"])

    def test_stale_predecessor_blocks_only_its_dependent(self):
        s = dict(STATE)
        s["P106"] = dict(s["P106"], status="review")
        result = plan(ITEMS, s, TRUST)
        self.assertEqual({r["id"] for r in result["ready"]}, {"P150", "P151", "P153"})
        self.assertIn("DEPENDENCY_NOT_DONE_P106",
                      next(r for r in result["blocked"] if r["id"] == "P152")["blockers"])


if __name__ == "__main__":
    unittest.main()
