"""Offline retry-risk advisor: NEVER an executor or a host permission boundary.

The `pre_dispatch_verified` parameter must come from a distinct authenticated
host observation in any future integration. Here it is a test input, NOT proof
and cannot authorize external effects. Only low-risk READ_ONLY work can be
suggested for retry, and no code in this module performs a retry.
"""
from __future__ import annotations

ALLOWED_EFFECTS = frozenset({"READ_ONLY", "IDEMPOTENT_WRITE", "NON_IDEMPOTENT_WRITE", "PRIVILEGED"})
ALLOWED_STATUS = frozenset({"SUCCESS", "DENIED", "RATE_LIMITED", "TIMEOUT", "CONNECTION_LOST", "FAILED", "UNKNOWN"})
ALLOWED_STAGE = frozenset({"NOT_DISPATCHED", "DISPATCHED", "UNKNOWN"})
MAX_FIELDS = 12
MAX_STRING = 120


def classify(effect, transport_status, dispatch_stage, *, pre_dispatch_verified=False,
             receipt_verified=False, client_retryable=None):
    """Conservative offline advisory, not a capability or live tool decision.

    client_retryable is deliberately ignored: it may be attacker controlled.
    Returns only a bounded typed recommendation, with no external side effect.
    """
    if (type(effect) is not str or effect not in ALLOWED_EFFECTS
            or type(transport_status) is not str or transport_status not in ALLOWED_STATUS
            or type(dispatch_stage) is not str or dispatch_stage not in ALLOWED_STAGE
            or type(pre_dispatch_verified) is not bool
            or type(receipt_verified) is not bool):
        return {"category":"INVALID_INPUT", "advice":"RECONCILE", "automatic_action_allowed":False}

    result = {"category":"OUTCOME_UNKNOWN", "advice":"RECONCILE",
              "automatic_action_allowed":False, "host_authentication_proven":False}
    # A client-provided success flag cannot prove execution, irrespective of
    # optimistic retry metadata. The evidence must come from a trusted source.
    if receipt_verified and transport_status == "SUCCESS":
        result.update(category="COMPLETED", advice="DO_NOT_RETRY")
        return result
    if receipt_verified and transport_status == "DENIED":
        result.update(category="PERMISSION_DENIED", advice="NEEDS_AUTHORIZED_OWNER")
        return result
    if (effect == "READ_ONLY" and dispatch_stage == "NOT_DISPATCHED"
            and pre_dispatch_verified
            and transport_status in {"RATE_LIMITED", "TIMEOUT", "CONNECTION_LOST"}):
        # Only a suggestion; a separate trusted host must re-check budget,
        # identity and actual evidence before initiating any new request.
        result.update(category="READ_RETRY_CANDIDATE",
                      advice="REQUIRE_HOST_BUDGET_AND_FRESH_ATTESTATION")
        return result
    if dispatch_stage == "DISPATCHED" or transport_status in {"TIMEOUT", "CONNECTION_LOST"}:
        result["category"] = "UNKNOWN_AFTER_POSSIBLE_DISPATCH"
    elif effect == "PRIVILEGED":
        result["category"] = "PRIVILEGED_POLICY_GATE"
        result["advice"] = "NEEDS_AUTHORIZED_OWNER"
    return result


def classify_receipt(contract, receipt):
    """Untrusted maps never confer pre-dispatch verification.

    Safe offline pre-dispatch examples can be assessed with classify(...),
    but this entrypoint cannot upgrade client-declared booleans.
    """
    if not isinstance(contract, dict) or not isinstance(receipt, dict):
        return classify(None,None,None)
    if len(contract) > MAX_FIELDS or len(receipt) > MAX_FIELDS:
        return classify(None,None,None)
    if any(not isinstance(k,str) or len(k)>MAX_STRING for k in (*contract,*receipt)):
        return classify(None,None,None)
    return classify(contract.get("effect"), receipt.get("status"), receipt.get("dispatch_stage"),
                    pre_dispatch_verified=False, receipt_verified=False,
                    client_retryable=receipt.get("retryable"))


if __name__ == "__main__":
    raise SystemExit("OFFLINE_LIBRARY_ONLY: no standalone tool execution")
