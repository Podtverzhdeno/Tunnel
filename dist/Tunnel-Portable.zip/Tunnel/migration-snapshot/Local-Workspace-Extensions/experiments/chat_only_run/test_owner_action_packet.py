"""Owner admission handoff tests: immutable bytes, no simulated approval."""
import hashlib
import json
import unittest
from unittest.mock import patch

import owner_action_packet as handoff

def preview(ids=("P150","P151","P152","P153"),blocked=()):
    material=json.dumps([{"id":x} for x in ids],sort_keys=True).encode()
    digest=hashlib.sha256(material).hexdigest()
    value={
      "mode":"OWNER_FOREGROUND_APPROVAL_REQUIRED","ready_ids":list(ids),
      "blocked":[{"id":x} for x in blocked],
      "old_seed_sha256":"a"*64,
      "new_seed_sha256":digest,
      "candidate_pool_sha256":"c"*64,
      "plan_id":digest[:16],
      "preview_only":True,"mutated":False
    }
    return value,material

class OwnerHandoffTests(unittest.TestCase):
    def test_four_owners_ready_and_digest_pinned(self):
        result=handoff.make_packet(preview)
        self.assertEqual(result["ready_count"],4)
        self.assertEqual(result["ready_task_ids"],["P150","P151","P152","P153"])
        self.assertTrue(result["human_foreground_required"])
        self.assertFalse(result["admission_performed"])
        self.assertFalse(result["formal_review_authorized"])
        self.assertIn("--plan-id "+result["plan_id"],result["powershell_command"])
        self.assertEqual(result["human_challenge"],"ADMIT "+result["plan_id"])

    def test_empty_is_not_actionable(self):
        result=handoff.make_packet(lambda:preview([]))
        self.assertEqual(result["mode"],"NO_READY_ADMISSION")
        self.assertIsNone(result["powershell_command"])

    def test_tampered_serialized_seed_rejected(self):
        value,payload=preview()
        with self.assertRaisesRegex(handoff.HandoffError,"SERIALIZED_SEED_SHA_MISMATCH"):
            handoff.make_packet(lambda:(value,payload+b"mutated"))

    def test_pretend_approval_rejected(self):
        value,payload=preview()
        value["mode"]="OWNER_FOREGROUND_ADMITTED"
        with self.assertRaisesRegex(handoff.HandoffError,"APPROVAL_BOUNDARY_MISMATCH"):
            handoff.make_packet(lambda:(value,payload))

    def test_preview_must_never_claim_queue_mutation(self):
        value,payload=preview()
        value["mutated"]=True
        with self.assertRaisesRegex(handoff.HandoffError,"PREVIEW_CLAIMS_WRITES"):
            handoff.make_packet(lambda:(value,payload))

    def test_invalid_plan_digest_rejected(self):
        value,payload=preview()
        value["plan_id"]="";self.assertRaises(
            handoff.HandoffError,handoff.make_packet,lambda:(value,payload))

    def test_duplicate_and_command_injection_ids_rejected(self):
        for ids in (["P150","P150"],["P150; del all"],[{"id":"P150"}]):
            value,payload=preview(["P150"])
            value["ready_ids"]=ids
            with self.assertRaises(handoff.HandoffError):
                handoff.make_packet(lambda:(value,payload))

    def test_only_preview_function_is_invoked(self):
        invoked=[]
        def reader():
            invoked.append("preview")
            return preview()
        handoff.make_packet(reader)
        self.assertEqual(invoked,["preview"])

if __name__=="__main__":
    unittest.main()
