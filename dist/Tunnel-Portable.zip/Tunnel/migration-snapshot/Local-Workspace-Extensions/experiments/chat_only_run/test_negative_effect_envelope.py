"""F08 fail-closed observations; no automatic actions or host trust."""
import unittest

from negative_effect_envelope import assess_effect_absence

SHA = "b" * 64
OBSERVERS = ["mcp.intent_log", "process.audit", "filesystem.audit"]


def report(name, **overrides):
    value = {
        "observer_id": name, "coverage_scope": "test.read_only",
        "coverage_complete": True, "source_sha256": SHA, "event_count": 0,
    }
    value.update(overrides)
    return value


def assess(reports, observers=OBSERVERS, scope="test.read_only", sha=SHA):
    return assess_effect_absence(observers, reports, scope_id=scope, source_sha256=sha)


class NegativeEffectEnvelopeTests(unittest.TestCase):
    def setUp(self):
        self.clean = [report(name) for name in OBSERVERS]

    def test_all_zero_is_advisory_not_absence_proof(self):
        result = assess(self.clean)
        self.assertEqual(result["status"], "ADVISORY_ZERO_OBSERVED")
        self.assertFalse(result["absence_proven"])
        self.assertFalse(result["trusted_observer_proven"])
        self.assertFalse(result["release_authorized"])

    def test_missing_observer_is_unverified(self):
        value = assess(self.clean[:2])
        self.assertEqual(value["status"], "UNVERIFIED")
        self.assertEqual(value["missing_observers"], ["filesystem.audit"])

    def test_incomplete_observation_is_unverified(self):
        rows = self.clean[:2] + [report("filesystem.audit", coverage_complete=False)]
        self.assertEqual(assess(rows)["status"], "UNVERIFIED")

    def test_any_reported_effect_is_surfaced(self):
        for name in OBSERVERS:
            with self.subTest(name=name):
                rows = [report(x, event_count=1 if x == name else 0) for x in OBSERVERS]
                result = assess(rows)
                self.assertEqual(result["status"], "REPORTED_EFFECT")
                self.assertFalse(result["absence_proven"])

    def test_stale_scope_source_and_duplicate_fail_closed(self):
        for tamper in (
            dict(source_sha256="c" * 64),
            dict(coverage_scope="another.scope"),
            dict(coverage_complete=None),
            dict(event_count=-1),
            dict(event_count=True),
            dict(event_count=[]),
        ):
            with self.subTest(tamper=tamper):
                rows = self.clean[:2] + [report("filesystem.audit", **tamper)]
                self.assertEqual(assess(rows)["status"], "UNVERIFIED")
        self.assertEqual(assess(self.clean + [self.clean[0]])["status"], "UNVERIFIED")

    def test_untrusted_attestation_flag_is_not_accepted(self):
        rows = self.clean[:2] + [report("filesystem.audit", host_verified=True)]
        self.assertEqual(assess(rows)["status"], "UNVERIFIED")

    def test_manifest_cannot_have_one_fake_observer(self):
        self.assertEqual(assess([self.clean[0]], observers=[OBSERVERS[0]])["status"],
                         "INVALID_INPUT")
        self.assertEqual(assess(self.clean, observers=OBSERVERS + [OBSERVERS[0]])["status"],
                         "INVALID_INPUT")

    def test_unhashable_or_long_inputs_never_raise(self):
        self.assertEqual(assess(self.clean, scope=[])["status"], "INVALID_INPUT")
        self.assertEqual(assess(self.clean, observers=[[], "fine"])["status"],
                         "INVALID_INPUT")
        self.assertEqual(assess([{}])["status"], "UNVERIFIED")
        self.assertEqual(assess(self.clean, sha="bad")["status"], "INVALID_INPUT")


if __name__ == "__main__":
    unittest.main()
