"""Independent scoped regression laboratory for review-only candidates.

No mutation of live team sqlite, developer workspaces or canonical sources.
Creates a disposable Python directory in a system tempfile and cleans it.
"""
from __future__ import annotations
import json
import shutil
import subprocess
import sys
import tempfile
import types
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/".agent-team"/"workspaces"
def inspected(role,task,name):
    path=SOURCE/role/task/name
    path=path.resolve(strict=True)
    if not path.is_relative_to(SOURCE.resolve(strict=True)) or not path.is_file() or path.stat().st_size>30000:
        raise RuntimeError("BAD_SCOPE")
    return path.read_text(encoding="utf-8")
def load(source,name):
    m=types.ModuleType(name)
    exec(compile(source,name,"exec",dont_inherit=True),m.__dict__)
    return m

def run():
    out={}
    p111=load(inspected("developer-4","P111","prompt_boundary_checks.py"),"p111")
    git_example="git -C repo push origin main"
    risk=p111.classify_untrusted_text(git_example)
    out["P111_GIT_C_OPTION"]={"observed":risk,
                             "missed_git_mutation":"GIT_MUTATION" not in risk["reason_codes"],
                             "is_authorization":risk["grants_authority"]}
    p149=load(inspected("developer-3","P149","lease_continuity_policy.py"),"p149")
    h="a"*64;b="b"*64
    facts={"task_id":"P149","role":"developer-3","task_status":"working",
           "spec_sha256":h,"current_spec_sha256":h,"base_sha256":b,
           "current_base_sha256":b,"now_utc":"2026-11-02T01:00:00Z",
           "task_label":"untrusted\ud800"}
    try:
        val=p149.plan_lease_continuation(facts)
        out["P149_SURROGATE"]={"exception":None,"decision":val["decision"],
                                "reason":val["reason"],
                                "fails_closed":val["decision"]=="REQUIRE_OWNER_REVIEW"}
    except BaseException as e:
        out["P149_SURROGATE"]={"exception":type(e).__name__,"fails_closed":False}
    with tempfile.TemporaryDirectory(prefix="p127-review-copy-") as root:
        tmp=Path(root)
        original=inspected("developer-4","P127","agent_metrics_series.py")
        old='if not val[0].isalnum() or any(not (ch.isalnum() or ch in "._:-") for ch in val):'
        new='if not val or not val[0].isalnum() or any(not (ch.isalnum() or ch in "._:-") for ch in val):'
        if original.count(old)!=1:
            raise RuntimeError("P127_SOURCE_CHANGED_NO_PATCH")
        (tmp/"agent_metrics_series.py").write_text(original.replace(old,new),encoding="utf-8")
        (tmp/"test_agent_metrics_series.py").write_text(
            inspected("developer-4","P127","test_agent_metrics_series.py"),encoding="utf-8")
        (tmp/"test_p127_empty_model_regression.py").write_text(
            'import unittest\nfrom agent_metrics_series import normalize_metric_series as norm\n'
            'class NewNegativeTests(unittest.TestCase):\n'
            ' def test_empty_model_expected_run(self):\n'
            '  obj=dict(role="developer-4",task_id="P127",run_id="r123",model="",timestamp="2026-11-02T00:00:00Z")\n'
            '  r=norm([],expected_runs=[obj]); self.assertFalse(r["ok"]);self.assertEqual(r["error"],"INVALID_ID")\n'
            ' def test_empty_model_receipt(self):\n'
            '  obj=dict(role="developer-4",task_id="P127",run_id="r123",model="",timestamp="2026-11-02T00:00:00Z",'
            'usage_id="u123",provider="test",source="provider_reported_unverified",input_tokens=1,output_tokens=1,'
            'cached_input_tokens=0,reasoning_output_tokens=0)\n'
            '  r=norm([obj]);self.assertFalse(r["ok"]);self.assertEqual(r["error"],"INVALID_ID")\n',encoding="utf-8")
        run=subprocess.run([sys.executable,"-B","-m","unittest","discover","-q"],cwd=tmp,
                           capture_output=True,text=True,timeout=20,encoding="utf-8",errors="replace")
        out["P127_DRY_RUN_FIX"]={"sandbox_copied_to_temporary_directory":True,
                                 "candidate_original_unchanged":True,"exit_code":run.returncode,
                                 "stdout_tail":run.stdout[-700:],
                                 "stderr_tail":run.stderr[-700:]}
    out["authorized_main_changes"]=False
    print(json.dumps(out,ensure_ascii=True))
    return 0 if (out["P127_DRY_RUN_FIX"]["exit_code"]==0 and
                 out["P149_SURROGATE"]["fails_closed"] and
                 out["P111_GIT_C_OPTION"]["missed_git_mutation"]) else 2
if __name__=="__main__":
    sys.exit(run())
