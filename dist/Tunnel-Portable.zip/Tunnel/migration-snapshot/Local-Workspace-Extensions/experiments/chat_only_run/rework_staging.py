"""Prepare immutable-source-hash verified *offline* rework candidates.

Never mutates submitted sandboxes, live queue, canonical main, or host grants.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import sqlite3
from contextlib import closing
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/"experiments"/"rework-staging"
DATA=ROOT/".agent-team"/"team.sqlite3"

def sh(data):return hashlib.sha256(data).hexdigest()

def prepare(task):
    if not task.startswith("P") or len(task)!=4 or not task[1:].isdigit():
        raise ValueError("TASK_INVALID")
    with closing(sqlite3.connect(DATA.resolve().as_uri()+"?mode=ro",uri=True)) as db:
        db.row_factory=sqlite3.Row
        row=db.execute("SELECT task_id,status,owner,deliverables,sandbox FROM tasks WHERE task_id=?",(task,)).fetchone()
    if not row or row["status"] not in ("review","reviewing"):
        raise ValueError("TASK_NOT_SUBMITTED")
    source=(ROOT/row["sandbox"]).resolve()
    if not source.is_relative_to((ROOT/".agent-team"/"workspaces").resolve()):
        raise ValueError("SOURCE_OUTSIDE_WORKSPACES")
    paths=json.loads(row["deliverables"])
    if not paths or len(paths)>6:raise ValueError("BAD_DELIVERABLES")
    files={}
    for name in paths:
        if (not isinstance(name,str) or name in (".","..") or
              "/" in name or "\\" in name or not name.endswith(".py")):
            raise ValueError("BAD_NAME")
        path=source/name
        if path.is_symlink() or not path.is_file() or path.stat().st_size>2*1024*1024:
            raise ValueError("UNSAFE_OR_MISSING_SOURCE")
        raw=path.read_bytes()
        raw.decode("utf-8")
        files[name]={"source_sha256":sh(raw),"bytes":raw}
    directory=BASE/task
    directory.mkdir(parents=True,exist_ok=True)
    marker=directory/"candidate_provenance.json"
    if marker.exists():
        existing=json.loads(marker.read_text("utf-8"))
        if existing["task_id"]!=task or existing["source_sha256"]!={k:v["source_sha256"] for k,v in files.items()}:
            raise ValueError("STAGING_SOURCE_DRIFT")
        return {"task_id":task,"status":"EXISTING_STAGE","staging":str(directory.relative_to(ROOT)),
                "source_hashes":existing["source_sha256"]}
    if list(directory.iterdir()):raise ValueError("NONEMPTY_STAGING")
    for name,data in files.items():
        (directory/name).write_bytes(data["bytes"])
    meta={"task_id":task,"original_owner":row["owner"],"source_sha256":{k:v["source_sha256"] for k,v in files.items()},
          "advisory_only":True,"may_publish_to_main":False,
          "note":"These staged files are NOT part of the live task and cannot be submitted or accepted until authorized reconciliation."}
    marker.write_text(json.dumps(meta,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return {"task_id":task,"status":"CREATED_STAGE","staging":str(directory.relative_to(ROOT)),
            "source_hashes":meta["source_sha256"]}
if __name__=="__main__":
    try:
        p=argparse.ArgumentParser();p.add_argument("task_id");a=p.parse_args()
        print(json.dumps({"ok":True,"data":prepare(a.task_id)},ensure_ascii=True))
    except (ValueError,sqlite3.Error,OSError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:200]},ensure_ascii=True));raise SystemExit(2)
