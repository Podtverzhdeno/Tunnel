"""Regression: scheduled entrypoints work from their real nested cwd.

No live queue writes, leases, imports from sandboxes or external services.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import unittest
from pathlib import Path


EXPERIMENT = Path(__file__).resolve().parent
ROOT = EXPERIMENT.parents[1]


class ScheduledQualityEntrypointTests(unittest.TestCase):
    def run_entrypoint(self, script, *args):
        env = dict(os.environ)
        env.pop("PYTHONPATH", None)
        return subprocess.run(
            [sys.executable, script, *args],
            cwd=EXPERIMENT,
            env=env,
            capture_output=True,
            text=True,
            timeout=25,
            check=False,
        )

    def test_standalone_quality_gate_imports_canonical_guard(self):
        result = self.run_entrypoint("agent_quality_gate.py", "schema")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertIn("maintainability", payload["data"]["dimensions"])

    def test_guarded_submit_can_start_without_pythonpath(self):
        result = self.run_entrypoint("quality_submit.py", "--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("usage:", result.stdout.lower())

    def test_unknown_task_is_structured_failure_not_import_exception(self):
        result = self.run_entrypoint("agent_quality_gate.py", "audit", "P000", "developer-1")
        self.assertEqual(result.returncode, 2)
        payload = json.loads(result.stdout)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"], "UNKNOWN_TASK")
        self.assertNotIn("ModuleNotFoundError", result.stderr)


if __name__ == "__main__":
    unittest.main()
