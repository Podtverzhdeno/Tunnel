"""Read-only static + evidence quality gate for isolated developer task sandboxes.

This augments but does not replace sandbox test execution or the privileged
architect reviewer. Assertions in the report are untrusted self-attestations.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import re
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
# Direct scheduled invocations start in experiments/chat_only_run, not the
# repository root. Always resolve the canonical guard from this project rather
# than relying on the caller's cwd or an inherited PYTHONPATH.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
MAIN_DB=ROOT/".agent-team"/"team.sqlite3"
ROLES={"developer-1","developer-2","developer-3","developer-4"}
TASK_PATTERN=re.compile(r"P[0-9]{3}\Z")
FILE_PATTERN=re.compile(r"(?:[a-z][a-z0-9_]*|test_[a-z][a-z0-9_]*)\.py\Z")
SECTIONS=("security","reliability","architecture","scalability","correctness",
          "maintainability","performance","observability","spec_traceability")
MAX_FILE=2*1024*1024
MAX_JSON=16*1024

# Code-reuse gate is imported through the canonical project root only, never
# from developer-controlled sandbox Python files.
from code_reuse_guard import audit as code_reuse_audit, ReuseGuardError

class GateError(ValueError):pass

def safe_read(path,maxbytes=MAX_FILE):
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)() or not path.is_file():
        raise GateError("UNSAFE_OR_MISSING_FILE")
    if path.stat().st_size>maxbytes:raise GateError("OVERSIZED_FILE")
    return path.read_bytes()

def read_task(task_id,db=MAIN_DB,root=ROOT):
    if not TASK_PATTERN.fullmatch(task_id):raise GateError("INVALID_TASK_ID")
    if db.is_symlink() or not db.is_file():raise GateError("QUEUE_MISSING")
    with closing(sqlite3.connect(db.resolve().as_uri()+"?mode=ro",uri=True)) as cx:
        cx.row_factory=sqlite3.Row
        cx.execute("PRAGMA query_only=ON")
        row=cx.execute("SELECT task_id,role_hint,owner,status,sandbox,deliverables,spec_ref "
                       "FROM tasks WHERE task_id=?",(task_id,)).fetchone()
    if row is None:raise GateError("UNKNOWN_TASK")
    data=dict(row)
    path=data["sandbox"]
    if not isinstance(path,str) or not path.startswith(".agent-team/workspaces/"):
        raise GateError("INVALID_SANDBOX")
    folder=(root/path).resolve()
    if not folder.is_relative_to((root/".agent-team"/"workspaces").resolve()) or not folder.is_dir():
        raise GateError("UNSAFE_SANDBOX")
    outputs=json.loads(data["deliverables"])
    if not isinstance(outputs,list) or not 1<=len(outputs)<=6 or len(set(outputs))!=len(outputs):
        raise GateError("INVALID_OUTPUTS")
    if any(not isinstance(x,str) or not FILE_PATTERN.fullmatch(x) for x in outputs):
        raise GateError("INVALID_OUTPUT_NAME")
    if not any(x.startswith("test_") for x in outputs):
        raise GateError("TEST_FILE_REQUIRED")
    data["folder"]=folder
    data["outputs"]=outputs
    return data

def qualified(node):
    if isinstance(node,ast.Name):return node.id
    if isinstance(node,ast.Attribute):
        root=qualified(node.value)
        return root+"."+node.attr if root else node.attr
    return ""

def depth(node):
    if not isinstance(node,(ast.If,ast.For,ast.AsyncFor,ast.While,ast.Try,
                            ast.With,ast.AsyncWith,ast.Match)):return 0
    inner=[n for stmt in ast.iter_child_nodes(node) for n in
           ([stmt] if isinstance(stmt,ast.stmt) else [])]
    return 1+max((depth(x) for x in inner),default=0)

def scan_file(name,raw):
    result=[]
    try:
        content=raw.decode("utf-8",errors="strict")
        tree=ast.parse(content,filename=name)
    except (SyntaxError,UnicodeError,ValueError,RecursionError) as e:
        return [{"file":name,"line":0,"rule":"PARSE_ERROR","detail":type(e).__name__}]
    lines=content.splitlines()
    if len(lines)>900:result.append({"file":name,"line":0,"rule":"MODULE_TOO_LONG","detail":str(len(lines))})
    if not content.strip():result.append({"file":name,"line":0,"rule":"EMPTY_MODULE","detail":""})
    for node in ast.walk(tree):
        line=getattr(node,"lineno",0)
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            length=(node.end_lineno or line)-line+1
            branches=sum(isinstance(x,(ast.If,ast.For,ast.AsyncFor,ast.While,
                                       ast.ExceptHandler,ast.IfExp,ast.Match,
                                       ast.comprehension)) for x in ast.walk(node))
            if length>110:result.append({"file":name,"line":line,"rule":"FUNCTION_TOO_LONG","detail":node.name+":"+str(length)})
            if branches>18:result.append({"file":name,"line":line,"rule":"HIGH_BRANCH_COMPLEXITY","detail":node.name+":"+str(branches)})
        if isinstance(node,ast.Call):
            name_call=qualified(node.func)
            if name_call in {"eval","exec","compile","os.system","os.popen","pickle.loads",
                             "pickle.load","marshal.loads","subprocess.getoutput","subprocess.getstatusoutput"}:
                result.append({"file":name,"line":line,"rule":"DANGEROUS_CALL","detail":name_call})
            if name_call.startswith("subprocess.") or name_call in {"Popen","run","call","check_call","check_output"}:
                if any(k.arg=="shell" and isinstance(k.value,ast.Constant) and k.value.value is True
                       for k in node.keywords):
                    result.append({"file":name,"line":line,"rule":"SHELL_TRUE","detail":name_call})
            if name_call in {"yaml.load","yaml.unsafe_load"}:
                result.append({"file":name,"line":line,"rule":"UNSAFE_YAML_LOAD","detail":name_call})
            if name_call in {"tempfile.mktemp"}:
                result.append({"file":name,"line":line,"rule":"RACY_TEMPFILE","detail":name_call})
        if isinstance(node,ast.ExceptHandler) and not node.body:
            result.append({"file":name,"line":line,"rule":"EMPTY_EXCEPT","detail":""})
        if isinstance(node,ast.ExceptHandler) and (
                node.type is None or qualified(node.type) in {"Exception","BaseException"}):
            if any(isinstance(x,ast.Pass) for x in node.body):
                result.append({"file":name,"line":line,"rule":"SILENT_BROAD_EXCEPTION","detail":""})
        if isinstance(node,ast.Assert) and not name.startswith("test_"):
            result.append({"file":name,"line":line,"rule":"ASSERT_IN_PRODUCTION","detail":"Assertions disappear under -O"})
        if isinstance(node,(ast.Assign,ast.AnnAssign)):
            lhs=([x for target in node.targets for x in ast.walk(target)] if isinstance(node,ast.Assign)
                 else list(ast.walk(node.target)))
            if any(isinstance(x,ast.Name) and re.search(r"(?i)(password|private_key|api_key|secret_token)",x.id) for x in lhs):
                val=node.value
                if isinstance(val,ast.Constant) and isinstance(val.value,str) and len(val.value)>8:
                    result.append({"file":name,"line":line,"rule":"POSSIBLE_HARDCODED_SECRET","detail":"redacted"})
    if name.startswith("test_") and not any(isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))
                   and x.name.startswith("test_") for x in ast.walk(tree)):
        # unittest methods count too, other frameworks named test_* count.
        result.append({"file":name,"line":0,"rule":"NO_TEST_FUNCTIONS","detail":""})
    return result

def review_report(data,item,hashes):
    errs=[]
    if not isinstance(data,dict):return ["REPORT_MISSING_OR_NOT_OBJECT"]
    if data.get("task_id")!=item["task_id"] or data.get("role")!=item["owner"]:
        errs.append("REPORT_WRONG_ROLE_OR_TASK")
    if data.get("file_hashes")!=hashes:errs.append("REPORT_SOURCE_HASH_MISMATCH")
    sections=data.get("dimensions")
    if not isinstance(sections,dict) or set(sections)!=set(SECTIONS):
        errs.append("DIMENSIONS_NOT_COMPLETE")
    else:
        for key in SECTIONS:
            entry=sections[key]
            if not isinstance(entry,dict) or set(entry)!={"status","evidence","risks"} or entry.get("status") not in ("PASS","FAIL","UNKNOWN"):
                errs.append("DIMENSION_INVALID:"+key);continue
            if entry["status"]!="PASS":errs.append("DIMENSION_NOT_PASS:"+key)
            for attr in ("evidence","risks"):
                val=entry[attr]
                if not isinstance(val,list) or (attr=="evidence" and not val) or len(val)>8:
                    errs.append("DIMENSION_MISSING_"+attr.upper()+":"+key);continue
                if any(not isinstance(v,str) or len(v.strip())<15 or len(v)>650 for v in val):
                    errs.append("DIMENSION_POOR_"+attr.upper()+":"+key)
    tests=data.get("test_runs")
    names={"focused","full","spec_check","openspec_strict"}
    if not isinstance(tests,list) or len(tests)>10 or not names.issubset({
           t.get("kind") for t in tests if isinstance(t,dict)}):
        errs.append("REQUIRED_TEST_RUNS_MISSING")
    else:
        for t in tests:
            if not isinstance(t,dict) or set(t)!={"kind","command","exit_code","result_summary","run_id"}:
                errs.append("TEST_RUN_MALFORMED");continue
            if (t["kind"] not in names or type(t["exit_code"]) is not int or t["exit_code"]!=0 or
                not isinstance(t["command"],str) or len(t["command"])<8 or
                not isinstance(t["result_summary"],str) or len(t["result_summary"])<25 or
                not isinstance(t["run_id"],str) or len(t["run_id"])<8):
                errs.append("TEST_EVIDENCE_INCOMPLETE")
    if not isinstance(data.get("residual_risks"),list) or not data["residual_risks"]:
        errs.append("RESIDUAL_RISKS_MISSING")
    if not isinstance(data.get("architecture_decisions"),list) or not data["architecture_decisions"]:
        errs.append("ARCH_DECISIONS_MISSING")
    return sorted(set(errs))

def audit(task_id,role,db=MAIN_DB,root=ROOT):
    if role not in ROLES:raise GateError("ROLE_INVALID")
    task=read_task(task_id,db,root)
    if task["owner"]!=role:raise GateError("NOT_TASK_OWNER")
    scan=[];hashes={}
    for name in task["outputs"]:
        raw=safe_read(task["folder"]/name)
        hashes[name]=hashlib.sha256(raw).hexdigest()
        scan+=scan_file(name,raw)
    f=task["folder"]/"agent_quality_report.json"
    data=None
    try:
        data=json.loads(safe_read(f,MAX_JSON).decode("utf-8"))
    except (GateError,ValueError,UnicodeError):pass
    evidence=review_report(data,task,hashes)
    reuse_candidates={name:task["folder"]/name for name in task["outputs"]
                      if not name.startswith("test_")}
    reuse={"decision":"PASS","hard_blockers":[],"review_findings":[]}
    if reuse_candidates:
        try:
            reuse=code_reuse_audit(root,reuse_candidates)
        except (ReuseGuardError,OSError,MemoryError,RecursionError) as exc:
            # The report must never be marked green when reuse verification
            # cannot inspect all current canonical production source files.
            scan.append({"file":"<reuse-index>","line":0,
                         "rule":"REUSE_GUARD_ERROR","detail":type(exc).__name__})
    for item in reuse.get("hard_blockers",[]):
        scan.append({"file":item["candidate"]["file"],
                     "line":item["candidate"]["line"],
                     "rule":"DUPLICATE_IMPLEMENTATION",
                     "detail":item["existing"]["file"]+":"+
                              item["existing"]["symbol"]})
    return {"task_id":task_id,"role":role,"mode":"ADVISORY_PRE_SUBMIT_GATE",
            "can_submit_according_to_quality_policy":not scan and not evidence,
            "static_findings":scan[:35],"total_static_findings":len(scan),
            "reuse_guard":reuse,
            "evidence_issues":evidence,"file_hashes":hashes,
            "note":"Self-reported test runs must be checked against independent tool results. This does NOT authorize submit/merge or authenticate actor."}

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument("command",choices=["audit","schema"])
    p.add_argument("task_id",nargs="?")
    p.add_argument("role",nargs="?")
    a=p.parse_args(argv)
    try:
        if a.command=="schema":
            res={"dimensions":list(SECTIONS),"required_test_kinds":["focused","full","spec_check","openspec_strict"],
                 "report_path":"SANDBOX/agent_quality_report.json","mode":"ADVISORY"}
        else:
            if not a.task_id or not a.role:raise GateError("TASK_AND_ROLE_REQUIRED")
            res=audit(a.task_id,a.role)
        print(json.dumps({"ok":True,"data":res},ensure_ascii=True))
        return 0
    except (GateError,OSError,sqlite3.Error,TypeError,KeyError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:190]},ensure_ascii=True))
        return 2

if __name__=="__main__":sys.exit(main())
