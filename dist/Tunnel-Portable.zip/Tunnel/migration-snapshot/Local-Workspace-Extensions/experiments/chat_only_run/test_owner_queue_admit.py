"""Owner queue preview and isolated coordinator admission tests."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import owner_queue_admit as o
from queue_supply_plan import load_candidates


class OwnerAdmissionTests(unittest.TestCase):
    def test_preview_does_not_change_live_seed(self):
        before=o.SEED.read_bytes()
        # Unit-check read-only preview in isolation. The separate negative
        # test below enforces the real SDD admission gate; P162+ may be
        # deliberately unmapped while waiting for the next SDD wave.
        with patch.object(o,"require_admitted_roadmap_contract"):
            view,body=o.candidate_preview()
        self.assertEqual(o.SEED.read_bytes(),before)
        candidate_ids={item["id"] for item in load_candidates()}
        blocked_ids={item["id"] for item in view["blocked"]}
        self.assertEqual(set(view["ready_ids"]) | blocked_ids, candidate_ids)
        self.assertFalse(set(view["ready_ids"]) & blocked_ids)
        if not view["ready_ids"]:
            # An already-admitted batch is an expected idempotent no-op.
            self.assertEqual(view["old_seed_sha256"], view["new_seed_sha256"])
        self.assertTrue(view["preview_only"])
        self.assertFalse(view["mutated"])
        self.assertEqual(body[:1],b"[")

    def test_owner_admission_refuses_unmapped_sdd_task(self):
        item=load_candidates()[0]
        with tempfile.TemporaryDirectory() as tmp:
            roadmap=Path(tmp)/"roadmap.json"
            roadmap.write_text(json.dumps({"tasks":[]}),encoding="utf-8")
            with patch.object(o,"ROADMAP",roadmap):
                with self.assertRaisesRegex(o.SupplyError,"SDD_ROADMAP_UNMAPPED"):
                    o.require_admitted_roadmap_contract([item])
        # No change to the live seed or queue is required by this negative case.

    def test_owner_admission_checks_exact_roadmap_contract(self):
        item=load_candidates()[0]
        row={k:item[k] for k in (
            "id","role_hint","priority","spec_ref","deliverables","depends_on")}
        row.update(admission="qa_validated_owner_gate",
                   spec_status="canonical_existing",review_required=True,
                   production_host_authorized=False)
        with tempfile.TemporaryDirectory() as tmp:
            roadmap=Path(tmp)/"roadmap.json"
            with patch.object(o,"ROADMAP",roadmap):
                roadmap.write_text(json.dumps({"tasks":[row]}),encoding="utf-8")
                o.require_admitted_roadmap_contract([item])
                changed=dict(row,spec_ref="unapproved/fake.md / Bad requirement")
                roadmap.write_text(json.dumps({"tasks":[changed]}),encoding="utf-8")
                with self.assertRaisesRegex(o.SupplyError,"CONTRACT_DRIFT"):
                    o.require_admitted_roadmap_contract([item])

    def test_owner_preview_blocks_seeded_status_before_admission(self):
        item=load_candidates()[0]
        row={k:item[k] for k in (
            "id","role_hint","priority","spec_ref","deliverables","depends_on")}
        row.update(admission="seeded_after_dependencies_accepted",
                   spec_status="canonical_existing",review_required=True,
                   production_host_authorized=False)
        with tempfile.TemporaryDirectory() as tmp:
            roadmap=Path(tmp)/"roadmap.json"
            roadmap.write_text(json.dumps({"tasks":[row]}),encoding="utf-8")
            with patch.object(o,"ROADMAP",roadmap):
                with self.assertRaisesRegex(o.SupplyError,"CONTRACT_DRIFT"):
                    o.require_admitted_roadmap_contract([item])

    def test_roadmap_digest_attached_to_preview_for_ready_tasks(self):
        # Force one artificial candidate in a disposable planning mock without
        # executing owner approval; the roadmap SHA must bind the preview.
        item=json.loads(json.dumps(load_candidates()[0]))
        item["responsibility"]={
            "id":"lease-restart-audit","module":"lease_restart_audit",
            "public_api":"audit","role":"owner",
            "reuse_decision":"PROPOSE_NEW_RESPONSIBILITY",
            "inputs":"Bounded lease event metadata","outputs":"Deterministic audit findings",
            "errors":"Explicit invalid input codes","scaling":"Linear event count budget",
            "depends_on":[],"allowed_extensions":["lease_restart_audit.py"]
        }
        with tempfile.TemporaryDirectory() as tmp:
            roadmap=Path(tmp)/"roadmap.json"
            row={k:item[k] for k in (
                "id","role_hint","priority","spec_ref","deliverables","depends_on")}
            row.update(admission="qa_validated_owner_gate",
                       spec_status="canonical_existing",review_required=True,
                       production_host_authorized=False)
            roadmap.write_text(json.dumps({"tasks":[row]}),encoding="utf-8")
            seed=Path(tmp)/"team_seed.json"
            seed.write_text("[]",encoding="utf-8")
            with patch.object(o,"ROADMAP",roadmap), patch.object(o,"SEED",seed), patch.object(
                o,"plan",return_value={"ready":[{"id":item["id"]}],
                                          "blocked":[]}):
                with patch.object(o,"load_candidates",return_value=[item]):
                    view,_=o.candidate_preview()
                    # Same semantic SDD contract but different source bytes
                    # must generate a DIFFERENT typed owner confirmation ID.
                    roadmap.write_text(json.dumps({"tasks":[row]},indent=2),
                                       encoding="utf-8")
                    changed,_=o.candidate_preview()
            self.assertNotEqual(view["plan_id"],changed["plan_id"])
            self.assertEqual(view["new_seed_sha256"],changed["new_seed_sha256"])
            self.assertEqual(changed["roadmap_sha256"],o.sha(roadmap.read_bytes()))
            self.assertTrue(view["preview_only"])
            self.assertFalse(view["mutated"])

    def test_real_interactive_terminal_required(self):
        class NonTTY:
            def isatty(self):return False
        with self.assertRaisesRegex(o.SupplyError,"FOREGROUND"):
            o.assert_foreground_owner(stdin=NonTTY(),stdout=NonTTY())

    def test_apply_denies_mcp_before_digest_or_preview(self):
        # Foreground gate precedes any preview or mutation.
        with patch.object(o, "assert_foreground_owner",side_effect=o.SupplyError("DENIED")):
            with self.assertRaisesRegex(o.SupplyError,"DENIED"):
                o.apply_plan("0"*16)

    def test_valid_new_contract_without_sdd_mapping_blocks_before_owner_prompt(self):
        # P162 has a reviewed proposed contract, but no authoritative SDD
        # admission row. Preview must not crash or solicit owner approval.
        item=json.loads(json.dumps(next(x for x in load_candidates() if x["id"]=="P162")))
        with tempfile.TemporaryDirectory() as tmp:
            roadmap=Path(tmp)/"roadmap.json"
            roadmap.write_text('{"tasks":[]}',encoding="utf-8")
            seed=Path(tmp)/"team_seed.json"
            seed.write_text("[]\n",encoding="utf-8")
            with patch.object(o,"ROADMAP",roadmap), patch.object(o,"SEED",seed), patch.object(
                o,"plan",return_value={"ready":[{"id":item["id"]}],"blocked":[]}
            ), patch.object(o,"load_candidates",return_value=[item]):
                view,_=o.candidate_preview()
            self.assertEqual(view["ready_ids"],[])
            self.assertEqual(view["blocked"][0]["id"],"P162")
            self.assertTrue(any("SDD_ROADMAP_UNMAPPED_P162" in reason
                                for reason in view["blocked"][0]["blockers"]))
            self.assertEqual(seed.read_text(encoding="utf-8"),"[]\n")
            self.assertFalse(view["mutated"])

    def test_plan_has_no_later_or_unreviewed_dep(self):
        with patch.object(o,"require_admitted_roadmap_contract"):
            view,_=o.candidate_preview()
        names={i["id"] for i in load_candidates()}
        self.assertEqual(names,set(view["ready_ids"]) |
                         {item["id"] for item in view["blocked"]})
        self.assertTrue(set(view["ready_ids"])<=names)
        self.assertNotIn("P108",names)
        self.assertNotIn("P110",names)
        self.assertNotIn("P125",names)

    def test_full_proposed_seed_accepted_in_disposable_coordinator(self):
        from agent_team import seed
        with patch.object(o,"require_admitted_roadmap_contract"):
            view,raw=o.candidate_preview()
        with tempfile.TemporaryDirectory() as temp:
            manifest=Path(temp)/"team_seed.json"
            db=Path(temp)/"test_team.sqlite3"
            manifest.write_bytes(raw)
            import sqlite3
            from queue_supply_plan import DB
            # Read-only SQLite backup reproduces existing accepted historical
            # revisions; creating all old revisions in a fresh DB is not valid.
            with contextlib.closing(sqlite3.connect(DB.resolve().as_uri()+"?mode=ro",uri=True)) as source:
                with contextlib.closing(sqlite3.connect(db)) as destination:
                    source.backup(destination)
            result=seed(manifest,db)
            self.assertEqual(result["added"],len(view["ready_ids"]))
            self.assertEqual(result["revised"],0)
            with contextlib.closing(sqlite3.connect(db)) as c:
                for tid in view["ready_ids"]:
                    state=c.execute("SELECT status,deliverables FROM tasks WHERE task_id=?",(tid,)).fetchone()
                    self.assertIsNotNone(state)
                    self.assertEqual(state[0],"available")
                    self.assertEqual(len(json.loads(state[1])),2)
            second=seed(manifest,db)
            self.assertEqual(second["added"],0)
            self.assertEqual(second["revised"],0)


if __name__=="__main__":unittest.main()
