"""Read-only, privacy-conserving inventory of all locally retained scheduler run intervals.

No raw prompts, replies, payloads, tool arguments or source contents leave this
program. run_id is used only internally to deduplicate overlapping snapshots.
SQLite 'agents.sessions' is an acquire-attempt counter, NOT scheduler runtime.
"""
from __future__ import annotations

import json
import sqlite3
from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
REPORTS=ROOT/".agent-team/reports"
KNOWN_ROLES={"developer-1", "developer-2", "architect-reviewer",
             "developer-3+4", "scheduler-developer-3+4"}
DURATION_CEILING=4*3600
END_KEYS=("completed_at","finish","finished_at","ended_at")
START_KEYS=("started_at","start")
MAX_JSON=4*1024*1024


def stamp(raw):
    if not isinstance(raw,str):
        return None
    try:
        dt=datetime.fromisoformat(raw.replace("Z","+00:00"))
        return dt.astimezone(timezone.utc) if dt.tzinfo else None
    except (ValueError,OverflowError):
        return None


def normalize(role):
    if role in ("scheduler-developer-3+4","developer-3+4"):
        return "developer-3+4 (один запуск)"
    return role


def inspect_node(value,source,rows):
    if isinstance(value,list):
        for child in value:
            inspect_node(child,source,rows)
        return
    if not isinstance(value,dict):
        return
    if isinstance(value.get("run_id"),str):
        rid=value["run_id"]
        role=value.get("role")
        if role in KNOWN_ROLES and 7<=len(rid)<=128:
            started=next((stamp(value.get(k)) for k in START_KEYS if stamp(value.get(k))),None)
            ended=next((stamp(value.get(k)) for k in END_KEYS if stamp(value.get(k))),None)
            elapsed=(ended-started).total_seconds() if started and ended else None
            explicit=value.get("duration_seconds")
            if type(explicit) in (float,int) and 0<explicit<=DURATION_CEILING:
                duration=round(float(explicit),3)
                if elapsed is not None and abs(elapsed-duration)>15:
                    duration=None
            elif elapsed is not None and 0<elapsed<=DURATION_CEILING:
                duration=round(elapsed,3)
            else:
                duration=None
            if duration is not None:
                rows.append({"id":rid,"role":normalize(role),"seconds":duration,
                             "started":started.isoformat() if started else None,
                             "ended":ended.isoformat() if ended else None,
                             "state":value.get("recorded_status",value.get("run_status",
                                             value.get("status","unknown"))),
                             "source":source})
    for key,child in value.items():
        if key not in ("prompt","message","text","content","result","messages"):
            inspect_node(child,source,rows)


def main():
    observations=[]
    inspected=0
    invalid=0
    for path in sorted(REPORTS.glob("*.json")):
        try:
            if not path.is_file() or path.stat().st_size>MAX_JSON or path.is_symlink():
                continue
            contents=json.loads(path.read_text(encoding="utf-8"))
            inspected+=1
            inspect_node(contents,path.name,observations)
        except (ValueError,UnicodeError,OSError,RecursionError):
            invalid+=1
    merged={}
    duplicate_mismatches=[]
    for row in observations:
        previous=merged.get(row["id"])
        if previous is None:
            merged[row["id"]]=row
        else:
            if abs(previous["seconds"]-row["seconds"])>15:
                duplicate_mismatches.append(row["id"])
            if (not previous["started"] and row["started"]) or (not previous["ended"] and row["ended"]):
                merged[row["id"]]=row
    byrole=defaultdict(lambda:{"runs":0,"seconds":0.0,"failed":0,"completed":0,"unknown":0})
    for row in merged.values():
        group=byrole[row["role"]]
        group["runs"]+=1
        group["seconds"]+=row["seconds"]
        status=row["state"]
        if status=="failed":group["failed"]+=1
        elif status=="completed":group["completed"]+=1
        else:group["unknown"]+=1
    metadata={}
    dbfile=ROOT/".agent-team/team.sqlite3"
    try:
        with closing(sqlite3.connect(dbfile.resolve().as_uri()+"?mode=ro",uri=True)) as db:
            db.row_factory=sqlite3.Row
            db.execute("PRAGMA query_only=ON")
            metadata["agents"]=[{"role":r["role"],"acquire_attempts":r["sessions"]}
                                for r in db.execute("SELECT role,sessions FROM agents ORDER BY role")]
            metadata["acquisition_rows"]=db.execute("SELECT COUNT(*) FROM acquisitions").fetchone()[0]
            metadata["acquisitions_with_task"]=db.execute(
                "SELECT COUNT(*) FROM acquisitions WHERE task_id IS NOT NULL").fetchone()[0]
            metadata["acquisitions_without_task"]=db.execute(
                "SELECT COUNT(*) FROM acquisitions WHERE task_id IS NULL").fetchone()[0]
            metadata["event_actions"]=dict(db.execute(
                "SELECT action,COUNT(*) FROM events GROUP BY action").fetchall())
            metadata["first_event_utc"]=db.execute("SELECT MIN(at) FROM events").fetchone()[0]
            metadata["last_event_utc"]=db.execute("SELECT MAX(at) FROM events").fetchone()[0]
    except (OSError,sqlite3.Error) as error:
        metadata={"error":type(error).__name__}
    result={"schema":"read-only-scheduler-interval-audit-v1",
            "files_considered":inspected, "invalid_files":invalid,
            "source_observations":len(observations),"deduplicated_runs":len(merged),
            "duplicate_observations":len(observations)-len(merged),
            "duplicate_conflicts":len(duplicate_mismatches),
            "sum_seconds":round(sum(row["seconds"] for row in merged.values()),3),
            "by_role":dict(byrole),
            "min_started":min((r["started"] for r in merged.values() if r["started"]),default=None),
            "max_ended":max((r["ended"] for r in merged.values() if r["ended"]),default=None),
            "sqlite":metadata,
            "caveat":"Incomplete retained snapshots; no host full Automations history. Elapsed runs include noncoding time. SQLite sessions count acquire attempts, not runtime."}
    print(json.dumps(result,ensure_ascii=True,sort_keys=True,default=str))
    return 0


if __name__=="__main__":
    raise SystemExit(main())
