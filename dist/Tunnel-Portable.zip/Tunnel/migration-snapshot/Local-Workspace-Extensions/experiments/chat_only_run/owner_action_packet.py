"""Read-only, fail-closed owner handoff for four QA-backed reserve tasks.

This does not admit tasks, call seed(), invent a host actor, or authorize
review. Actual admission is an interactive Windows owner-only terminal action
in owner_queue_admit.py with CAS and owner-typed plan challenge.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Callable

from owner_queue_admit import candidate_preview

TASK_RE=re.compile(r"P[0-9]{3}\Z")
HEX_RE=re.compile(r"[0-9a-f]{64}\Z")
PLAN_RE=re.compile(r"[0-9a-f]{16}\Z")

class HandoffError(ValueError):
    pass

def assert_digest(value):
    if not isinstance(value,str) or not HEX_RE.fullmatch(value):
        raise HandoffError("HASH_MISSING_OR_MALFORMED")
    return value

def make_packet(preview_fn:Callable=candidate_preview):
    view,payload=preview_fn()
    if not isinstance(view,dict) or not isinstance(payload,bytes):
        raise HandoffError("PREVIEW_INVALID")
    if view.get("mode")!="OWNER_FOREGROUND_APPROVAL_REQUIRED":
        raise HandoffError("APPROVAL_BOUNDARY_MISMATCH")
    if view.get("preview_only") is not True or view.get("mutated") is not False:
        raise HandoffError("PREVIEW_CLAIMS_WRITES")
    import hashlib
    old=assert_digest(view.get("old_seed_sha256"))
    new=assert_digest(view.get("new_seed_sha256"))
    pool=assert_digest(view.get("candidate_pool_sha256"))
    plan=view.get("plan_id")
    if not isinstance(plan,str) or not PLAN_RE.fullmatch(plan) or plan!=new[:16]:
        raise HandoffError("PLAN_AND_SHA_MISMATCH")
    if hashlib.sha256(payload).hexdigest()!=new:
        raise HandoffError("SERIALIZED_SEED_SHA_MISMATCH")
    if not isinstance(view.get("ready_ids"),list):
        raise HandoffError("READY_LIST_MISSING")
    ready=view["ready_ids"]
    if (any(not isinstance(x,str) for x in ready) or len(ready)!=len(set(ready)) or
            any(not TASK_RE.fullmatch(x) for x in ready)):
        raise HandoffError("READY_INVALID_OR_DUPLICATE")
    if (not isinstance(view.get("blocked"),list) or
            any(not isinstance(x,dict) or not isinstance(x.get("id"),str)
                for x in view["blocked"])):
        raise HandoffError("BLOCKED_LIST_INVALID")
    # Command is a fixed script path with a digest validated to 16 hex
    # characters, never text interpolated from a task title/instruction.
    command=("python .\\experiments\\chat_only_run\\owner_queue_admit.py "
             "--apply --plan-id "+plan)
    return {
        "mode":"READY_FOR_OWNER_FOREGROUND_ACTION" if ready else "NO_READY_ADMISSION",
        "ready_task_ids":ready,
        "ready_count":len(ready),
        "blocked_count":len(view["blocked"]),
        "digest_checks_passed":True,
        "old_seed_sha256":old,
        "proposed_seed_sha256":new,
        "candidate_pool_sha256":pool,
        "plan_id":plan,
        "human_foreground_required":True,
        "human_challenge":"ADMIT "+plan,
        "powershell_cwd":"C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions",
        "powershell_command":command if ready else None,
        "admission_performed":False,
        "host_actor_authenticated":False,
        "formal_review_authorized":False,
        "next":"After genuine owner foreground admission, run agent_team.py overview and plan-work for each role. Do not assume P085 is fixed."
    }

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.parse_args(argv)
    try:
        print(json.dumps({"ok":True,"data":make_packet()},ensure_ascii=True))
        return 0
    except (HandoffError,OSError,ValueError,TypeError,KeyError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:200]},ensure_ascii=True))
        return 2

if __name__=="__main__":
    sys.exit(main())
