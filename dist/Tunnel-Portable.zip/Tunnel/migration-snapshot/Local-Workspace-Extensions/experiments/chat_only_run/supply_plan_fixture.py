"""Disposable project root for queue-supply planner contract tests.

Canonical specification contents are copied only as read-only input fixtures.
The planner's real SOURCE_EXISTS_* protection is never mocked or disabled.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

from queue_supply_plan import ROOT, plan as _plan


def plan(candidates, states, trust, *, existing=(), **kwargs):
    with tempfile.TemporaryDirectory(prefix="queue_supply_fixture_") as directory:
        project = Path(directory)
        spec_files = set()
        for entry in candidates:
            if not isinstance(entry, dict):
                continue
            reference = entry.get("spec_ref")
            if not isinstance(reference, str) or " / " not in reference:
                continue
            name = reference.partition(" / ")[0]
            # Invalid paths remain invalid in the real planner; never resolve
            # arbitrary paths while constructing a synthetic test project.
            if (not name.startswith("openspec/changes/")
                    or ".." in name.split("/")
                    or "\\" in name or ":" in name):
                continue
            spec_files.add(name)
        for name in sorted(spec_files):
            original = ROOT / name
            if not original.is_file() or original.is_symlink():
                # The planner will explicitly reject absent/unsafe specs.
                continue
            dest = project / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(original.read_bytes())
        for filename in existing:
            if (not isinstance(filename, str)
                    or not filename.endswith(".py")
                    or Path(filename).name != filename
                    or "\\" in filename or ":" in filename):
                raise ValueError("INVALID_TEST_EXISTING_FILE")
            # The test intentionally exercises a real existing file: the
            # source-exists veto remains fully enabled in _plan.
            (project / filename).write_text("# existing file\n", encoding="utf-8")
        return _plan(candidates, states, trust, project=project, **kwargs)
