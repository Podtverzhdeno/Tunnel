"""Read-only live multi-agent activity window audit (no prompts or secrets)."""
from __future__ import annotations
import json
import sqlite3
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
DB=ROOT/".agent-team"/"team.sqlite3"
def recent():
    now=datetime.now(timezone.utc)
    if not DB.is_file() or DB.is_symlink() or getattr(DB,"is_junction",lambda:False)():
        raise RuntimeError("QUEUE_UNAVAILABLE")
    out={"as_of_utc":now.isoformat(timespec="seconds"),"windows":{}}
    with closing(sqlite3.connect(DB.resolve().as_uri()+"?mode=ro",uri=True,timeout=5)) as con:
        con.row_factory=sqlite3.Row
        con.execute("PRAGMA query_only=ON")
        for minutes in (30,120):
            cutoff=(now-timedelta(minutes=minutes)).isoformat(timespec="seconds")
            rows=[dict(r) for r in con.execute(
                "SELECT task_id,role,action,at FROM events WHERE at>=? "
                "ORDER BY at DESC,id DESC LIMIT 200",(cutoff,))]
            counter=Counter(x["action"] for x in rows)
            real_count=con.execute("SELECT COUNT(*) FROM events WHERE at>=?",(cutoff,)).fetchone()[0]
            out["windows"][str(minutes)]={"from_utc":cutoff,"event_count":real_count,
                "truncated":real_count>len(rows),"by_action":dict(counter),"latest_events":rows[:65]}
        out["task_status"]=[dict(r) for r in con.execute(
            "SELECT status,COUNT(*) AS count FROM tasks GROUP BY status ORDER BY status")]
        out["agents"]=[dict(r) for r in con.execute(
            "SELECT role,sessions,last_started,last_activity FROM agents ORDER BY role")]
    return out
if __name__=="__main__":
    print(json.dumps(recent(),ensure_ascii=True,sort_keys=True))
