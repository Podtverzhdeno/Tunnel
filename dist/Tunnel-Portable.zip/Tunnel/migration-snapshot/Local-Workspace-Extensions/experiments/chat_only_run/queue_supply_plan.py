"""Fail-closed, read-only queue supply planner for *chat-only* scheduled developers.

Proposes only spec-backed, disjoint offline coding tasks whose predecessors have
durable independent QA receipts. No mutating SQLite or owner/reviewer actions.
An admission decision must still come from an authorized human/reviewer.
"""
from __future__ import annotations
import argparse
import json
import re
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))  # Project-owned audit module; never arbitrary paths.
CANDIDATES = Path(__file__).resolve().with_name("queue_supply_candidates_backlog.json")
DB = ROOT / ".agent-team" / "team.sqlite3"
SPEC = re.compile(r"^openspec/changes/local-pc-agent-tooling/specs/[a-z0-9-]+/spec\.md$")
REQUIREMENT = re.compile(r"^### Requirement: (.+)$", re.M)
PYFILE = re.compile(r"^(?:[a-z][a-z0-9_]*|test_[a-z][a-z0-9_]*)\.py$")
ID = re.compile(r"^P[0-9]{3}$")
ROLES = {"developer-1","developer-2","developer-3","developer-4"}


class SupplyError(ValueError): pass


def load_candidates(path=CANDIDATES):
    path = Path(path)
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)() or not path.is_file() or path.stat().st_size>65536:
        raise SupplyError("unsafe candidate manifest")
    document=json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(document,dict) or document.get("schema")!="chat-only-queue-supply-v1"
        or document.get("lifecycle")!="PROPOSED_ONLY_REQUIRES_REVIEW"
        or not isinstance(document.get("tasks"),list) or len(document["tasks"])>20):
        raise SupplyError("unapproved/invalid candidate manifest")
    return document["tasks"]


def read_live_state(db_path=DB, project=ROOT):
    from team_acceptance_audit import audit_acceptances
    db_path=Path(db_path)
    if not db_path.is_file() or db_path.is_symlink() or getattr(db_path,"is_junction",lambda:False)():
        raise SupplyError("unsafe/missing live task database")
    audit=audit_acceptances(db_path, Path(project))
    trust={r["task_id"]:r["evidence_status"] for r in audit["tasks"]}
    # Explicit SQLite mode=ro. This method never calls the coordinator mutators.
    uri=db_path.resolve().as_uri()+"?mode=ro"
    with closing(sqlite3.connect(uri,uri=True,timeout=5)) as c:
        c.row_factory=sqlite3.Row
        c.execute("PRAGMA query_only=ON")
        rows=c.execute("SELECT task_id,status,role_hint,deliverables FROM tasks LIMIT 501").fetchall()
        if len(rows)>500:raise SupplyError("task queue too large")
        state={r["task_id"]:dict(r) for r in rows}
    return state,trust


def plan(candidates, states, trust, project=ROOT, limit_per_role=2):
    project=Path(project)
    if not 1<=limit_per_role<=3:raise SupplyError("invalid cap")
    seen_ids=set()
    pending_files=set()
    busy_files=set()
    ready_count={r:0 for r in ROLES}
    for task in states.values():
        if task["status"]!="done":
            try: busy_files.update(json.loads(task["deliverables"]))
            except (TypeError,ValueError):raise SupplyError("live deliverables corrupt")
        if task["status"]=="available" and task["role_hint"] in ready_count:
            ready_count[task["role_hint"]]+=1
    proposals=[]
    for item in candidates:
        if not isinstance(item,dict):raise SupplyError("candidate malformed")
        ident=item.get("id")
        if not isinstance(ident,str) or not ID.fullmatch(ident) or ident in seen_ids:
            raise SupplyError("duplicate or invalid candidate ID")
        seen_ids.add(ident)
        role=item.get("role_hint")
        if role not in ROLES:raise SupplyError("invalid role")
        spec_ref=item.get("spec_ref")
        if not isinstance(spec_ref,str) or " / " not in spec_ref:
            raise SupplyError("missing canonical spec reference")
        rel,title=spec_ref.split(" / ",1)
        if not SPEC.fullmatch(rel) or not title.strip():
            raise SupplyError("invalid spec reference")
        f=project/rel
        if f.is_symlink() or getattr(f,"is_junction",lambda:False)() or not f.is_file() or f.stat().st_size>262144:
            raise SupplyError("unsafe/missing canonical spec")
        spec_text=f.read_text(encoding="utf-8")
        if title not in REQUIREMENT.findall(spec_text):
            raise SupplyError("candidate requirement not canonical")
        files=item.get("deliverables")
        if (not isinstance(files,list) or not 1<=len(files)<=6
            or len(files)!=len(set(files))
            or any(not isinstance(x,str) or not PYFILE.fullmatch(x) for x in files)):
            raise SupplyError("invalid candidate deliverables")
        if set(files)&pending_files:
            raise SupplyError("candidate-to-candidate output overlap")
        pending_files.update(files)
        deps=item.get("depends_on")
        if not isinstance(deps,list) or not deps or len(set(deps))!=len(deps) or any(not isinstance(t,str) or not ID.fullmatch(t) or t==ident for t in deps):
            raise SupplyError("invalid dependency list")
        if not isinstance(item.get("instructions"),str) or len(item["instructions"])<150 or len(item["instructions"])>3000:
            raise SupplyError("insufficient task acceptance/instructions")
        if type(item.get("priority")) is not int or not 0<=item["priority"]<=100:
            raise SupplyError("invalid priority")
        blockers=[]
        if ident in states:blockers.append("ALREADY_IN_LIVE_QUEUE")
        if set(files)&busy_files:blockers.append("CONFLICT_WITH_ACTIVE_OUTPUT")
        for name in files:
            fpath=project/name
            if fpath.exists() or fpath.is_symlink():
                blockers.append("SOURCE_EXISTS_"+name)
        for dep in deps:
            task=states.get(dep)
            if task is None or task["status"]!="done":
                blockers.append("DEPENDENCY_NOT_DONE_"+dep)
            elif trust.get(dep)!="recorded_pass":
                blockers.append("DEPENDENCY_QA_NOT_VERIFIED_"+dep)
        if ready_count[role]>=limit_per_role:
            blockers.append("ROLE_READY_BUFFER_FULL")
        if not blockers:ready_count[role]+=1
        proposals.append({
            "id":ident,"role":role,"status":"READY_FOR_AUTHORIZED_REVIEW" if not blockers else "BLOCKED",
            "blockers":sorted(set(blockers)),"dependencies":deps,
            "deliverables":files,"spec_ref":spec_ref,"priority":item["priority"]
        })
    return {
        "mode":"READ_ONLY_ADMISSION_PROPOSAL",
        "queue_mutated":False,"owner_approval_granted":False,
        "host_actor_authenticated":False,
        "ready":[r for r in proposals if r["status"]=="READY_FOR_AUTHORIZED_REVIEW"],
        "blocked":[r for r in proposals if r["status"]=="BLOCKED"],
        "available_buffer_after_proposal":ready_count,
        "note":"Dependence and QA audit are necessary, NOT sufficient for source promotion, owner authority, OS host auth or actual SQLite admission."
    }


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-ready-per-role",type=int,default=2)
    a=parser.parse_args(argv)
    try:
        items=load_candidates()
        states,trust=read_live_state()
        result=plan(items,states,trust,limit_per_role=a.max_ready_per_role)
    except (SupplyError,OSError,sqlite3.DatabaseError,ValueError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:180]},ensure_ascii=True))
        return 2
    print(json.dumps({"ok":True,"data":result},ensure_ascii=True))
    return 0


if __name__=="__main__":
    raise SystemExit(main())
