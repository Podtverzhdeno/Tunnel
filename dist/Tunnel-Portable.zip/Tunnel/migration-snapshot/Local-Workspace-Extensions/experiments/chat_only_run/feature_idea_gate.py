"""Strict bounded feature-candidate intake and independent architect adjudication.

No new tickets/specs/grants are created. All proposal files are fixed to a
manifest-hash wave, so idle scheduled runs cannot emit the same 10+ ideas hourly.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from collections import Counter

ROOT=Path(__file__).resolve().parents[2]
SEED=ROOT/"team_seed.json"
EXISTING=ROOT/"docs"/"FEATURE_PORTFOLIO_V1.json"
STATE=ROOT/".agent-team"/"feature-proposals"
ROLES=tuple("developer-"+str(n) for n in range(1,5))
SECTIONS=("problem","user_value","evidence","technical_design","interfaces",
          "scaling_design","security_design","reliability_design","observability",
          "acceptance_metric","migration_plan","rollback_plan","costs_and_tradeoffs")
LENGTHS={"problem":90,"user_value":65,"evidence":75,"technical_design":200,
         "interfaces":70,"scaling_design":90,"security_design":95,
         "reliability_design":95,"observability":70,"acceptance_metric":70,
         "migration_plan":70,"rollback_plan":70,"costs_and_tradeoffs":95}
SCORES=("impact","confidence","feasibility","strategic_fit","engineering_effort","security_risk")
DECISIONS=("PROMOTE_FOR_OWNER_SPEC_APPROVAL","MERGE_EXISTING","DEFER","REJECT")
ARCH_SCORE_FIELDS=("impact","confidence","feasibility","strategic_fit","engineering_effort","security_risk")

def strict_arch_score(dimensions):
    if not isinstance(dimensions,dict) or set(dimensions)!=set(ARCH_SCORE_FIELDS):
        raise IntakeError("ARCH_DIMENSIONS_INVALID")
    if any(type(dimensions[x]) is not int or not 1<=dimensions[x]<=5 for x in ARCH_SCORE_FIELDS):
        raise IntakeError("ARCH_DIMENSIONS_OUT_OF_RANGE")
    d=dimensions
    return max(0,min(100,8*d["impact"]+5*d["feasibility"]+4*d["confidence"]+
                    3*d["strategic_fit"]-3*d["engineering_effort"]-
                    4*d["security_risk"]+15))
MAX_BYTES=350*1024
ID=re.compile(r"F(?:0[1-9]|1[0-9]|20)\Z")

class IntakeError(ValueError):pass

def safe_json(path,limit=MAX_BYTES):
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)() or not path.is_file():
        raise IntakeError("MISSING_OR_UNSAFE_FILE")
    data=path.read_bytes()
    if len(data)>limit:raise IntakeError("TOO_LARGE")
    return json.loads(data.decode("utf-8"))

def wave(root=ROOT):
    p=root/"team_seed.json"
    if p.is_symlink() or not p.is_file():raise IntakeError("UNSAFE_SEED")
    raw=p.read_bytes()
    if not 0<len(raw)<300000:raise IntakeError("SEED_SIZE")
    return hashlib.sha256(raw).hexdigest()[:16]

def norm(value):
    return " ".join(re.findall(r"[\w]+",str(value).casefold()))

def proposal_path(role,root=ROOT):
    if role not in ROLES:raise IntakeError("INVALID_ROLE")
    return root/".agent-team"/"feature-proposals"/wave(root)/(role+".json")

def assert_text(entry,key,errors,minimum=None):
    value=entry.get(key)
    if not isinstance(value,str) or not minimum<=len(value.strip())<=5000:
        errors.append("TEXT_TOO_SHORT_OR_INVALID:"+key)

def check_proposal(obj,role,w,existing_titles=None):
    errors=[]
    if not isinstance(obj,dict):return ["NOT_OBJECT"],[]
    if set(obj)!={"schema","wave","role","candidates","cycle_reason"}:
        errors.append("PROPOSAL_SCHEMA_KEYS")
    if obj.get("schema")!="feature-candidates-v1":errors.append("SCHEMA_INVALID")
    if obj.get("wave")!=w:errors.append("WAVE_MISMATCH")
    if obj.get("role")!=role:errors.append("ROLE_MISMATCH")
    if not isinstance(obj.get("cycle_reason"),str) or len(obj["cycle_reason"].strip())<65:
        errors.append("CYCLE_REASON_TOO_SHORT")
    items=obj.get("candidates")
    if not isinstance(items,list) or not 10<=len(items)<=20:
        return sorted(set(errors+["REQUIRES_BETWEEN_10_AND_20_FEATURES"])),[]
    ids=set()
    titles=set()
    accepted=[]
    for ix,item in enumerate(items,1):
        prefix=f"candidate[{ix}]"
        if not isinstance(item,dict):
            errors.append(prefix+":NOT_OBJECT");continue
        needed={"id","title","summary","related_existing_ids","failure_scenarios",
                "test_strategy","alternatives","score","sections","confidence_note"}
        if set(item)!=needed:errors.append(prefix+":KEYS_MISMATCH")
        fid=item.get("id")
        if not isinstance(fid,str) or not ID.fullmatch(fid) or fid in ids:
            errors.append(prefix+":ID_INVALID_OR_DUPLICATE")
        else:ids.add(fid)
        title=item.get("title")
        if not isinstance(title,str) or not 18<=len(title.strip())<=120:
            errors.append(prefix+":TITLE_INVALID")
        else:
            nt=norm(title)
            if nt in titles or nt in (existing_titles or set()):
                errors.append(prefix+":TITLE_DUPLICATE_EXISTING")
            titles.add(nt)
        assert_text(item,"summary",errors,95)
        assert_text(item,"confidence_note",errors,65)
        related=item.get("related_existing_ids")
        if not isinstance(related,list) or len(related)>12 or any(
                not isinstance(x,str) or not re.fullmatch(r"(MF-\d{3}|P\d{3})",x) for x in related):
            errors.append(prefix+":RELATED_IDS_INVALID")
        for k,at_least in (("failure_scenarios",3),("test_strategy",4),("alternatives",2)):
            rows=item.get(k)
            if not isinstance(rows,list) or not at_least<=len(rows)<=12 or any(
                    not isinstance(x,str) or len(x.strip())<50 or len(x)>1100 for x in rows):
                errors.append(prefix+":"+k.upper()+"_INSUFFICIENT")
        score=item.get("score")
        if not isinstance(score,dict) or set(score)!=set(SCORES) or any(
                type(score[k]) is not int or not 1<=score[k]<=5 for k in SCORES if k in score):
            errors.append(prefix+":SCORE_INVALID")
        sections=item.get("sections")
        if not isinstance(sections,dict) or set(sections)!=set(SECTIONS):
            errors.append(prefix+":SECTIONS_INCOMPLETE")
        else:
            for field in SECTIONS:
                if not isinstance(sections[field],str) or not LENGTHS[field]<=len(sections[field].strip())<=4200:
                    errors.append(prefix+":SECTION_WEAK:"+field)
        accepted.append(item)
    return sorted(set(errors)),accepted

def current_existing(root=ROOT):
    obj=safe_json(root/"docs"/"FEATURE_PORTFOLIO_V1.json")
    items=obj.get("features",[])
    if not isinstance(items,list):raise IntakeError("EXISTING_FEATURES_INVALID")
    return {norm(x["title"]) for x in items if isinstance(x,dict) and isinstance(x.get("title"),str)}

def evaluate(role,root=ROOT):
    p=proposal_path(role,root)
    w=wave(root)
    try:
        obj=safe_json(p)
    except IntakeError as e:
        return {"role":role,"wave":w,"state":"NOT_SUBMITTED","errors":[str(e)],
                "path":str(p.relative_to(root)),"ready":False}
    errors,items=check_proposal(obj,role,w,current_existing(root))
    return {"role":role,"wave":w,"state":"VALIDATED" if not errors else "INVALID",
            "errors":errors[:65],"count":len(items),"ready":not errors,
            "sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
            "path":str(p.relative_to(root))}

def catalog(root=ROOT):
    w=wave(root)
    entries=[evaluate(role,root) for role in ROLES]
    return {"wave":w,"roles":entries,"all_ready":all(e["ready"] for e in entries),
            "total_candidates":sum(e.get("count",0) for e in entries if e["ready"]),
            "mutated_live_queue":False,"owner_approved_specs":False}

def architect_decisions(root=ROOT):
    state=catalog(root)
    if not state["all_ready"]:return {"ready":False,"reason":"WAIT_FOR_FOUR_STRICTLY_VALIDATED_PORTFOLIOS","catalog":state}
    w=state["wave"]
    path=root/".agent-team"/"feature-proposals"/w/"architect_decisions.json"
    allids=set()
    title_lookup={}
    for role in ROLES:
        p=safe_json(proposal_path(role,root))
        for x in p["candidates"]:
            fid=role+":"+x["id"]
            allids.add(fid);title_lookup[fid]=norm(x["title"])
    try:obj=safe_json(path)
    except IntakeError:return {"ready":False,"reason":"ARCHITECT_DECISIONS_NOT_WRITTEN","expected":len(allids),
                                "path":str(path.relative_to(root)),"catalog":state}
    errors=[]
    if not isinstance(obj,dict) or set(obj)!={"schema","wave","decisions","architecture_summary","owner_gate_acknowledged"}:
        return {"ready":False,"errors":["DECISION_SCHEMA_INVALID"]}
    if obj["schema"]!="architect-feature-decisions-v1" or obj["wave"]!=w:
        errors.append("DECISION_WAVE_OR_SCHEMA")
    if obj["owner_gate_acknowledged"] is not True:errors.append("OWNER_GATE_NOT_ACKNOWLEDGED")
    if not isinstance(obj["architecture_summary"],str) or len(obj["architecture_summary"])<180:
        errors.append("ARCHITECTURE_SUMMARY_INSUFFICIENT")
    decisions=obj.get("decisions")
    if not isinstance(decisions,list) or len(decisions)!=len(allids):
        return {"ready":False,"errors":errors+["EVERY_ID_NEEDS_DECISION"],"expected":len(allids)}
    seen=set()
    promoted=[]
    for row in decisions:
        if not isinstance(row,dict) or set(row)!={"feature_id","decision","rationale","similar_to","risks","tests_required","weighted_score","dimensions"}:
            errors.append("DECISION_ITEM_SCHEMA");continue
        name=row["feature_id"]
        if name not in allids or name in seen:errors.append("INVALID_OR_DUPLICATE_ID")
        seen.add(name)
        if row["decision"] not in DECISIONS:errors.append("INVALID_DECISION")
        if not isinstance(row["rationale"],str) or len(row["rationale"])<120:
            errors.append("WEAK_ARCHITECT_RATIONALE")
        try:
            expected=strict_arch_score(row["dimensions"])
            if type(row["weighted_score"]) is not int or row["weighted_score"]!=expected:
                errors.append("SCORE_NOT_DERIVED_FROM_INDEPENDENT_RUBRIC")
        except IntakeError:
            errors.append("ARCH_SCORE_DIMENSIONS_INVALID")
        if not isinstance(row["risks"],list) or not row["risks"] or any(
                not isinstance(x,str) or len(x)<35 for x in row["risks"]):
            errors.append("RISK_ASSESSMENT_MISSING")
        if not isinstance(row["tests_required"],list) or not row["tests_required"] or any(
                not isinstance(x,str) or len(x)<35 for x in row["tests_required"]):
            errors.append("TEST_ASSESSMENT_MISSING")
        if row["decision"]=="PROMOTE_FOR_OWNER_SPEC_APPROVAL":
            if type(row["weighted_score"]) is not int or row["weighted_score"]<78:
                errors.append("PROMOTION_BELOW_STRICT_THRESHOLD")
            if row["similar_to"]:errors.append("PROMOTION_DUPLICATE_OR_DEPENDENCY")
            promoted.append(name)
        if row["decision"]=="MERGE_EXISTING" and not row["similar_to"]:
            errors.append("MERGE_TARGET_MISSING")
    if set(allids)!=seen:errors.append("MISSING_DECISIONS")
    if len(promoted)>8:errors.append("TOO_MANY_PROMOTIONS_MAX_8")
    groups={}
    for row in decisions:
        if isinstance(row,dict):
            fid=row.get("feature_id")
            if fid in title_lookup:
                groups.setdefault(title_lookup[fid],[]).append(row)
    for rows in groups.values():
        if len(rows)>1 and sum(x.get("decision")=="PROMOTE_FOR_OWNER_SPEC_APPROVAL" for x in rows)>1:
            errors.append("CROSS_AGENT_DUPLICATE_PROMOTION")
    return {"ready":not errors,"errors":sorted(set(errors)), "total_evaluated":len(seen),
            "promoted_to_owner_proposal":promoted if not errors else [],
            "formal_spec_approval":False,"live_queue_mutated":False,
            "path":str(path.relative_to(root))}

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=["wave","validate","catalog","architect"])
    parser.add_argument("role",nargs="?")
    args=parser.parse_args(argv)
    try:
        if args.command=="wave":data={"wave":wave(),"one_portfolio_per_role_per_wave":True}
        elif args.command=="validate":
            if args.role not in ROLES:raise IntakeError("ROLE_REQUIRED")
            data=evaluate(args.role)
        elif args.command=="catalog":data=catalog()
        else:data=architect_decisions()
        print(json.dumps({"ok":True,"data":data},ensure_ascii=True))
        return 0
    except (IntakeError,OSError,UnicodeError,TypeError,KeyError,ValueError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:180]},ensure_ascii=True))
        return 2

if __name__=="__main__":sys.exit(main())
