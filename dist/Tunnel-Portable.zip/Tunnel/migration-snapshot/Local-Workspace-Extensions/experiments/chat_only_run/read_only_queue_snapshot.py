"""Bounded, provably query-only SQLite snapshot for ChatGPT scheduled turns.

Separate from agent_team.connect(), which runs schema creation and PRAGMA
journal_mode=WAL even for its overview CLI. No task text, lease tokens,
checkpoint bodies or user files are read. Never use this as host identity.
"""
from __future__ import annotations

import re
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
DB_REL = Path(".agent-team") / "team.sqlite3"
ROLES = frozenset(("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer"))
STATES = frozenset(("available", "working", "review", "reviewing", "rework", "done", "blocked"))
TASK = re.compile(r"P[0-9]{3,6}\Z")
MAX_TASKS = 2500
MAX_DB_BYTES = 128 * 1024 * 1024


class ReadOnlySnapshotError(ValueError):
    """No untrusted SQLite data included in error output."""


def _time(text, nullable=False):
    if text is None and nullable:
        return None
    if not isinstance(text, str) or len(text) > 64:
        raise ReadOnlySnapshotError("BAD_TIMESTAMP")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ReadOnlySnapshotError("BAD_TIMESTAMP") from exc
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ReadOnlySnapshotError("NAIVE_TIMESTAMP")
    return dt.astimezone(timezone.utc)


def _age(now, earlier):
    if earlier is None:
        return None
    return max(0.0, round((now - earlier).total_seconds() / 60, 1))


def _check_db(root):
    root = Path(root)
    if root.is_symlink() or getattr(root, "is_junction", lambda: False)():
        raise ReadOnlySnapshotError("UNSAFE_ROOT")
    folder = root / ".agent-team"
    path = root / DB_REL
    for candidate in (folder, path):
        if candidate.is_symlink() or getattr(candidate, "is_junction", lambda: False)():
            raise ReadOnlySnapshotError("UNSAFE_PATH")
    try:
        if not path.is_file() or path.stat().st_size > MAX_DB_BYTES:
            raise ReadOnlySnapshotError("DATABASE_UNAVAILABLE")
    except OSError as exc:
        raise ReadOnlySnapshotError("DATABASE_UNAVAILABLE") from exc
    return path


def read_overview(root=PROJECT, *, now=None):
    """Query-only, single consistent snapshot of live SQLite coordinator state."""
    now = now or datetime.now(timezone.utc)
    if not isinstance(now, datetime) or now.utcoffset() is None:
        raise ReadOnlySnapshotError("BAD_NOW")
    now = now.astimezone(timezone.utc)
    dbfile = _check_db(root)
    try:
        with closing(sqlite3.connect(dbfile.as_uri() + "?mode=ro",
                                     uri=True, timeout=3)) as db:
            db.execute("PRAGMA query_only=ON")
            db.execute("BEGIN")
            tasks = db.execute(
                "SELECT task_id,status,owner,role_hint,activity_at,lease_until,review_until "
                "FROM tasks ORDER BY task_id LIMIT ?", (MAX_TASKS + 1,)
            ).fetchall()
            actors = db.execute(
                "SELECT role,sessions,last_started,last_activity FROM agents "
                "ORDER BY role LIMIT 7"
            ).fetchall()
            checkpoints = db.execute(
                "SELECT task_id,MAX(recorded_at) FROM task_checkpoints "
                "GROUP BY task_id LIMIT ?", (MAX_TASKS + 1,)
            ).fetchall()
            db.execute("COMMIT")
    except sqlite3.Error as exc:
        raise ReadOnlySnapshotError("QUEUE_READ_FAILED") from exc
    if len(tasks) > MAX_TASKS or len(checkpoints) > MAX_TASKS or len(actors) > 5:
        raise ReadOnlySnapshotError("QUEUE_LIMIT_EXCEEDED")
    if len({row[0] for row in tasks}) != len(tasks):
        raise ReadOnlySnapshotError("DUPLICATE_TASK")
    cp = {}
    for tid, at in checkpoints:
        if not isinstance(tid, str) or not TASK.fullmatch(tid) or tid in cp:
            raise ReadOnlySnapshotError("BAD_CHECKPOINT_ID")
        cp[tid] = _time(at)
    result_tasks, counts = [], {}
    for tid, state, owner, hint, activity, deadline, review_deadline in tasks:
        if (not isinstance(tid, str) or not TASK.fullmatch(tid)
            or state not in STATES or hint not in ROLES or hint == "architect-reviewer"
            or owner is not None and owner != hint):
            raise ReadOnlySnapshotError("BAD_TASK_STATE")
        # Owned available tasks are valid candidates in the coordinator.
        if state in {"working", "rework", "review", "reviewing", "done"} and owner is None:
            raise ReadOnlySnapshotError("OWNED_TASK_WITHOUT_OWNER")
        last = _time(activity)
        until = _time(deadline, nullable=True)
        minutes = round((until - now).total_seconds() / 60, 1) if until else None
        review_until = _time(review_deadline, nullable=True)
        review_minutes = round((review_until - now).total_seconds() / 60, 1) if review_until else None
        attention = []
        if state == "working" and until is None:
            attention.append("working_missing_lease")
        if state == "working" and minutes is not None and minutes < 0:
            attention.append("developer_lease_expired")
        if state == "review" and _age(now, last) >= 60:
            attention.append("review_waiting_over_hour")
        if state == "reviewing" and review_until is None:
            attention.append("reviewing_missing_lease")
        if state == "reviewing" and review_minutes is not None and review_minutes < 0:
            attention.append("reviewer_lease_expired")
        if state == "rework":
            attention.append("review_rework_required")
        result_tasks.append({
            "task_id": tid, "status": state, "owner": owner,
            "last_activity_utc": last.isoformat(),
            "lease_remaining_minutes": minutes,
            "review_lease_remaining_minutes": review_minutes,
            "checkpoint_at_utc": cp[tid].isoformat() if tid in cp else None,
            "next_steps": [],  # Raw checkpoint text intentionally excluded.
            "attention": attention,
        })
        counts[state] = counts.get(state, 0) + 1
    result_agents = []
    for role, sessions, started, activity in actors:
        if (role not in ROLES or type(sessions) is not int or sessions < 0
            or role in {x["role"] for x in result_agents}):
            raise ReadOnlySnapshotError("BAD_AGENT_STATE")
        result_agents.append({
            "role": role, "sessions": sessions,
            "last_started_utc": _time(started, nullable=True).isoformat() if started else None,
            "last_activity_utc": _time(activity, nullable=True).isoformat() if activity else None,
        })
    return {
        "project": "Local-Workspace-Extensions",
        "as_of_utc": now.isoformat(timespec="seconds"),
        "task_counts": counts,
        "agents": result_agents,
        "tasks": result_tasks,
        "snapshot_origin": "query_only_sqlite_single_transaction",
        "contains_raw_checkpoint_text": False,
        "host_actor_authenticated": False,
        "may_mutate": False,
    }
