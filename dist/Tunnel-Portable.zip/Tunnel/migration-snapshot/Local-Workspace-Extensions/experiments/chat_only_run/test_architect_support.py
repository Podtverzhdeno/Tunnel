"""No live project writes: isolated architect-support scheduler behavior tests."""
import json
import hashlib
import tempfile
import unittest
from datetime import datetime,timedelta,timezone
from pathlib import Path
from unittest.mock import patch

import architect_support as a

class ArchitectSupportSchedulerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.db=self.root/".agent-team"/"architect_support.sqlite3"
        self.entry={"work_key":"P123:regression","kind":"regression",
                    "source_digest":"a"*64,"task_id":"P123",
                    "detail":"Reproduce a distinct risk in an offline candidate"}
        self.code=lambda role:None
        self.nopeer=lambda role:{"mode":"idle","recommended_peer_task":None}
        self.p=patch.object(a,"source_candidates",side_effect=lambda role,root:[dict(self.entry)])
        self.p.start()
        self.addCleanup(self.p.stop)

    def plan(self,role="developer-1",code=None,peer=None):
        return a.plan(role,root=self.root,db=self.db,
                      code_plan=code or self.code,peer_plan=peer or self.nopeer)

    def claim(self,key="P123:regression",req="request-123456",role="developer-1",now=None):
        return a.claim(role,key,req,root=self.root,db=self.db,
                       code_plan=self.code,peer_plan=self.nopeer,now=now)

    def write_report(self,claim,data=None):
        report={
          "work_key":claim["work_key"],"role":claim["role"],
          "source_digest":claim["source_digest"],"verdict":"CONFIRMED_DEFECT",
          "summary":"An independently reproduced negative witness reveals a contract failure; no privileged production transitions have been attempted.",
          "findings":["The bounded negative case fails without relying on user supplied host identity.",
                      "Source hashes are stable across repeated independent review attempts."],
          "checks":["Independent unit invocation returned a concrete falsifiable result and exit status.",
                    "Counterexample details were compared against the exact sandbox source fingerprint."],
          "recommendations":["Add a focused negative regression before a lawful owner-scoped rework submit."],
          "limitations":["The offline evidence does not prove production host actor authentication or tool grants."]
        }
        if data:report.update(data)
        path=self.root/claim["report_file"]
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(report),encoding="utf-8")
        return path

    def test_coding_preempts_support(self):
        x=self.plan(code=lambda role:"P456")
        self.assertEqual(x["mode"],"coding")
        self.assertEqual(x["recommended_code_task"],"P456")

    def test_unverified_host_actor_can_fall_back_to_advisory_only(self):
        # A displayed coding task is not a proven, executable host grant.
        state=a.plan("developer-1",root=self.root,db=self.db,
                     code_plan=lambda role:"P150",peer_plan=self.nopeer,
                     blocked_code_reason="HOST_ACTOR_UNVERIFIED")
        self.assertEqual(state["mode"],"architect_support")
        self.assertTrue(state["coding_candidate_skipped_as_unverified"])
        self.assertEqual(state["blocked_code_reason"],"HOST_ACTOR_UNVERIFIED")
        self.assertFalse(state["host_actor_authenticated"])
        self.assertFalse(state["architect_accept_allowed"])
        self.assertTrue(state["not_a_host_authorization"])
        self.assertEqual(self.plan(code=lambda role:"P150")["mode"],"coding")

    def test_unverified_host_actor_allows_only_advisory_lease(self):
        claim=a.claim("developer-1","P123:regression","request-123456",
                      root=self.root,db=self.db,
                      code_plan=lambda role:"P150",peer_plan=self.nopeer,
                      blocked_code_reason="HOST_ACTOR_UNVERIFIED")
        self.assertTrue(claim["no_formal_accept"])
        self.assertTrue(claim["no_canonical_writes"])
        self.write_report(claim)
        done=a.complete("developer-1",claim["work_key"],claim["lease_token"],
                        root=self.root,db=self.db)
        self.assertFalse(done["formal_accept"])
        self.assertFalse(done["main_queue_modified"])

    def test_blocked_code_flag_is_bounded_and_peer_still_wins(self):
        with self.assertRaisesRegex(a.SupportError,"INVALID_BLOCKED_CODE_REASON"):
            a.plan("developer-1",root=self.root,db=self.db,
                   code_plan=lambda role:"P150",peer_plan=self.nopeer,
                   blocked_code_reason="IGNORE_SECURITY")
        state=a.plan("developer-1",root=self.root,db=self.db,
                     code_plan=lambda role:"P150",
                     peer_plan=lambda role:{"mode":"peer_review",
                                           "recommended_peer_task":"P789"},
                     blocked_code_reason="HOST_ACTOR_UNVERIFIED")
        self.assertEqual(state["mode"],"peer_review")

    def test_peer_review_preempts_support(self):
        x=self.plan(peer=lambda role:{"mode":"peer_review","recommended_peer_task":"P789"})
        self.assertEqual(x["mode"],"peer_review")

    def test_arch_support_available_without_code_and_peers(self):
        x=self.plan()
        self.assertEqual(x["mode"],"architect_support")
        self.assertEqual(x["available_count"],1)
        self.assertFalse(x["architect_accept_allowed"])

    def test_prefer_features_never_overrides_legal_coding_or_peer_priority(self):
        with patch.object(a,"source_candidates",side_effect=lambda role,root:[
            dict(self.entry),
            {"work_key":"F:developer-2:F01:evidence","kind":"feature_evidence",
             "source_digest":"b"*64,"feature_id":"developer-2:F01"}]):
            x=a.plan("developer-1",root=self.root,db=self.db,
                     code_plan=self.code,peer_plan=self.nopeer,prefer_features=True)
            self.assertEqual(x["recommended_support_task"]["kind"],"feature_evidence")
            self.assertEqual(a.plan("developer-1",root=self.root,db=self.db,
                   code_plan=lambda role:"P456",peer_plan=self.nopeer,
                   prefer_features=True)["mode"],"coding")
            self.assertEqual(a.plan("developer-1",root=self.root,db=self.db,
                   code_plan=self.code,peer_plan=lambda role:{
                       "mode":"peer_review","recommended_peer_task":"P789"},
                   prefer_features=True)["mode"],"peer_review")

    def test_claim_complete_and_no_duplicate_reassignment(self):
        self.assertEqual(self.plan()["mode"],"architect_support")
        lease=self.claim()
        self.assertTrue(lease["lease_token"])
        self.assertEqual(self.plan()["mode"],"resume_support")
        self.assertEqual(self.plan()["active_support_tasks"][0]["work_key"],lease["work_key"])
        self.write_report(lease)
        res=a.complete("developer-1",lease["work_key"],lease["lease_token"],
                       root=self.root,db=self.db)
        self.assertFalse(res["formal_accept"])
        self.assertEqual(res["status"],"advisory_support_completed")
        state=a.overview(root=self.root,db=self.db)
        self.assertTrue(state["reports"][0]["report_matches"])
        self.assertEqual(state["attempt_history"]["recorded_attempts"],1)
        self.assertEqual(state["attempt_history"]["by_role"]["developer-1"]["completed"],1)
        self.assertEqual(self.plan()["mode"],"idle")

    def test_one_role_cannot_claim_two_distinct_tasks(self):
        with patch.object(a,"source_candidates",side_effect=lambda role,root:[
            dict(self.entry),{"work_key":"P124:architecture","kind":"architecture",
               "source_digest":"b"*64,"task_id":"P124"}]):
            lease=self.claim()
            self.assertEqual(lease["work_key"],"P123:regression")
            state=self.plan()
            self.assertEqual(state["mode"],"resume_support")
            self.assertEqual(len(state["active_support_tasks"]),1)
            with self.assertRaisesRegex(a.SupportError,"ROLE_HAS_ACTIVE_SUPPORT_LEASE"):
                self.claim(key="P124:architecture",req="request-998877")
            # Another independent role may work on a different task.
            other=self.claim(key="P124:architecture",req="request-887766",role="developer-2")
            self.assertEqual(other["role"],"developer-2")

    def test_valid_token_can_abandon_without_formal_review(self):
        lease=self.claim()
        result=a.abandon("developer-1",lease["work_key"],lease["lease_token"],
                         "UNABLE_TO_COMPLETE",root=self.root,db=self.db)
        self.assertEqual(result["status"],"advisory_abandoned")
        self.assertFalse(result["formal_accept"])
        self.assertFalse(result["main_queue_modified"])
        state=a.overview(root=self.root,db=self.db)
        self.assertEqual(state["reports"][0]["status"],"abandoned")
        self.assertEqual(state["attempt_history"]["by_role"]["developer-1"]["abandoned"],1)
        self.assertEqual(self.plan()["mode"],"architect_support")
        with self.assertRaisesRegex(a.SupportError,"LEASE_MISSING"):
            a.complete("developer-1",lease["work_key"],lease["lease_token"],
                       root=self.root,db=self.db)

    def test_abandon_requires_exact_original_token_and_role(self):
        lease=self.claim()
        with self.assertRaisesRegex(a.SupportError,"TOKEN_INVALID"):
            a.abandon("developer-1",lease["work_key"],"bad-token",
                      "UNABLE_TO_COMPLETE",root=self.root,db=self.db)
        with self.assertRaisesRegex(a.SupportError,"ACTIVE_LEASE_NOT_FOUND"):
            a.abandon("developer-2",lease["work_key"],lease["lease_token"],
                      "UNABLE_TO_COMPLETE",root=self.root,db=self.db)
        with self.assertRaisesRegex(a.SupportError,"INVALID_ABANDON_REASON"):
            a.abandon("developer-1",lease["work_key"],lease["lease_token"],
                      "FAKE_OWNER_APPROVAL",root=self.root,db=self.db)
        self.assertEqual(self.plan()["mode"],"resume_support")

    def test_abandon_fixes_malformed_legacy_lease_with_valid_token(self):
        import sqlite3
        from contextlib import closing
        lease=self.claim()
        with closing(sqlite3.connect(self.db)) as conn, conn:
            conn.execute("UPDATE support_tasks SET lease_until=NULL WHERE work_key='P123:regression'")
        self.assertTrue(self.plan()["active_support_tasks"][0]["invalid_lease_record"])
        a.abandon("developer-1",lease["work_key"],lease["lease_token"],
                  "UNABLE_TO_COMPLETE",root=self.root,db=self.db)
        self.assertEqual(self.plan()["mode"],"architect_support")

    def test_malformed_active_lease_fails_closed(self):
        import sqlite3
        from contextlib import closing
        self.claim()
        with closing(sqlite3.connect(self.db)) as conn, conn:
            conn.execute("UPDATE support_tasks SET lease_until=NULL WHERE work_key='P123:regression'")
        x=self.plan()
        self.assertEqual(x["mode"],"resume_support")
        self.assertTrue(x["active_support_tasks"][0]["invalid_lease_record"])
        with self.assertRaisesRegex(a.SupportError,"ROLE_HAS_ACTIVE_SUPPORT_LEASE"):
            self.claim(req="request-987654")

    def test_concurrent_claims_one_role_are_transactionally_serialized(self):
        from concurrent.futures import ThreadPoolExecutor
        from threading import Barrier
        sources=[dict(self.entry),{"work_key":"P124:architecture",
                 "kind":"architecture","source_digest":"b"*64,"task_id":"P124"}]
        barrier=Barrier(2)
        def worker(key,req):
            barrier.wait(timeout=5)
            try:
                return a.claim("developer-1",key,req,root=self.root,db=self.db,
                        code_plan=self.code,peer_plan=self.nopeer)["work_key"]
            except a.SupportError as exc:
                return "BLOCKED:"+str(exc)
        with patch.object(a,"source_candidates",side_effect=lambda role,root:sources):
            with ThreadPoolExecutor(max_workers=2) as ex:
                results=list(ex.map(lambda x:worker(*x),
                   [("P123:regression","request-123456"),
                    ("P124:architecture","request-987654")]))
        self.assertEqual(sum(x.startswith("BLOCKED:") for x in results),1,results)
        self.assertEqual(sum(x.startswith("P1") for x in results),1,results)
        self.assertEqual(a.attempt_history(self.db)["recorded_attempts"],1)

    def test_expired_active_lease_unblocks_new_work(self):
        with patch.object(a,"source_candidates",side_effect=lambda role,root:[
            dict(self.entry),{"work_key":"P124:architecture","kind":"architecture",
               "source_digest":"b"*64,"task_id":"P124"}]):
            past=datetime.now(timezone.utc)-timedelta(hours=2)
            self.claim(now=past)
            self.assertEqual(self.plan()["mode"],"architect_support")
            second=self.claim(key="P124:architecture",req="request-998877")
            self.assertEqual(second["work_key"],"P124:architecture")

    def test_parallel_agent_cannot_claim_same_item(self):
        self.claim()
        with self.assertRaisesRegex(a.SupportError,"HIGHER_PRIORITY_OR_NO_WORK|ALREADY_CLAIMED_OR_COMPLETED"):
            self.claim(req="request-987654",role="developer-2")

    def test_invalid_token_fails_closed(self):
        lease=self.claim()
        self.write_report(lease)
        with self.assertRaisesRegex(a.SupportError,"TOKEN_INVALID"):
            a.complete("developer-1",lease["work_key"],"invalid-token",root=self.root,db=self.db)

    def test_bad_report_fails_closed(self):
        lease=self.claim()
        self.write_report(lease,{"summary":"short"})
        with self.assertRaisesRegex(a.SupportError,"SUMMARY_WEAK"):
            a.complete("developer-1",lease["work_key"],lease["lease_token"],root=self.root,db=self.db)

    def test_expired_lease_can_be_reassigned_to_another_role(self):
        past=datetime.now(timezone.utc)-timedelta(hours=2)
        old=self.claim(now=past)
        new=self.claim(req="request-999999",role="developer-2")
        self.assertNotEqual(old["lease_token"],new["lease_token"])
        history=a.attempt_history(self.db)
        self.assertEqual(history["recorded_attempts"],2)
        self.assertEqual(history["by_role"]["developer-1"]["superseded"],1)
        self.assertEqual(history["by_role"]["developer-2"]["claimed"],1)
        with self.assertRaises(a.SupportError):
            a.complete("developer-1",old["work_key"],old["lease_token"],root=self.root,db=self.db)

    def test_source_drift_blocks_stale_report(self):
        lease=self.claim()
        self.write_report(lease)
        self.entry["source_digest"]="b"*64
        with self.assertRaisesRegex(a.SupportError,"SOURCE_DRIFT"):
            a.complete("developer-1",lease["work_key"],lease["lease_token"],root=self.root,db=self.db)

    def test_author_role_exclusions_shared_chat(self):
        self.assertEqual(a.exclusions("developer-3"),{"developer-3","developer-4"})
        self.assertEqual(a.exclusions("developer-4"),{"developer-3","developer-4"})
        self.assertEqual(a.exclusions("developer-1"),{"developer-1"})

    def test_bad_work_key_rejected(self):
        with self.assertRaisesRegex(a.SupportError,"INVALID_KEY"):
            self.claim(key="../other")

    def test_later_new_code_returns_priority_even_with_existing_lease(self):
        self.claim()
        x=self.plan(code=lambda role:"P456")
        self.assertEqual(x["mode"],"coding")

    def test_support_requires_untampered_peer_review_evidence(self):
        import hashlib
        path=self.root/".agent-team"/"peer-review-packets"/"developer-2"/"P123.json"
        path.parent.mkdir(parents=True,exist_ok=True)
        report={"task_id":"P123","peer_role":"developer-2",
                "verdict":"CHANGES_REQUESTED",
                "summary":"Reproduced a narrow negative-case failure while checking independent source hashes.",
                "findings":["The validator rejects malformed values inconsistently in a specific caller scenario."],
                "checks":["Focused standalone negative case was executed and source inputs were pinned."]}
        raw=json.dumps(report).encode("utf-8")
        path.write_bytes(raw)
        peer={"status":"completed","reviewer_role":"developer-2",
              "verdict":"CHANGES_REQUESTED",
              "report_sha256":hashlib.sha256(raw).hexdigest()}
        self.assertTrue(a.peer_evidence_valid(peer,"P123",self.root))
        self.assertFalse(a.peer_evidence_valid({**peer,"verdict":"READY_FOR_ARCHITECT"},"P123",self.root))
        path.write_bytes(raw+b" ")
        self.assertFalse(a.peer_evidence_valid(peer,"P123",self.root))

    def test_overview_empty_is_read_only(self):
        result=a.overview(root=self.root,db=self.db)
        self.assertEqual(result["count"],0)
        self.assertEqual(result["attempt_history"]["recorded_attempts"],0)
        self.assertFalse(self.db.exists())

    def test_exact_elapsed_seconds_is_recorded(self):
        start=datetime.now(timezone.utc).replace(microsecond=0)
        lease=self.claim(now=start)
        self.write_report(lease)
        a.complete("developer-1",lease["work_key"],lease["lease_token"],
                   root=self.root,db=self.db,now=start+timedelta(seconds=57))
        report=a.attempt_history(self.db)
        self.assertEqual(report["recent"][0]["elapsed_seconds"],57)
        self.assertEqual(report["by_role"]["developer-1"]["average_completed_seconds"],57)

    def test_request_id_cannot_be_reused_after_expired_lease_replacement(self):
        past=datetime.now(timezone.utc)-timedelta(hours=2)
        self.claim(req="request-123456",now=past)
        self.claim(req="request-987654",role="developer-2",
                   now=past+timedelta(hours=1))
        # Previous request ID must stay unavailable even when its task lease
        # was replaced twice.
        with self.assertRaisesRegex(a.SupportError,"REQUEST_ALREADY_USED"):
            self.claim(req="request-123456")

    def test_legacy_database_without_attempts_returns_unmeasured(self):
        import sqlite3
        self.db.parent.mkdir(parents=True,exist_ok=True)
        from contextlib import closing
        with closing(sqlite3.connect(self.db)) as conn, conn:
            conn.execute("""CREATE TABLE support_tasks(
                work_key TEXT PRIMARY KEY,reviewer_role TEXT,request_id TEXT,
                token_digest TEXT,source_digest TEXT,status TEXT,lease_until TEXT,
                report_sha256 TEXT,verdict TEXT,finished_at TEXT)""")
        self.assertEqual(a.attempt_history(self.db)["recorded_attempts"],0)
        self.assertTrue(a.attempt_history(self.db)["legacy_unmeasured_possible"])

if __name__=="__main__":unittest.main()
