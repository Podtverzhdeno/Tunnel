"""Read-only architecture review of the proposed P162-P169 reserve.

Never creates queue rows, actor credentials, approval grants or reviewer receipts.
"""
from __future__ import annotations

import ast
import hashlib
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from agent_responsibility_guard import validate_contract

POOL = ROOT / "experiments/chat_only_run/queue_supply_candidates_backlog.json"
PROPOSAL = ROOT / "requests/p162-p169-responsibility-migration-review.json"
SEED = ROOT / "team_seed.json"
ROADMAP = ROOT / "specs/001-local-pc-agent-tooling/roadmap_tasks.json"
IDS = {f"P{x}" for x in range(162,170)}
CONSUMERS = {"P162":"spec_traceability", "P163":"token_usage_export",
             "P167":"team_acceptance_audit"}


class ReviewedCandidateContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pool_bytes = POOL.read_bytes()
        cls.proposal = json.loads(PROPOSAL.read_text(encoding="utf-8"))
        cls.candidates = json.loads(cls.pool_bytes.decode("utf-8"))["tasks"]
        cls.by_id = {t["id"]: t for t in cls.candidates}

    def test_proposal_tied_to_current_exact_backlog_bytes(self):
        self.assertEqual(self.proposal["schema"],"agent-code-reuse-roadmap-review-v1")
        self.assertEqual(self.proposal["stage"],"PROPOSED_ONLY")
        self.assertFalse(self.proposal["approval_granted"])
        self.assertFalse(self.proposal["task_queue_mutated"])
        self.assertEqual(hashlib.sha256(self.pool_bytes).hexdigest(),
                         self.proposal["source_manifest_sha256"])

    def test_eight_distinct_contracts_are_valid(self):
        self.assertEqual(set(self.by_id).intersection(IDS),IDS)
        contracts=[]
        for tid in sorted(IDS):
            t=self.by_id[tid]
            contract=validate_contract(t["responsibility"], set(t["deliverables"]))
            contracts.append(contract)
            self.assertEqual(t["deliverables"][0],
                             contract["allowed_extensions"][0])
            self.assertNotIn(contract["module"]+".py",t["deliverables"]
                             if contract["role"]=="consumer" else [])
        # Each owner creates one distinct canonical implementation; consumers reuse
        # the verified existing owner rather than minting another owner ID.
        owners=[c for c in contracts if c["role"]=="owner"]
        self.assertEqual(len({c["id"] for c in owners}),len(owners))
        self.assertEqual(len({c["module"] for c in owners}),len(owners))

    def test_existing_consumers_reference_actual_public_api(self):
        for tid, canonical in CONSUMERS.items():
            with self.subTest(task=tid):
                contract=self.by_id[tid]["responsibility"]
                self.assertEqual(contract["role"],"consumer")
                self.assertEqual(contract["reuse_decision"],"REUSE_EXISTING")
                self.assertEqual(contract["module"],canonical)
                source=ROOT / (canonical+".py")
                self.assertTrue(source.is_file(),source)
                tree=ast.parse(source.read_text(encoding="utf-8"))
                public={n.name for n in tree.body
                        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
                self.assertIn(contract["public_api"],public)

    def test_no_candidate_reuses_existing_source_deliverable(self):
        existing=json.loads(SEED.read_text(encoding="utf-8"))
        existing_ids={t["id"] for t in existing}
        self.assertFalse(IDS & existing_ids)
        owned_files={name for row in existing
                     for name in row.get("deliverables",[])}
        for tid in IDS:
            for output in self.by_id[tid]["deliverables"]:
                self.assertNotIn(output,owned_files)
                self.assertFalse((ROOT/output).exists(),
                                 "Proposed new file already exists: "+output)

    def test_planned_sdd_admission_not_fabricated(self):
        rows=json.loads(ROADMAP.read_text(encoding="utf-8"))["tasks"]
        roadmap={r["id"]:r for r in rows}
        for tid in IDS:
            if tid in roadmap:
                self.assertNotEqual(roadmap[tid].get("admission"),"seeded_ready")
                self.assertNotEqual(roadmap[tid].get("admission"),
                                    "seeded_after_dependencies_accepted")

    def test_retention_alerts_wait_for_p153_reviewer_acceptance(self):
        row=self.by_id["P169"]
        self.assertIn("P153",row["depends_on"])
        self.assertEqual(row["responsibility"]["role"],"owner")
        self.assertEqual(row["responsibility"]["module"],"trace_saturation_alerts")


if __name__ == "__main__":
    unittest.main()
