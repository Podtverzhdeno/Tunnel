"""Bounded read-only inventory of agent feature proposals for architect.
Does not mutate canonical spec, live queue, permissions, portfolio or reports.
"""
import json,sys,re,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/".agent-team"/"feature-proposals"/"705343afee3f9a15"
ROLES=("developer-1","developer-2","developer-3","developer-4")
def main():
    for role in ROLES:
        path=BASE/(role+".json")
        if path.is_symlink() or not path.is_file() or path.stat().st_size>200000: raise ValueError("UNSAFE")
        obj=json.loads(path.read_text(encoding="utf-8"))
        print("ROLE",role,"COUNT",len(obj["candidates"]),"SHA",hashlib.sha256(path.read_bytes()).hexdigest())
        for f in obj["candidates"]:
            sections=f["sections"]
            rec={"id":role+":"+f["id"],"title":f["title"],"score":f["score"],
                 "related":f["related_existing_ids"],"summary":f["summary"][:240],
                 "problem":sections["problem"][:210],"evidence":sections["evidence"][:210],
                 "technical_design":sections["technical_design"][:250],
                 "security":sections["security_design"][:120],
                 "costs":sections["costs_and_tradeoffs"][:150]}
            print(json.dumps(rec,ensure_ascii=True))
if __name__=="__main__":main()
