"""Read-only P111 regression laboratory: proposed mitigation in temp copy only."""
from __future__ import annotations
import json
import sys
import tempfile
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/".agent-team"/"workspaces"/"developer-4"/"P111"
MARKER='_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (\n'
OPTION_PATTERN=r'''_GIT_GLOBAL_OPTIONS = re.compile(
    r"^(?:(?:please|now|you\s+must|you\s+should|пожалуйста|срочно)\s+)?"
    r"(?:(?:run|execute)\s+)?git\s+"
    r"(?:(?:-[Cc]\s+\S{1,128}|-c\s+\S{1,128}|"
    r"--git-dir(?:=\S{1,128}|\s+\S{1,128})|"
    r"--work-tree(?:=\S{1,128}|\s+\S{1,128}))\s+){1,3}"
    r"(?:push|commit|reset|clean)\b", re.I)
'''
TESTS='''import unittest
from prompt_boundary_checks import classify_untrusted_text as classify
class GitGlobalOptionsNegativeTests(unittest.TestCase):
    def test_git_c_push(self):
        value=classify("git -C repo push origin main")
        self.assertEqual(value["decision"],"DENY")
        self.assertIn("GIT_MUTATION",value["reason_codes"])
        self.assertFalse(value["grants_authority"])
    def test_git_c_status_benign(self):
        self.assertEqual(classify("git -C repo status")["decision"],"REVIEW")
    def test_never_git_c_push_documentation(self):
        self.assertEqual(classify("Never git -C repo push")["decision"],"REVIEW")
    def test_git_config_push(self):
        self.assertIn("GIT_MUTATION",classify("git -c core.hooksPath=none push origin main")["reason_codes"])
    def test_run_git_c_push(self):
        self.assertIn("GIT_MUTATION",classify("Run git -C repo push origin main")["reason_codes"])
'''
def guarded_read(path):
    if (path.is_symlink() or getattr(path,"is_junction",lambda:False)()
            or not path.is_file() or path.stat().st_size>200000):
        raise ValueError("UNSAFE_SOURCE")
    return path.read_text(encoding="utf-8")
def run():
    original=guarded_read(BASE/"prompt_boundary_checks.py")
    original_tests=guarded_read(BASE/"test_prompt_boundary_checks.py")
    if original.count(MARKER)!=1:raise ValueError("SOURCE_CHANGED_REVIEW_REQUIRED")
    modified=original.replace(MARKER,OPTION_PATTERN+"\n"+MARKER,1)
    hook="    reasons: list[str] = []\n"
    if original.count(hook)!=1:raise ValueError("SOURCE_CHANGED_REVIEW_REQUIRED")
    extra="""    reasons: list[str] = []
    # Review complete shell lines before punctuation-based clause splitting.
    # Git -c core.name=value contains a dot, not a sentence separator.
    for raw_line in normalized.splitlines():
        line=raw_line.strip()
        if _GIT_GLOBAL_OPTIONS.search(line):
            reasons.append("GIT_MUTATION")
"""
    modified=modified.replace(hook,extra,1)
    with tempfile.TemporaryDirectory(prefix="p111-read-only-lab-") as td:
        temp=Path(td)
        (temp/"prompt_boundary_checks.py").write_text(modified,encoding="utf-8")
        (temp/"test_prompt_boundary_checks.py").write_text(original_tests,encoding="utf-8")
        (temp/"test_p111_git_global_options.py").write_text(TESTS,encoding="utf-8")
        process=subprocess.run([sys.executable,"-B","-m","unittest","discover","-q"],cwd=temp,
                               capture_output=True,timeout=35,text=True,errors="replace")
        outcome={"scope":"TEMPORARY_COPY_ONLY",
                 "candidate_source_modified":False,"live_queue_modified":False,
                 "new_negative_scenarios":5,
                 "exit_code":process.returncode,
                 "stdout_tail":process.stdout[-450:],
                 "stderr_tail":process.stderr[-1300:]}
    print(json.dumps(outcome,ensure_ascii=True))
    return 0 if outcome["exit_code"]==0 else 2
if __name__=="__main__":sys.exit(run())
