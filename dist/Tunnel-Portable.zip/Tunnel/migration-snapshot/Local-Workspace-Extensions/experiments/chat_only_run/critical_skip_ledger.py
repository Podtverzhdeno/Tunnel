"""F02 offline critical-SKIP ledger.

This is an advisory, pure function over caller-supplied evidence. It does not
attest a Windows SID, an MCP grant, a job receipt, or authorize release/merge.
The expected test inventory MUST come from independent canonical policy before
any future integration. No file, SQLite, network, or subprocess side effects.
"""
from __future__ import annotations

import re

TARGET_OSES = frozenset({"windows", "linux", "macos"})
STATUSES = frozenset({"PASS", "FAIL", "SKIP"})
MAX_ROWS = 512
_TEST_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,119}\Z")
_SHA = re.compile(r"[a-f0-9]{64}\Z")


def _result(status, *, reason, missing=(), skipped=(), failed=(), invalid=(),
            checked=0, not_applicable=()):
    """Use bounded identifiers only, never raw logs/skip reasons or secrets."""
    return {
        "schema": "critical-skip-ledger-offline-v1",
        "status": status,
        "reason": reason,
        "checked": checked,
        "missing_critical": sorted(missing),
        "skipped": sorted(skipped),
        "failed": sorted(failed),
        "invalid": sorted(invalid),
        "not_applicable": sorted(not_applicable),
        "advisory_only": True,
        "host_attested": False,
        "release_authorized": False,
    }


def assess_critical_skips(expected, receipts, *, target_os, source_sha256):
    """Classify coverage from explicit expected tests, failing closed on gaps.

    expected: [{test_id, os: windows|linux|macos|any, critical: bool}, ...]
    receipts: [{test_id, os, source_sha256, outcome, skip_reason, job_exit}, ...]
    A noncritical skip is visible but does not block an advisory green result.
    A green result is never host-verified evidence or a release authorization.
    """
    if (type(target_os) is not str or target_os not in TARGET_OSES
            or type(source_sha256) is not str
            or _SHA.fullmatch(source_sha256) is None
            or not isinstance(expected, list) or not isinstance(receipts, list)
            or not (1 <= len(expected) <= MAX_ROWS)
            or len(receipts) > MAX_ROWS):
        return _result("INVALID_INPUT", reason="INVALID_ENVELOPE")
    inventory = {}
    invalid = []
    for index, row in enumerate(expected):
        if (not isinstance(row, dict) or set(row) != {"test_id", "os", "critical"}
                or type(row.get("test_id")) is not str
                or _TEST_ID.fullmatch(row["test_id"]) is None
                or type(row.get("os")) is not str
                or row["os"] not in (TARGET_OSES | {"any"})
                or type(row.get("critical")) is not bool):
            invalid.append(f"expected:{index}")
            continue
        key = row["test_id"]
        if key in inventory:
            invalid.append(f"duplicate_expected:{index}")
        else:
            inventory[key] = row
    if invalid:
        return _result("INVALID_INPUT", reason="INVALID_EXPECTED_INVENTORY",
                       invalid=invalid)

    applicable = {k: v for k, v in inventory.items()
                  if v["os"] in ("any", target_os)}
    other_os = set(inventory) - set(applicable)
    if not any(row["critical"] for row in applicable.values()):
        return _result("INCOMPLETE", reason="NO_APPLICABLE_CRITICAL_TESTS",
                       not_applicable=other_os)

    observed = {}
    for index, row in enumerate(receipts):
        if (not isinstance(row, dict)
                or set(row) != {"test_id", "os", "source_sha256", "outcome",
                                "skip_reason", "job_exit"}
                or type(row.get("test_id")) is not str
                or _TEST_ID.fullmatch(row["test_id"]) is None
                or row.get("os") != target_os
                or type(row.get("source_sha256")) is not str
                or row["source_sha256"] != source_sha256
                or type(row.get("outcome")) is not str
                or row["outcome"] not in STATUSES
                or (row.get("skip_reason") is not None
                    and (type(row["skip_reason"]) is not str
                         or len(row["skip_reason"]) > 256))
                or (row.get("job_exit") is not None
                    and (type(row["job_exit"]) is not int
                         or not -255 <= row["job_exit"] <= 255))):
            invalid.append(f"receipt:{index}")
            continue
        key = row["test_id"]
        if key not in applicable or key in observed:
            invalid.append(f"unexpected_or_duplicate:{index}")
            continue
        observed[key] = row

    missing = [k for k, v in applicable.items() if v["critical"] and k not in observed]
    skipped = []
    failed = []
    unknown = []
    for key, row in observed.items():
        if row["outcome"] == "FAIL" or (
                row["job_exit"] is not None and row["job_exit"] != 0):
            failed.append(key)
        elif row["job_exit"] is None:
            unknown.append(key)
        elif row["outcome"] == "SKIP":
            skipped.append(key)
            if not row["skip_reason"]:
                unknown.append(key)
            elif applicable[key]["critical"]:
                unknown.append(key)
        elif row["skip_reason"]:
            unknown.append(key)

    if failed:
        status, reason = "FAIL", "TEST_FAILURE"
    elif missing or unknown or invalid:
        status, reason = "INCOMPLETE", "CRITICAL_COVERAGE_OR_RECEIPT_GAP"
    else:
        status, reason = "ADVISORY_PASS", "CALLER_SUPPLIED_COVERAGE_ONLY"
    return _result(status, reason=reason, missing=missing, skipped=skipped,
                   failed=failed, invalid=invalid + [f"unknown:{k}" for k in unknown],
                   checked=len(observed), not_applicable=other_os)
