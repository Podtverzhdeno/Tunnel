"""Negative QA, scaling and portfolio tests, fully isolated from live SQLite."""
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

import agent_quality_gate as q
import feature_idea_gate as f

class StrictGatesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.db=self.root/".agent-team"/"team.sqlite3"
        self.db.parent.mkdir(parents=True)
        self.folder=self.root/".agent-team"/"workspaces"/"developer-1"/"P777"
        self.folder.mkdir(parents=True)
        for name,text in {
            "safe_module.py":"def compute(value):\n    if not isinstance(value,int):\n        raise ValueError('bad')\n    return value + 1\n",
            "test_safe_module.py":"def test_one():\n    assert 1 + 1 == 2\n",
        }.items():(self.folder/name).write_text(text,encoding="utf-8")
        with closing(sqlite3.connect(self.db)) as db, db:
            db.execute("""CREATE TABLE tasks(
                task_id TEXT PRIMARY KEY,role_hint TEXT,owner TEXT,status TEXT,
                sandbox TEXT,deliverables TEXT,spec_ref TEXT)""")
            db.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?)",
                ("P777","developer-1","developer-1","working",
                 ".agent-team/workspaces/developer-1/P777",
                 json.dumps(["safe_module.py","test_safe_module.py"]),
                 "openspec/changes/local-pc-agent-tooling/specs/agent-orchestration/spec.md"))
        (self.root/"team_seed.json").write_text('[{"id":"P777"}]',encoding="utf-8")
        p=self.root/"docs"/"FEATURE_PORTFOLIO_V1.json"
        p.parent.mkdir()
        p.write_text(json.dumps({"features":[{"title":"Previously accepted proposal concept"}]}),encoding="utf-8")

    def report(self):
        item=q.read_task("P777",self.db,self.root)
        hashes={x:q.hashlib.sha256((self.folder/x).read_bytes()).hexdigest()
                for x in item["outputs"]}
        data={
            "task_id":"P777","role":"developer-1","file_hashes":hashes,
            "dimensions":{key:{"status":"PASS","evidence":["Reviewed scoped module and negative cases for "+key],
                               "risks":[]} for key in q.SECTIONS},
            "test_runs":[{"kind":name,"command":"python -m unittest discover",
                          "exit_code":0,"result_summary":"All tests passed with no failures",
                          "run_id":"job-12345678"} for name in
                         ("focused","full","spec_check","openspec_strict")],
            "residual_risks":["Low-risk Python stdlib-only module."],
            "architecture_decisions":["Single-purpose pure function and bounded input."]
        }
        return data

    def save(self,data):
        (self.folder/"agent_quality_report.json").write_text(
            json.dumps(data,ensure_ascii=False),encoding="utf-8")

    def test_valid_report_and_safe_ast_allow_policy_pass(self):
        self.save(self.report())
        r=q.audit("P777","developer-1",self.db,self.root)
        self.assertTrue(r["can_submit_according_to_quality_policy"])
        self.assertEqual(r["total_static_findings"],0)

    def test_missing_evidence_is_fail_closed(self):
        self.assertIn("REPORT_MISSING_OR_NOT_OBJECT",q.audit("P777","developer-1",self.db,self.root)["evidence_issues"])

    def test_self_report_sha_mismatch_rejected(self):
        data=self.report()
        data["file_hashes"]["safe_module.py"]="0"*64
        self.save(data)
        self.assertIn("REPORT_SOURCE_HASH_MISMATCH",q.audit("P777","developer-1",self.db,self.root)["evidence_issues"])

    def test_missing_dimensions_and_failed_tests_rejected(self):
        data=self.report()
        del data["dimensions"]["reliability"]
        data["test_runs"][0]["exit_code"]=1
        self.save(data)
        res=q.audit("P777","developer-1",self.db,self.root)
        self.assertIn("DIMENSIONS_NOT_COMPLETE",res["evidence_issues"])
        self.assertIn("TEST_EVIDENCE_INCOMPLETE",res["evidence_issues"])

    def test_wrong_owner_refused(self):
        self.save(self.report())
        with self.assertRaisesRegex(q.GateError,"NOT_TASK_OWNER"):
            q.audit("P777","developer-2",self.db,self.root)

    def test_dangerous_calls_and_shell_true(self):
        problems=q.scan_file("safe_module.py",b"import os\nos.system('rm')\n")
        self.assertTrue(any(x["rule"]=="DANGEROUS_CALL" for x in problems))
        problems=q.scan_file("safe_module.py",b"import subprocess\nsubprocess.run('cmd',shell=True)\n")
        self.assertTrue(any(x["rule"]=="SHELL_TRUE" for x in problems))

    def test_missing_negative_tests_and_bare_exception(self):
        self.assertTrue(any(x["rule"]=="NO_TEST_FUNCTIONS" for x in q.scan_file("test_safe_module.py",b"x=2")))
        self.assertTrue(any(x["rule"]=="SILENT_BROAD_EXCEPTION" for x in q.scan_file(
            "safe_module.py",b"try:\n    x=3\nexcept Exception:\n    pass")))

    def test_secure_symlink_rejected(self):
        # Windows without Developer Mode may disallow symlinks, skip if unavailable.
        path=self.folder/"safe_module.py"
        other=self.root/"other.py"
        other.write_text("x=1")
        path.unlink()
        try:path.symlink_to(other)
        except (OSError,NotImplementedError):self.skipTest("No symlink permission")
        with self.assertRaisesRegex(q.GateError,"UNSAFE_OR_MISSING_FILE"):
            q.audit("P777","developer-1",self.db,self.root)

    def candidate(self,num, title=None):
        title=title or f"Deterministic traceable improvement number {num} for orchestration"
        return {
            "id":f"F{num:02d}","title":title,
            "summary":"A concrete task-specific measurable improvement that reduces operational failures " * 2,
            "related_existing_ids":["MF-011"],
            "failure_scenarios":["Failure mode is bounded, logged, measurable and has a negative test plan." for _ in range(3)],
            "test_strategy":["Execute negative input tests with actual process exit codes and compare SHA." for _ in range(4)],
            "alternatives":["Alternative requires consideration of simpler incremental changes and their costs." for _ in range(2)],
            "score":{n:3 for n in f.SCORES},
            "sections":{k:"Evaluate baseline, constraints, bounded worst cases, implementation details, and a testable outcome. "*4
                        for k in f.SECTIONS},
            "confidence_note":"Confidence is limited to empirical measurements on the existing workspace and history."}
    def portfolio(self,n=10):
        return {"schema":"feature-candidates-v1","role":"developer-1","wave":f.wave(self.root),
                "cycle_reason":"No more available coding tasks or independent peer reviews; proposal wave is ready for the architect.",
                "candidates":[self.candidate(i) for i in range(1,n+1)]}

    def test_ten_unique_features_required(self):
        obj=self.portfolio(10)
        errors,items=f.check_proposal(obj,"developer-1",f.wave(self.root),f.current_existing(self.root))
        self.assertEqual(errors,[])
        self.assertEqual(len(items),10)

    def test_nine_fails_and_twenty_one_fails(self):
        for count in (9,21):
            e,_=f.check_proposal(self.portfolio(count),"developer-1",f.wave(self.root))
            self.assertIn("REQUIRES_BETWEEN_10_AND_20_FEATURES",e)

    def test_duplicate_detected_with_same_title(self):
        obj=self.portfolio()
        obj["candidates"][1]["title"]=obj["candidates"][0]["title"]
        e,_=f.check_proposal(obj,"developer-1",f.wave(self.root))
        self.assertTrue(any("TITLE_DUPLICATE" in x for x in e))

    def test_existing_duplicate_detected(self):
        obj=self.portfolio()
        obj["candidates"][0]["title"]="Previously accepted proposal concept"
        e,_=f.check_proposal(obj,"developer-1",f.wave(self.root),f.current_existing(self.root))
        self.assertTrue(any("TITLE_DUPLICATE_EXISTING" in x for x in e))

    def test_missing_security_or_scaling_detail_rejected(self):
        obj=self.portfolio()
        obj["candidates"][0]["sections"]["scaling_design"]="It scales"
        obj["candidates"][2]["sections"]["security_design"]="secure"
        e,_=f.check_proposal(obj,"developer-1",f.wave(self.root))
        self.assertTrue(any("SCALING" in x.upper() or "scaling_design" in x for x in e))
        self.assertTrue(any("security_design" in x for x in e))

    def test_weak_scenarios_rejected(self):
        obj=self.portfolio()
        obj["candidates"][4]["test_strategy"]=["looks good"]
        e,_=f.check_proposal(obj,"developer-1",f.wave(self.root))
        self.assertTrue(any("TEST_STRATEGY_INSUFFICIENT" in x for x in e))

    def test_wave_changes_only_when_manifest_changes(self):
        one=f.wave(self.root)
        (self.root/"team_seed.json").write_text('[{"id":"P778"}]')
        self.assertNotEqual(one,f.wave(self.root))

    def test_catalog_waits_for_all_roles_and_does_not_mutate(self):
        data=f.catalog(self.root)
        self.assertFalse(data["all_ready"])
        self.assertEqual(data["total_candidates"],0)
        self.assertFalse(data["mutated_live_queue"])

    def test_architect_refuses_unsubmitted_portfolios(self):
        r=f.architect_decisions(self.root)
        self.assertFalse(r["ready"])
        self.assertEqual(r["reason"],"WAIT_FOR_FOUR_STRICTLY_VALIDATED_PORTFOLIOS")

    def all_four(self):
        for role in f.ROLES:
            obj=self.portfolio(10)
            obj["role"]=role
            for x in obj["candidates"]:
                x["title"]=x["title"]+" by "+role
            path=f.proposal_path(role,self.root)
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(json.dumps(obj),encoding="utf-8")

    def decision_rows(self):
        rows=[]
        dims={x:3 for x in f.ARCH_SCORE_FIELDS}
        for role in f.ROLES:
            for num in range(1,11):
                rows.append({"feature_id":role+":F"+f"{num:02d}",
                             "decision":"DEFER",
                             "rationale":"Requires additional baseline measurements, risk experiments and independent comparison before prioritization."*2,
                             "similar_to":[],"risks":["Potential unauthorized writes require a deny-by-default design and independent audit."],
                             "tests_required":["Run controlled negative cases and performance baseline comparison in sandbox."],
                             "dimensions":dims,
                             "weighted_score":f.strict_arch_score(dims)})
        return rows

    def test_full_architect_adjudication_is_planning_only(self):
        self.all_four()
        d=f.catalog(self.root)
        self.assertTrue(d["all_ready"])
        self.assertEqual(d["total_candidates"],40)
        path=self.root/".agent-team"/"feature-proposals"/f.wave(self.root)/"architect_decisions.json"
        path.write_text(json.dumps({
            "schema":"architect-feature-decisions-v1","wave":f.wave(self.root),
            "architecture_summary":"All 40 features need concrete metrics and risk experiments before owner-led spec approval. "
                                   "Deduplication, dependency ordering, impact, feasibility and security are independently considered.",
            "owner_gate_acknowledged":True,"decisions":self.decision_rows()}),encoding="utf-8")
        result=f.architect_decisions(self.root)
        self.assertTrue(result["ready"],result)
        self.assertEqual(result["total_evaluated"],40)
        self.assertFalse(result["formal_spec_approval"])

    def test_architect_rejects_fabricated_score_and_weak_promotion(self):
        self.all_four()
        path=self.root/".agent-team"/"feature-proposals"/f.wave(self.root)/"architect_decisions.json"
        rows=self.decision_rows()
        rows[0]["decision"]="PROMOTE_FOR_OWNER_SPEC_APPROVAL"
        rows[0]["weighted_score"]=100  # Not derived from independent dimensions!
        obj={"schema":"architect-feature-decisions-v1","wave":f.wave(self.root),
             "architecture_summary":"All 40 feature decisions require independent analysis, risk assessment, "
                                    "technical feasibility checks and user-facing owner approvals, never automatic admission.",
             "owner_gate_acknowledged":True,"decisions":rows}
        path.write_text(json.dumps(obj),encoding="utf-8")
        result=f.architect_decisions(self.root)
        self.assertFalse(result["ready"])
        self.assertIn("SCORE_NOT_DERIVED_FROM_INDEPENDENT_RUBRIC",result["errors"])

    def test_architecture_score_bounds_and_no_boolean(self):
        best={"impact":5,"confidence":5,"feasibility":5,"strategic_fit":5,
              "engineering_effort":1,"security_risk":1}
        self.assertEqual(f.strict_arch_score(best),100)
        for field in f.ARCH_SCORE_FIELDS:
            case=dict(best);case[field]=True
            with self.assertRaises(f.IntakeError):
                f.strict_arch_score(case)

    def test_policy_submit_rejects_failed_security_gate_without_calling_submit(self):
        from quality_submit import quality_submit
        calls=[]
        result=quality_submit("developer-1","P777","lease-token",
            "Detailed independent test and security evidence.",
            auditor=lambda task,role:{"can_submit_according_to_quality_policy":False,
                                       "static_findings":[{"rule":"SHELL_TRUE"}],
                                       "evidence_issues":[]},
            submitter=lambda *args:calls.append(args))
        self.assertFalse(result["submitted"])
        self.assertEqual(calls,[])

    def test_policy_submit_calls_coordinator_only_after_green_gate(self):
        from quality_submit import quality_submit
        calls=[]
        good={"can_submit_according_to_quality_policy":True,
              "static_findings":[],"evidence_issues":[]}
        result=quality_submit("developer-1","P777","lease-token",
            "Detailed independent test and security evidence.",
            auditor=lambda task,role:good,
            submitter=lambda *args:calls.append(args) or {"status":"review"})
        self.assertTrue(result["submitted"])
        self.assertEqual(result["coordinator_result"]["status"],"review")
        self.assertEqual(len(calls),1)
        self.assertFalse(result["host_actor_authenticated"])

    def test_policy_submit_rejects_missing_inconsistent_report(self):
        from quality_submit import quality_submit
        result=quality_submit("developer-1","P777","lease-token",
            "Detailed independent test and security evidence.",
            auditor=lambda task,role:{"can_submit_according_to_quality_policy":True,
                                       "static_findings":[],"evidence_issues":["SOURCE_HASH_MISMATCH"]},
            submitter=lambda *args: (_ for _ in ()).throw(AssertionError("should not call submit")))
        self.assertFalse(result["submitted"])

if __name__=="__main__":unittest.main()
