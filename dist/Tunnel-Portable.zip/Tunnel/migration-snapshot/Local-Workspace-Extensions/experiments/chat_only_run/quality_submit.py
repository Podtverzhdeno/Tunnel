"""Cooperative strict developer-submit entrypoint.

Runs static/evidence gate before the existing fenced agent_team.submit.
This is policy-level enforcement for the scheduled role, NOT a host-level
denial of direct access to the legacy command or spoofed actor identity.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Callable
from agent_quality_gate import audit

ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
import agent_team

def quality_submit(role,task_id,token,notes,*,auditor:Callable=audit,submitter:Callable=agent_team.submit):
    if role not in agent_team.DEVELOPERS:raise ValueError("INVALID_ROLE")
    if not isinstance(task_id,str) or not agent_team.TASK_ID.fullmatch(task_id):
        raise ValueError("INVALID_TASK_ID")
    if not isinstance(notes,str) or len(notes.strip())<30:
        raise ValueError("EVIDENCE_NOTES_MISSING")
    result=auditor(task_id,role)
    if (not isinstance(result,dict) or
            result.get("can_submit_according_to_quality_policy") is not True or
            result.get("static_findings") or result.get("evidence_issues")):
        return {"submitted":False,"reason":"QUALITY_GATE_BLOCKED",
                "audit":result if isinstance(result,dict) else {"invalid":"AUDIT_UNAVAILABLE"}}
    # The native coordinator must still verify role, scoped lease, allowed
    # outputs and current baseline under its own SQLite transaction.
    actual=submitter(role,task_id,token,notes)
    return {"submitted":True,"coordinator_result":actual,
            "quality_check":"POLICY_STATIC_AND_UNVERIFIED_EVIDENCE",
            "host_actor_authenticated":False}

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument("role",choices=agent_team.DEVELOPERS)
    p.add_argument("task_id")
    p.add_argument("lease_token")
    p.add_argument("notes")
    args=p.parse_args(argv)
    try:
        out=quality_submit(args.role,args.task_id,args.lease_token,args.notes)
        print(json.dumps({"ok":out.get("submitted") is True,"data":out},ensure_ascii=True))
        return 0 if out["submitted"] else 2
    except (ValueError,agent_team.TeamError,OSError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:200]},ensure_ascii=True))
        return 2

if __name__=="__main__":sys.exit(main())
