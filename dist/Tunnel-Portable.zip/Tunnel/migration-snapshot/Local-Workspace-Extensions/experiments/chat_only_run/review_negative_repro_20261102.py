"""Read-only independent negative repro for unaccepted candidate snapshots.
Only imports two known source modules inspected by reviewer; no writes or network.
Exit 0 means repro successfully observed, NOT that candidates pass QA.
"""
import importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/".agent-team"/"workspaces"
def load(rel,alias):
    path=(DATA/rel).resolve()
    if not path.is_relative_to(DATA.resolve()) or path.is_symlink() or path.stat().st_size>20000:
        raise RuntimeError("UNSAFE_CANDIDATE")
    spec=importlib.util.spec_from_file_location(alias,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
def attempt(name,fn):
    try:
        result=fn()
        return {"case":name,"exception":None,"outcome":str(result)[:200]}
    except BaseException as e:
        return {"case":name,"exception":type(e).__name__,"error_category":"UNHANDLED_BAD_INPUT_EXCEPTION"}
def main():
    metrics=load("developer-4/P127/agent_metrics_series.py","p127_repro")
    rows=[{"role":"developer-4","task_id":"P127","run_id":"run12345678",
          "model":"","timestamp":"2026-11-02T00:00:00Z"}]
    a=attempt("P127_EMPTY_MODEL",lambda:metrics.normalize_metric_series([],expected_runs=rows))
    media=load("developer-4/P131/media_rights_schema.py","p131_repro")
    bad={"assets":[{"asset_id":"asset1","sha256":"a"*64,"source_path":"clip\ud800.mp4",
        "license_category":"CC0","rights_holder":"owner","attribution":None,
        "expires_at":None,"reuse_allowed":True,"verified":False,
        "verification_evidence":None}],
        "scenes":[{"scene_id":"scene01","asset_ids":["asset1"]}]}
    b=attempt("P131_LONE_SURROGATE_SOURCE_PATH",lambda:media.validate_media_rights(bad))
    expected_p131=(b["exception"] is None and "'ok': False" in b.get("outcome","") and
                   "'error': 'INVALID_INPUT'" in b.get("outcome",""))
    out={"probes":[a,b],"p127_bug_reproduced":a["exception"]=="IndexError",
         "p131_unicode_fails_closed":expected_p131,
         "scope":"offline_candidate_sandbox","live_queue_mutated":False,"formal_accept":False,
         "interpretation":"P127 needs a fix and regression; P131 allegation of unhandled UnicodeEncodeError is refuted by observed structured INVALID_INPUT"}
    print(json.dumps(out,ensure_ascii=True))
    return 0 if out["p127_bug_reproduced"] and expected_p131 else 2
if __name__=="__main__":sys.exit(main())
