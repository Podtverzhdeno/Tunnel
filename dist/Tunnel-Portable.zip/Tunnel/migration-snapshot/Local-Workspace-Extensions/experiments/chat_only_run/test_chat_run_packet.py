import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import chat_run_packet as p


def fixture():
    return {
        "as_of_utc": "2026-11-02T00:00:00+00:00",
        "agents": [{"role": "developer-3"}],
        "tasks": [
            {"task_id": "P096", "status": "working", "owner": "developer-3",
             "lease_remaining_minutes": 20, "next_steps": ["Needs review"], "attention": []},
            {"task_id": "P110", "status": "available", "owner": None, "attention": []},
            {"task_id": "P111", "status": "review", "owner": "developer-4", "attention": []},
            {"task_id": "P125", "status": "reviewing", "owner": "developer-2", "attention": []},
        ],
    }


class ChatRunPacketTests(unittest.TestCase):
    def test_developer_plan_skips_stale_owned_task(self):
        calls = []
        def fake(args):
            calls.append(args)
            if args == ["overview"]:
                return fixture()
            return {
                "recommended_task_id": "P110",
                "candidates": [{"task_id": "P110", "status": "available",
                                "blocked_reason": None}],
            }
        result = p.make_packet("developer-3", fake)
        self.assertEqual(result["recommended_available_task_id"], "P110")
        self.assertEqual(result["tasks_owned_unfinished"][0]["task_id"], "P096")
        self.assertFalse(result["authority"]["lease_issued"])
        self.assertEqual(calls, [["overview"], ["plan-work", "developer-3"]])

    def test_no_task_does_not_invent_new_work(self):
        result = p.make_packet("developer-1", lambda args:
            fixture() if args == ["overview"] else
            {"recommended_task_id": None, "candidates": []})
        self.assertIsNone(result["recommended_available_task_id"])
        self.assertIn("Never invent", result["safe_next_action"])

    def test_reviewer_uses_review_queue_without_grant(self):
        def fake(args):
            if args != ["overview"]:
                raise AssertionError("reviewer must never acquire on preflight")
            return fixture()
        result = p.make_packet("architect-reviewer", fake)
        self.assertEqual([x["task_id"] for x in result["review_queue"]], ["P111", "P125"])
        self.assertFalse(result["authority"]["approval_granted"])
        self.assertNotIn("recommended_available_task_id", result)

    def test_refuse_unknown_role(self):
        with self.assertRaises(ValueError):
            p.make_packet("owner", lambda _: fixture())

    def test_no_lease_token_disclosure(self):
        data = fixture()
        data["tasks"][0]["lease_token"] = "DO_NOT_SHOW"
        data["tasks"][0]["secret"] = "PASSWORD"
        result = p.make_packet("developer-3", lambda args:
            data if args == ["overview"] else
            {"recommended_task_id": "P110", "candidates": []})
        text = json.dumps(result)
        self.assertNotIn("DO_NOT_SHOW", text)
        self.assertNotIn("PASSWORD", text)

    def test_malformed_recommendation_fails_closed(self):
        with self.assertRaises(p.SnapshotError):
            p.make_packet("developer-3", lambda args: fixture() if args == ["overview"]
                          else {"recommended_task_id": "../../evil", "candidates": []})

    def test_missing_task_array_rejected(self):
        with self.assertRaises(p.SnapshotError):
            p.make_packet("developer-3", lambda args: {"agents": []})

    def test_coordinator_parses_healthy_cli(self):
        result = SimpleNamespace(returncode=0,
                                 stdout=json.dumps({"ok": True, "data": fixture()}))
        out = p.coordinator(["plan-work", "developer-3"], runner=lambda command, **kwargs: result)
        self.assertEqual(len(out["tasks"]), 4)

    def test_coordinator_rejects_error_and_shell_is_off(self):
        def fake(command, **kwargs):
            self.assertFalse(kwargs["shell"])
            self.assertEqual(command[1].split("\\")[-1].split("/")[-1], "agent_team.py")
            return SimpleNamespace(returncode=1, stdout='{"ok":false}')
        with self.assertRaises(p.SnapshotError):
            p.coordinator(["plan-work", "developer-3"], runner=fake)

    def test_mutating_coordinator_commands_are_rejected_before_subprocess(self):
        def forbidden(*_args, **_kwargs):
            raise AssertionError("must never invoke subprocess for unsafe command")
        for args in (["acquire", "developer-1"], ["review", "P110"],
                     ["overview"], ["plan-work", "architect-reviewer"]):
            with self.subTest(args=args), self.assertRaisesRegex(p.SnapshotError, "READ_ONLY_PLAN_WORK_ONLY"):
                p.coordinator(list(args), runner=forbidden)

    def test_cli_output_does_not_expose_raw_notes(self):
        result = p.make_packet("developer-3", lambda args:
            fixture() if args == ["overview"] else
            {"recommended_task_id": "P110", "candidates": []})
        self.assertEqual(result["mode"], "read_only_chat_launch_packet")
        self.assertFalse(result["authority"]["production_queue_mutated"])


if __name__ == "__main__":
    unittest.main()
