"""Generate reviewable offline diffs from isolated rework copies.

Read-only against live queue/sandboxes. Never applies patches, marks accepted,
changes authorization or touches canonical sources.
"""
from __future__ import annotations
import difflib
import hashlib
import json
import re
import sqlite3
from contextlib import closing
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
STAGING=ROOT/"experiments"/"rework-staging"
REPORT=ROOT/".agent-team"/"reports"/"rework_patch_review_2026-11-02"
TASKS=("P108","P110","P111","P127","P131","P148","P149")
def sha(b):return hashlib.sha256(b).hexdigest()

def report():
    if REPORT.exists() and list(REPORT.iterdir()):
        raise ValueError("REPORT_ALREADY_EXISTS_DO_NOT_OVERWRITE")
    with closing(sqlite3.connect(
        (ROOT/".agent-team"/"team.sqlite3").resolve().as_uri()+"?mode=ro",uri=True)) as db:
        db.row_factory=sqlite3.Row
        data={}
        for tid in TASKS:
            row=db.execute("SELECT task_id,status,sandbox,owner,deliverables FROM tasks WHERE task_id=?",(tid,)).fetchone()
            if not row or row["status"] not in ("review","reviewing"):
                raise ValueError("TASK_STATE_CHANGED:"+tid)
            data[tid]=dict(row)
    staged=[]
    bundles={}
    for tid,row in data.items():
        original=(ROOT/row["sandbox"]).resolve()
        if not original.is_relative_to((ROOT/".agent-team"/"workspaces").resolve()):
            raise ValueError("ORIGINAL_SCOPE_DRIFT")
        folder=STAGING/tid
        meta=json.loads((folder/"candidate_provenance.json").read_text("utf-8"))
        diffs=[]
        hashes=[]
        for name in json.loads(row["deliverables"]):
            before=original/name
            after=folder/name
            if before.is_symlink() or after.is_symlink() or not before.is_file() or not after.is_file():
                raise ValueError("UNSAFE_FILE:"+tid)
            raw=before.read_bytes()
            new=after.read_bytes()
            if sha(raw)!=meta["source_sha256"][name]:
                raise ValueError("ORIGINAL_DRIFT:"+tid+":"+name)
            if name.startswith("test_"):
                continue  # unchanged original tests included in staging
            old=raw.decode("utf-8").splitlines(keepends=True)
            now=new.decode("utf-8").splitlines(keepends=True)
            delta="".join(difflib.unified_diff(
                old,now,fromfile="a/"+name,tofile="b/"+name,n=4))
            if not delta:raise ValueError("NO_PATCH_FOR_TASK:"+tid)
            diffs.append(delta)
            hashes.append({"file":name,"original_sha256":sha(raw),"proposed_sha256":sha(new),
                           "proposed_bytes":len(new)})
        testfile=folder/"test_rework_regressions.py"
        if not testfile.is_file() or testfile.is_symlink():raise ValueError("MISSING_REGRESSION")
        regression=testfile.read_text("utf-8")
        if "class ReworkRegression" not in regression:
            raise ValueError("NOT_A_REGRESSION")
        newfile="".join(difflib.unified_diff([],
            [x+"\n" for x in regression.splitlines()],
            fromfile="/dev/null",tofile="b/test_rework_regressions.py",n=4))
        patch="\n".join(diffs+[newfile])
        bundles[tid]=patch
        staged.append({"task_id":tid,"original_owner":row["owner"],
                       "changes":hashes,"regression_sha256":sha(regression.encode("utf-8")),
                       "patch_sha256":sha(patch.encode("utf-8")),
                       "staging":str(folder.relative_to(ROOT)).replace("\\","/"),
                       "policy":"PROPOSAL_ONLY_REQUIRES_AUTHORIZED_REWORK_LEASE"})
    REPORT.mkdir(parents=True,exist_ok=True)
    for tid,patch in bundles.items():
        (REPORT/(tid+".patch")).write_text(patch,encoding="utf-8")
    index={"schema":"offline-rework-patch-report-v1",
           "not_an_acceptance":True,"live_queue_changed":False,
           "trusted_host_grant_present":False,
           "rework_requires_rejection_and_fresh_owner_lease":True,
           "items":staged}
    (REPORT/"index.json").write_text(json.dumps(index,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return {"count":len(staged),"report_directory":str(REPORT.relative_to(ROOT)).replace("\\","/"),
            "patches":[x["task_id"] for x in staged],
            "all_original_source_hashes_match":True,
            "advisory_only":True}

if __name__=="__main__":
    try:
        print(json.dumps({"ok":True,"data":report()},ensure_ascii=True))
    except (OSError,ValueError,json.JSONDecodeError,sqlite3.Error) as exc:
        print(json.dumps({"ok":False,"error":str(exc)[:200]},ensure_ascii=True))
        raise SystemExit(2)
