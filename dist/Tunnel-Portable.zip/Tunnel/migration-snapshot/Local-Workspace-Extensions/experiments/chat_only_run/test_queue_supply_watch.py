"""Read-only, role-scoped admission watch unit tests. No live queue writes."""
import unittest

from queue_supply_watch import summarize, reconcile_admission_preview

ROLES=("developer-1","developer-2","developer-3","developer-4")


def fixture():
    tasks={}
    ready=[]
    blocked=[]
    for i,role in enumerate(ROLES):
        tasks[f"P{150+i}"]={"status":"available","role_hint":role}
        ready += [{"id":f"P{154+i}","role":role},{"id":f"P{158+i}","role":role}]
        blocked += [{"id":f"P{162+i}","role":role,
                     "blockers":["ROLE_READY_BUFFER_FULL"]}]
    supply={"mode":"READ_ONLY_ADMISSION_PROPOSAL","ready":ready,
            "blocked":blocked,"queue_mutated":False,
            "owner_approval_granted":False}
    return tasks,supply


class WatchTests(unittest.TestCase):
    def test_four_role_reserve_triggers_approval(self):
        tasks,p=fixture()
        result=summarize(tasks,p)
        self.assertEqual(result["total_live_ready"],4)
        self.assertEqual(result["total_ready_for_owner_review"],8)
        self.assertEqual(result["total_future_blocked"],4)
        self.assertEqual(set(result["admission_required_roles"]),set(ROLES))
        self.assertEqual(result["exhausted_roles"],[])
        self.assertFalse(result["owner_approval_granted"])
        for role in ROLES:
            self.assertEqual(result["roles"][role]["projected_ready_after_foreground_admission"],3)
            self.assertFalse(result["roles"][role]["guaranteed_future_work"])

    def test_no_candidates_is_not_success(self):
        tasks,p=fixture()
        p["ready"]=[]
        p["blocked"]=[]
        result=summarize(tasks,p)
        self.assertEqual(set(result["exhausted_roles"]),set(ROLES))
        self.assertEqual(result["total_ready_for_owner_review"],0)

    def test_approved_candidates_are_not_double_counted_as_future_buffer(self):
        tasks,p=fixture()
        p["ready"]=[]
        for item in list(p["blocked"]):
            p["blocked"].append({"id":"P199-"+item["role"],"role":item["role"],
                                 "blockers":["ALREADY_IN_LIVE_QUEUE",
                                             "CONFLICT_WITH_ACTIVE_OUTPUT",
                                             "ROLE_READY_BUFFER_FULL"]})
        result=summarize(tasks,p)
        self.assertEqual(result["total_already_admitted_candidate_ids"],4)
        self.assertEqual(result["total_future_blocked"],4)
        for role in ROLES:
            self.assertEqual(result["roles"][role]["already_admitted_in_candidate_manifest"],1)
            self.assertEqual(result["roles"][role]["future_proposals_pending_capacity_or_qa"],1)
            self.assertNotIn("ALREADY_IN_LIVE_QUEUE",
                             result["roles"][role]["blocked_reasons"])

    def test_post_admission_pool_has_no_fictitious_next_wave(self):
        tasks,p=fixture()
        p["ready"]=[]
        p["blocked"]=[]
        for i,role in enumerate(ROLES):
            for k in range(2):
                tasks[f"P{154+i+4*k}"]={"status":"available","role_hint":role}
                p["blocked"].append({"id":f"P{154+i+4*k}","role":role,
                                    "blockers":["ALREADY_IN_LIVE_QUEUE","ROLE_READY_BUFFER_FULL"]})
        result=summarize(tasks,p)
        self.assertEqual(result["total_live_ready"],12)
        self.assertEqual(result["total_future_blocked"],0)
        self.assertEqual(result["total_already_admitted_candidate_ids"],8)
        self.assertEqual(result["admission_required_roles"],[])

    def test_live_buffer_above_threshold_is_healthy(self):
        tasks,p=fixture()
        p["ready"]=[]
        for i,role in enumerate(ROLES):
            tasks[f"P{190+i}"]={"status":"available","role_hint":role}
        result=summarize(tasks,p)
        self.assertEqual(result["admission_required_roles"],[])
        self.assertEqual(result["exhausted_roles"],[])

    def test_blocked_old_work_is_not_ready(self):
        tasks,p=fixture()
        tasks["P096"]={"status":"working","role_hint":"developer-3",
                      "blocked_reason":"SOURCE_DRIFT_REQUIRES_REBASE"}
        result=summarize(tasks,p)
        self.assertEqual(result["roles"]["developer-3"]["live_ready"],1)
        self.assertEqual(result["roles"]["developer-3"]["live_working_not_necessarily_leased"],1)

    def test_mcp_or_candidate_claimed_approval_is_rejected(self):
        tasks,p=fixture()
        p["owner_approval_granted"]=True
        with self.assertRaises(ValueError):
            summarize(tasks,p)

    def test_sdd_unmapped_candidate_is_not_reported_as_admissible(self):
        states, supply=fixture()
        supply["ready"]=[{"id":"P163","role":"developer-2"}]
        supply["blocked"]=[]
        preview={"mode":"OWNER_FOREGROUND_APPROVAL_REQUIRED",
                 "preview_only":True,"mutated":False,"ready_ids":[],
                 "blocked":[{"id":"P163","status":"BLOCKED",
                             "blockers":["SDD_AUTHORITY:SDD_ROADMAP_UNMAPPED_P163"]}]}
        filtered=reconcile_admission_preview(supply,preview)
        result=summarize(states,filtered)
        self.assertEqual(result["total_ready_for_owner_review"],0)
        self.assertIn("developer-2",result["exhausted_roles"])
        self.assertIn("SDD_AUTHORITY:SDD_ROADMAP_UNMAPPED_P163",
                      result["roles"]["developer-2"]["blocked_reasons"])
        self.assertFalse(result["owner_approval_granted"])

    def test_admission_only_retains_exact_approved_preview_subset(self):
        _,supply=fixture()
        preview={"mode":"OWNER_FOREGROUND_APPROVAL_REQUIRED",
                 "preview_only":True,"mutated":False,
                 "ready_ids":["P154"],"blocked":[]}
        filtered=reconcile_admission_preview(supply,preview)
        self.assertEqual([x["id"] for x in filtered["ready"]],["P154"])
        self.assertEqual(len(filtered["blocked"]),11)
        self.assertEqual(len(supply["ready"]),8)  # Caller snapshot unchanged.
        self.assertTrue(all(x.get("status")=="BLOCKED" for x in filtered["blocked"][4:]))

    def test_untrusted_or_stale_admission_preview_fails_closed(self):
        _,supply=fixture()
        valid={"mode":"OWNER_FOREGROUND_APPROVAL_REQUIRED",
               "preview_only":True,"mutated":False,"ready_ids":[],"blocked":[]}
        for changed in ({"mutated":True}, {"preview_only":False},
                        {"ready_ids":["P999"]},
                        {"ready_ids":["P154","P154"]},
                        {"blocked":[{"id":"P163","blockers":"not-a-list"}]}):
            with self.subTest(changed=changed):
                with self.assertRaises(ValueError):
                    reconcile_admission_preview(supply,{**valid,**changed})

    def test_no_extra_over_cap(self):
        tasks,p=fixture()
        p["ready"].append({"id":"P199","role":"developer-1"})
        with self.assertRaises(ValueError):
            summarize(tasks,p)

    def test_invalid_thresholds(self):
        tasks,p=fixture()
        for values in ((0,3),(2,4),(3,2),(True,3)):
            with self.assertRaises(ValueError):
                summarize(tasks,p,minimum_ready=values[0],target_ready=values[1])


if __name__=="__main__":
    unittest.main()
