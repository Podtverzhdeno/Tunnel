"""Isolated peer switch / no-self-review / lease / evidence regression tests."""
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

from peer_review_switch import (
    PeerError, claim, complete, eligible, exclusions, fingerprint, get_live,
    open_peer, plan, validate_report
)

TIME=datetime(2026,11,2,tzinfo=timezone.utc)

class PeerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.main=self.root/".agent-team"/"team.sqlite3"
        self.main.parent.mkdir()
        self.side=self.root/".agent-team"/"peer.sqlite3"
        self.spec="openspec/changes/local-pc-agent-tooling/specs/agent-orchestration/spec.md"
        f=self.root/self.spec
        f.parent.mkdir(parents=True)
        f.write_text("### Requirement: Task decomposition\n",encoding="utf-8")
        self.add_task("P116","developer-1")
        self.add_task("P148","developer-2")
        self.add_task("P149","developer-3")
        self.add_task("P127","developer-4")

    def add_task(self,tid,role,status="review",revision=1):
        d=self.root/".agent-team"/"workspaces"/role/tid
        d.mkdir(parents=True,exist_ok=True)
        names=[f"peer_{tid.lower()}.py",f"test_peer_{tid.lower()}.py"]
        for n in names:(d/n).write_text("print('safe')\n",encoding="utf-8")
        with closing(sqlite3.connect(self.main)) as db, db:
            db.executescript("""CREATE TABLE IF NOT EXISTS tasks(
                task_id TEXT PRIMARY KEY,status TEXT,owner TEXT,role_hint TEXT,
                sandbox TEXT,deliverables TEXT,spec_ref TEXT,revision INT,
                submitted_at TEXT,review_until TEXT);
                CREATE TABLE IF NOT EXISTS events(
                task_id TEXT,role TEXT,action TEXT);""")
            db.execute("INSERT OR REPLACE INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (tid,status,role,role,str(d.relative_to(self.root)).replace("\\","/"),
                        json.dumps(names),self.spec+" / Task decomposition",revision,
                        "2026-11-01T23:10:00+00:00",None))
            db.execute("INSERT INTO events VALUES(?,?,?)",(tid,role,"submit"))

    def routing(self,role,after=False,code=None):
        return plan(role,after,main=self.main,peer=self.side,project=self.root,
                    code_plan=lambda _:code,now=TIME)

    def claiming(self,role,tid,after=False,code=None,rid="request-001"):
        return claim(role,tid,rid,after_code=after,main=self.main,peer=self.side,
                     project=self.root,code_plan=lambda _:code,now=TIME)

    def save_report(self,role,tid):
        location=self.root/".agent-team"/"peer-review-packets"/role
        location.mkdir(parents=True,exist_ok=True)
        (location/(tid+".json")).write_text(json.dumps({
            "task_id":tid,"peer_role":role,"verdict":"CHANGES_REQUESTED",
            "summary":"Read-only review found concrete missing negative assertions in the task.",
            "findings":["Potential issue in one negative branch should be covered with a regression fixture."],
            "checks":["Focused unittest: 12 passed exit_code=0, independent as reported by reviewer."]
        }),encoding="utf-8")

    def completing(self,role,tid,token):
        return complete(role,tid,token,main=self.main,peer=self.side,project=self.root,now=TIME+timedelta(minutes=5))

    def test_code_first_peer_after_code_then_back_to_code(self):
        a=self.routing("developer-2",code="P200")
        self.assertEqual(a["mode"],"coding")
        b=self.routing("developer-2",after=True,code="P200")
        self.assertEqual(b["mode"],"peer_review")
        self.assertIn(b["recommended_peer_task"],("P116","P149","P127"))
        c=self.claiming("developer-2","P116",after=True,code="P200")
        self.save_report("developer-2","P116")
        done=self.completing("developer-2","P116",c["peer_token"])
        self.assertFalse(done["formal_accept"])
        again=self.routing("developer-2",code="P200")
        self.assertEqual(again["mode"],"coding")

    def test_self_review_forbidden_at_plan_and_claim(self):
        self.assertNotIn("P116",self.routing("developer-1")["peer_candidates"])
        with self.assertRaisesRegex(PeerError,"NOT_ELIGIBLE"):
            self.claiming("developer-1","P116")

    def test_shared_chat_d3_d4_exclude_both(self):
        for role in ("developer-3","developer-4"):
            p=self.routing(role)
            self.assertNotIn("P149",p["peer_candidates"])
            self.assertNotIn("P127",p["peer_candidates"])
            for tid in ("P149","P127"):
                with self.assertRaisesRegex(PeerError,"NOT_ELIGIBLE"):
                    self.claiming(role,tid)
        self.assertEqual(exclusions("developer-3"),{"developer-3","developer-4"})

    def test_foreign_owner_and_historical_contributor(self):
        with closing(sqlite3.connect(self.main)) as db, db:
            db.execute("INSERT INTO events VALUES(?,?,?)",("P116","developer-2","checkpoint"))
        self.assertNotIn("P116",self.routing("developer-2")["peer_candidates"])

    def test_claim_in_one_role_prevents_duplicate(self):
        c=self.claiming("developer-2","P116")
        with self.assertRaisesRegex(PeerError,"NOT_ELIGIBLE"):
            self.claiming("developer-3","P116",rid="request-002")
        self.assertTrue(c["peer_token"])

    def test_claim_code_priority(self):
        with self.assertRaisesRegex(PeerError,"CODING_TASK_HAS_PRIORITY"):
            self.claiming("developer-2","P116",code="P999")

    def test_request_reuse_other_task_fails(self):
        self.claiming("developer-2","P116")
        with self.assertRaisesRegex(PeerError,"REQUEST_ALREADY_BOUND"):
            self.claiming("developer-2","P149")

    def test_stale_lease_expires_and_others_claim(self):
        c=self.claiming("developer-2","P116")
        x=claim("developer-3","P116","request-123",main=self.main,peer=self.side,project=self.root,
                code_plan=lambda _:None,now=TIME+timedelta(minutes=46))
        self.assertNotEqual(x["peer_token"],c["peer_token"])
        self.save_report("developer-2","P116")
        with self.assertRaisesRegex(PeerError,"MISSING"):
            self.completing("developer-2","P116",c["peer_token"])

    def test_invalid_token_refused(self):
        self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        with self.assertRaisesRegex(PeerError,"INVALID"):
            self.completing("developer-2","P116","fake")

    def test_pending_task_cannot_complete(self):
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        with closing(sqlite3.connect(self.main)) as db, db:
            db.execute("UPDATE tasks SET status='rework' WHERE task_id='P116'")
        with self.assertRaisesRegex(PeerError,"NOT_IN_REVIEW"):
            self.completing("developer-2","P116",c["peer_token"])

    def test_changed_task_source_blocks_completion(self):
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        path=self.root/".agent-team"/"workspaces"/"developer-1"/"P116"/"peer_p116.py"
        path.write_text("changed",encoding="utf-8")
        with self.assertRaisesRegex(PeerError,"SOURCE_CHANGED"):
            self.completing("developer-2","P116",c["peer_token"])

    def test_malformed_report_rejected(self):
        c=self.claiming("developer-2","P116")
        path=self.root/".agent-team"/"peer-review-packets"/"developer-2"
        path.mkdir(parents=True)
        (path/"P116.json").write_text('{"verdict":"READY_FOR_ARCHITECT"}')
        with self.assertRaisesRegex(PeerError,"REPORT_SCHEMA"):
            self.completing("developer-2","P116",c["peer_token"])

    def test_completed_has_explicit_advisory_record_only(self):
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        r=self.completing("developer-2","P116",c["peer_token"])
        self.assertEqual(r["status"],"advisory_review_completed")
        self.assertEqual(get_live(self.main)[0]["P116"]["status"],"review")
        with closing(open_peer(self.side)) as db:
            row=db.execute("SELECT status,verdict FROM peer_reviews WHERE task_id='P116'").fetchone()
            self.assertEqual(tuple(row),("completed","CHANGES_REQUESTED"))

    def test_no_self_review_if_owner_changes_during_claim(self):
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        with closing(sqlite3.connect(self.main)) as db, db:
            db.execute("INSERT INTO events VALUES(?,?,?)",("P116","developer-2","acquire"))
        with self.assertRaisesRegex(PeerError,"SELF_REVIEW"):
            self.completing("developer-2","P116",c["peer_token"])

    def test_tampered_spec_digest_rejected(self):
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        (self.root/self.spec).write_text("CHANGED")
        with self.assertRaisesRegex(PeerError,"SOURCE_CHANGED"):
            self.completing("developer-2","P116",c["peer_token"])

    def test_active_architect_reviewing_task_skipped(self):
        with closing(sqlite3.connect(self.main)) as db, db:
            db.execute("UPDATE tasks SET status='reviewing', review_until=? WHERE task_id='P116'",
                       ((TIME+timedelta(minutes=8)).isoformat(),))
        self.assertNotIn("P116",self.routing("developer-2")["peer_candidates"])

    def test_revision_change_reopens_peer_review_without_forging_accept(self):
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        self.completing("developer-2","P116",c["peer_token"])
        self.assertNotIn("P116",self.routing("developer-3")["peer_candidates"])
        with closing(sqlite3.connect(self.main)) as db, db:
            db.execute("UPDATE tasks SET revision=revision+1,submitted_at=? WHERE task_id='P116'",
                       ("2026-11-02T00:05:00+00:00",))
        self.assertIn("P116",self.routing("developer-3")["peer_candidates"])
        new=self.claiming("developer-3","P116",rid="fresh-request-002")
        self.assertNotEqual(new["peer_token"],c["peer_token"])

    def test_overview_tracks_advisory_report_integrity(self):
        from peer_review_switch import overview
        c=self.claiming("developer-2","P116")
        self.save_report("developer-2","P116")
        self.completing("developer-2","P116",c["peer_token"])
        data=overview(self.side,self.root)
        self.assertEqual(data["formal_accepts"],0)
        self.assertTrue(data["reviews"][0]["report_matches"])
        note=self.root/".agent-team"/"peer-review-packets"/"developer-2"/"P116.json"
        note.write_text(note.read_text(encoding="utf-8")+" ",encoding="utf-8")
        data2=overview(self.side,self.root)
        self.assertFalse(data2["reviews"][0]["report_matches"])

if __name__=="__main__":unittest.main()
