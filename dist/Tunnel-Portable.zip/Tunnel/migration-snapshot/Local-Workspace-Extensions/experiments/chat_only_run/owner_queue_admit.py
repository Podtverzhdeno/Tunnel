"""Owner-only foreground admission of QA-backed, canonically specified task reserve.

Default: read-only preview. Apply REQUIRES a genuine local interactive terminal,
exact plan digest + typed confirmation, and rechecked live state. This is not a
substitute for host-authenticated MCP grants or independent integration review.
Never invoke --apply from an MCP scheduled chat.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import sys
import tempfile
import sqlite3
from contextlib import closing
from pathlib import Path

from queue_supply_plan import CANDIDATES, DB, ROOT, SupplyError, load_candidates, read_live_state, plan
from agent_responsibility_guard import validate_contract, check_ownership, ResponsibilityError

SEED=ROOT/"team_seed.json"
ROADMAP=ROOT/"specs"/"001-local-pc-agent-tooling"/"roadmap_tasks.json"
REPORTS=ROOT/".agent-team"/"reports"
# Cap is enforced by queue_supply_plan (1..3); include all live available
# tasks in the count. Never admit beyond three ready coding tasks per role.
READY_BUFFER_CAP=3


def sha(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()


def require_admitted_roadmap_contract(candidates):
    """Fail closed BEFORE owner confirmation if approved SDD cannot execute tickets.

    No automatic roadmap generation, queue writes or owner-approval bypass.
    """
    if not candidates:
        return
    if (not ROADMAP.is_file() or ROADMAP.is_symlink()
            or getattr(ROADMAP, "is_junction", lambda: False)()
            or ROADMAP.stat().st_size > 256 * 1024):
        raise SupplyError("SDD_ROADMAP_MISSING_OR_UNSAFE")
    try:
        doc=json.loads(ROADMAP.read_text(encoding="utf-8"))
    except (ValueError,UnicodeError,OSError) as exc:
        raise SupplyError("SDD_ROADMAP_INVALID") from exc
    rows=doc.get("tasks") if isinstance(doc,dict) else None
    if not isinstance(rows,list) or len(rows)>150:
        raise SupplyError("SDD_ROADMAP_SCHEMA_INVALID")
    by_id={}
    for row in rows:
        if not isinstance(row,dict) or not isinstance(row.get("id"),str):
            raise SupplyError("SDD_ROADMAP_ROW_INVALID")
        if row["id"] in by_id:
            raise SupplyError("SDD_ROADMAP_DUPLICATE")
        by_id[row["id"]]=row
    for item in candidates:
        tid=item["id"]
        mapped=by_id.get(tid)
        if mapped is None:
            raise SupplyError("SDD_ROADMAP_UNMAPPED_" + tid)
        if (mapped.get("admission") != "qa_validated_owner_gate"
                or mapped.get("spec_status") != "canonical_existing"
                or mapped.get("production_host_authorized") is not False
                or mapped.get("review_required") is not True
                or any(mapped.get(key)!=item.get(key) for key in (
                    "role_hint","priority","spec_ref","deliverables","depends_on"))):
            raise SupplyError("SDD_ROADMAP_CONTRACT_DRIFT_" + tid)


def candidate_preview():
    for f in (SEED,CANDIDATES):
        if f.is_symlink() or getattr(f,"is_junction",lambda:False)() or not f.is_file():
            raise SupplyError("unsafe main manifest")
    existing_bytes=SEED.read_bytes()
    candidate_bytes=CANDIDATES.read_bytes()
    if len(existing_bytes)>256*1024 or len(candidate_bytes)>65536:
        raise SupplyError("manifest too large")
    existing=json.loads(existing_bytes)
    if not isinstance(existing,list) or len(existing)>450:
        raise SupplyError("malformed or too many seeded tasks")
    items=load_candidates()
    state,trust=read_live_state()
    result=plan(items,state,trust,limit_per_role=READY_BUFFER_CAP)
    ready_ids={row["id"] for row in result["ready"]}
    contract_blocked=[]
    seen_ids=set()
    seen_modules=set()
    # Prevent a typed owner confirmation for a plan that the authoritative
    # SQLite ownership gate would reject immediately after approval.
    try:
        with closing(sqlite3.connect(DB.resolve().as_uri()+"?mode=ro",
                                     uri=True,timeout=5)) as guard_db:
            guard_db.row_factory=sqlite3.Row
            for item in items:
                if item["id"] not in ready_ids:
                    continue
                try:
                    contract=validate_contract(item.get("responsibility"),
                                               set(item["deliverables"]))
                    check_ownership(guard_db,item["id"],contract)
                    if contract["role"]=="owner":
                        if (contract["id"] in seen_ids or
                                contract["module"] in seen_modules):
                            raise ResponsibilityError("DUPLICATE_PROPOSED_OWNER")
                except ResponsibilityError as exc:
                    ready_ids.remove(item["id"])
                    contract_blocked.append({
                        "id":item["id"],"status":"BLOCKED",
                        "blockers":["RESPONSIBILITY_GUARD:"+str(exc)[:80]]
                    })
                else:
                    if contract["role"]=="owner":
                        seen_ids.add(contract["id"])
                        seen_modules.add(contract["module"])
    except (sqlite3.Error,OSError) as exc:
        raise SupplyError("RESPONSIBILITY_REGISTRY_UNAVAILABLE") from exc
    # Roadmap authority is a separate gate. Unmapped proposed tasks remain
    # visible as blocked, rather than aborting the entire read-only preview
    # or asking the owner to approve a plan that cannot be admitted.
    for item in items:
        if item["id"] not in ready_ids:
            continue
        try:
            require_admitted_roadmap_contract([item])
        except SupplyError as exc:
            ready_ids.remove(item["id"])
            contract_blocked.append({
                "id":item["id"],"status":"BLOCKED",
                "blockers":["SDD_AUTHORITY:"+str(exc)[:96]]
            })
    accepted=[{**{k:item[k] for k in ("id","title","role_hint","spec_ref","deliverables","instructions","priority")},
                "responsibility":item["responsibility"]}
              for item in items if item["id"] in ready_ids]
    ids=[a.get("id") for a in existing]
    if len(ids)!=len(set(ids)) or any(i in ids for i in ready_ids):
        raise SupplyError("existing seed conflicts")
    proposed=existing+accepted
    data=(json.dumps(proposed,ensure_ascii=False,indent=2)+"\n").encode("utf-8")
    if len(data)>256*1024:
        raise SupplyError("queue snapshot too large")
    integrity=sha(data)
    roadmap_digest=sha(ROADMAP.read_bytes()) if ready_ids else None
    candidate_digest=sha(candidate_bytes)
    # Bind the typed owner confirmation to the exact normalized seed
    # AND the reviewed source bytes of the candidate pool and SDD mapping.
    # Legacy empty preview remains deterministic; no owner action is possible.
    plan_id=(hashlib.sha256(data+bytes.fromhex(roadmap_digest)
                           +bytes.fromhex(candidate_digest)).hexdigest()[:16]
             if ready_ids else integrity[:16])
    return {"mode":"OWNER_FOREGROUND_APPROVAL_REQUIRED",
            "ready_ids":sorted(ready_ids),
            "blocked":result["blocked"]+contract_blocked,
            "old_seed_sha256":sha(existing_bytes),
            "candidate_pool_sha256":candidate_digest,
            "roadmap_sha256":roadmap_digest,
            "new_seed_sha256":integrity,
            "plan_id":plan_id,
            "preview_only":True,
            "mutated":False},data


def assert_foreground_owner(*, stdin=None, stdout=None):
    source=stdin or sys.stdin
    target=stdout or sys.stdout
    if not source.isatty() or not target.isatty():
        raise SupplyError("FOREGROUND_INTERACTIVE_OWNER_TERMINAL_REQUIRED")


def atomic_create(path:Path,data:bytes):
    flags=os.O_CREAT|os.O_EXCL|os.O_WRONLY
    fd=os.open(path,flags,0o600)
    try:
        with os.fdopen(fd,"wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
    except BaseException:
        # Leave potentially interrupted receipt for manual inspection.
        raise


def apply_plan(expected_id:str, source_input=input):
    assert_foreground_owner()
    view,serialized=candidate_preview()
    if not view["ready_ids"]:
        raise SupplyError("no QA-backed candidate ready")
    if view["plan_id"]!=expected_id:
        raise SupplyError("plan digest changed, run --preview again")
    phrase="ADMIT "+view["plan_id"]
    print("QUEUE OWNER APPROVAL — scope:",", ".join(view["ready_ids"]))
    print("Expected main-seed SHA256:",view["old_seed_sha256"])
    print("Resulting main-seed SHA256:",view["new_seed_sha256"])
    if source_input("Type exactly "+phrase+": ").strip()!=phrase:
        raise SupplyError("owner declined")
    REPORTS.mkdir(parents=True,exist_ok=True)
    marker=REPORTS/("queue_admission_"+view["plan_id"]+".pending")
    if marker.exists():
        raise SupplyError("prior admission incomplete; manual reconciliation needed")
    # No state-changing action before explicit confirmation and exclusive marker.
    atomic_create(marker,(json.dumps(view)+"\n").encode("utf-8"))
    try:
        # Recheck preconditions after human input. No attempt to override external changes.
        refreshed,_=candidate_preview()
        if (refreshed["new_seed_sha256"]!=view["new_seed_sha256"]
                or refreshed["candidate_pool_sha256"]!=view["candidate_pool_sha256"]
                or refreshed["roadmap_sha256"]!=view["roadmap_sha256"]
                or sha(SEED.read_bytes())!=view["old_seed_sha256"]):
            raise SupplyError("live queue, roadmap or project changed; manual reconciliation required")
        backup=REPORTS/("queue_seed_backup_"+view["plan_id"]+".json")
        atomic_create(backup,SEED.read_bytes())
        fd,temp=tempfile.mkstemp(prefix=".team-seed-pending-",suffix=".json",dir=ROOT)
        try:
            with os.fdopen(fd,"wb") as f:
                f.write(serialized);f.flush();os.fsync(f.fileno())
            if sha(SEED.read_bytes())!=view["old_seed_sha256"]:
                raise SupplyError("seed CAS failed, manual reconciliation required")
            os.replace(temp,SEED)
        finally:
            if os.path.exists(temp):os.unlink(temp)
        from agent_team import seed
        result=seed()
        if result["added"]!=len(view["ready_ids"]):
            raise SupplyError("unexpected coordinator admission count; reconcile")
    except BaseException:
        # Keep pending receipt; never blindly replay a potentially half-admitted queue.
        raise
    marker.rename(marker.with_suffix(".applied"))
    return {"mode":"OWNER_FOREGROUND_ADMITTED","ids":view["ready_ids"],"result":result,
            "new_seed_sha256":view["new_seed_sha256"],
            "host_authenticated_mcp_actor":False,"reviewer_qa_bypassed":False}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply",action="store_true")
    parser.add_argument("--plan-id",default="")
    a=parser.parse_args(argv)
    try:
        if a.apply:
            if not a.plan_id:raise SupplyError("missing --plan-id from preview")
            result=apply_plan(a.plan_id)
        else:
            result,_=candidate_preview()
        print(json.dumps({"ok":True,"data":result},ensure_ascii=True))
        return 0
    except (OSError,SupplyError,ValueError,KeyError) as e:
        print(json.dumps({"ok":False,"error":str(e)[:200]},ensure_ascii=True))
        return 2


if __name__=="__main__":
    raise SystemExit(main())
