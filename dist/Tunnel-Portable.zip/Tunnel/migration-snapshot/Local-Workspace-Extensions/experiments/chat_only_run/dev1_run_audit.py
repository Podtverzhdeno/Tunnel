"""Read-only forensic audit: Developer 1 portfolio and queue during 2026-11-02T01:27-01:33 UTC.

Uses immutable SQLite readers, never mutates queue or artifacts.
"""
from __future__ import annotations
import json,sqlite3,hashlib
from pathlib import Path
from contextlib import closing
from difflib import SequenceMatcher
from collections import Counter
ROOT=Path(__file__).resolve().parents[2]
TEAM=ROOT/".agent-team"/"team.sqlite3"
PEERS=ROOT/".agent-team"/"peer_reviews.sqlite3"
WAVE="705343afee3f9a15"
PORT=ROOT/".agent-team"/"feature-proposals"/WAVE/"developer-1.json"
DECISION=ROOT/".agent-team"/"feature-proposals"/WAVE/"architect_decisions.json"
START="2026-11-02T01:27:00"
END="2026-11-02T01:33:00"
def open_db(path):
    if path.is_symlink() or not path.is_file():raise RuntimeError("UNSAFE_DB")
    conn=sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True)
    conn.row_factory=sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    return conn
def read(path,limit=400000):
    if path.is_symlink() or path.stat().st_size>limit:raise RuntimeError("UNSAFE_FILE")
    raw=path.read_bytes()
    return json.loads(raw.decode("utf-8")),hashlib.sha256(raw).hexdigest()
def main():
    output={}
    with closing(open_db(TEAM)) as db:
        events=db.execute("select task_id,role,action,detail,at from events where at>=? and at<=? order by at,id limit 150",(START,END)).fetchall()
        output["team_events_during_run"]=[{"task":r["task_id"],"role":r["role"],"action":r["action"],"at":r["at"],"detail":str(r["detail"])[:120]} for r in events]
        status=db.execute("select status,count(*) total from tasks group by status").fetchall()
        output["queue_current_counts"]={r["status"]:r["total"] for r in status}
        output["dev1_owned"]=[dict(r) for r in db.execute("select task_id,status,owner,submitted_at,reviewed_at from tasks where owner='developer-1' order by task_id")]
        output["task_status_last_modified_before_run"]=[]
        rows=db.execute("select task_id,status,activity_at,created_at,owner from tasks order by task_id").fetchall()
        output["all_tasks_last_activity"]=[dict(r) for r in rows if r["status"]!="done"]
        relevant=db.execute("select task_id,role,action,at from events where role='developer-1' order by id desc limit 25").fetchall()
        output["dev1_latest_events"]=[dict(r) for r in relevant]
    with closing(open_db(PEERS)) as db:
        tables={r["name"] for r in db.execute("select name from sqlite_master where type='table'")}
        output["peer_tables"]=sorted(tables)
        for tbl in sorted(tables):
            if "review" in tbl:
                columns=[r["name"] for r in db.execute("pragma table_info("+tbl+")")]
                output["peer_column_names"]=columns
                if "status" in columns:
                    rows=db.execute("select * from "+tbl+" limit 80").fetchall()
                    entries=[]
                    for r in rows:
                        d=dict(r)
                        entries.append({k:d.get(k) for k in ("task_id","peer_reviewer","role","status","verdict","claimed_at","finished_at","lease_until") if k in d})
                    output["peers_snapshot"]=entries
    obj,h=read(PORT)
    output["portfolio"]={"bytes":PORT.stat().st_size,"sha256":h,"role":obj.get("role"),"wave":obj.get("wave"),"items":[]}
    strings=[]
    for candidate in obj["candidates"]:
        sec=candidate["sections"]
        parts=[sec[k] for k in sorted(sec)]
        alltext="\n".join(parts)
        strings.append(alltext)
        output["portfolio"]["items"].append({"id":candidate["id"],"title":candidate["title"],"score":candidate["score"],
             "chars":len(alltext),"sections":len(sec),"testcases":len(candidate["test_strategy"]),
             "failure_cases":len(candidate["failure_scenarios"]), "alternatives":len(candidate["alternatives"]),
             "related":candidate["related_existing_ids"],"problem":sec["problem"][:180],"evidence":sec["evidence"][:180]})
    similarities=[]
    for i in range(len(strings)):
        for j in range(i+1,len(strings)):
            ratio=SequenceMatcher(None,strings[i],strings[j],autojunk=True).ratio()
            similarities.append((round(ratio,3),i+1,j+1))
    output["portfolio"]["highest_pairwise_char_similarity"]=sorted(similarities,reverse=True)[:5]
    if DECISION.is_file():
        obj,_=read(DECISION)
        output["architect_decisions_on_dev1"]=[{"id":d["feature_id"],"decision":d["decision"],"score":d["weighted_score"]} for d in obj["decisions"] if d.get("feature_id","").startswith("developer-1:")]
    print(json.dumps(output,ensure_ascii=True))
if __name__=="__main__":main()
