"""One-call, read-only launch packet for scheduled ChatGPT chat agents.

Uses the existing *live* SQLite coordinator CLI. No acquire, lease-token
recovery, checkpoint, source edits, Git, model/API/Browser or schedule changes.
The role is a filter, never an authenticated principal.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Callable

from read_only_queue_snapshot import read_overview, ReadOnlySnapshotError

PROJECT = Path(__file__).resolve().parents[2]
ROLES = ("developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer")
MAX_STDOUT = 512_000


class SnapshotError(RuntimeError):
    pass


def coordinator(args: list[str], runner: Callable = subprocess.run) -> dict:
    # Do not turn a launch packet into a generic privileged coordinator runner.
    if (not isinstance(args, list) or len(args) != 2 or
            args[0] != "plan-work" or args[1] not in ROLES[:-1]):
        raise SnapshotError("READ_ONLY_PLAN_WORK_ONLY")
    process = runner(
        [sys.executable, str(PROJECT / "agent_team.py"), *args],
        cwd=str(PROJECT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=35,
        shell=False,
    )
    if process.returncode != 0 or len(process.stdout.encode("utf-8")) > MAX_STDOUT:
        raise SnapshotError("coordinator unavailable or oversized response")
    try:
        data = json.loads(process.stdout)
        if data.get("ok") is not True or not isinstance(data.get("data"), dict):
            raise SnapshotError("coordinator returned an error")
        return data["data"]
    except (ValueError, TypeError, AttributeError) as e:
        raise SnapshotError("invalid coordinator JSON response") from e


def safe_coordinator(args: list[str]) -> dict:
    """Default packet uses only SQL mode=ro; plan-work is also query-only."""
    if args == ["overview"]:
        return read_overview()
    if len(args) == 2 and args[0] == "plan-work" and args[1] in ROLES[:-1]:
        return coordinator(args)
    raise SnapshotError("unsupported read-only query")


def make_packet(role: str, call: Callable[[list[str]], dict] | None = None) -> dict:
    if role not in ROLES:
        raise ValueError("unsupported role")
    call = call if call is not None else safe_coordinator
    overview = call(["overview"])
    if not isinstance(overview.get("tasks"), list) or not isinstance(overview.get("agents"), list):
        raise SnapshotError("missing task/agent status")
    tasks = overview["tasks"]
    owner_tasks = sorted(
        (t for t in tasks if t.get("owner") == role and t.get("status") not in ("done", "cancelled")),
        key=lambda t: (t.get("status") != "working", str(t.get("task_id"))),
    )
    limited = [
        {
            "task_id": str(t.get("task_id"))[:80],
            "status": str(t.get("status"))[:32],
            "lease_remaining_minutes": t.get("lease_remaining_minutes"),
            "checkpoint_next": [str(x)[:200] for x in (t.get("next_steps") or [])[:2]],
            "last_checkpoint_utc": t.get("checkpoint_at_utc"),
            "attention": [str(x)[:100] for x in (t.get("attention") or [])[:2]],
        }
        for t in owner_tasks[:6]
    ]
    packet = {
        "mode": "read_only_chat_launch_packet",
        "source": overview.get("snapshot_origin", "injected_test_snapshot_unverified"),
        "merge_intents_checked": False,
        "host_actor_authenticated": False,
        "snapshot_at_utc": overview.get("as_of_utc"),
        "role_filter_not_authentication": role,
        "tasks_owned_unfinished": limited,
        "authority": {
            "lease_issued": False,
            "tokens_disclosed": False,
            "approval_granted": False,
            "task_completed": False,
            "production_queue_mutated": False,
        },
    }

    if role == "architect-reviewer":
        review = [
            {"task_id": t.get("task_id"), "status": t.get("status"),
             "owner": t.get("owner"),
             "review_lease_remaining_minutes": t.get("review_lease_remaining_minutes"),
             "attention": (t.get("attention") or [])[:2]}
            for t in tasks if t.get("status") in ("review", "reviewing")
        ]
        packet["review_queue"] = review[:10]
        packet["safe_next_action"] = (
            "Review current ready candidates using review-preview and merge-status; "
            "only authorized reviewer lease plus independent tests allows accept/reject. "
            "A reviewing item may be held by another invocation; never steal its lease."
            if review else
            "Read canonical backlog for spec-backed, non-overlapping reviewable work; "
            "do not create placeholder tasks or bypass owner spec approval."
        )
    else:
        plan = call(["plan-work", role])
        task = plan.get("recommended_task_id")
        if task is not None and (not isinstance(task, str) or not task.startswith("P")):
            raise SnapshotError("invalid recommended task ID")
        packet["recommended_available_task_id"] = task
        packet["alternatives"] = [
            {
                "task_id": t.get("task_id"),
                "status": t.get("status"),
                "blocked_reason": t.get("blocked_reason"),
            } for t in plan.get("candidates", [])[:8]
        ]
        packet["safe_next_action"] = (
            "Read exact canonical spec and task_resume_packet; obtain fresh request_id, "
            "then acquire this task using agent_team.py --task with host-authorized role. "
            "The recommendation itself does not grant a lease."
            if task else
            "No safe coding lease is ready. First run peer_review_switch.py plan ROLE; "
            "claim any independent peer review and complete a verified report. When "
            "peer tasks are exhausted call architect_support.py plan ROLE to help "
            "the architect: reproduce contested defects, verify QA/architecture "
            "and challenge proposed feature evidence under a separate advisory "
            "lease. Recheck coding and peer queues after EVERY useful step. "
            "Never invent coding tickets, self-review, or formally accept/reject."
        )

    packet["continuation_contract"] = (
        "Within this scheduled CHAT invocation: loop between real scoped coding "
        "under lease, strict nine-dimension agent_quality_gate and guarded submit; "
        "then fresh independent peer reviews; then bounded architect support with "
        "architect_support.py (independent regression witnesses, reliability, "
        "architecture and feature evidence). After EVERY completed useful task, "
        "recheck coding and peer queues; return to coding immediately when a legal "
        "ready task appears. After coding/peer, prepare 10+ deep feature proposals "
        "ONCE per role/seed wave, then test 8 architect-selected feature hypotheses "
        "via non-self architect support. Reuse saved work and do not generate "
        "redundant 10-idea batches. Architect handles final assessment; owner grants "
        "normative changes and queue admission. Each scheduled invocation is finite: "
        "persist incomplete evidence on expiry and honestly end only when all useful "
        "scoped support lanes are exhausted, not simply when coding queue is empty. "
        "Never self-review, claim host identity or merge/accept without authorization."
    )
    return packet


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", choices=ROLES, required=True)
    args = parser.parse_args(argv)
    try:
        print(json.dumps({"ok": True, "data": make_packet(args.role)},
                         ensure_ascii=True, separators=(",", ":")))
        return 0
    except (SnapshotError, ReadOnlySnapshotError, subprocess.TimeoutExpired, OSError) as e:
        print(json.dumps({"ok": False, "error": str(e), "role": args.role},
                         ensure_ascii=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
