"""F08 offline negative-effect envelope; observational advice, NEVER proof.

Client-supplied zero events, completeness flags and observer names cannot prove
that a tool produced no side effects or attest a trusted principal. No external
tool invocation or state mutation. Requires independent host trust in any
future production deployment, which is deliberately absent here.
"""
from __future__ import annotations

import re

MAX_OBSERVERS = 64
_ID = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,95}\Z")
_SHA = re.compile(r"[a-f0-9]{64}\Z")
REPORT_FIELDS = frozenset({
    "observer_id", "coverage_scope", "coverage_complete",
    "source_sha256", "event_count",
})


def _report(status, reason, missing=(), invalid=(), observed=0):
    return {
        "schema": "negative-effect-envelope-offline-v1",
        "status": status,
        "reason": reason,
        "missing_observers": sorted(missing),
        "invalid_records": sorted(invalid),
        "reported_positive_effect_observations": observed,
        "advisory_only": True,
        "absence_proven": False,
        "trusted_observer_proven": False,
        "release_authorized": False,
    }


def assess_effect_absence(expected_observers, reports, *, scope_id, source_sha256):
    """Compare bounded reports with a fixed declared observation envelope.

    Complete zero-event evidence yields ADVISORY_ZERO_OBSERVED only, never
    ABSENCE_PROVEN. Any missing, stale or ambiguous observer yields UNVERIFIED;
    a positive event in a syntactically valid report yields REPORTED_EFFECT.
    """
    if (type(scope_id) is not str or _ID.fullmatch(scope_id) is None
            or type(source_sha256) is not str or _SHA.fullmatch(source_sha256) is None
            or not isinstance(expected_observers, list)
            or not isinstance(reports, list)
            or not 2 <= len(expected_observers) <= MAX_OBSERVERS
            or len(reports) > MAX_OBSERVERS):
        return _report("INVALID_INPUT", "INVALID_ENVELOPE")
    if (any(type(o) is not str or _ID.fullmatch(o) is None
            for o in expected_observers)
            or len(set(expected_observers)) != len(expected_observers)):
        return _report("INVALID_INPUT", "INVALID_OBSERVER_MANIFEST")
    wanted = set(expected_observers)
    seen = set()
    invalid = []
    incomplete = set()
    positive = 0
    for index, item in enumerate(reports):
        if (not isinstance(item, dict) or set(item) != REPORT_FIELDS
                or type(item.get("observer_id")) is not str
                or _ID.fullmatch(item["observer_id"]) is None
                or type(item.get("coverage_scope")) is not str
                or item["coverage_scope"] != scope_id
                or type(item.get("source_sha256")) is not str
                or item["source_sha256"] != source_sha256
                or type(item.get("coverage_complete")) is not bool
                or type(item.get("event_count")) is not int
                or not 0 <= item["event_count"] <= 1_000_000_000):
            invalid.append(f"row:{index}")
            continue
        key = item["observer_id"]
        if key not in wanted or key in seen:
            invalid.append(f"unexpected_or_duplicate:{index}")
            continue
        seen.add(key)
        if not item["coverage_complete"]:
            incomplete.add(key)
        if item["event_count"] > 0:
            positive += 1
    missing = wanted - seen
    if positive:
        return _report("REPORTED_EFFECT", "CALLER_REPORTED_POSITIVE_EVENTS",
                       missing=missing, invalid=invalid, observed=positive)
    if missing or invalid or incomplete:
        return _report("UNVERIFIED", "OBSERVATION_ENVELOPE_INCOMPLETE",
                       missing=missing, invalid=invalid + [
                           f"incomplete:{x}" for x in sorted(incomplete)])
    return _report("ADVISORY_ZERO_OBSERVED", "CALLER_SUPPLIED_ZERO_EVENTS_ONLY")
