"""Cross-role advisory peer reviews for scheduled ChatGPT developer chats.

This is NOT the architect's privileged accept/reject workflow. The role passed
via CLI is never an authenticated host identity. Immutable source fingerprints,
SQLite leases and author exclusions prevent accidental self-reviews/duplicates
under the cooperative local scheduler; they cannot establish a host security
boundary against arbitrary local script execution.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import secrets
import sqlite3
import sys
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN_DB = ROOT / ".agent-team" / "team.sqlite3"
PEER_DB = ROOT / ".agent-team" / "peer_reviews.sqlite3"
PACKETS = ROOT / ".agent-team" / "peer-review-packets"
ROLES = tuple("developer-"+str(n) for n in range(1,5))
TASK_ID = re.compile(r"P[0-9]{3}\Z")
REQUEST_ID = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9._:-]{7,127}\Z")
FILE = re.compile(r"(?:[a-z][a-z0-9_]*|test_[a-z][a-z0-9_]*)\.py\Z")
MAX_REPORT = 16384
TTL = timedelta(minutes=45)

class PeerError(ValueError): pass

def utcnow():
    return datetime.now(timezone.utc)

def stamp(date):
    return date.isoformat(timespec="seconds")

def ensure_role(role):
    if role not in ROLES: raise PeerError("INVALID_ROLE")

def exclusions(role):
    ensure_role(role)
    # D3 and D4 are two logical roles in ONE ChatGPT conversation.
    return {"developer-3","developer-4"} if role in ROLES[2:] else {role}

def safe_file(path, maximum=2*1024*1024):
    if (path.is_symlink() or getattr(path, "is_junction",lambda:False)() or
            not path.is_file() or path.stat().st_size>maximum):
        raise PeerError("UNSAFE_OR_MISSING_FILE")
    return path.read_bytes()

def open_main(db_path):
    path=Path(db_path)
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)() or not path.is_file():
        raise PeerError("MAIN_DB_UNSAFE")
    return sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True,timeout=5)

def get_live(db_path=MAIN_DB):
    with closing(open_main(db_path)) as db:
        db.row_factory=sqlite3.Row
        db.execute("PRAGMA query_only=ON")
        tasks=db.execute(
            "SELECT task_id,status,owner,role_hint,sandbox,deliverables,"
            "spec_ref,revision,submitted_at,review_until "
            "FROM tasks ORDER BY task_id LIMIT 1001").fetchall()
        if len(tasks)>1000: raise PeerError("QUEUE_TOO_LARGE")
        author_events=db.execute(
            "SELECT task_id,role FROM events WHERE role LIKE 'developer-%' "
            "AND action IN ('acquire','submit','checkpoint','checkpoint_file',"
            "'sync_sandbox','seed_revision') LIMIT 10001").fetchall()
        if len(author_events)>10000:raise PeerError("HISTORY_TOO_LARGE")
    authors={}
    for row in author_events:
        authors.setdefault(row["task_id"],set()).add(row["role"])
    return {t["task_id"]:dict(t) for t in tasks},authors

def fingerprint(item,project=ROOT):
    task_id=item["task_id"]
    if not TASK_ID.fullmatch(task_id):raise PeerError("INVALID_TASK")
    scope=Path(project).resolve()
    path=item["sandbox"]
    if not isinstance(path,str) or not path.startswith(".agent-team/workspaces/"):
        raise PeerError("INVALID_SANDBOX")
    folder=(scope/path).resolve()
    state=(scope/".agent-team"/"workspaces").resolve()
    if not folder.is_relative_to(state) or not folder.is_dir() or folder.is_symlink():
        raise PeerError("SANDBOX_ESCAPE")
    files=json.loads(item["deliverables"])
    if not isinstance(files,list) or not 1<=len(files)<=6 or len(files)!=len(set(files)):
        raise PeerError("INVALID_OUTPUTS")
    sha=[]
    for name in sorted(files):
        if not isinstance(name,str) or not FILE.fullmatch(name):raise PeerError("INVALID_OUTPUT")
        sha.append([name,hashlib.sha256(safe_file(folder/name)).hexdigest()])
    spec_rel=item["spec_ref"].partition(" / ")[0]
    if not spec_rel.startswith("openspec/changes/local-pc-agent-tooling/specs/") or not spec_rel.endswith("/spec.md"):
        raise PeerError("INVALID_SPEC")
    spec=(scope/spec_rel).resolve()
    if not spec.is_relative_to(scope):raise PeerError("SPEC_ESCAPE")
    canonical=hashlib.sha256(safe_file(spec,262144)).hexdigest()
    material={"task":task_id,"revision":item["revision"],
              "submitted_at":item["submitted_at"],"canonical_spec_sha256":canonical,
              "outputs":sha}
    return hashlib.sha256(json.dumps(material,sort_keys=True).encode()).hexdigest()

def eligible(role,tasks,authors,peer_rows,now=None,project=ROOT):
    ensure_role(role)
    now=utcnow() if now is None else now
    not_owned=exclusions(role)
    candidates=[]
    for task_id,item in tasks.items():
        if item["status"] not in ("review","reviewing"):continue
        if ({item["role_hint"],item["owner"]}|authors.get(task_id,set()))&not_owned:
            continue
        if item["status"]=="reviewing":
            # Do not inspect a task while the privileged architect has a lease.
            until=item["review_until"]
            try:
                if not isinstance(until,str) or datetime.fromisoformat(until)>now:
                    continue
            except ValueError:continue
        current=peer_rows.get(task_id)
        if current:
            # Dedup all roles while current review is in progress/completed.
            lease=current.get("lease_until")
            if current["status"]=="completed":
                try:
                    if current["source_digest"]==fingerprint(item,project):
                        continue  # Exactly this code version already independently reviewed.
                except (PeerError,OSError,ValueError,TypeError):
                    continue  # Unsafe changed source does not become reviewable.
            if current["status"]=="claimed" and lease:
                try:
                    if datetime.fromisoformat(lease)>now:continue
                except ValueError:continue
        candidates.append(item)
    return sorted(candidates,key=lambda t:(t.get("submitted_at") or "",t["task_id"]))

def open_peer(path=PEER_DB):
    path=Path(path)
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)():
        raise PeerError("PEER_DB_UNSAFE")
    path.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(str(path),isolation_level=None,timeout=15)
    db.row_factory=sqlite3.Row
    db.execute("PRAGMA busy_timeout=15000")
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("""CREATE TABLE IF NOT EXISTS peer_reviews(
      task_id TEXT PRIMARY KEY, reviewer_role TEXT NOT NULL, request_id TEXT NOT NULL,
      token_digest TEXT NOT NULL, source_digest TEXT NOT NULL,
      status TEXT NOT NULL, lease_until TEXT, verdict TEXT,
      report_sha256 TEXT, summary TEXT, finished_at TEXT)""")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS peer_by_request ON peer_reviews(reviewer_role,request_id)")
    return db

def peer_state(db):
    return {r["task_id"]:dict(r) for r in db.execute("SELECT * FROM peer_reviews")}


def read_peer_state(path=PEER_DB):
    """Read ledger without creating it or touching SQLite WAL configuration."""
    path=Path(path)
    if not path.exists():return {}
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)() or not path.is_file():
        raise PeerError("PEER_DB_UNSAFE")
    with closing(sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True,timeout=5)) as db:
        db.row_factory=sqlite3.Row
        db.execute("PRAGMA query_only=ON")
        return peer_state(db)

def developer_plan(role):
    # The coordinator's existing query-only plan-work is authoritative for coding.
    if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
    from agent_team import plan_work
    result=plan_work(role)
    return result.get("recommended_task_id")

def plan(role, after_code=False, main=MAIN_DB, peer=PEER_DB, project=ROOT,
         code_plan=developer_plan,now=None):
    ensure_role(role)
    tasks,authors=get_live(main)
    reviewers=eligible(role,tasks,authors,read_peer_state(peer),now,project)
    coding=code_plan(role)
    review=reviewers[0]["task_id"] if reviewers else None
    mode=("peer_review" if after_code and review else
          "coding" if coding else "peer_review" if review else "idle")
    return {"mode":mode,"role_filter_not_host_identity":role,
            "recommended_code_task":coding,"recommended_peer_task":review,
            "peer_candidates":[r["task_id"] for r in reviewers[:12]],
            "exclude_authors":sorted(exclusions(role)),
            "may_accept_or_merge":False,"production_queue_mutated":False,
            "next":"After review completion call plan again; do not use peer evidence as privileged acceptance."}

def claim(role,task_id,request_id,*,after_code=False,main=MAIN_DB,peer=PEER_DB,
          project=ROOT,code_plan=developer_plan,now=None):
    ensure_role(role)
    if not TASK_ID.fullmatch(task_id):raise PeerError("INVALID_TASK")
    if not REQUEST_ID.fullmatch(request_id):raise PeerError("INVALID_REQUEST")
    now=utcnow() if now is None else now
    code=code_plan(role)
    if code and not after_code:raise PeerError("CODING_TASK_HAS_PRIORITY")
    tasks,authors=get_live(main)
    if task_id not in tasks:raise PeerError("TASK_NOT_FOUND")
    # Capture fingerprint before the peer lease. No source modifications.
    digest=fingerprint(tasks[task_id],project)
    with closing(open_peer(peer)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            prev=db.execute("SELECT * FROM peer_reviews WHERE reviewer_role=? AND request_id=?",
                            (role,request_id)).fetchone()
            if prev:
                # Request retries never allocate a different task.
                if prev["task_id"]!=task_id:raise PeerError("REQUEST_ALREADY_BOUND")
                raise PeerError("REQUEST_ALREADY_USED_CHECK_OWN_TOKEN")
            rows=peer_state(db)
            if task_id not in {r["task_id"] for r in eligible(role,tasks,authors,rows,now,project)}:
                raise PeerError("PEER_REVIEW_NOT_ELIGIBLE")
            existing=rows.get(task_id)
            if existing and existing["status"]=="completed" and existing["source_digest"]==digest:
                raise PeerError("ALREADY_PEER_REVIEWED")
            token=secrets.token_urlsafe(32)
            token_sha=hashlib.sha256(token.encode()).hexdigest()
            db.execute("""INSERT INTO peer_reviews
              (task_id,reviewer_role,request_id,token_digest,source_digest,status,lease_until)
              VALUES(?,?,?,?,?,'claimed',?)
              ON CONFLICT(task_id) DO UPDATE SET
              reviewer_role=excluded.reviewer_role, request_id=excluded.request_id,
              token_digest=excluded.token_digest,source_digest=excluded.source_digest,
              status='claimed',lease_until=excluded.lease_until,
              verdict=NULL,report_sha256=NULL,summary=NULL,finished_at=NULL""",
              (task_id,role,request_id,token_sha,digest,stamp(now+TTL)))
            db.execute("COMMIT")
        except BaseException:
            db.execute("ROLLBACK")
            raise
    return {"task_id":task_id,"peer_role":role,"peer_token":token,
            "source_digest":digest,"lease_until":stamp(now+TTL),
            "report_file":str((Path(project)/".agent-team"/"peer-review-packets"/role/(task_id+".json")).relative_to(project)),
            "may_accept_or_merge":False}

def validate_report(raw,task_id,role):
    if not isinstance(raw,dict) or set(raw)!={"task_id","peer_role","verdict","summary","findings","checks"}:
        raise PeerError("REPORT_SCHEMA_INVALID")
    if raw["task_id"]!=task_id or raw["peer_role"]!=role:raise PeerError("REPORT_ROLE_MISMATCH")
    if raw["verdict"] not in ("READY_FOR_ARCHITECT","CHANGES_REQUESTED","BLOCKED"):
        raise PeerError("REPORT_VERDICT_INVALID")
    if not isinstance(raw["summary"],str) or not 30<=len(raw["summary"])<=1800:
        raise PeerError("REPORT_SUMMARY_INVALID")
    for field in ("findings","checks"):
        val=raw[field]
        if not isinstance(val,list) or not 1<=len(val)<=24:
            raise PeerError("REPORT_EVIDENCE_MISSING")
        if any(not isinstance(x,str) or not 8<=len(x)<=450 for x in val):
            raise PeerError("REPORT_EVIDENCE_INVALID")
    return raw

def complete(role,task_id,token,*,main=MAIN_DB,peer=PEER_DB,project=ROOT,now=None):
    ensure_role(role)
    if not TASK_ID.fullmatch(task_id):raise PeerError("INVALID_TASK")
    now=utcnow() if now is None else now
    with closing(open_peer(peer)) as db:
        row=db.execute("SELECT * FROM peer_reviews WHERE task_id=?",(task_id,)).fetchone()
    if row is None or row["reviewer_role"]!=role or row["status"]!="claimed":
        raise PeerError("PEER_LEASE_MISSING")
    if (not isinstance(token,str) or
        not secrets.compare_digest(row["token_digest"],hashlib.sha256(token.encode()).hexdigest())):
        raise PeerError("PEER_LEASE_INVALID")
    if datetime.fromisoformat(row["lease_until"])<=now:raise PeerError("PEER_LEASE_EXPIRED")
    tasks,authors=get_live(main)
    task=tasks.get(task_id)
    if task is None or task["status"] not in ("review","reviewing"):
        raise PeerError("TASK_NOT_IN_REVIEW")
    if ({task["owner"],task["role_hint"]}|authors.get(task_id,set()))&exclusions(role):
        raise PeerError("SELF_REVIEW_FORBIDDEN")
    if fingerprint(task,project)!=row["source_digest"]:raise PeerError("SOURCE_CHANGED")
    path=Path(project)/".agent-team"/"peer-review-packets"/role/(task_id+".json")
    data=safe_file(path,MAX_REPORT)
    try: parsed=json.loads(data.decode("utf-8"))
    except (json.JSONDecodeError,UnicodeDecodeError) as e:
        raise PeerError("REPORT_PARSE_ERROR") from e
    report=validate_report(parsed,task_id,role)
    checksum=hashlib.sha256(data).hexdigest()
    with closing(open_peer(peer)) as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            old=db.execute("SELECT * FROM peer_reviews WHERE task_id=?",(task_id,)).fetchone()
            if not old or old["status"]!="claimed" or old["token_digest"]!=row["token_digest"] or old["source_digest"]!=row["source_digest"]:
                raise PeerError("STALE_PEER_LEASE")
            db.execute("UPDATE peer_reviews SET status='completed',verdict=?,report_sha256=?,summary=?,finished_at=?,lease_until=NULL WHERE task_id=?",
                        (report["verdict"],checksum,report["summary"],stamp(now),task_id))
            db.execute("COMMIT")
        except BaseException:
            db.execute("ROLLBACK")
            raise
    return {"task_id":task_id,"peer_role":role,"status":"advisory_review_completed",
            "verdict":report["verdict"],"report_sha256":checksum,
            "formal_accept":False,"main_queue_modified":False}

def overview(peer=PEER_DB,project=ROOT):
    """Advisory record index, not a privileged accept queue or host attestation."""
    records=read_peer_state(peer)
    if len(records)>500:raise PeerError("PEER_QUEUE_TOO_LARGE")
    rows=list(records.values())
    summary=[]
    for row in rows:
        record=dict(row)
        path=Path(project)/".agent-team"/"peer-review-packets"/record["reviewer_role"]/(record["task_id"]+".json")
        matching=False
        if record["status"]=="completed" and record["report_sha256"]:
            try:
                matching=hashlib.sha256(safe_file(path,MAX_REPORT)).hexdigest()==record["report_sha256"]
            except (OSError,PeerError):pass
        summary.append({
            "task_id":record["task_id"],"peer_reviewer":record["reviewer_role"],
            "status":record["status"],"verdict":record["verdict"],
            "report_sha256":record["report_sha256"],"report_matches":matching,
            "report_path":str(path.relative_to(project)),"finished_at":record["finished_at"],
            "lease_until":record["lease_until"],
            "advisory_only":True})
    return {"reviews":summary,"count":len(summary),
            "formal_accepts":0,"host_actor_authenticated":False}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="command",required=True)
    sub.add_parser("overview")
    s=sub.add_parser("plan");s.add_argument("role",choices=ROLES);s.add_argument("--after-code",action="store_true")
    s=sub.add_parser("claim");s.add_argument("role",choices=ROLES);s.add_argument("task_id");s.add_argument("request_id");s.add_argument("--after-code",action="store_true")
    s=sub.add_parser("complete");s.add_argument("role",choices=ROLES);s.add_argument("task_id");s.add_argument("peer_token")
    a=p.parse_args(argv)
    try:
        if a.command=="overview":result=overview()
        elif a.command=="plan":result=plan(a.role,a.after_code)
        elif a.command=="claim":result=claim(a.role,a.task_id,a.request_id,after_code=a.after_code)
        else:result=complete(a.role,a.task_id,a.peer_token)
        print(json.dumps({"ok":True,"data":result},ensure_ascii=True))
        return 0
    except (PeerError,OSError,sqlite3.DatabaseError,ValueError,TypeError,KeyError) as e:
        print(json.dumps({"ok":False,"error":{"code":str(e)[:150]}},ensure_ascii=True))
        return 2

if __name__=="__main__":
    sys.exit(main())
