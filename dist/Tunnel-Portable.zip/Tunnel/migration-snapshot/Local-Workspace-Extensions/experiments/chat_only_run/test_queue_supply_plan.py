"""Offline admission tests. No real task seed or SQLite mutation."""
import copy
import unittest
from pathlib import Path
from unittest.mock import patch
from queue_supply_plan import load_candidates, SupplyError
from supply_plan_fixture import plan

# Historical P116/P127/P131/P148/P149 contract fixtures remain stable even
# when the active owner-approved candidate batch advances to a new wave.
ITEMS = load_candidates(Path(__file__).with_name('queue_supply_candidates.json'))
TRUST = {f"P{i}":"recorded_pass" for i in (104,105,106,107)}
STATE = {f"P{i}":{"task_id":f"P{i}","status":"done","role_hint":"developer-1","deliverables":"[]"}
         for i in (104,105,106,107)}

class SupplyTests(unittest.TestCase):
    def test_exact_five_ready_across_all_roles(self):
        x=plan(ITEMS,STATE,TRUST)
        self.assertEqual(len(x["ready"]),5)
        self.assertEqual(len(x["blocked"]),0)
        self.assertFalse(x["queue_mutated"])
        self.assertFalse(x["owner_approval_granted"])
        self.assertEqual({v["role"] for v in x["ready"]},
                         {"developer-1","developer-2","developer-3","developer-4"})
    def test_unaccepted_predecessor_rejected(self):
        t=dict(TRUST);t["P105"]="legacy_unverifiable"
        x=plan(ITEMS,STATE,t)
        self.assertEqual({a["id"] for a in x["ready"]},{"P116","P131","P149"})
        self.assertIn("DEPENDENCY_QA_NOT_VERIFIED_P105",
                      next(a for a in x["blocked"] if a["id"]=="P148")["blockers"])
    def test_review_not_done(self):
        state=dict(STATE);state["P107"]=dict(state["P107"],status="review")
        x=plan(ITEMS,state,TRUST)
        self.assertTrue(any("DEPENDENCY_NOT_DONE_P107" in a["blockers"] for a in x["blocked"]))
    def test_existing_task_is_not_reseeded(self):
        state=dict(STATE)
        state["P116"]={"task_id":"P116","status":"available","role_hint":"developer-1",
                       "deliverables":'["task_dag_schema.py","test_task_dag_schema.py"]'}
        x=plan(ITEMS,state,TRUST)
        self.assertIn("ALREADY_IN_LIVE_QUEUE",x["blocked"][0]["blockers"])
    def test_no_overlapping_live_output(self):
        state=dict(STATE)
        state["P999"]={"task_id":"P999","status":"working","role_hint":"developer-3",
                       "deliverables":'["agent_metrics_series.py"]'}
        x=plan(ITEMS,state,TRUST)
        self.assertIn("CONFLICT_WITH_ACTIVE_OUTPUT",
                      next(v for v in x["blocked"] if v["id"]=="P127")["blockers"])
    def test_limit_bounds_d4_second_task(self):
        x=plan(ITEMS,STATE,TRUST,limit_per_role=1)
        self.assertIn("ROLE_READY_BUFFER_FULL",next(v for v in x["blocked"] if v["id"]=="P131")["blockers"])
        with self.assertRaises(SupplyError):plan(ITEMS,STATE,TRUST,limit_per_role=100)
    def test_cross_candidate_output_conflict(self):
        items=copy.deepcopy(ITEMS)
        items[1]["deliverables"]=list(items[0]["deliverables"])
        with self.assertRaises(SupplyError):plan(items,STATE,TRUST)
    def test_noncanonical_requirement_fails(self):
        items=copy.deepcopy(ITEMS)
        items[0]["spec_ref"]=items[0]["spec_ref"].replace("Task decomposition","Forged owner approval")
        with self.assertRaises(SupplyError):plan(items,STATE,TRUST)
    def test_unknown_role_and_unscoped_output_rejected(self):
        for mutate in ({"role_hint":"root"}, {"deliverables":["../.env"]},
                       {"priority":True}, {"depends_on":["P999","P999"]}):
            items=copy.deepcopy(ITEMS)
            items[0].update(mutate)
            with self.assertRaises(SupplyError):plan(items,STATE,TRUST)
    def test_no_implicit_acceptance_from_done(self):
        x=plan(ITEMS,STATE,{})
        self.assertEqual(len(x["ready"]),0)
        self.assertEqual(len(x["blocked"]),5)
        self.assertEqual(x["host_actor_authenticated"],False)
    def test_unknown_source_file_exists_fails_closed(self):
        items=copy.deepcopy(ITEMS)
        items[0]["deliverables"]=["agent_team.py","test_task_dag_schema.py"]
        x=plan(items,STATE,TRUST,existing=("agent_team.py",))
        self.assertIn("SOURCE_EXISTS_agent_team.py",x["blocked"][0]["blockers"])

if __name__=="__main__":unittest.main()
