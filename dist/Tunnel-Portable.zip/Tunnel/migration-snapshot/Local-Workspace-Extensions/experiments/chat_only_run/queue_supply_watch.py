"""Read-only per-role coding backlog watchdog for five-role ChatGPT team.

Returns candidate/queue evidence, not work authorizations. No SQLite writes,
owner approval, leases, scheduler invocations, or ChatGPT token guesses.
"""
from __future__ import annotations

import json

from queue_supply_plan import ROLES, load_candidates, read_live_state, plan
from owner_queue_admit import candidate_preview


def reconcile_admission_preview(supply, preview):
    """Fail closed on candidates that the *actual* owner gate cannot admit.

    This only refines an advisory snapshot; it does not grant approval, change
    a roadmap, or write the live queue.  The owner gate is the source of truth
    for SDD mappings and ownership conflicts.
    """
    if (not isinstance(preview, dict)
            or preview.get("mode") != "OWNER_FOREGROUND_APPROVAL_REQUIRED"
            or preview.get("preview_only") is not True
            or preview.get("mutated") is not False
            or not isinstance(preview.get("ready_ids"), list)
            or not isinstance(preview.get("blocked"), list)):
        raise ValueError("UNTRUSTED_OWNER_ADMISSION_PREVIEW")
    planned = {row["id"] for row in supply["ready"]}
    allowed = preview["ready_ids"]
    if (any(type(task_id) is not str for task_id in allowed)
            or len(allowed) != len(set(allowed))
            or any(task_id not in planned for task_id in allowed)):
        raise ValueError("OWNER_PREVIEW_SUPPLY_DRIFT")
    blocked_by_id = {}
    for item in preview["blocked"]:
        if not isinstance(item, dict) or type(item.get("id")) is not str:
            raise ValueError("INVALID_ADMISSION_BLOCKER")
        reasons = item.get("blockers", [])
        if (not isinstance(reasons, list)
                or any(type(reason) is not str for reason in reasons)):
            raise ValueError("INVALID_ADMISSION_BLOCKER")
        blocked_by_id[item["id"]] = reasons
    outcome = {**supply, "ready": [], "blocked": list(supply["blocked"])}
    for row in supply["ready"]:
        if row["id"] in allowed:
            outcome["ready"].append(row)
        else:
            reasons = blocked_by_id.get(row["id"], ["ADMISSION_PREVIEW_UNVERIFIED"])
            if (not isinstance(reasons, list)
                    or any(type(reason) is not str for reason in reasons)):
                raise ValueError("INVALID_ADMISSION_BLOCKER")
            outcome["blocked"].append({
                **row, "status": "BLOCKED",
                "blockers": sorted(set(reasons or ["ADMISSION_PREVIEW_UNVERIFIED"]))
            })
    return outcome


def summarize(states, supply, *, minimum_ready=2, target_ready=3):
    if (type(minimum_ready) is not int or type(target_ready) is not int
            or not 1 <= minimum_ready <= target_ready <= 3):
        raise ValueError("INVALID_READY_BUFFER_POLICY")
    if not isinstance(states, dict) or not isinstance(supply, dict):
        raise ValueError("INVALID_QUEUE_SNAPSHOT")
    expected={"mode","ready","blocked","queue_mutated","owner_approval_granted"}
    if not expected.issubset(supply) or supply["queue_mutated"] or supply["owner_approval_granted"]:
        raise ValueError("UNTRUSTED_PROPOSAL")
    if not isinstance(supply["ready"], list) or not isinstance(supply["blocked"], list):
        raise ValueError("INVALID_CANDIDATE_LIST")
    details = {}
    for role in sorted(ROLES):
        available = sum(t.get("status")=="available" and
                        t.get("role_hint")==role for t in states.values())
        active = sum(t.get("status")=="working" and
                     t.get("role_hint")==role for t in states.values())
        pending = [x["id"] for x in supply["ready"] if x.get("role")==role]
        blocked = [x for x in supply["blocked"] if x.get("role")==role]
        if any(type(x) is not str for x in pending):
            raise ValueError("INVALID_CANDIDATE_ID")
        if available+len(pending) > target_ready:
            raise ValueError("BACKLOG_CAP_EXCEEDED")
        # A candidate blocked because it is ALREADY IN LIVE QUEUE is not
        # a future task reserve; reporting it as such hid exhaustion after
        # successful owner admission. Preserve the distinction explicitly.
        already_live = [x for x in blocked if "ALREADY_IN_LIVE_QUEUE" in x.get("blockers", [])]
        future_blocked = [x for x in blocked if "ALREADY_IN_LIVE_QUEUE" not in x.get("blockers", [])]
        candidate_reserve = len(future_blocked)
        if available < minimum_ready and pending:
            status="OWNER_ADMISSION_REQUIRED"
        elif available < minimum_ready and not pending:
            status="BACKLOG_EXHAUSTED_OR_BLOCKED"
        else:
            status="LIVE_QUEUE_READY"
        details[role]={
            "live_ready": available,
            "live_working_not_necessarily_leased": active,
            "ready_for_owner_review": pending,
            "additional_proposals_blocked": candidate_reserve,
            "already_admitted_in_candidate_manifest": len(already_live),
            "future_proposals_pending_capacity_or_qa": candidate_reserve,
            "blocked_reasons": sorted({r for x in future_blocked for r in x.get("blockers", [])}),
            "projected_ready_after_foreground_admission": available+len(pending),
            "status": status,
            "guaranteed_future_work": False,
        }
    return {
        "schema": "chat-only-backlog-watch-v1",
        "read_only": True,
        "owner_approval_granted": False,
        "min_ready_policy": minimum_ready,
        "max_ready_per_role": target_ready,
        "admission_required_roles": [role for role in sorted(details)
                                     if details[role]["status"]=="OWNER_ADMISSION_REQUIRED"],
        "exhausted_roles": [role for role in sorted(details)
                            if details[role]["status"]=="BACKLOG_EXHAUSTED_OR_BLOCKED"],
        "total_live_ready": sum(v["live_ready"] for v in details.values()),
        "total_ready_for_owner_review": sum(len(v["ready_for_owner_review"]) for v in details.values()),
        "total_future_blocked": sum(v["additional_proposals_blocked"] for v in details.values()),
        "total_already_admitted_candidate_ids": sum(v["already_admitted_in_candidate_manifest"] for v in details.values()),
        "roles": details,
        "next": ("Run owner_queue_admit.py without arguments for read-only preview. "
                 "After SDD/QA blockers are resolved, a trusted owner may run "
                 "--apply --plan-id in an interactive foreground terminal; "
                 "never bypass lease/reviewer gates or claim constant future work."),
    }


def main():
    try:
        # A candidate with good dependency QA is not yet owner-admissible:
        # responsibility conflicts or an unmapped SDD row can still veto it.
        # Refresh the owner gate's read-only preview every time we report supply.
        admission, _ = candidate_preview()
        states,trust=read_live_state()
        proposals=plan(load_candidates(),states,trust,limit_per_role=3)
        verified=reconcile_admission_preview(proposals,admission)
        print(json.dumps({"ok":True,"data":summarize(states,verified)},sort_keys=True))
        return 0
    except (OSError, ValueError) as exc:
        print(json.dumps({"ok":False,"error":type(exc).__name__+":"+str(exc)[:120]}))
        return 2


if __name__=="__main__":
    raise SystemExit(main())
