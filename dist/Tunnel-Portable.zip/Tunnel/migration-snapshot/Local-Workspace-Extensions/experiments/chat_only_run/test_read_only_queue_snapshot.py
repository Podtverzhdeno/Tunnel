"""Security and consistency tests for mode=ro scheduled-turn snapshot."""
from __future__ import annotations
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch
import read_only_queue_snapshot as m
import chat_run_packet as packet

NOW=datetime(2026, 11, 2, 1, 0, tzinfo=timezone.utc)

class ReadOnlyQueueTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        (self.root / ".agent-team").mkdir()
        self.file=self.root/".agent-team"/"team.sqlite3"
        with closing(sqlite3.connect(self.file)) as db:
            db.executescript("""
            CREATE TABLE tasks(task_id TEXT,status TEXT,owner TEXT,role_hint TEXT,activity_at TEXT,lease_until TEXT,review_until TEXT,lease_token TEXT,secret TEXT);
            CREATE TABLE agents(role TEXT,sessions INTEGER,last_started TEXT,last_activity TEXT);
            CREATE TABLE task_checkpoints(task_id TEXT,recorded_at TEXT,progress_json TEXT);
            """)
            db.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)", (
                "P096","working","developer-3","developer-3",
                "2026-11-01T23:00:00+00:00","2026-11-02T01:20:00+00:00",None,
                "TOP_SECRET_LEASE", "PRIVATE_TASK_INSTRUCTIONS"))
            db.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)", (
                "P110","review","developer-3","developer-3",
                "2026-11-01T22:55:00+00:00",None,None,None,"CONFIDENTIAL"))
            db.execute("INSERT INTO agents VALUES(?,?,?,?)", (
                "developer-3",12,"2026-11-01T22:59:00+00:00","2026-11-01T23:01:00+00:00"))
            db.execute("INSERT INTO task_checkpoints VALUES(?,?,?)", (
                "P096","2026-11-01T23:00:00+00:00",
                '{"next":["PRIVATE_PROGRESS_DETAILS"],"token":"SECRET_CHECKPOINT"}'))
            db.commit()
    def tearDown(self):
        self.tmp.cleanup()
    def sql(self,statement,params=()):
        with closing(sqlite3.connect(self.file)) as db:
            db.execute(statement,params)
            db.commit()
    def test_readonly_sqlite_and_redacted_output(self):
        before=self.file.read_bytes()
        modified=self.file.stat().st_mtime_ns
        view=m.read_overview(self.root,now=NOW)
        self.assertEqual(before,self.file.read_bytes())
        self.assertEqual(modified,self.file.stat().st_mtime_ns)
        self.assertFalse((self.root/".agent-team"/"team.sqlite3-wal").exists())
        self.assertEqual(view["task_counts"],{"working":1,"review":1})
        task=view["tasks"][0]
        self.assertEqual(task["checkpoint_at_utc"],"2026-11-01T23:00:00+00:00")
        self.assertEqual(task["lease_remaining_minutes"],20)
        self.assertEqual(view["snapshot_origin"],"query_only_sqlite_single_transaction")
        blob=json.dumps(view)
        for token in ("TOP_SECRET_LEASE","PRIVATE_TASK_INSTRUCTIONS","PRIVATE_PROGRESS_DETAILS","SECRET_CHECKPOINT"):
            self.assertNotIn(token,blob)
        self.assertFalse(view["may_mutate"])
    def test_expired_lease_attention(self):
        view=m.read_overview(self.root,now=NOW+timedelta(hours=1))
        self.assertIn("developer_lease_expired",view["tasks"][0]["attention"])
        self.assertIn("review_waiting_over_hour",view["tasks"][1]["attention"])
    def test_reviewer_lease_expiration_is_visible(self):
        self.sql("UPDATE tasks SET status='reviewing', review_until=? WHERE task_id='P110'",
                 ("2026-11-02T00:59:00+00:00",))
        view=m.read_overview(self.root,now=NOW)
        self.assertEqual(view["tasks"][1]["review_lease_remaining_minutes"], -1)
        self.assertIn("reviewer_lease_expired",view["tasks"][1]["attention"])
        self.assertNotIn("reviewer_lease_expired",view["tasks"][0]["attention"])
    def test_reviewer_active_lease_not_expired(self):
        self.sql("UPDATE tasks SET status='reviewing', review_until=? WHERE task_id='P110'",
                 ("2026-11-02T01:01:00+00:00",))
        view=m.read_overview(self.root,now=NOW)
        self.assertEqual(view["tasks"][1]["review_lease_remaining_minutes"], 1)
        self.assertNotIn("reviewer_lease_expired",view["tasks"][1]["attention"])
    def test_do_not_produce_recommendations_from_overview(self):
        with patch.object(packet,"read_overview",return_value=m.read_overview(self.root,now=NOW)):
            with patch.object(packet,"coordinator",return_value={"recommended_task_id":None,"candidates":[]}) as cmd:
                result=packet.make_packet("developer-3")
        cmd.assert_called_once_with(["plan-work","developer-3"])
        self.assertEqual(result["source"],"query_only_sqlite_single_transaction")
        self.assertFalse(result["merge_intents_checked"])
        self.assertEqual(result["tasks_owned_unfinished"][0]["task_id"],"P096")
    def test_reviewer_does_not_call_cli_at_all(self):
        with patch.object(packet,"read_overview",return_value=m.read_overview(self.root,now=NOW)):
            with patch.object(packet,"coordinator",side_effect=AssertionError("not query-only")):
                result=packet.make_packet("architect-reviewer")
        self.assertEqual([x["task_id"] for x in result["review_queue"]],["P110"])
        self.assertFalse(result["authority"]["approval_granted"])
    def test_malformed_datetime_rejected(self):
        self.sql("UPDATE tasks SET activity_at=? WHERE task_id='P096'",("not a timestamp",))
        with self.assertRaisesRegex(m.ReadOnlySnapshotError,"BAD_TIMESTAMP"):
            m.read_overview(self.root,now=NOW)
    def test_bogus_owner_rejected(self):
        self.sql("UPDATE tasks SET owner=? WHERE task_id='P096'",("architect-reviewer",))
        with self.assertRaisesRegex(m.ReadOnlySnapshotError,"BAD_TASK_STATE"):
            m.read_overview(self.root,now=NOW)
    def test_available_owned_is_legal(self):
        self.sql("UPDATE tasks SET status='available',lease_until=NULL WHERE task_id='P096'")
        view=m.read_overview(self.root,now=NOW)
        self.assertEqual(view["task_counts"]["available"],1)
    def test_invalid_task_id_rejected(self):
        self.sql("UPDATE tasks SET task_id=? WHERE task_id='P096'",("../x",))
        with self.assertRaisesRegex(m.ReadOnlySnapshotError,"BAD_TASK_STATE"):
            m.read_overview(self.root,now=NOW)
    def test_unsafe_symlink_database_rejected(self):
        # Symlink tests are OS capability dependent on Windows.
        target=self.root/"safe-db.sqlite3"
        target.write_bytes(self.file.read_bytes())
        self.file.unlink()
        try:
            self.file.symlink_to(target)
        except (OSError,NotImplementedError):
            self.skipTest("Windows symlinks unavailable")
        with self.assertRaisesRegex(m.ReadOnlySnapshotError,"UNSAFE_PATH"):
            m.read_overview(self.root,now=NOW)
    def test_naive_time_rejected(self):
        with self.assertRaisesRegex(m.ReadOnlySnapshotError,"BAD_NOW"):
            m.read_overview(self.root,now=datetime(2026,11,2,1,0))
    def test_no_file_does_not_initialize_database(self):
        self.file.unlink()
        with self.assertRaisesRegex(m.ReadOnlySnapshotError,"DATABASE_UNAVAILABLE"):
            m.read_overview(self.root,now=NOW)
        self.assertFalse(self.file.exists())

if __name__=="__main__":
    unittest.main()
