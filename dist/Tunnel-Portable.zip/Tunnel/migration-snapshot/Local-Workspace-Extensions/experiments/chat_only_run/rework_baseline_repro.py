"""Create isolated baseline reproductions, retaining original sandbox files untouched.

Each baseline folder includes the original task's code and new regression test
from a proposed patch. A failure in baseline and pass in patched copy is
meaningful evidence of a behavioral regression test, not merge approval.
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import sys
from pathlib import Path
from contextlib import closing
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/"experiments"/"rework-baseline-validation"
STAGE=ROOT/"experiments"/"rework-staging"
DB=ROOT/".agent-team"/"team.sqlite3"
TASKS={"P108","P110","P111","P127","P131","P148","P149"}
def build(tid):
    if tid not in TASKS:raise ValueError("NOT_AUTHORIZED_TASK")
    with closing(sqlite3.connect(DB.resolve().as_uri()+"?mode=ro",uri=True)) as db:
        db.row_factory=sqlite3.Row
        row=db.execute("SELECT sandbox,deliverables,status FROM tasks WHERE task_id=?",(tid,)).fetchone()
    if not row or row["status"] not in ("review","reviewing"):
        raise ValueError("TASK_NO_LONGER_REVIEW")
    source=(ROOT/row["sandbox"]).resolve()
    if not source.is_relative_to((ROOT/".agent-team"/"workspaces").resolve()):
        raise ValueError("SOURCE_ESCAPE")
    stage=STAGE/tid
    metadata=json.loads((stage/"candidate_provenance.json").read_text("utf-8"))
    staged_test=stage/"test_rework_regressions.py"
    if staged_test.is_symlink() or not staged_test.is_file():
        raise ValueError("REGRESSION_MISSING")
    target=BASE/tid
    if target.exists() and list(target.iterdir()):
        raise ValueError("BASELINE_ALREADY_EXISTS")
    files={}
    for filename in json.loads(row["deliverables"]):
        if filename not in metadata["source_sha256"] or Path(filename).name!=filename:
            raise ValueError("INVALID_FILENAME")
        s=source/filename
        if s.is_symlink() or not s.is_file():raise ValueError("SYMLINK")
        data=s.read_bytes()
        if hashlib.sha256(data).hexdigest()!=metadata["source_sha256"][filename]:
            raise ValueError("SOURCE_SHA_DRIFT")
        files[filename]=data
    target.mkdir(parents=True,exist_ok=True)
    for filename,data in files.items():
        (target/filename).write_bytes(data)
    (target/"test_rework_regressions.py").write_bytes(staged_test.read_bytes())
    return {"task_id":tid,"baseline":str(target.relative_to(ROOT)).replace("\\","/"),
            "source_sha_verified":True,"tests_may_fail_as_intended":True,
            "live_queue_unchanged":True}
if __name__=="__main__":
    try:print(json.dumps({"ok":True,"data":build(sys.argv[1])},ensure_ascii=True))
    except (OSError,IndexError,ValueError,sqlite3.Error) as e:
        print(json.dumps({"ok":False,"error":str(e)[:200]},ensure_ascii=True))
        sys.exit(2)
