"""Offline security regression for F07. No live tool calls."""
import unittest
from retry_safety_advisor import classify, classify_receipt


class RetrySafetyAdvisorTests(unittest.TestCase):
    def test_100_partial_commit_receipts_never_propose_retry(self):
        effects=["READ_ONLY","IDEMPOTENT_WRITE","NON_IDEMPOTENT_WRITE","PRIVILEGED"]
        statuses=["TIMEOUT","CONNECTION_LOST","RATE_LIMITED","UNKNOWN","FAILED"]
        cases=0
        for effect in effects:
            for status in statuses:
                for proof in (False,True):
                    for receipt in (False,True):
                        for stage in ("DISPATCHED",):
                            for attacker_claim in (None,True):
                                result=classify(effect,status,stage,
                                    pre_dispatch_verified=proof,
                                    receipt_verified=receipt,
                                    client_retryable=attacker_claim)
                                self.assertNotEqual(result["category"],"READ_RETRY_CANDIDATE")
                                self.assertFalse(result["automatic_action_allowed"])
                                cases+=1
        self.assertGreaterEqual(cases,100)

    def test_attested_pre_dispatch_read_is_only_advice(self):
        result=classify("READ_ONLY","RATE_LIMITED","NOT_DISPATCHED",
                        pre_dispatch_verified=True)
        self.assertEqual(result["category"],"READ_RETRY_CANDIDATE")
        self.assertEqual(result["advice"],"REQUIRE_HOST_BUDGET_AND_FRESH_ATTESTATION")
        self.assertFalse(result["automatic_action_allowed"])
        self.assertFalse(result["host_authentication_proven"])

    def test_unknown_or_unverified_predispatch_is_not_retry_candidate(self):
        for status in ("TIMEOUT","RATE_LIMITED","CONNECTION_LOST"):
            for stage in ("NOT_DISPATCHED","UNKNOWN","DISPATCHED"):
                result=classify("READ_ONLY",status,stage,pre_dispatch_verified=False)
                self.assertNotEqual(result["category"],"READ_RETRY_CANDIDATE")

    def test_writes_and_privileged_never_get_retry_candidate(self):
        for effect in ("IDEMPOTENT_WRITE","NON_IDEMPOTENT_WRITE","PRIVILEGED"):
            for status in ("TIMEOUT","CONNECTION_LOST","RATE_LIMITED"):
                result=classify(effect,status,"NOT_DISPATCHED",pre_dispatch_verified=True)
                self.assertNotEqual(result["category"],"READ_RETRY_CANDIDATE")

    def test_success_requires_verified_receipt(self):
        a=classify("READ_ONLY","SUCCESS","DISPATCHED",receipt_verified=False)
        b=classify("READ_ONLY","SUCCESS","DISPATCHED",receipt_verified=True)
        self.assertNotEqual(a["category"],"COMPLETED")
        self.assertEqual(b["category"],"COMPLETED")
        self.assertEqual(b["advice"],"DO_NOT_RETRY")

    def test_attested_denied_never_promoted_to_retry(self):
        x=classify("IDEMPOTENT_WRITE","DENIED","NOT_DISPATCHED",receipt_verified=True)
        self.assertEqual(x["category"],"PERMISSION_DENIED")
        self.assertEqual(x["advice"],"NEEDS_AUTHORIZED_OWNER")

    def test_model_supplied_retryable_true_is_ignored(self):
        contract={"effect":"READ_ONLY"}
        receipt={"status":"RATE_LIMITED","dispatch_stage":"NOT_DISPATCHED",
                 "retryable":True,"pre_dispatch_verified":True,
                 "receipt_verified":True}
        x=classify_receipt(contract,receipt)
        self.assertNotEqual(x["category"],"READ_RETRY_CANDIDATE")
        self.assertFalse(x["host_authentication_proven"])
        self.assertFalse(x["automatic_action_allowed"])

    def test_client_reported_success_never_becomes_verified(self):
        x=classify_receipt({"effect":"READ_ONLY"},
                           {"status":"SUCCESS","dispatch_stage":"DISPATCHED",
                            "receipt_verified":True})
        self.assertNotEqual(x["category"],"COMPLETED")

    def test_invalid_policy_and_missing_fields_are_reconcile(self):
        for effect in ("",None,False,"SHELL_COMMAND","READ_ONLY"*200):
            x=classify(effect,"RATE_LIMITED","NOT_DISPATCHED",pre_dispatch_verified=True)
            self.assertEqual(x["category"],"INVALID_INPUT")
        self.assertEqual(classify_receipt({"effect":"READ_ONLY"},{}),
                         {"category":"INVALID_INPUT","advice":"RECONCILE","automatic_action_allowed":False})

    def test_bad_bool_types_cannot_forge_trust(self):
        for proof in ("true",1,[],{}):
            x=classify("READ_ONLY","RATE_LIMITED","NOT_DISPATCHED",
                       pre_dispatch_verified=proof)
            self.assertEqual(x["category"],"INVALID_INPUT")

    def test_bounded_receipt_shape_and_keys(self):
        x=classify_receipt({"effect":"READ_ONLY"},dict.fromkeys([str(i) for i in range(13)]))
        self.assertEqual(x["category"],"INVALID_INPUT")
        y=classify_receipt({"effect":"READ_ONLY", "x"*130:1},
                           {"status":"RATE_LIMITED","dispatch_stage":"NOT_DISPATCHED"})
        self.assertEqual(y["category"],"INVALID_INPUT")

    def test_lost_reply_after_dispatch_always_requires_reconciliation(self):
        for effect in ("READ_ONLY","IDEMPOTENT_WRITE","NON_IDEMPOTENT_WRITE","PRIVILEGED"):
            for status in ("TIMEOUT","CONNECTION_LOST"):
                x=classify(effect,status,"DISPATCHED",pre_dispatch_verified=True)
                self.assertEqual(x["category"],"UNKNOWN_AFTER_POSSIBLE_DISPATCH")
                self.assertEqual(x["advice"],"RECONCILE")


if __name__=="__main__":
    unittest.main()
