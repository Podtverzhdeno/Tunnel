"""Cooperative architect support queue for idle scheduled developers.

Priority is always coding, then independent peer review, then scoped architect
support. This separate advisory SQLite ledger never accepts/rejects live tasks,
modifies task sandboxes, changes canonical specs or assumes host actor identity.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import secrets
import sqlite3
import sys
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
DB=ROOT/".agent-team"/"architect_support.sqlite3"
REPORT_ROOT=ROOT/".agent-team"/"architect-support-packets"
MAX_REPORT=20000
TTL=timedelta(minutes=45)
ROLES={"developer-1","developer-2","developer-3","developer-4"}
KEY_RE=re.compile(r"(?:P[0-9]{3}:(?:regression|reliability|architecture)|F:developer-[1-4]:F(?:0[1-9]|1[0-9]|20):evidence)\Z")
REQUEST=re.compile(r"[a-zA-Z0-9][a-zA-Z0-9._:-]{7,127}\Z")
VERDICTS={"CONFIRMED_DEFECT","NEGATIVE_TESTS_PASS","UNVERIFIED","FEATURE_RECOMMENDATION","FEATURE_REJECT_RECOMMENDATION"}
class SupportError(ValueError):pass

def utcnow():return datetime.now(timezone.utc)
def stamp(t):return t.isoformat(timespec="seconds")
def exclusions(role):
    if role not in ROLES:raise SupportError("INVALID_ROLE")
    return {"developer-3","developer-4"} if role in ("developer-3","developer-4") else {role}
def safe_bytes(path,maxbytes=MAX_REPORT):
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)() or not path.is_file():
        raise SupportError("UNSAFE_OR_MISSING_FILE")
    if path.stat().st_size>maxbytes:raise SupportError("OVERSIZED_FILE")
    return path.read_bytes()
def read_db(path=DB):
    if not path.exists():return {}
    if path.is_symlink() or not path.is_file():raise SupportError("UNSAFE_SUPPORT_DB")
    with closing(sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True,timeout=5)) as db:
        db.row_factory=sqlite3.Row;db.execute("PRAGMA query_only=ON")
        return {r["work_key"]:dict(r) for r in db.execute("SELECT * FROM support_tasks")}
def open_write_db(path=DB):
    if path.is_symlink() or getattr(path,"is_junction",lambda:False)():raise SupportError("UNSAFE_SUPPORT_DB")
    path.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(str(path),isolation_level=None,timeout=15)
    db.row_factory=sqlite3.Row
    db.execute("PRAGMA busy_timeout=15000")
    db.execute("""CREATE TABLE IF NOT EXISTS support_tasks (
         work_key TEXT PRIMARY KEY, reviewer_role TEXT NOT NULL, request_id TEXT NOT NULL,
         token_digest TEXT NOT NULL, source_digest TEXT NOT NULL, status TEXT NOT NULL,
         lease_until TEXT, report_sha256 TEXT, verdict TEXT, finished_at TEXT)""")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS support_request ON support_tasks(reviewer_role,request_id)")
    db.execute("""CREATE TABLE IF NOT EXISTS support_attempts (
        attempt_id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_key TEXT NOT NULL, reviewer_role TEXT NOT NULL,
        request_id TEXT NOT NULL, source_digest TEXT NOT NULL,
        started_at TEXT NOT NULL, finished_at TEXT,
        result TEXT NOT NULL, verdict TEXT, report_sha256 TEXT,
        UNIQUE(reviewer_role,request_id))""")
    db.execute("CREATE INDEX IF NOT EXISTS support_attempt_by_work ON support_attempts(work_key,attempt_id)")
    return db
def peer_evidence_valid(peer,task_id,root=ROOT):
    """Never derive support work from a tampered or mismatched peer report."""
    if not isinstance(peer,dict) or peer.get("status")!="completed":
        return False
    if not re.fullmatch(r"P[0-9]{3}",task_id):
        return False
    reviewer=peer.get("reviewer_role")
    if reviewer not in ROLES:return False
    digest=peer.get("report_sha256")
    if not isinstance(digest,str) or not re.fullmatch(r"[0-9a-f]{64}",digest):
        return False
    path=root/".agent-team"/"peer-review-packets"/reviewer/(task_id+".json")
    try:
        # Parent symlink/junction must not escape the exact evidence root.
        expected=(root/".agent-team"/"peer-review-packets").resolve()
        if not path.resolve().is_relative_to(expected):
            return False
        if any(part.is_symlink() or getattr(part,"is_junction",lambda:False)()
               for part in (path,path.parent,path.parent.parent)):
            return False
        raw=safe_bytes(path,16384)
        if hashlib.sha256(raw).hexdigest()!=digest:return False
        document=json.loads(raw.decode("utf-8"))
        from peer_review_switch import validate_report
        validate_report(document,task_id,reviewer)
        return document["verdict"]==peer.get("verdict")
    except (OSError,ValueError,TypeError,KeyError,UnicodeError):
        return False


def source_candidates(role,root=ROOT,main=None):
    if role not in ROLES:raise SupportError("INVALID_ROLE")
    from peer_review_switch import get_live, fingerprint, read_peer_state
    from feature_idea_gate import catalog, proposal_path, safe_json, architect_decisions
    tasks,authors=get_live(root/".agent-team"/"team.sqlite3")
    peers=read_peer_state(root/".agent-team"/"peer_reviews.sqlite3")
    out=[]
    exclude=exclusions(role)
    for ident,item in sorted(tasks.items()):
        if item["status"] not in ("review","reviewing"):continue
        if ({item["role_hint"],item["owner"]}|authors.get(ident,set()))&exclude:continue
        if item["status"]=="reviewing":
            exp=item.get("review_until")
            if not isinstance(exp,str):continue
            try:
                if datetime.fromisoformat(exp)>utcnow():continue
            except ValueError:continue
        peer=peers.get(ident)
        if not peer or not peer_evidence_valid(peer,ident,root):continue
        try:
            digest=fingerprint(item,root)
            if digest!=peer["source_digest"]:continue
        except (ValueError,OSError,TypeError):continue
        # Architect support is an *additional*, distinct focused investigation,
        # not a repetition of the previous peer review.
        if peer["verdict"]=="CHANGES_REQUESTED":
            out.append({"work_key":ident+":regression","kind":"regression",
                "detail":"Independently reproduce or refute peer claim with bounded minimal negative test, immutable source SHA and real job status",
                "source_digest":digest,"peer_verdict":peer["verdict"],"task_id":ident})
        out.extend([
            {"work_key":ident+":reliability","kind":"reliability",
             "detail":"Check an independent failure, concurrency, recovery or security threat not already tested by peer; supply a reproducible witness or narrow risk ledger",
             "source_digest":digest,"peer_verdict":peer["verdict"],"task_id":ident},
            {"work_key":ident+":architecture","kind":"architecture",
             "detail":"Assess cohesion/complexity/scale and independently verify QA evidence/claims; propose bounded refactoring and reproducible risk tests, no source edits",
             "source_digest":digest,"peer_verdict":peer["verdict"],"task_id":ident},
        ])
    portfolio=catalog(root)
    decision_state=architect_decisions(root) if portfolio["all_ready"] else {"ready":False}
    if decision_state.get("ready"):
        approved_advisory=set(decision_state["promoted_to_owner_proposal"])
        w=portfolio["wave"]
        path=root/".agent-team"/"feature-proposals"/w/"architect_decisions.json"
        if path.is_file():
            try:
                decision=safe_json(path)
                if decision["wave"]!=w or decision["schema"]!="architect-feature-decisions-v1":
                    raise SupportError("INVALID_ARCH_WAVE")
                dec_sha=hashlib.sha256(safe_bytes(path,400000)).hexdigest()
                for d in decision["decisions"]:
                    if (d.get("decision")!="PROMOTE_FOR_OWNER_SPEC_APPROVAL"
                            or d.get("feature_id") not in approved_advisory):continue
                    member,fid=d["feature_id"].split(":")
                    if member in exclude:continue
                    pp=proposal_path(member,root)
                    srcsha=hashlib.sha256(safe_bytes(pp,400000)).hexdigest()
                    key="F:"+member+":"+fid+":evidence"
                    if not KEY_RE.fullmatch(key):continue
                    source=hashlib.sha256(json.dumps([w,d["feature_id"],srcsha,dec_sha]).encode()).hexdigest()
                    out.append({"work_key":key,"kind":"feature_evidence","detail":
                        "Independently challenge promoted feature assumptions, compare alternatives and costs, design falsifiable safety/scale/performance experiments and objective reject criteria",
                        "source_digest":source,"feature_id":d["feature_id"]})
            except (KeyError,TypeError,ValueError,UnicodeError,IndexError):
                pass  # Untrusted incomplete decision file cannot grant any task.
    return out

def available(role,entries,records,now,prefer_features=False):
    options=[]
    for item in entries:
        rec=records.get(item["work_key"])
        if rec:
            if rec["source_digest"]==item["source_digest"] and rec["status"]=="completed":
                continue
            if rec["status"]=="claimed" and rec["lease_until"]:
                try:
                    if datetime.fromisoformat(rec["lease_until"])>now:continue
                except ValueError:continue
        options.append(item)
    # Complete conflicting peer findings and practical regressions before
    # lower-priority architecture or speculative feature evidence.
    order=({"feature_evidence":0,"regression":1,"reliability":2,"architecture":3}
           if prefer_features else
           {"regression":0,"reliability":1,"architecture":2,"feature_evidence":3})
    return sorted(options,key=lambda x:(order[x["kind"]],x["work_key"]))

def active_claims(role,records,now):
    """An advisory role gets at most one NEW active claim; expose legacy overlaps."""
    exclusions(role)
    found=[]
    for r in records.values():
        if r.get("reviewer_role")!=role or r.get("status")!="claimed":
            continue
        value=r.get("lease_until")
        invalid=False
        try:
            expiry=datetime.fromisoformat(value)
            if expiry.tzinfo is None or expiry.utcoffset() is None:
                invalid=True
            elif expiry<=now:
                continue
        except (TypeError,ValueError,OverflowError):
            invalid=True
        # A malformed live claim is NOT evidence that its lease expired:
        # fail closed until explicit trusted reconciliation, never give a
        # second claim to the same role based on a broken timestamp.
        found.append({"work_key":r["work_key"],
                      "lease_until":value if isinstance(value,str) else None,
                      "source_digest":r["source_digest"],
                      "invalid_lease_record":invalid})
    return sorted(found,key=lambda x:x["work_key"])


def plan(role,*,root=ROOT,db=DB,code_plan=None,peer_plan=None,now=None,prefer_features=False,blocked_code_reason=None):
    exclusions(role)
    # Advisory-only fallback for an independently identified host role-identity
    # gap. This is NOT proof of a denied grant or any host authorization.
    # It NEVER changes the main queue and cannot authorize a coding lease.
    if blocked_code_reason not in (None, "HOST_ACTOR_UNVERIFIED"):
        raise SupportError("INVALID_BLOCKED_CODE_REASON")
    if code_plan is None:
        from peer_review_switch import developer_plan
        code_plan=developer_plan
    if peer_plan is None:
        from peer_review_switch import plan as peer_scheduler
        peer_plan=peer_scheduler
    coding=code_plan(role)
    if coding and blocked_code_reason is None:
        return {"mode":"coding","recommended_code_task":coding,"role":role,
                "host_actor_authenticated":False,"architect_accept_allowed":False}
    peer=peer_plan(role)
    if peer.get("mode")=="peer_review" and peer.get("recommended_peer_task"):
        return {"mode":"peer_review","recommended_peer_task":peer["recommended_peer_task"],
                "role":role,"host_actor_authenticated":False,"architect_accept_allowed":False}
    now=now or utcnow()
    records=read_db(db)
    owned=active_claims(role,records,now)
    if owned:
        return {"mode":"resume_support","role":role,
                "active_support_tasks":owned,
                "multiple_active_legacy_leases":len(owned)>1,
                "recommended_support_task":None,"support_candidates":[],
                "available_count":0,"host_actor_authenticated":False,
                "architect_accept_allowed":False,"main_queue_mutated":False,
                "next":"Finish existing advisory report using original token; no extra claims. If token lost or source drifted, allow lease to expire and recover according to policy."}
    entries=source_candidates(role,root)
    options=available(role,entries,records,now,prefer_features=prefer_features)
    return {"mode":"architect_support" if options else "idle",
            "role":role,"recommended_support_task":options[0] if options else None,
            "support_candidates":[x["work_key"] for x in options[:20]],
            "available_count":len(options),"host_actor_authenticated":False,
            "architect_accept_allowed":False,"main_queue_mutated":False,
            "blocked_code_reason":blocked_code_reason if coding else None,
            "coding_candidate_skipped_as_unverified":bool(coding and blocked_code_reason),
            "not_a_host_authorization":True,
            "next":"After each completed support report re-run plan; verified coding and fresh peer review win. Advisory fallback does not authorize code."}

def report_path(role,key,root=ROOT):
    exclusions(role)
    if not KEY_RE.fullmatch(key):raise SupportError("INVALID_KEY")
    return root/".agent-team"/"architect-support-packets"/role/(key.replace(":","-")+".json")

def claim(role,key,request_id,*,root=ROOT,db=DB,code_plan=None,peer_plan=None,now=None,blocked_code_reason=None):
    exclusions(role)
    if not KEY_RE.fullmatch(key):raise SupportError("INVALID_KEY")
    if not REQUEST.fullmatch(request_id):raise SupportError("INVALID_REQUEST")
    now=now or utcnow()
    if active_claims(role,read_db(db),now):
        raise SupportError("ROLE_HAS_ACTIVE_SUPPORT_LEASE")
    current=plan(role,root=root,db=db,code_plan=code_plan,peer_plan=peer_plan,now=now,blocked_code_reason=blocked_code_reason)
    if current["mode"]!="architect_support":raise SupportError("HIGHER_PRIORITY_OR_NO_WORK")
    entries={x["work_key"]:x for x in source_candidates(role,root)}
    if key not in entries:raise SupportError("UNAVAILABLE_OR_SELF_ASSIGNED")
    entry=entries[key]
    with closing(open_write_db(db)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            rows={r["work_key"]:dict(r) for r in conn.execute("SELECT * FROM support_tasks")}
            if active_claims(role,rows,now):
                raise SupportError("ROLE_HAS_ACTIVE_SUPPORT_LEASE")
            if not any(x["work_key"]==key for x in available(role,list(entries.values()),rows,now)):
                raise SupportError("ALREADY_CLAIMED_OR_COMPLETED")
            # Historical request IDs must not be replayed after a task row was
            # overwritten by a subsequent (expired) owner. The append-only
            # attempts ledger keeps all request IDs without storing any tokens.
            if conn.execute("SELECT 1 FROM support_attempts WHERE reviewer_role=? AND request_id=?",
                            (role,request_id)).fetchone():
                raise SupportError("REQUEST_ALREADY_USED")
            if any(r["reviewer_role"]==role and r["request_id"]==request_id for r in rows.values()):
                raise SupportError("REQUEST_ALREADY_USED")
            previous=rows.get(key)
            if previous and previous["status"]=="claimed":
                conn.execute("""UPDATE support_attempts
                    SET result='superseded',finished_at=?
                    WHERE work_key=? AND request_id=? AND result='claimed'""",
                    (stamp(now),key,previous["request_id"]))
            token=secrets.token_urlsafe(32)
            conn.execute("""INSERT INTO support_tasks
                 (work_key,reviewer_role,request_id,token_digest,source_digest,status,lease_until)
                 VALUES(?,?,?,?,?,'claimed',?)
                 ON CONFLICT(work_key) DO UPDATE SET
                 reviewer_role=excluded.reviewer_role,request_id=excluded.request_id,
                 token_digest=excluded.token_digest,source_digest=excluded.source_digest,
                 status='claimed',lease_until=excluded.lease_until,report_sha256=NULL,
                 verdict=NULL,finished_at=NULL""",
                 (key,role,request_id,hashlib.sha256(token.encode()).hexdigest(),
                  entry["source_digest"],stamp(now+TTL)))
            conn.execute("""INSERT INTO support_attempts
                    (work_key,reviewer_role,request_id,source_digest,started_at,result)
                    VALUES(?,?,?,?,?,'claimed')""",
                    (key,role,request_id,entry["source_digest"],stamp(now)))
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    return {"work_key":key,"role":role,"kind":entry["kind"],
            "source_digest":entry["source_digest"],"lease_token":token,
            "expires":stamp(now+TTL),"report_file":str(report_path(role,key,root).relative_to(root)),
            "no_formal_accept":True,"no_canonical_writes":True}

ABANDON_REASONS={"CODING_PREEMPTED","SOURCE_CHANGED","INVALID_SOURCE",
                 "UNABLE_TO_COMPLETE","ROLE_WORK_HANDOFF"}

def abandon(role,key,token,reason,*,root=ROOT,db=DB,now=None):
    """Voluntary abandonment of an advisory task, fenced by its own token.

    Does not delete bytes, change any code/peer/reviewer state, or give grants.
    Even an expired or malformed legacy lease can be safely relinquished if
    the unchanged bearer token still matches the current row.
    """
    exclusions(role)
    if not KEY_RE.fullmatch(key):raise SupportError("INVALID_KEY")
    if reason not in ABANDON_REASONS:raise SupportError("INVALID_ABANDON_REASON")
    if not isinstance(token,str) or len(token)>256:raise SupportError("TOKEN_INVALID")
    now=now or utcnow()
    digest=hashlib.sha256(token.encode()).hexdigest()
    with closing(open_write_db(db)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            row=conn.execute("SELECT * FROM support_tasks WHERE work_key=?",(key,)).fetchone()
            if not row or row["status"]!="claimed" or row["reviewer_role"]!=role:
                raise SupportError("ACTIVE_LEASE_NOT_FOUND")
            if not secrets.compare_digest(row["token_digest"],digest):
                raise SupportError("TOKEN_INVALID")
            conn.execute("""UPDATE support_tasks SET status='abandoned',lease_until=NULL,
                         verdict=NULL,finished_at=? WHERE work_key=? AND
                         reviewer_role=? AND status='claimed' AND token_digest=?""",
                         (stamp(now),key,role,digest))
            conn.execute("""UPDATE support_attempts SET result='abandoned',
                         finished_at=? WHERE work_key=? AND reviewer_role=? AND
                         request_id=? AND result='claimed'""",
                         (stamp(now),key,role,row["request_id"]))
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    return {"work_key":key,"status":"advisory_abandoned","reason":reason,
            "released_for_replan":True,"formal_accept":False,
            "main_queue_modified":False,"host_actor_authenticated":False}

def validate_report(data,key,role,digest):
    required={"work_key","role","source_digest","verdict","summary","findings","checks",
              "recommendations","limitations"}
    if not isinstance(data,dict) or set(data)!=required:raise SupportError("REPORT_SCHEMA")
    if data["work_key"]!=key or data["role"]!=role or data["source_digest"]!=digest:
        raise SupportError("REPORT_MISMATCH")
    if data["verdict"] not in VERDICTS:raise SupportError("VERDICT_INVALID")
    if not isinstance(data["summary"],str) or not 100<=len(data["summary"])<=3500:
        raise SupportError("SUMMARY_WEAK")
    for k,n in (("findings",2),("checks",2),("recommendations",1),("limitations",1)):
        values=data[k]
        if (not isinstance(values,list) or not n<=len(values)<=18 or
                any(not isinstance(v,str) or not 35<=len(v)<=1200 for v in values)):
            raise SupportError("REPORT_WEAK_"+k.upper())
    return data

def complete(role,key,token,*,root=ROOT,db=DB,now=None):
    exclusions(role)
    if not KEY_RE.fullmatch(key):raise SupportError("INVALID_KEY")
    now=now or utcnow()
    records=read_db(db)
    r=records.get(key)
    if not r or r["reviewer_role"]!=role or r["status"]!="claimed":raise SupportError("LEASE_MISSING")
    if not isinstance(token,str) or not secrets.compare_digest(r["token_digest"],hashlib.sha256(token.encode()).hexdigest()):
        raise SupportError("TOKEN_INVALID")
    if datetime.fromisoformat(r["lease_until"])<=now:raise SupportError("LEASE_EXPIRED")
    latest={x["work_key"]:x for x in source_candidates(role,root)}.get(key)
    if not latest or latest["source_digest"]!=r["source_digest"]:raise SupportError("SOURCE_DRIFT")
    path=report_path(role,key,root)
    raw=safe_bytes(path)
    try:data=json.loads(raw.decode("utf-8"))
    except (UnicodeError,ValueError) as e:raise SupportError("REPORT_UNPARSABLE") from e
    validate_report(data,key,role,r["source_digest"])
    digest=hashlib.sha256(raw).hexdigest()
    with closing(open_write_db(db)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            row=conn.execute("SELECT * FROM support_tasks WHERE work_key=?",(key,)).fetchone()
            if (not row or row["status"]!="claimed" or row["token_digest"]!=r["token_digest"] or
                    row["source_digest"]!=r["source_digest"]):
                raise SupportError("LEASE_CHANGED")
            conn.execute("""UPDATE support_tasks SET status='completed',report_sha256=?,
                    verdict=?,finished_at=?,lease_until=NULL WHERE work_key=?""",
                    (digest,data["verdict"],stamp(now),key))
            # Legacy pre-migration leases have no recorded start timestamp.
            # Their completion remains valid, but no duration is invented.
            conn.execute("""UPDATE support_attempts
                 SET result='completed',finished_at=?,verdict=?,report_sha256=?
                 WHERE work_key=? AND reviewer_role=? AND request_id=? AND result='claimed'""",
                 (stamp(now),data["verdict"],digest,key,role,r["request_id"]))
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK");raise
    return {"work_key":key,"status":"advisory_support_completed","verdict":data["verdict"],
            "report_sha256":digest,"main_queue_modified":False,"formal_accept":False}

def attempt_history(db=DB):
    """Bounded, read-only attempt timing window; never infer model token usage."""
    path=Path(db)
    if not path.exists():
        return {"recorded_attempts":0,"sample_size":0,"truncated":False,
                "by_role":{},"recent":[],"legacy_unmeasured_possible":True}
    if path.is_symlink() or not path.is_file():raise SupportError("UNSAFE_SUPPORT_DB")
    with closing(sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True,timeout=5)) as conn:
        conn.row_factory=sqlite3.Row
        conn.execute("PRAGMA query_only=ON")
        available=conn.execute("""SELECT 1 FROM sqlite_master
                                  WHERE type='table' AND name='support_attempts'""").fetchone()
        if not available:
            return {"recorded_attempts":0,"sample_size":0,"truncated":False,
                    "by_role":{},"recent":[],"legacy_unmeasured_possible":True}
        total=conn.execute("SELECT COUNT(*) FROM support_attempts").fetchone()[0]
        rows=conn.execute("""SELECT work_key,reviewer_role,source_digest,
                         started_at,finished_at,result,verdict,report_sha256
                         FROM support_attempts ORDER BY attempt_id DESC LIMIT 500""").fetchall()
    roles={}
    recent=[]
    for row in rows:
        item=dict(row)
        elapsed=None
        if item["finished_at"] and item["started_at"]:
            try:
                start=datetime.fromisoformat(item["started_at"])
                end=datetime.fromisoformat(item["finished_at"])
                if start.tzinfo is not None and end.tzinfo is not None:
                    seconds=(end-start).total_seconds()
                    if 0<=seconds<=TTL.total_seconds()+3600:
                        elapsed=int(seconds)
            except (TypeError,ValueError,OverflowError):
                pass
        role=item["reviewer_role"]
        aggregate=roles.setdefault(role,{"completed":0,"superseded":0,"abandoned":0,
                                         "claimed":0,"measured_completed":0,
                                         "total_completed_seconds":0})
        status=item["result"]
        if status in ("completed","superseded","abandoned","claimed"):
            aggregate[status]+=1
        if status=="completed" and elapsed is not None:
            aggregate["measured_completed"]+=1
            aggregate["total_completed_seconds"]+=elapsed
        if len(recent)<15:
            recent.append({"work_key":item["work_key"],"reviewer_role":role,
                           "status":status,"started_at":item["started_at"],
                           "finished_at":item["finished_at"],"elapsed_seconds":elapsed,
                           "verdict":item["verdict"]})
    for stats in roles.values():
        n=stats["measured_completed"]
        stats["average_completed_seconds"]=round(stats["total_completed_seconds"]/n,1) if n else None
    return {"recorded_attempts":total,"sample_size":len(rows),
            "truncated":total>len(rows),"by_role":roles,"recent":recent,
            "legacy_unmeasured_possible":True,
            "note":"Only per-attempt lease-to-report durations, not model execution, provider usage or cost."}

def overview(*,root=ROOT,db=DB):
    rows=[]
    for key,r in sorted(read_db(db).items()):
        path=report_path(r["reviewer_role"],key,root)
        try:
            matching=r["status"]=="completed" and hashlib.sha256(safe_bytes(path)).hexdigest()==r["report_sha256"]
        except (SupportError,OSError):matching=False
        rows.append({"work_key":key,"reviewer_role":r["reviewer_role"],"status":r["status"],
                     "verdict":r["verdict"],"report_matches":matching,
                     "report_path":str(path.relative_to(root)), "finished_at":r["finished_at"]})
    return {"count":len(rows),"reports":rows,"attempt_history":attempt_history(db),
            "host_identity_attested":False,"formal_accepts":0}

def main(args=None):
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest="action",required=True)
    pp=sub.add_parser("plan");pp.add_argument("role",choices=sorted(ROLES));pp.add_argument("--prefer-features",action="store_true")
    pp.add_argument("--blocked-code-host-unverified",action="store_true",
                    help="Advisory fallback only: skip a coding suggestion lacking host actor proof")
    cc=sub.add_parser("claim");cc.add_argument("role",choices=sorted(ROLES));cc.add_argument("work_key");cc.add_argument("request_id")
    cc.add_argument("--blocked-code-host-unverified",action="store_true",
                    help="Acquire only a non-formal advisory report lease; never a code grant")
    zz=sub.add_parser("complete");zz.add_argument("role",choices=sorted(ROLES));zz.add_argument("work_key");zz.add_argument("lease_token")
    xx=sub.add_parser("abandon");xx.add_argument("role",choices=sorted(ROLES));xx.add_argument("work_key");xx.add_argument("lease_token");xx.add_argument("reason",choices=sorted(ABANDON_REASONS))
    sub.add_parser("overview")
    a=p.parse_args(args)
    try:
        if a.action=="plan":result=plan(a.role,prefer_features=a.prefer_features,
                blocked_code_reason="HOST_ACTOR_UNVERIFIED" if a.blocked_code_host_unverified else None)
        elif a.action=="claim":result=claim(a.role,a.work_key,a.request_id,
                blocked_code_reason="HOST_ACTOR_UNVERIFIED" if a.blocked_code_host_unverified else None)
        elif a.action=="complete":result=complete(a.role,a.work_key,a.lease_token)
        elif a.action=="abandon":result=abandon(a.role,a.work_key,a.lease_token,a.reason)
        else:result=overview()
        print(json.dumps({"ok":True,"data":result},ensure_ascii=True))
        return 0
    except (SupportError,ValueError,TypeError,KeyError,OSError,sqlite3.Error) as e:
        print(json.dumps({"ok":False,"error":str(e)[:190]},ensure_ascii=True))
        return 2

if __name__=="__main__":sys.exit(main())
