import unittest
from test_crash_reconcile_plan import fixture,classify
class ReworkRegression(unittest.TestCase):
    def test_non_done_with_acceptance_recorded_blocks(self):
        for status in ("working","review","reviewing"):
            with self.subTest(status=status):
                data=fixture()
                data["task"]["status"]=status
                data["task"]["acceptance_recorded"]=True
                result=classify(data)
                self.assertEqual(result["classification"],"BLOCKED",result)
                self.assertIn("INCONSISTENT_COMMIT",result["incident_codes"],result)
                self.assertFalse(result["automatic_recovery_authorized"])
