"""P110: adversarial offline crash-reconciliation contract tests."""
from __future__ import annotations

import copy
import json
import unittest
from unittest import mock

import crash_reconcile_plan as subject

BEFORE = "a" * 64
TARGET = "b" * 64
OTHER = "c" * 64
NOW = "2026-11-01T22:00:00+00:00"


def fixture(state="prepared"):
    return {
        "task": {
            "task_id": "P110", "status": "working",
            "lease_until": "2026-11-01T23:00:00+00:00",
            "acceptance_recorded": False,
        },
        "journal": {
            "state": state, "sqlite_committed": False,
            "files": [{
                "path": "src/файл.py", "before_sha256": BEFORE,
                "target_sha256": TARGET, "current_sha256": BEFORE,
                "staged_sha256": None, "stage_state": "missing",
                "cas_ok": True, "is_symlink": False,
            }],
        },
    }


def classify(data, now=NOW):
    return subject.plan_crash_reconciliation(data, now_utc=now)


class ReconcilePlanTests(unittest.TestCase):
    def assert_class(self, doc, expected, code=None):
        result = classify(doc)
        self.assertEqual(expected, result["classification"], result)
        if code:
            self.assertIn(code, result["incident_codes"], result)
        self.assertFalse(result["automatic_recovery_authorized"])
        self.assertTrue(result["owner_action_required"])
        self.assertFalse(result["host_actor_verified"])
        self.assertEqual("caller_supplied_unverified", result["evidence_provenance"])
        self.assertNotIn("src/файл.py", json.dumps(result, ensure_ascii=False))
        return result

    def test_prepared_no_changes_safe_to_inspect_only(self):
        self.assert_class(fixture(), "SAFE_TO_INSPECT")
    
    def test_prepared_with_staged_file(self):
        doc = fixture()
        file = doc["journal"]["files"][0]
        file["staged_sha256"] = TARGET
        file["stage_state"] = "staged"
        self.assert_class(doc, "SAFE_TO_INSPECT")

    def test_partial_application_requires_manual_review(self):
        doc = fixture("applying")
        doc["journal"]["files"].append({
            **doc["journal"]["files"][0], "path": "src/second.py",
            "current_sha256": TARGET, "stage_state": "applied",
            "staged_sha256": TARGET,
        })
        self.assert_class(doc, "MANUAL_REVIEW")

    def test_applied_before_commit_manual(self):
        doc = fixture("applied")
        file = doc["journal"]["files"][0]
        file.update(current_sha256=TARGET, staged_sha256=TARGET, stage_state="applied")
        self.assert_class(doc, "MANUAL_REVIEW")

    def test_committed_done_not_self_authorized(self):
        doc = fixture("committed")
        doc["journal"]["sqlite_committed"] = True
        doc["task"].update(status="done", lease_until=None, acceptance_recorded=True)
        doc["journal"]["files"][0].update(
            current_sha256=TARGET, staged_sha256=TARGET, stage_state="applied"
        )
        doc["validation"] = {"openspec_pass": True, "sdd_pass": True}
        self.assert_class(doc, "MANUAL_REVIEW")

    def test_committed_missing_validation_blocked(self):
        doc = fixture("committed")
        doc["journal"]["sqlite_committed"] = True
        doc["task"].update(status="done", lease_until=None, acceptance_recorded=True)
        doc["journal"]["files"][0].update(
            current_sha256=TARGET, staged_sha256=TARGET, stage_state="applied"
        )
        self.assert_class(doc, "MANUAL_REVIEW", "UNVERIFIED_VALIDATION")

    def test_failed_cas_blocked(self):
        doc = fixture()
        doc["journal"]["files"][0]["cas_ok"] = False
        self.assert_class(doc, "BLOCKED", "CAS_FAILED")

    def test_divergent_user_edit_blocked(self):
        doc = fixture("applying")
        doc["journal"]["files"][0]["current_sha256"] = OTHER
        self.assert_class(doc, "BLOCKED", "DIVERGENT_USER_EDIT")

    def test_missing_file_blocked(self):
        doc = fixture()
        doc["journal"]["files"][0]["current_sha256"] = None
        self.assert_class(doc, "BLOCKED", "MISSING_FILE")

    def test_staged_hash_mismatch(self):
        doc = fixture()
        doc["journal"]["files"][0].update(stage_state="staged", staged_sha256=OTHER)
        self.assert_class(doc, "BLOCKED", "STAGED_HASH_MISMATCH")

    def test_applied_state_with_before_hash(self):
        doc = fixture("applying")
        doc["journal"]["files"][0].update(stage_state="applied", staged_sha256=TARGET)
        self.assert_class(doc, "BLOCKED", "APPLIED_HASH_MISMATCH")

    def test_applied_journal_with_partial_files(self):
        doc = fixture("applied")
        self.assert_class(doc, "BLOCKED", "INCONSISTENT_APPLIED")

    def test_prepared_with_applied_file(self):
        doc = fixture("prepared")
        doc["journal"]["files"][0].update(
            current_sha256=TARGET, staged_sha256=TARGET, stage_state="applied")
        self.assert_class(doc, "BLOCKED", "INCONSISTENT_PREPARED")

    def test_committed_with_unapplied_hash(self):
        doc = fixture("committed")
        doc["journal"]["sqlite_committed"] = True
        doc["task"].update(status="done", lease_until=None, acceptance_recorded=True)
        doc["validation"] = {"openspec_pass": True, "sdd_pass": True}
        self.assert_class(doc, "BLOCKED", "COMMITTED_HASH_MISMATCH")

    def test_forged_done(self):
        doc = fixture()
        doc["task"].update(status="done", lease_until=None, acceptance_recorded=True)
        self.assert_class(doc, "BLOCKED", "FORGED_DONE")

    def test_fake_accepted_status(self):
        doc = fixture("committed")
        doc["task"].update(status="done", lease_until=None, acceptance_recorded=False)
        self.assert_class(doc, "BLOCKED", "FORGED_DONE")

    def test_expired_lease(self):
        doc = fixture()
        doc["task"]["lease_until"] = "2026-11-01T21:59:59+00:00"
        self.assert_class(doc, "MANUAL_REVIEW", "EXPIRED_LEASE")

    def test_malformed_timestamp(self):
        doc = fixture()
        doc["task"]["lease_until"] = "2026-99-99"
        self.assert_class(doc, "UNKNOWN", "INVALID_TIMESTAMP")

    def test_naive_timestamp(self):
        self.assertIn("INVALID_TIMESTAMP", classify(fixture(), now="2026-11-01T22:00:00")["incident_codes"])

    def test_unknown_journal_state(self):
        doc = fixture("future_state")
        self.assert_class(doc, "UNKNOWN", "UNKNOWN_JOURNAL_STATE")

    def test_empty_manifest(self):
        doc = fixture()
        doc["journal"]["files"] = []
        self.assert_class(doc, "BLOCKED", "EMPTY_JOURNAL")

    def test_windows_path_escape(self):
        for path in ("../secret", "C:/Windows/x", r"dir\evil", "//server/share",
                     "CON.txt", "CONIN$.txt", "LPT¹.txt", "src/.git/config",
                     "a//b", "a/./b", "a/b."):
            with self.subTest(path=path):
                doc = fixture()
                doc["journal"]["files"][0]["path"] = path
                self.assert_class(doc, "BLOCKED", "UNSAFE_PATH")

    def test_windows_unicode_compatibility_escape(self):
        doc = fixture()
        doc["journal"]["files"][0]["path"] = "src/ＦＩＬＥ.txt"
        self.assert_class(doc, "BLOCKED", "UNSAFE_PATH")

    def test_symlink_claim_rejected(self):
        doc = fixture()
        doc["journal"]["files"][0]["is_symlink"] = True
        self.assert_class(doc, "BLOCKED", "UNSAFE_PATH")

    def test_casefold_duplicate(self):
        doc = fixture()
        doc["journal"]["files"].append({
            **doc["journal"]["files"][0], "path": "SRC/ФАЙЛ.py",
        })
        self.assert_class(doc, "BLOCKED", "DUPLICATE_PATH")

    def test_boolean_cas_not_number(self):
        doc = fixture()
        doc["journal"]["files"][0]["cas_ok"] = 1
        self.assert_class(doc, "UNKNOWN", "INVALID_FIELDS")

    def test_bad_stage_type_fails_closed(self):
        for stage in ([], {}, 1, None, True):
            with self.subTest(stage=stage):
                doc = fixture()
                doc["journal"]["files"][0]["stage_state"] = stage
                self.assert_class(doc, "UNKNOWN", "INVALID_STAGE")

    def test_bad_sha_type_fails_closed(self):
        doc = fixture()
        doc["journal"]["files"][0]["target_sha256"] = 1
        self.assert_class(doc, "UNKNOWN", "INVALID_HASH")

    def test_invalid_json_duplicate_key(self):
        raw = json.dumps(fixture())
        raw = raw.replace('"task":', '"task":{},"task":', 1)
        self.assert_class(raw, "UNKNOWN", "DUPLICATE_JSON_KEY")

    def test_invalid_utf8(self):
        self.assert_class(b"\xff", "UNKNOWN", "INVALID_UTF8")

    def test_oversized_evidence(self):
        self.assert_class("x" * (subject.MAX_BYTES + 1), "UNKNOWN", "EVIDENCE_TOO_LARGE")

    def test_excess_files(self):
        doc = fixture()
        doc["journal"]["files"] = [copy.deepcopy(doc["journal"]["files"][0]) for _ in range(subject.MAX_FILES + 1)]
        self.assert_class(doc, "UNKNOWN", "INVALID_FIELDS")

    def test_nested_cycles_rejected(self):
        doc = fixture()
        doc["extra"] = doc
        self.assert_class(doc, "UNKNOWN", "CYCLIC_OR_SHARED_OBJECT")

    def test_unknown_fields_rejected(self):
        doc = fixture()
        doc["owner_grant"] = "yes"
        self.assert_class(doc, "UNKNOWN", "INVALID_FIELDS")

    def test_malformed_validation_claim(self):
        doc = fixture()
        doc["validation"] = {"openspec_pass": 1, "sdd_pass": True}
        self.assert_class(doc, "UNKNOWN", "INVALID_VALIDATION")

    def test_failed_validation_is_blocked(self):
        doc = fixture()
        doc["validation"] = {"openspec_pass": False, "sdd_pass": True}
        self.assert_class(doc, "BLOCKED", "VALIDATION_FAILED")

    def test_done_with_stale_lease_is_not_trusted(self):
        doc = fixture("committed")
        doc["journal"]["sqlite_committed"] = True
        doc["task"].update(status="done", acceptance_recorded=True)
        doc["journal"]["files"][0].update(current_sha256=TARGET,
            staged_sha256=TARGET, stage_state="applied")
        doc["validation"] = {"openspec_pass": True, "sdd_pass": True}
        self.assert_class(doc, "BLOCKED", "DONE_WITH_LEASE")

    def test_committed_without_stage_proof_is_blocked(self):
        doc = fixture("committed")
        doc["journal"]["sqlite_committed"] = True
        doc["task"].update(status="done", lease_until=None, acceptance_recorded=True)
        doc["journal"]["files"][0].update(current_sha256=TARGET)
        doc["validation"] = {"openspec_pass": True, "sdd_pass": True}
        self.assert_class(doc, "BLOCKED", "COMMITTED_STAGE_EVIDENCE_MISSING")

    def test_no_side_effects_or_privileged_io(self):
        with mock.patch("builtins.open", side_effect=AssertionError("disk read")), \
             mock.patch("subprocess.run", side_effect=AssertionError("subprocess")), \
             mock.patch("sqlite3.connect", side_effect=AssertionError("sqlite")):
            self.assert_class(fixture(), "SAFE_TO_INSPECT")

    def test_repeatable_and_pure(self):
        doc = fixture()
        original = copy.deepcopy(doc)
        self.assertEqual(classify(doc), classify(doc))
        self.assertEqual(original, doc)


if __name__ == "__main__":
    unittest.main()
