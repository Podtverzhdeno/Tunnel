"""Offline, advisory classification of a bounded scheduled-agent queue snapshot.

All inputs, including host/QA flags, are caller supplied and UNTRUSTED.
No result grants a lease, host identity, review acceptance, or file access.
The function does not read SQLite, execute code, or access the filesystem.
"""
from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Any, Mapping

ROLES = ("developer-1", "developer-2", "developer-3", "developer-4")
STATUSES = frozenset({"available", "working", "review", "reviewing", "rework", "done"})
_ID = re.compile(r"P[0-9]{3,6}\Z", re.ASCII)
_MAX_TASKS = 512
_MAX_DEPENDENCIES = 64
_MAX_TEXT = 128

# Diagnostic precedence, not permission or scheduler priority.
_RANK = {
    "ready": 0,
    "missing_host_authorization": 1,
    "stale_source": 2,
    "missing_dependency": 3,
    "expired_lease": 4,
    "active_inaccessible_lease": 5,
    "active_foreign_lease": 6,
    "review_waiting": 7,
    "idle_no_safe_work": 8,
}


def _fail(message: str) -> None:
    raise ValueError(message)


def _id(value: Any) -> str:
    if type(value) is not str or _ID.fullmatch(value) is None:
        _fail("invalid_task_id")
    return value


def _role(value: Any, *, nullable: bool = False) -> str | None:
    if nullable and value is None:
        return None
    if type(value) is not str or value not in ROLES:
        _fail("invalid_role")
    return value


def _timestamp(value: Any, *, nullable: bool = True) -> datetime | None:
    if value is None and nullable:
        return None
    if type(value) is not str or len(value) > 40:
        _fail("invalid_timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, OverflowError):
        _fail("invalid_timestamp")
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        _fail("timestamp_must_be_timezone_aware")
    return parsed.astimezone(timezone.utc)


def _bool(value: Any, *, default: bool = False) -> bool:
    if value is None:
        return default
    if type(value) is not bool:
        _fail("invalid_boolean")
    return value


def _task(record: Any, now: datetime) -> dict[str, Any]:
    if type(record) is not dict:
        _fail("invalid_task")
    if len(record) > 24 or any(type(k) is not str or len(k) > _MAX_TEXT for k in record):
        _fail("oversized_task_record")
    if any(type(v) is str and len(v) > _MAX_TEXT for v in record.values()):
        _fail("oversized_task_field")
    tid = _id(record.get("task_id"))
    status = record.get("status")
    if type(status) is not str or status not in STATUSES:
        _fail("invalid_status")
    owner = _role(record.get("owner"), nullable=True)
    role = _role(record.get("role_hint"))
    lease = _timestamp(record.get("lease_until"))
    submitted = _timestamp(record.get("submitted_at"))
    reviewed = _timestamp(record.get("reviewed_at"))
    activity = _timestamp(record.get("activity_at"))
    if activity is not None and activity > now:
        _fail("future_activity_timestamp")
    if status == "available" and (owner is not None or lease or submitted or reviewed):
        _fail("contradictory_available_state")
    if status in ("working", "rework", "review", "reviewing", "done") and owner is None:
        _fail("missing_task_owner")
    if status in ("review", "reviewing", "done") and submitted is None:
        _fail("missing_submission_timestamp")
    if status == "done" and reviewed is None:
        _fail("missing_review_timestamp")
    if status != "done" and reviewed is not None:
        _fail("contradictory_review_timestamp")
    if submitted and submitted > now:
        _fail("future_submission_timestamp")
    if reviewed and (reviewed > now or (submitted and reviewed < submitted)):
        _fail("contradictory_review_timestamp")
    if status in ("available", "review", "done") and lease is not None:
        _fail("contradictory_lease")
    if status == "working" and lease is None:
        _fail("working_without_lease")
    if status == "rework" and submitted is None:
        _fail("rework_without_previous_submission")
    if status == "working" and submitted is not None:
        _fail("working_with_submission")
    if status == "rework" and reviewed is not None:
        _fail("rework_with_review_timestamp")
    dependencies = record.get("dependencies", [])
    if type(dependencies) is not list or len(dependencies) > _MAX_DEPENDENCIES:
        _fail("invalid_dependencies")
    dep_ids = [_id(x) for x in dependencies]
    if len(set(dep_ids)) != len(dep_ids) or tid in dep_ids:
        _fail("duplicate_or_self_dependency")
    qa = _bool(record.get("independently_accepted_qa_record"), default=False)
    if qa and status != "done":
        _fail("qa_receipt_for_unaccepted_task")
    # Unknown hashes are not proof of a current source or spec.
    source_ok = _bool(record.get("source_sha_matches"), default=False)
    spec_ok = _bool(record.get("spec_sha_matches"), default=False)
    priority = record.get("priority", 0)
    if type(priority) is not int or not -1000 <= priority <= 1000:
        _fail("invalid_priority")
    return {
        "task_id": tid, "status": status, "owner": owner, "role_hint": role,
        "lease_until": lease, "submitted_at": submitted, "reviewed_at": reviewed,
        "activity_at": activity,
        "dependencies": dep_ids, "qa": qa, "source_ok": source_ok,
        "spec_ok": spec_ok, "priority": priority,
    }


def _candidate(task: dict[str, Any], role: str, all_tasks: Mapping[str, dict[str, Any]],
               now: datetime, caller_host_flag: bool) -> tuple[str, str]:
    status = task["status"]
    if status == "done":
        return "idle_no_safe_work", "no_action"
    if status in ("review", "reviewing"):
        return "review_waiting", "wait_for_independent_reviewer"
    if status in ("working", "rework") and task["lease_until"] is not None:
        if task["lease_until"] > now:
            if task["owner"] == role:
                return "active_inaccessible_lease", "wait_for_lease_or_use_own_valid_token"
            return "active_foreign_lease", "do_not_steal_lease"
        return "expired_lease", "read_only_source_reconciliation_then_fresh_acquire"
    if task["owner"] not in (None, role):
        return "active_foreign_lease", "do_not_steal_lease"
    if not (task["source_ok"] and task["spec_ok"]):
        return "stale_source", "request_reviewer_source_reconciliation"
    for dep in task["dependencies"]:
        prior = all_tasks.get(dep)
        if prior is None or prior["status"] != "done" or not prior["qa"]:
            return "missing_dependency", "wait_for_independent_dependency_acceptance"
    if not caller_host_flag:
        return "missing_host_authorization", "request_host_authorized_fresh_acquire"
    # Ready means ONLY caller-snapshot queue eligibility. No host identity is verified here.
    return "ready", "request_host_authorized_fresh_acquire"


def classify_queue_snapshot(snapshot: Mapping[str, Any], *, now_utc: str | None = None) -> dict[str, Any]:
    """Return deterministic per-developer advisory diagnoses without side effects.

    Snapshot schema: tasks=[{task_id,status,role_hint,owner,lease_until,
    submitted_at,reviewed_at,dependencies,independently_accepted_qa_record,
    source_sha_matches,spec_sha_matches,priority}], agents=[{role,
    host_authorized}]. Flags are unverified statements by the caller.
    """
    if type(snapshot) is not dict:
        _fail("snapshot_must_be_object")
    raw_tasks = snapshot.get("tasks")
    raw_agents = snapshot.get("agents")
    if type(raw_tasks) is not list or len(raw_tasks) > _MAX_TASKS:
        _fail("invalid_task_count")
    if type(raw_agents) is not list or len(raw_agents) > len(ROLES):
        _fail("invalid_agent_count")
    now = _timestamp(now_utc, nullable=False) if now_utc is not None else _timestamp(
        snapshot.get("as_of_utc"), nullable=False
    )
    task_map: dict[str, dict[str, Any]] = {}
    for entry in raw_tasks:
        task = _task(entry, now)
        if task["task_id"] in task_map:
            _fail("duplicate_task_id")
        task_map[task["task_id"]] = task
    # A cyclic task graph cannot establish a trustworthy dependency closure.
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(start: str) -> None:
        stack: list[tuple[str, bool]] = [(start, False)]
        while stack:
            tid, leaving = stack.pop()
            if leaving:
                visiting.remove(tid)
                visited.add(tid)
                continue
            if tid in visited:
                continue
            if tid in visiting:
                _fail("dependency_cycle")
            visiting.add(tid)
            stack.append((tid, True))
            for dep in reversed(task_map[tid]["dependencies"]):
                if dep in task_map:
                    stack.append((dep, False))
    for tid in task_map:
        if tid not in visited:
            visit(tid)
    agent_flags: dict[str, bool] = {}
    agent_activity: dict[str, datetime | None] = {}
    for entry in raw_agents:
        if type(entry) is not dict:
            _fail("invalid_agent")
        role = _role(entry.get("role"))
        if role in agent_flags:
            _fail("duplicate_agent_role")
        if len(entry) > 6 or any(type(k) is not str or len(k) > _MAX_TEXT for k in entry):
            _fail("oversized_agent_record")
        agent_flags[role] = _bool(entry.get("host_authorized"), default=False)
        activity = _timestamp(entry.get("last_activity_at"))
        if activity is not None and activity > now:
            _fail("future_agent_activity")
        agent_activity[role] = activity
    roles: dict[str, dict[str, Any]] = {}
    for role in ROLES:
        candidates: list[dict[str, Any]] = []
        for task in task_map.values():
            if task["role_hint"] != role:
                continue
            category, action = _candidate(task, role, task_map, now, agent_flags.get(role, False))
            if category == "idle_no_safe_work":
                continue
            candidates.append({
                "task_id": task["task_id"],
                "classification": category,
                "safe_next_action": action,
                "priority": task["priority"],
                "last_activity_utc": task["activity_at"].isoformat() if task["activity_at"] else None,
                "minutes_since_activity": round((now - task["activity_at"]).total_seconds() / 60, 2) if task["activity_at"] else None,
                "lease_remaining_minutes": round((task["lease_until"] - now).total_seconds() / 60, 2) if task["lease_until"] else None,
            })
        candidates.sort(key=lambda x: (_RANK[x["classification"]], -x["priority"], x["task_id"]))
        selected = candidates[0] if candidates else None
        roles[role] = {
            "classification": selected["classification"] if selected else "idle_no_safe_work",
            "task_id": selected["task_id"] if selected else None,
            "safe_next_action": selected["safe_next_action"] if selected else "read_only_wait_for_spec_backed_task",
            "candidates": candidates,
            "last_activity_utc": selected["last_activity_utc"] if selected else None,
            "minutes_since_activity": selected["minutes_since_activity"] if selected else None,
            "lease_remaining_minutes": selected["lease_remaining_minutes"] if selected else None,
            "agent_last_activity_utc": agent_activity[role].isoformat() if agent_activity.get(role) else None,
            "agent_minutes_since_activity": round((now - agent_activity[role]).total_seconds() / 60, 2) if agent_activity.get(role) else None,
            "host_authorization_source": "caller_claim_unverified",
        }
    return {
        "ok": True,
        "as_of_utc": now.isoformat(),
        "roles": roles,
        "advisory_only": True,
        "host_actor_authenticated": False,
        "may_mutate": False,
        "lease_issued": False,
        "review_accepted": False,
        "actual_input_tokens": "UNKNOWN",
        "actual_output_tokens": "UNKNOWN",
        "evidence_limit": "caller_supplied_snapshot_not_host_attestation",
    }


analyze_queue_starvation = classify_queue_snapshot
