import unittest
from test_queue_starvation_diagnostics import task,snap,role
from queue_starvation_diagnostics import classify_queue_snapshot
class ReworkRegression(unittest.TestCase):
    def test_done_accepted_dependency_with_drift_cannot_unlock_successor(self):
        for drift in ("source_sha_matches","spec_sha_matches"):
            with self.subTest(drift=drift):
                upstream=task("P105","done",**{drift:False})
                successor=task("P148",dependencies=["P105"])
                result=classify_queue_snapshot(snap(
                    [upstream,successor],[{"role":"developer-2","host_authorized":True}]))
                self.assertEqual(role(result)["classification"],"missing_dependency",result)
                self.assertFalse(result["host_actor_authenticated"])
