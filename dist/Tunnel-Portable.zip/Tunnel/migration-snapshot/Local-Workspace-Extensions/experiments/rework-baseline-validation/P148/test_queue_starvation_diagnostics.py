"""Adversarial tests for advisory queue starvation diagnostics."""
from __future__ import annotations

import copy
import unittest
from queue_starvation_diagnostics import classify_queue_snapshot, analyze_queue_starvation

NOW = "2026-11-01T23:30:00+00:00"
PAST = "2026-11-01T22:00:00+00:00"
FUTURE = "2026-11-02T00:30:00+00:00"


def task(tid="P148", status="available", role="developer-2", **kwargs):
    item = {
        "task_id": tid, "status": status, "role_hint": role,
        "owner": None, "lease_until": None,
        "submitted_at": None, "reviewed_at": None,
        "source_sha_matches": True, "spec_sha_matches": True,
        "independently_accepted_qa_record": False,
        "dependencies": [], "priority": 90,
    }
    if status != "available":
        item["owner"] = role
    if status == "working":
        item["lease_until"] = FUTURE
    if status in ("review", "reviewing", "done"):
        item["submitted_at"] = PAST
    if status == "done":
        item["reviewed_at"] = NOW
        item["independently_accepted_qa_record"] = True
    item.update(kwargs)
    return item


def snap(tasks=None, agents=None):
    return {"as_of_utc": NOW, "tasks": tasks if tasks is not None else [],
            "agents": agents if agents is not None else []}


def role(result, name="developer-2"):
    return result["roles"][name]


class QueueStarvationTests(unittest.TestCase):
    def diagnose(self, tasks=None, agents=None):
        return classify_queue_snapshot(snap(tasks, agents))

    def test_empty_queue_is_idle_for_four_roles(self):
        r = self.diagnose()
        self.assertEqual(set(r["roles"]), {f"developer-{n}" for n in range(1, 5)})
        self.assertTrue(all(x["classification"] == "idle_no_safe_work" for x in r["roles"].values()))

    def test_available_without_host_evidence_is_missing_authorization(self):
        r = self.diagnose([task()])
        self.assertEqual(role(r)["classification"], "missing_host_authorization")
        self.assertEqual(role(r)["safe_next_action"], "request_host_authorized_fresh_acquire")

    def test_available_with_caller_host_claim_is_advisory_ready(self):
        r = self.diagnose([task()], [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["classification"], "ready")
        self.assertFalse(r["host_actor_authenticated"])
        self.assertFalse(r["may_mutate"])
        self.assertFalse(r["lease_issued"])

    def test_unknown_tokens_never_zero(self):
        r = self.diagnose([task()])
        self.assertEqual(r["actual_input_tokens"], "UNKNOWN")
        self.assertEqual(r["actual_output_tokens"], "UNKNOWN")

    def test_accepted_dependency_unblocks_queue_candidate(self):
        predecessor = task("P105", "done")
        candidate = task(dependencies=["P105"])
        r = self.diagnose([candidate, predecessor], [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["classification"], "ready")
        self.assertEqual(role(r)["task_id"], "P148")

    def test_forged_done_without_qa_receipt_does_not_unlock(self):
        forged = task("P105", "done", independently_accepted_qa_record=False)
        r = self.diagnose([task(dependencies=["P105"]), forged])
        self.assertEqual(role(r)["classification"], "missing_dependency")

    def test_missing_qa_proof_does_not_unlock(self):
        forged = task("P105", "done")
        del forged["independently_accepted_qa_record"]
        r = self.diagnose([task(dependencies=["P105"]), forged])
        self.assertEqual(role(r)["classification"], "missing_dependency")

    def test_missing_dependency_record_is_blocked(self):
        r = self.diagnose([task(dependencies=["P999"])])
        self.assertEqual(role(r)["classification"], "missing_dependency")

    def test_unaccepted_dependency_is_blocked(self):
        r = self.diagnose([task(dependencies=["P105"]), task("P105", "review")])
        self.assertEqual(role(r)["classification"], "missing_dependency")

    def test_review_waiting(self):
        r = self.diagnose([task(status="review")])
        self.assertEqual(role(r)["classification"], "review_waiting")
        self.assertEqual(role(r)["safe_next_action"], "wait_for_independent_reviewer")

    def test_review_waiting_does_not_block_independent_ready(self):
        r = self.diagnose([task("P125", "review"), task("P148")],
                          [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["task_id"], "P148")
        self.assertEqual(role(r)["classification"], "ready")

    def test_source_sha_drift(self):
        r = self.diagnose([task(source_sha_matches=False)])
        self.assertEqual(role(r)["classification"], "stale_source")

    def test_unknown_spec_sha_fails_closed(self):
        t = task()
        del t["spec_sha_matches"]
        self.assertEqual(role(self.diagnose([t]))["classification"], "stale_source")

    def test_active_own_lease_is_inaccessible(self):
        r = self.diagnose([task(status="working")])
        self.assertEqual(role(r)["classification"], "active_inaccessible_lease")

    def test_active_foreign_lease_is_blocked(self):
        r = self.diagnose([task(status="working", owner="developer-1")])
        self.assertEqual(role(r)["classification"], "active_foreign_lease")

    def test_expired_lease_never_becomes_ready(self):
        r = self.diagnose([task(status="working", lease_until=PAST)],
                          [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["classification"], "expired_lease")

    def test_future_lease_remains_active(self):
        r = self.diagnose([task(status="working", lease_until=FUTURE)])
        self.assertEqual(role(r)["classification"], "active_inaccessible_lease")

    def test_timezone_offset_normalization(self):
        r = classify_queue_snapshot(snap([task(status="working", lease_until="2026-11-01T19:00:00-05:00")]))
        self.assertEqual(role(r)["classification"], "active_inaccessible_lease")

    def test_priority_order_deterministic(self):
        r = self.diagnose([task("P149", priority=10), task("P148", priority=95)],
                          [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["task_id"], "P148")

    def test_unicode_in_irrelevant_metadata_is_not_echoed(self):
        r = self.diagnose([dict(task(), description="Проверка очереди ☃")])
        self.assertNotIn("Проверка", str(r))
        self.assertEqual(role(r)["classification"], "missing_host_authorization")

    def test_attacker_supplied_string_cannot_execute_or_become_id(self):
        with self.assertRaisesRegex(ValueError, "invalid_task_id"):
            self.diagnose([task("P148; __import__('os').system('whoami')")])

    def test_invalid_role_string_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_role"):
            self.diagnose([task(role="developer-2;admin")])

    def test_duplicate_task_ids_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate_task_id"):
            self.diagnose([task(), task()])

    def test_duplicate_agent_roles_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate_agent_role"):
            self.diagnose([], [{"role": "developer-2"}, {"role": "developer-2"}])

    def test_duplicate_dependencies_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate_or_self_dependency"):
            self.diagnose([task(dependencies=["P105", "P105"])])

    def test_self_dependency_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate_or_self_dependency"):
            self.diagnose([task(dependencies=["P148"])])

    def test_available_owner_is_contradictory(self):
        with self.assertRaisesRegex(ValueError, "contradictory_available_state"):
            self.diagnose([task(owner="developer-2")])

    def test_done_without_review_timestamp_rejected(self):
        with self.assertRaisesRegex(ValueError, "missing_review_timestamp"):
            self.diagnose([task(status="done", reviewed_at=None)])

    def test_reviewed_before_submitted_rejected(self):
        with self.assertRaisesRegex(ValueError, "contradictory_review_timestamp"):
            self.diagnose([task(status="done", submitted_at=NOW, reviewed_at=PAST)])

    def test_future_review_timestamp_rejected(self):
        with self.assertRaisesRegex(ValueError, "contradictory_review_timestamp"):
            self.diagnose([task(status="done", reviewed_at=FUTURE)])

    def test_future_submission_timestamp_rejected(self):
        with self.assertRaisesRegex(ValueError, "future_submission_timestamp"):
            self.diagnose([task(status="review", submitted_at=FUTURE)])

    def test_working_without_lease_rejected(self):
        with self.assertRaisesRegex(ValueError, "working_without_lease"):
            self.diagnose([task(status="working", lease_until=None)])

    def test_done_with_live_lease_rejected(self):
        with self.assertRaisesRegex(ValueError, "contradictory_lease"):
            self.diagnose([task(status="done", lease_until=FUTURE)])

    def test_naive_timestamp_rejected(self):
        with self.assertRaisesRegex(ValueError, "timestamp_must_be_timezone_aware"):
            classify_queue_snapshot(snap(), now_utc="2026-11-01T23:30:00")

    def test_malformed_timestamp_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_timestamp"):
            self.diagnose([task(status="working", lease_until="tomorrow")])

    def test_bool_instead_of_int_priority_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_priority"):
            self.diagnose([task(priority=True)])

    def test_non_boolean_host_flag_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_boolean"):
            self.diagnose([], [{"role": "developer-2", "host_authorized": "true"}])

    def test_unaccepted_task_with_qa_flag_rejected(self):
        with self.assertRaisesRegex(ValueError, "qa_receipt_for_unaccepted_task"):
            self.diagnose([task(independently_accepted_qa_record=True)])

    def test_snapshot_type_rejected(self):
        with self.assertRaisesRegex(ValueError, "snapshot_must_be_object"):
            classify_queue_snapshot("not a snapshot")

    def test_bounded_task_count(self):
        with self.assertRaisesRegex(ValueError, "invalid_task_count"):
            self.diagnose([task(f"P{i:03d}") for i in range(513)])

    def test_bounded_dependencies(self):
        with self.assertRaisesRegex(ValueError, "invalid_dependencies"):
            self.diagnose([task(dependencies=[f"P{i:03d}" for i in range(65)])])

    def test_unknown_status_rejected(self):
        with self.assertRaisesRegex(ValueError, "invalid_status"):
            self.diagnose([task(status="approved")])

    def test_active_rework_lease_is_not_ready(self):
        r = self.diagnose([task(status="rework", lease_until=FUTURE, submitted_at=PAST)],
                          [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["classification"], "active_inaccessible_lease")

    def test_expired_rework_lease_needs_reconciliation(self):
        r = self.diagnose([task(status="rework", lease_until=PAST, submitted_at=PAST)],
                          [{"role": "developer-2", "host_authorized": True}])
        self.assertEqual(role(r)["classification"], "expired_lease")

    def test_rework_without_submission_is_contradictory(self):
        with self.assertRaisesRegex(ValueError, "rework_without_previous_submission"):
            self.diagnose([task(status="rework")])

    def test_oversized_attacker_field_rejected(self):
        with self.assertRaisesRegex(ValueError, "oversized_task_field"):
            self.diagnose([dict(task(), description="💥" * 5000)])

    def test_expired_lease_reports_last_real_activity(self):
        r = self.diagnose([task(status="working", lease_until=PAST, activity_at=PAST)])
        self.assertEqual(role(r)["classification"], "expired_lease")
        self.assertEqual(role(r)["minutes_since_activity"], 90.0)
        self.assertEqual(role(r)["lease_remaining_minutes"], -90.0)
        self.assertEqual(role(r)["last_activity_utc"], PAST)

    def test_unknown_last_activity_stays_unknown(self):
        r = self.diagnose([task(status="working", lease_until=PAST)])
        self.assertIsNone(role(r)["minutes_since_activity"])

    def test_future_activity_rejected(self):
        with self.assertRaisesRegex(ValueError, "future_activity_timestamp"):
            self.diagnose([task(activity_at=FUTURE)])

    def test_dependency_cycle_rejected(self):
        a = task("P148", dependencies=["P149"])
        b = task("P149", dependencies=["P148"])
        with self.assertRaisesRegex(ValueError, "dependency_cycle"):
            self.diagnose([a, b])

    def test_agent_activity_is_distinct_from_task_activity(self):
        r = self.diagnose([task(activity_at=NOW)],
                          [{"role": "developer-2", "last_activity_at": PAST}])
        self.assertEqual(role(r)["minutes_since_activity"], 0.0)
        self.assertEqual(role(r)["agent_minutes_since_activity"], 90.0)
        self.assertEqual(role(r)["agent_last_activity_utc"], PAST)

    def test_future_agent_activity_rejected(self):
        with self.assertRaisesRegex(ValueError, "future_agent_activity"):
            self.diagnose([], [{"role": "developer-2", "last_activity_at": FUTURE}])

    def test_dict_subclass_cannot_execute_overridden_get(self):
        class Evil(dict):
            def get(self, key, default=None):
                raise AssertionError("untrusted method invoked")
        with self.assertRaisesRegex(ValueError, "invalid_task"):
            self.diagnose([Evil(task())])

    def test_no_mutation_and_alias(self):
        original = snap([task()])
        clone = copy.deepcopy(original)
        self.assertEqual(analyze_queue_starvation(original), classify_queue_snapshot(original))
        self.assertEqual(original, clone)


if __name__ == "__main__":
    unittest.main()
