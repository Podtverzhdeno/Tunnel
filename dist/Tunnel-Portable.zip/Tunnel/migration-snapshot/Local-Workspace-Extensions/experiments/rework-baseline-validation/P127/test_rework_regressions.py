import unittest
from agent_metrics_series import normalize_metric_series
class ReworkRegression(unittest.TestCase):
    def test_empty_model_returns_structured_failure(self):
        row={"role":"developer-4","task_id":"P127","run_id":"run-001",
             "model":"","timestamp":"2026-11-02T00:00:00Z"}
        result=normalize_metric_series([],expected_runs=[row])
        self.assertEqual(result["ok"],False)
        self.assertEqual(result["error"],"INVALID_ID")
    def test_unpaired_surrogate_returns_structured_failure(self):
        for source in ([{"text":"\ud800"}],[]):
            result=normalize_metric_series(source,expected_runs=[{"model":"\ud800"}] if not source else ())
            self.assertFalse(result["ok"])
            self.assertEqual(result["error"],"INVALID_INPUT")
