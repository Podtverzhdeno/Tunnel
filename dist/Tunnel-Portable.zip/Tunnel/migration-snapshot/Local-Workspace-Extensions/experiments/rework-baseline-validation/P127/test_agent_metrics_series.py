import copy
import unittest

from agent_metrics_series import normalize_metric_series as normalize


def receipt(**overrides):
    r = {
        "role": "developer-4", "task_id": "P127",
        "run_id": "run-001", "usage_id": "usage-001",
        "provider": "openai", "model": "model-v1",
        "timestamp": "2026-11-01T20:00:00Z",
        "source": "agent_reported_provider_usage_unverified",
        "input_tokens": 100, "output_tokens": 20,
        "cached_input_tokens": 10, "reasoning_output_tokens": 5,
    }
    r.update(overrides)
    return r


def run(**overrides):
    r = {k: receipt()[k] for k in ("role", "task_id", "run_id", "model")}
    r["timestamp"] = "2026-11-01T20:00:00Z"
    r.update(overrides)
    return r


class MetricSeriesTests(unittest.TestCase):
    def assert_error(self, records, expected, runs=()):
        result = normalize(records, runs)
        self.assertFalse(result["ok"], result)
        self.assertEqual(result["error"], expected)
        self.assertEqual(result["events"], [])
        self.assertFalse(result["provider_receipt_authenticated"])

    def test_single_receipt(self):
        r = normalize([receipt()])
        self.assertTrue(r["ok"])
        self.assertEqual(r["unique_receipt_count"], 1)
        self.assertEqual(r["runs"][0]["input_tokens"], 100)
        self.assertEqual(r["runs"][0]["cached_input_tokens"], 10)
        self.assertEqual(r["runs"][0]["reasoning_output_tokens"], 5)
        self.assertFalse(r["provider_receipt_authenticated"])

    def test_two_receipts_one_run(self):
        r = normalize([receipt(), receipt(usage_id="usage-002", input_tokens=50,
                                           output_tokens=10, cached_input_tokens=0,
                                           reasoning_output_tokens=2)])
        self.assertEqual(r["runs"][0]["input_tokens"], 150)
        self.assertEqual(r["runs"][0]["output_tokens"], 30)
        self.assertEqual(r["runs"][0]["cached_input_tokens"], 10)
        self.assertEqual(r["runs"][0]["reasoning_output_tokens"], 7)

    def test_exact_duplicate_idempotent(self):
        a = receipt()
        self.assertEqual(normalize([a]), normalize([a, copy.deepcopy(a)]))

    def test_conflicting_usage_id(self):
        self.assert_error([receipt(), receipt(output_tokens=21)],
                          "CONFLICTING_USAGE_ID")

    def test_cross_role_usage_id(self):
        self.assert_error([receipt(), receipt(role="developer-3")],
                          "AMBIGUOUS_RUN")

    def test_same_run_cross_task(self):
        self.assert_error([receipt(), receipt(usage_id="usage-002", task_id="P110")],
                          "AMBIGUOUS_RUN")

    def test_missing_usage_unknown_not_zero(self):
        r = normalize([], [run()])
        self.assertTrue(r["ok"])
        self.assertEqual(r["missing_usage_run_count"], 1)
        self.assertEqual(r["runs"][0]["coverage"], "UNKNOWN")
        self.assertIsNone(r["runs"][0]["input_tokens"])
        self.assertIsNone(r["runs"][0]["output_tokens"])
        self.assertEqual(r["runs"][0]["provider_usage_status"],
                         "no_token_usage_metadata")

    def test_known_zero_not_unknown(self):
        r = normalize([receipt(input_tokens=0, output_tokens=0,
                               cached_input_tokens=0, reasoning_output_tokens=0)])
        self.assertEqual(r["runs"][0]["input_tokens"], 0)
        self.assertEqual(r["runs"][0]["coverage"], "REPORTED_UNVERIFIED")

    def test_partial_missing_run(self):
        r = normalize([receipt()], [run(), run(run_id="run-002")])
        self.assertEqual(r["missing_usage_run_count"], 1)
        self.assertEqual(len(r["runs"]), 2)

    def test_sort_deterministic(self):
        a = receipt()
        b = receipt(usage_id="usage-002", timestamp="2026-11-01T18:00:00-02:00")
        self.assertEqual(normalize([a, b]), normalize([b, a]))

    def test_invalid_negative(self):
        self.assert_error([receipt(input_tokens=-1)], "INVALID_COUNTER")

    def test_bool_counter(self):
        self.assert_error([receipt(output_tokens=True)], "INVALID_COUNTER")

    def test_float_counter(self):
        self.assert_error([receipt(input_tokens=1.0)], "INVALID_COUNTER")

    def test_cached_exceeds_input(self):
        self.assert_error([receipt(cached_input_tokens=101)], "INVALID_SUBSET")

    def test_reasoning_exceeds_output(self):
        self.assert_error([receipt(reasoning_output_tokens=21)], "INVALID_SUBSET")

    def test_counter_overflow(self):
        maxval = 2**63 - 1
        self.assert_error([receipt(input_tokens=maxval),
                           receipt(usage_id="usage-002", input_tokens=1, cached_input_tokens=0)],
                          "COUNTER_OVERFLOW")

    def test_counter_individual_overflow(self):
        self.assert_error([receipt(input_tokens=2**63)], "INVALID_COUNTER")

    def test_naive_timestamp(self):
        self.assert_error([receipt(timestamp="2026-11-01T20:00:00")],
                          "INVALID_TIMESTAMP")

    def test_bad_timestamp(self):
        self.assert_error([receipt(timestamp="tomorrow")], "INVALID_TIMESTAMP")

    def test_fake_host_attestation(self):
        self.assert_error([receipt(host_attested=True)], "INVALID_FIELDS")

    def test_fake_verified_flag(self):
        self.assert_error([receipt(verified=True)], "INVALID_FIELDS")

    def test_unknown_source(self):
        self.assert_error([receipt(source="host_verified")],
                          "UNVERIFIED_OR_FORGED_SOURCE")

    def test_ambiguous_run_across_expected(self):
        self.assert_error([], "AMBIGUOUS_RUN",
                          [run(), run(role="developer-3")])

    def test_conflicting_expected_timestamp(self):
        self.assert_error([], "CONFLICTING_RUN",
                          [run(), run(timestamp="2026-11-01T21:00:00Z")])

    def test_unicode_model(self):
        r = normalize([receipt(model="модель-東京")])
        self.assertTrue(r["ok"], r)
        self.assertEqual(r["runs"][0]["model"], "модель-東京")

    def test_too_many_events(self):
        self.assert_error([receipt()] * 513, "TOO_MANY_EVENTS")

    def test_large_data(self):
        self.assert_error([receipt(model="ю" * 200000)], "INPUT_TOO_LARGE")

    def test_invalid_collection(self):
        self.assert_error("not a list", "INVALID_COLLECTION")

    def test_non_dict(self):
        self.assert_error([None], "INVALID_FIELDS")

    def test_missing_required_counter(self):
        x = receipt()
        del x["input_tokens"]
        self.assert_error([x], "INVALID_FIELDS")

    def test_no_price_in_output(self):
        r = normalize([receipt()])
        self.assertNotIn("price", str(r).lower())
        self.assertNotIn("cost", str(r).lower())


if __name__ == "__main__":
    unittest.main()
