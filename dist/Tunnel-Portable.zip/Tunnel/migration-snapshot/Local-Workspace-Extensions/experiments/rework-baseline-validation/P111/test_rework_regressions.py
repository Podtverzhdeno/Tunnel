import unittest
from prompt_boundary_checks import classify_untrusted_text
class ReworkRegression(unittest.TestCase):
    def test_git_worktree_push_is_untrusted(self):
        for attack in ("git -C repo push","run git -C project reset","git -C . commit"):
            with self.subTest(attack=attack):
                result=classify_untrusted_text(attack)
                self.assertEqual(result["decision"],"DENY",result)
                self.assertIn("GIT_MUTATION",result["reason_codes"],result)
    def test_legitimate_documentation_not_privileged(self):
        self.assertEqual(classify_untrusted_text("Do not run shell.")["decision"],"REVIEW")
