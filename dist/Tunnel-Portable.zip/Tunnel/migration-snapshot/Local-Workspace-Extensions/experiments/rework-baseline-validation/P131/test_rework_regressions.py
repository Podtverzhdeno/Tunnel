import unittest
from media_rights_schema import validate_media_rights
class ReworkRegression(unittest.TestCase):
    def test_unpaired_unicode_surrogate_fails_closed(self):
        manifest={"assets":[{"source_path":"\ud800"}],
                  "scenes":[{"scene_id":"scene01","asset_ids":["asset"]}]}
        result=validate_media_rights(manifest)
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"],"INVALID_MANIFEST")
        self.assertFalse(result["publication_approved"])
