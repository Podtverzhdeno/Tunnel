import copy
import unittest

from media_rights_schema import validate_media_rights as validate

SHA = "a" * 64


def asset(**updates):
    a = {
        "asset_id": "asset01", "sha256": SHA,
        "source_path": "clips/сцена01.mp4", "license_category": "CC-BY",
        "rights_holder": "Studio", "attribution": "Studio / Director",
        "expires_at": "2027-11-01T00:00:00Z", "reuse_allowed": True,
        "verified": False, "verification_evidence": None,
    }
    a.update(updates)
    return a


def manifest(a=None):
    return {"assets": [a if a is not None else asset()],
            "scenes": [{"scene_id": f"scene{i:02d}", "asset_ids": ["asset01"]}
                       for i in range(1, 7)]}


class RightsSchemaTests(unittest.TestCase):
    def check_error(self, data, error):
        result = validate(data)
        self.assertFalse(result["ok"], result)
        self.assertEqual(result["error"], error)
        self.assertFalse(result["publication_approved"])
        self.assertFalse(result["render_approved"])
        self.assertFalse(result["host_attested"])

    def test_six_scene_metadata_never_approves(self):
        result = validate(manifest())
        self.assertTrue(result["ok"], result)
        self.assertEqual(len(result["scenes"]), 6)
        self.assertEqual(result["assets"][0]["status"], "UNKNOWN")
        self.assertTrue(all(s["status"] == "UNKNOWN" for s in result["scenes"]))
        self.assertFalse(result["publication_approved"])

    def test_forged_verified_flag(self):
        result = validate(manifest(asset(verified=True)))
        self.assertTrue(result["ok"])
        self.assertEqual(result["assets"][0]["reason"], "UNTRUSTED_VERIFIED_FLAG")
        self.assertEqual(result["scenes"][0]["status"], "BLOCKED")

    def test_untrusted_evidence_not_approval(self):
        result = validate(manifest(asset(verification_evidence="sha:123")))
        self.assertEqual(result["assets"][0]["status"], "UNKNOWN")

    def test_missing_rights(self):
        result = validate(manifest(asset(rights_holder=None)))
        self.assertEqual(result["assets"][0]["reason"], "RIGHTS_UNCONFIRMED")

    def test_missing_attribution(self):
        result = validate(manifest(asset(attribution=None)))
        self.assertEqual(result["assets"][0]["reason"], "ATTRIBUTION_MISSING")

    def test_expired_license(self):
        result = validate(manifest(asset(expires_at="2020-01-01T00:00:00Z")))
        self.assertEqual(result["assets"][0]["reason"], "LICENSE_EXPIRED")

    def test_reuse_restricted(self):
        result = validate(manifest(asset(reuse_allowed=False)))
        self.assertEqual(result["assets"][0]["reason"], "REUSE_RESTRICTED")

    def test_unknown_license(self):
        result = validate(manifest(asset(license_category="UNKNOWN")))
        self.assertEqual(result["assets"][0]["status"], "UNKNOWN")

    def test_unknown_license_category_rejected(self):
        self.check_error(manifest(asset(license_category="OWNED_FOR_SURE")),
                         "INVALID_LICENSE")

    def test_duplicate_asset(self):
        x = manifest()
        x["assets"].append(copy.deepcopy(x["assets"][0]))
        self.check_error(x, "DUPLICATE_ASSET")

    def test_duplicate_scene(self):
        x = manifest()
        x["scenes"][1]["scene_id"] = "scene01"
        self.check_error(x, "INVALID_OR_DUPLICATE_SCENE")

    def test_unknown_scene_asset(self):
        x = manifest()
        x["scenes"][0]["asset_ids"] = ["missing"]
        self.check_error(x, "UNKNOWN_SCENE_ASSET")

    def test_duplicate_scene_asset(self):
        x = manifest()
        x["scenes"][0]["asset_ids"] = ["asset01", "asset01"]
        self.check_error(x, "DUPLICATE_SCENE_ASSET")

    def test_invalid_sha(self):
        self.check_error(manifest(asset(sha256="fake")), "INVALID_SHA256")

    def test_path_traversal(self):
        for path in ("../secret.mp4", "clips/../secret.mp4", "C:/Users/secret",
                     "//server/private.mp4", "clips//bad.mp4", "clips/CON.mp4",
                     "clips/COM1", "clips/COM¹.mp4", "clips/LPT³", "clips/.", "clips/file."):
            with self.subTest(path=path):
                self.check_error(manifest(asset(source_path=path)), "INVALID_PATH")

    def test_unicode_safe_relative_path(self):
        result = validate(manifest(asset(source_path="кадры/東京 01.mp4")))
        self.assertTrue(result["ok"], result)

    def test_bad_expiry(self):
        self.check_error(manifest(asset(expires_at="2030-01-01")), "INVALID_EXPIRY")

    def test_bool_reuse_rejected(self):
        self.check_error(manifest(asset(reuse_allowed=1)), "INVALID_BOOLEAN")

    def test_bool_verified_rejected(self):
        self.check_error(manifest(asset(verified=1)), "INVALID_BOOLEAN")

    def test_unknown_field_rejected(self):
        self.check_error(manifest(asset(host_approved=True)), "INVALID_ASSET_FIELDS")

    def test_empty_assets(self):
        self.check_error({"assets": [], "scenes": manifest()["scenes"]},
                         "INVALID_COUNT")

    def test_more_than_six_scenes(self):
        x = manifest()
        x["scenes"].append({"scene_id": "scene07", "asset_ids": ["asset01"]})
        self.check_error(x, "INVALID_COUNT")

    def test_large_input(self):
        x = manifest(asset(attribution="x" * 300000))
        self.check_error(x, "INPUT_TOO_LARGE")

    def test_invalid_collection(self):
        self.check_error([], "INVALID_MANIFEST")

    def test_no_secret_data_echo(self):
        x = manifest(asset(rights_holder="private-untrusted-text"))
        result = validate(x)
        self.assertNotIn("private-untrusted-text", str(result))

    def test_deterministic(self):
        x = manifest()
        self.assertEqual(validate(x), validate(copy.deepcopy(x)))


if __name__ == "__main__":
    unittest.main()
