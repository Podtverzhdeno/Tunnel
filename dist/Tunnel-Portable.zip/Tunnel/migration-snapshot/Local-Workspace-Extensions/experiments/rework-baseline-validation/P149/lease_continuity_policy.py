"""Pure, untrusted-input lease-continuation advisor (not an authorizer).

All facts are caller supplied. In particular, `host_actor_authenticated` and
`coordinator_verified_lease` are *claims*, not cryptographic attestations.
The result MUST NOT be used to authorize filesystem, queue, or MCP operations.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import re

_MAX_BYTES = 4096
_HEX = re.compile(r"^[0-9a-fA-F]{64}$")
_TASK = re.compile(r"^P[0-9]{3,5}$")
_ROLE = re.compile(r"^developer-[1-4]$")
_KEYS = frozenset({
    "task_id", "role", "task_status", "task_owner", "spec_sha256",
    "current_spec_sha256", "base_sha256", "current_base_sha256",
    "now_utc", "lease_task_id", "lease_owner", "lease_expires_at",
    "has_current_lease", "coordinator_verified_lease",
    "host_actor_authenticated", "independent_task_id",
    "independent_task_ready", "request_id", "previous_request_id",
    "previous_request_task_id", "task_label",
})
_REQUIRED = frozenset({
    "task_id", "role", "task_status", "spec_sha256",
    "current_spec_sha256", "base_sha256", "current_base_sha256", "now_utc",
})
_STATUSES = frozenset({"available", "working", "rework", "review", "reviewing", "done"})


def _result(decision: str, reason: str) -> dict:
    return {
        "decision": decision,
        "reason": reason,
        "advisory_only": True,
        "authorization_granted": False,
        "host_actor_authenticated": False,
        "lease_token_disclosed": False,
        "provenance": "caller_supplied_unverified",
    }


def _parse_time(value: object) -> datetime | None:
    if type(value) is not str or len(value) > 40:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            return None
        return parsed.astimezone(timezone.utc)
    except (ValueError, OverflowError):
        return None


def plan_lease_continuation(facts: object) -> dict:
    """Classify a bounded snapshot. Never mutate, replay or authenticate.

    RESUME_WITH_CURRENT_LEASE is an *advisory candidate* only: the real
    coordinator/host MUST independently validate identity, task and token.
    """
    deny = lambda reason: _result("REQUIRE_OWNER_REVIEW", reason)
    if type(facts) is not dict:
        return deny("INVALID_INPUT")
    try:
        encoded = json.dumps(facts, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError, OverflowError, RecursionError):
        return deny("INVALID_INPUT")
    if len(encoded.encode("utf-8")) > _MAX_BYTES:
        return deny("INPUT_TOO_LARGE")
    if not _REQUIRED.issubset(facts) or set(facts) - _KEYS:
        return deny("UNKNOWN_OR_MISSING_FIELDS")
    for key, value in facts.items():
        if key in {"has_current_lease", "coordinator_verified_lease",
                   "host_actor_authenticated", "independent_task_ready"}:
            if type(value) is not bool:
                return deny("INVALID_BOOLEAN")
        elif type(value) is not str and value is not None:
            return deny("INVALID_FIELD_TYPE")
        elif type(value) is str and len(value) > 128:
            return deny("FIELD_TOO_LONG")
    task = facts["task_id"]
    role = facts["role"]
    if (type(task) is not str or type(role) is not str or
            not _TASK.fullmatch(task) or not _ROLE.fullmatch(role)):
        return deny("INVALID_TASK_OR_ROLE")
    if facts["task_status"] not in _STATUSES:
        return deny("INVALID_TASK_STATUS")
    for key in ("spec_sha256", "current_spec_sha256", "base_sha256", "current_base_sha256"):
        if type(facts[key]) is not str or not _HEX.fullmatch(facts[key]):
            return deny("INVALID_DIGEST")
    now = _parse_time(facts["now_utc"])
    if now is None:
        return deny("INVALID_TIMESTAMP")
    expiry = facts.get("lease_expires_at")
    deadline = _parse_time(expiry) if expiry is not None else None
    if expiry is not None and deadline is None:
        return deny("INVALID_TIMESTAMP")
    for key in ("lease_task_id", "independent_task_id", "previous_request_task_id"):
        value = facts.get(key)
        if value is not None and not _TASK.fullmatch(value):
            return deny("INVALID_TASK_REFERENCE")
    for key in ("task_owner", "lease_owner"):
        value = facts.get(key)
        if value is not None and not _ROLE.fullmatch(value):
            return deny("INVALID_OWNER")
    for key in ("request_id", "previous_request_id"):
        value = facts.get(key)
        if value is not None and (len(value) < 8 or len(value) > 128 or
                                  not re.fullmatch(r"[A-Za-z0-9_-]+", value)):
            return deny("INVALID_REQUEST_ID")
    if facts.get("request_id") is not None and (
        facts["request_id"] == facts.get("previous_request_id")
    ):
        return deny("REQUEST_ID_REPLAY")
    if (facts["spec_sha256"].lower() != facts["current_spec_sha256"].lower() or
            facts["base_sha256"].lower() != facts["current_base_sha256"].lower()):
        return deny("STALE_SPEC_OR_SOURCE")
    if facts.get("task_owner") not in (None, role):
        return deny("CONFLICTING_OWNER")
    if facts.get("lease_task_id") not in (None, task):
        return deny("OTHER_TASK_LEASE")
    if facts.get("lease_owner") not in (None, role):
        return deny("FOREIGN_LEASE")
    if facts["task_status"] in ("review", "reviewing", "done"):
        return deny("REVIEW_OR_COMPLETED")
    if facts["task_status"] in ("working", "rework"):
        if deadline is None:
            return deny("MISSING_LEASE_DEADLINE")
        if deadline > now:
            if (facts.get("has_current_lease") is True and
                    facts.get("coordinator_verified_lease") is True and
                    facts.get("host_actor_authenticated") is True and
                    facts.get("lease_task_id") == task and
                    facts.get("lease_owner") == role):
                return _result("RESUME_WITH_CURRENT_LEASE", "RECHECK_WITH_TRUSTED_HOST")
            return _result("WAIT_FOR_EXPIRY", "ACTIVE_LEASE_NOT_VERIFIED")
    other = facts.get("independent_task_id")
    if (facts.get("independent_task_ready") is True and
            other is not None and other != task):
        return _result("ACQUIRE_NEW_INDEPENDENT_TASK", "FRESH_FENCED_ACQUIRE_REQUIRED")
    return _result("READ_ONLY_PREFLIGHT", "NO_VERIFIED_CURRENT_LEASE")
