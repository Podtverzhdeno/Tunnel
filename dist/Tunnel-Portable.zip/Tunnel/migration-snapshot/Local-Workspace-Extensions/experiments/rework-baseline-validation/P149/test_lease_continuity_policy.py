import copy
import unittest

from lease_continuity_policy import plan_lease_continuation as plan

H = "a" * 64
B = "b" * 64


def sample(**updates):
    data = {
        "task_id": "P149", "role": "developer-3", "task_status": "working",
        "task_owner": "developer-3", "spec_sha256": H,
        "current_spec_sha256": H, "base_sha256": B,
        "current_base_sha256": B, "now_utc": "2026-11-01T20:00:00Z",
        "lease_task_id": "P149", "lease_owner": "developer-3",
        "lease_expires_at": "2026-11-01T21:00:00+00:00",
        "has_current_lease": True, "coordinator_verified_lease": True,
        "host_actor_authenticated": True,
    }
    data.update(updates)
    return data


class LeaseContinuationTests(unittest.TestCase):
    def decision(self, data):
        result = plan(data)
        self.assertFalse(result["authorization_granted"])
        self.assertFalse(result["host_actor_authenticated"])
        self.assertFalse(result["lease_token_disclosed"])
        self.assertTrue(result["advisory_only"])
        self.assertEqual(result["provenance"], "caller_supplied_unverified")
        self.assertNotIn("token", result)
        return result["decision"]

    def test_current_lease_advisory(self):
        self.assertEqual(self.decision(sample()), "RESUME_WITH_CURRENT_LEASE")

    def test_missing_host_claim_waits(self):
        self.assertEqual(self.decision(sample(host_actor_authenticated=False)),
                         "WAIT_FOR_EXPIRY")

    def test_missing_fence_waits(self):
        self.assertEqual(self.decision(sample(coordinator_verified_lease=False)),
                         "WAIT_FOR_EXPIRY")

    def test_lost_token_waits(self):
        self.assertEqual(self.decision(sample(has_current_lease=False)),
                         "WAIT_FOR_EXPIRY")

    def test_expired_lease_independent_task(self):
        self.assertEqual(self.decision(sample(lease_expires_at="2026-11-01T19:00:00Z",
                                             independent_task_ready=True,
                                             independent_task_id="P150")),
                         "ACQUIRE_NEW_INDEPENDENT_TASK")

    def test_expired_lease_no_alternative(self):
        self.assertEqual(self.decision(sample(lease_expires_at="2026-11-01T19:00:00Z")),
                         "READ_ONLY_PREFLIGHT")

    def test_available(self):
        self.assertEqual(self.decision(sample(task_status="available",
                                             lease_expires_at=None)),
                         "READ_ONLY_PREFLIGHT")

    def test_stale_spec(self):
        self.assertEqual(self.decision(sample(current_spec_sha256=B)),
                         "REQUIRE_OWNER_REVIEW")

    def test_stale_source(self):
        self.assertEqual(self.decision(sample(current_base_sha256=H)),
                         "REQUIRE_OWNER_REVIEW")

    def test_other_task_token(self):
        self.assertEqual(self.decision(sample(lease_task_id="P110")),
                         "REQUIRE_OWNER_REVIEW")

    def test_conflicting_owner(self):
        self.assertEqual(self.decision(sample(task_owner="developer-4")),
                         "REQUIRE_OWNER_REVIEW")

    def test_forged_reviewer(self):
        self.assertEqual(self.decision(sample(role="architect-reviewer")),
                         "REQUIRE_OWNER_REVIEW")

    def test_request_id_replay(self):
        self.assertEqual(self.decision(sample(request_id="request-1234",
                                             previous_request_id="request-1234")),
                         "REQUIRE_OWNER_REVIEW")

    def test_naive_datetime(self):
        self.assertEqual(self.decision(sample(now_utc="2026-11-01T20:00:00")),
                         "REQUIRE_OWNER_REVIEW")

    def test_bad_timezone(self):
        self.assertEqual(self.decision(sample(lease_expires_at="yesterday")),
                         "REQUIRE_OWNER_REVIEW")

    def test_bool_is_not_string(self):
        self.assertEqual(self.decision(sample(spec_sha256=True)),
                         "REQUIRE_OWNER_REVIEW")

    def test_none_digest(self):
        self.assertEqual(self.decision(sample(spec_sha256=None)),
                         "REQUIRE_OWNER_REVIEW")

    def test_non_boolean_claim(self):
        self.assertEqual(self.decision(sample(host_actor_authenticated=1)),
                         "REQUIRE_OWNER_REVIEW")

    def test_unknown_secret_field(self):
        self.assertEqual(self.decision(sample(lease_token="secret-value")),
                         "REQUIRE_OWNER_REVIEW")

    def test_huge_input(self):
        self.assertEqual(self.decision(sample(task_label="ю" * 3000)),
                         "REQUIRE_OWNER_REVIEW")

    def test_unicode_label_no_echo(self):
        result = plan(sample(task_label="Задача: проверка продолжения"))
        self.assertEqual(result["decision"], "RESUME_WITH_CURRENT_LEASE")
        self.assertNotIn("Задача", str(result))

    def test_non_mapping_and_nested(self):
        for value in (None, [], {"task_id": {"evil": "x"}}, {"task_id": 3}):
            with self.subTest(value=value):
                self.assertEqual(self.decision(value), "REQUIRE_OWNER_REVIEW")

    def test_null_role_and_task_fail_closed(self):
        for update in ({"role": None}, {"task_id": None}):
            with self.subTest(update=update):
                self.assertEqual(self.decision(sample(**update)),
                                 "REQUIRE_OWNER_REVIEW")

    def test_expiry_at_current_instant_is_not_valid(self):
        self.assertEqual(self.decision(sample(lease_expires_at="2026-11-01T20:00:00Z")),
                         "READ_ONLY_PREFLIGHT")

    def test_foreign_lease_owner(self):
        self.assertEqual(self.decision(sample(lease_owner="developer-4")),
                         "REQUIRE_OWNER_REVIEW")

    def test_missing_deadline(self):
        self.assertEqual(self.decision(sample(lease_expires_at=None)),
                         "REQUIRE_OWNER_REVIEW")

    def test_review_state(self):
        self.assertEqual(self.decision(sample(task_status="reviewing")),
                         "REQUIRE_OWNER_REVIEW")

    def test_deterministic(self):
        data = sample(task_label="Проверка")
        self.assertEqual(plan(data), plan(copy.deepcopy(data)))


if __name__ == "__main__":
    unittest.main()
