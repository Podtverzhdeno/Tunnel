import unittest
from lease_continuity_policy import plan_lease_continuation
class ReworkRegression(unittest.TestCase):
    def test_invalid_unicode_yields_reason_not_exception(self):
        result=plan_lease_continuation({"task_id":"\ud800"})
        self.assertEqual(result["decision"],"REQUIRE_OWNER_REVIEW")
        self.assertEqual(result["reason"],"INVALID_INPUT")
        self.assertFalse(result["authorization_granted"])
