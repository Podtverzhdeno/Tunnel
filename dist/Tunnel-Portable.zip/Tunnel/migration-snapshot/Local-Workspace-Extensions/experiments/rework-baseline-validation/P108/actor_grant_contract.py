"""P108: bounded, offline host-actor/grant *shape* validation.

No code in this module authenticates a host, checks a signature, binds a process,
reserves a one-use token, reads a real clock, or authorizes MCP execution.
All evidence is supplied by the caller and is UNVERIFIED. The actual MCP host
must independently authenticate actor/issuer, scope, action, expiry and replay.
A structural eligibility result MUST NEVER be interpreted as permission.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Any

ROLES = frozenset({
    "developer-1", "developer-2", "developer-3", "developer-4",
    "architect-reviewer",
})
RISKS = frozenset({"R0", "R1", "R2", "R3"})
EXECUTORS = frozenset({
    "run_script", "run_command", "shell", "exec", "execute",
    "python_exec", "powershell", "docker_exec", "subprocess",
    "system_command",
})
IDENT = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:@-]{1,127}\Z")
WORKSPACE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z")
TOOL = re.compile(r"[a-z][a-z0-9_.-]{0,63}\Z")
STAMP = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?"
    r"(?:Z|[+-]\d{2}:\d{2})\Z"
)
HEX = re.compile(r"[0-9a-f]{64}\Z")
MAX_BYTES = 16384
MAX_NODES = 512
MAX_DEPTH = 8
MAX_TTL = timedelta(minutes=5)
PATH_KEYS = frozenset({
    "path", "cwd", "root", "directory", "filename", "source_path",
    "target_path", "file_path", "filepath", "destination_path",
    "output_path", "input_path", "workdir", "working_directory",
    "output_file", "input_file", "source", "target", "folder",
    "file", "dest", "destination",
})
PATH_SUFFIXES = ("_path", "_filepath", "_directory", "_folder", "_file", "_filename", "_dir")


class ContractInputError(ValueError):
    """Stable denial reason, never includes caller-provided secrets."""


def _fail(code: str) -> None:
    raise ContractInputError(code)


def _record(value: Any, required: set[str]) -> dict[str, Any]:
    if type(value) is not dict:
        _fail("INVALID_RECORD")
    if set(value) != required or any(type(k) is not str for k in value):
        _fail("INVALID_FIELDS")
    return value


def _identifier(value: Any, pattern: re.Pattern[str], code: str) -> str:
    if type(value) is not str or not pattern.fullmatch(value):
        _fail(code)
    return value


def _risk(value: Any) -> str:
    if type(value) is not str or value not in RISKS:
        _fail("INVALID_RISK")
    return value


def _stamp(value: Any) -> datetime:
    if type(value) is not str or not STAMP.fullmatch(value):
        _fail("INVALID_TIMESTAMP")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None or dt.utcoffset() is None:
            _fail("INVALID_TIMESTAMP")
        return dt.astimezone(timezone.utc)
    except (ValueError, OverflowError) as exc:
        raise ContractInputError("INVALID_TIMESTAMP") from exc


def _source(value: Any) -> str:
    # The prefix is a *claimed* source type, NOT cryptographic proof.
    if (type(value) is not str or not value.startswith("host:")
            or len(value) > 128 or len(value) < 7
            or not re.fullmatch(r"host:[A-Za-z0-9_.:-]{2,123}", value)):
        _fail("MISSING_HOST_PROVENANCE")
    return value


def _path_argument(value: str) -> None:
    """Lexical defense in depth only; does not resolve junctions/symlinks."""
    normalized = value.replace("\\", "/")
    segments = normalized.split("/")
    if (not value or "\x00" in value or value.startswith(("~", "/", "\\"))
            or unicodedata.normalize("NFKC", value) != value
            or re.search(r"%[0-9A-Fa-f]{2}", value)
            or re.match(r"^[A-Za-z]:", value)
            or any(part in ("", ".", "..") for part in segments)
            or any(part.endswith((" ", ".")) for part in segments)
            or any(":" in part for part in segments)):
        _fail("UNSAFE_ARGUMENT_PATH")
    reserved = re.compile(
        r"(?:CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[1-9¹²³]|LPT[1-9¹²³])"
        r"(?:\..*)?\Z", re.IGNORECASE
    )
    if any(reserved.fullmatch(part) for part in segments):
        _fail("UNSAFE_ARGUMENT_PATH")


def _normalize(value: Any, depth: int, counter: list[int]) -> Any:
    counter[0] += 1
    if counter[0] > MAX_NODES or depth > MAX_DEPTH:
        _fail("ARGUMENT_LIMIT")
    if value is None or type(value) is bool:
        return value
    if type(value) is int:
        if abs(value) > 2**53 - 1:
            _fail("INVALID_ARGUMENT_NUMBER")
        return value
    if type(value) is str:
        if len(value) > 4096:
            _fail("ARGUMENT_LIMIT")
        value = unicodedata.normalize("NFC", value)
        if any(unicodedata.category(ch) in ("Cc", "Cf", "Cs") for ch in value):
            _fail("INVALID_ARGUMENT_TEXT")
        return value
    if type(value) is list:
        if len(value) > 128:
            _fail("ARGUMENT_LIMIT")
        return [_normalize(x, depth + 1, counter) for x in value]
    if type(value) is dict:
        if len(value) > 128:
            _fail("ARGUMENT_LIMIT")
        result: dict[str, Any] = {}
        seen_casefold: set[str] = set()
        for key, item in value.items():
            if type(key) is not str or len(key) > 128:
                _fail("INVALID_ARGUMENT_KEY")
            normalized_key = _normalize(key, depth + 1, counter)
            if normalized_key.casefold() in seen_casefold:
                _fail("DUPLICATE_NORMALIZED_KEY")
            seen_casefold.add(normalized_key.casefold())
            normalized_item = _normalize(item, depth + 1, counter)
            path_key = normalized_key.casefold()
            if path_key in PATH_KEYS or path_key.endswith(PATH_SUFFIXES):
                if type(normalized_item) is not str:
                    _fail("UNSAFE_ARGUMENT_PATH")
                _path_argument(normalized_item)
            result[normalized_key] = normalized_item
        return result
    # Floats, bytes, sets, custom objects and arbitrary Python objects cannot
    # be safely round-tripped through a portable JSON action digest.
    _fail("INVALID_ARGUMENT_TYPE")


def normalized_args_sha256(args: Any) -> str:
    """Stable SHA-256 over bounded NFC-normalized JSON arguments.

    This is a digest *calculator*, not an attestation of the action or caller.
    """
    normalized = _normalize(args, 0, [0])
    try:
        encoded = json.dumps(
            normalized, sort_keys=True, separators=(",", ":"),
            ensure_ascii=False, allow_nan=False,
        ).encode("utf-8", errors="strict")
    except (UnicodeError, TypeError, ValueError) as exc:
        raise ContractInputError("INVALID_ARGUMENT_ENCODING") from exc
    if len(encoded) > MAX_BYTES:
        _fail("ARGUMENT_LIMIT")
    return hashlib.sha256(encoded).hexdigest()


def _ids(value: Any, maximum: int = 256) -> frozenset[str]:
    if type(value) not in (list, tuple) or len(value) > maximum:
        _fail("INVALID_REPLAY_SET")
    checked = [_identifier(item, IDENT, "INVALID_REPLAY_SET") for item in value]
    if len(checked) != len(set(checked)):
        _fail("INVALID_REPLAY_SET")
    return frozenset(checked)


def _registry(value: Any) -> dict[str, str]:
    if type(value) is not dict or not value or len(value) > 128:
        _fail("INVALID_REGISTRY")
    result: dict[str, str] = {}
    for name, risk in value.items():
        name = _identifier(name, TOOL, "INVALID_REGISTRY")
        result[name] = _risk(risk)
    return result


def _window(issued: Any, expires: Any, now: datetime) -> datetime:
    start, end = _stamp(issued), _stamp(expires)
    if end <= start or end - start > MAX_TTL:
        _fail("INVALID_GRANT_WINDOW")
    if now < start:
        _fail("GRANT_NOT_YET_VALID")
    if now >= end:
        _fail("GRANT_EXPIRED")
    return end


def _check(
    actor: Any, grant: Any, request: Any, registry: Any,
    known_actors: Any, now: Any, used_grant_ids: Any,
    approval: Any, used_approval_ids: Any,
) -> str:
    actor = _record(actor, {"actor_id", "role", "workspaces", "verified_host_source"})
    actor_id = _identifier(actor["actor_id"], IDENT, "UNKNOWN_ACTOR")
    role = actor["role"]
    if type(role) is not str or role not in ROLES:
        _fail("UNKNOWN_ACTOR")
    actor_source = _source(actor["verified_host_source"])
    workspaces = actor["workspaces"]
    if (type(workspaces) not in (list, tuple) or not workspaces
            or len(workspaces) > 32):
        _fail("INVALID_ACTOR_SCOPE")
    scopes = [_identifier(x, WORKSPACE, "INVALID_ACTOR_SCOPE") for x in workspaces]
    if len(scopes) != len(set(scopes)):
        _fail("INVALID_ACTOR_SCOPE")
    if type(known_actors) is not dict or len(known_actors) > 128:
        _fail("INVALID_ACTOR_REGISTRY")
    for known_id, entry in known_actors.items():
        _identifier(known_id, IDENT, "INVALID_ACTOR_REGISTRY")
        _record(entry, {"role", "verified_host_source", "workspaces"})
        if (type(entry["role"]) is not str or entry["role"] not in ROLES
                or type(entry["workspaces"]) not in (list, tuple)
                or not entry["workspaces"] or len(entry["workspaces"]) > 32):
            _fail("INVALID_ACTOR_REGISTRY")
        _source(entry["verified_host_source"])
        if any(type(w) is not str or not WORKSPACE.fullmatch(w)
               for w in entry["workspaces"]):
            _fail("INVALID_ACTOR_REGISTRY")
    known = known_actors.get(actor_id)
    if known is None:
        _fail("UNKNOWN_ACTOR")
    if (known["role"] != role or known["verified_host_source"] != actor_source
            or known["workspaces"] != workspaces):
        _fail("ACTOR_REGISTRY_MISMATCH")

    request = _record(request, {
        "actor_id", "claimed_role", "tool", "workspace", "args", "risk",
    })
    if request["actor_id"] != actor_id:
        _fail("ACTOR_MISMATCH")
    if request["claimed_role"] != role:
        _fail("ROLE_SPOOF")
    tool = _identifier(request["tool"], TOOL, "INVALID_TOOL")
    workspace = _identifier(request["workspace"], WORKSPACE, "INVALID_WORKSPACE")
    if workspace not in scopes:
        _fail("WORKSPACE_OUT_OF_SCOPE")
    risk = _risk(request["risk"])
    registry = _registry(registry)
    if tool not in registry:
        _fail("UNKNOWN_TOOL")
    if tool in EXECUTORS:
        _fail("UNRESTRICTED_EXECUTOR")
    if registry[tool] != risk:
        _fail("RISK_MISMATCH")
    if type(request["args"]) is not dict:
        _fail("INVALID_ARGUMENT_TYPE")
    digest = normalized_args_sha256(request["args"])
    _ids(used_approval_ids)

    grant = _record(grant, {
        "grant_id", "actor_id", "role", "tool", "workspace",
        "args_sha256", "risk", "issued_at", "expires_at", "verified_host_source",
    })
    grant_id = _identifier(grant["grant_id"], IDENT, "INVALID_GRANT_ID")
    if grant_id in _ids(used_grant_ids):
        _fail("GRANT_REPLAY")
    if grant["actor_id"] != actor_id or grant["role"] != role:
        _fail("GRANT_ACTOR_MISMATCH")
    if grant["tool"] != tool or grant["workspace"] != workspace:
        _fail("GRANT_SCOPE_MISMATCH")
    if _risk(grant["risk"]) != risk:
        _fail("GRANT_RISK_MISMATCH")
    if type(grant["args_sha256"]) is not str or not HEX.fullmatch(grant["args_sha256"]):
        _fail("INVALID_GRANT_DIGEST")
    if grant["args_sha256"] != digest:
        _fail("GRANT_ARGUMENT_MISMATCH")
    if _source(grant["verified_host_source"]) != actor_source:
        _fail("HOST_SOURCE_MISMATCH")
    current_time = _stamp(now)
    grant_expiry = _window(grant["issued_at"], grant["expires_at"], current_time)

    if risk == "R3":
        # Standard profile has no independently configured privileged broker.
        _fail("PRIVILEGED_BROKER_REQUIRED")
    if risk == "R2":
        approval = _record(approval, {
            "approval_id", "grant_id", "actor_id", "tool", "workspace",
            "args_sha256", "risk", "issued_at", "expires_at",
            "verified_host_source",
        })
        approval_id = _identifier(approval["approval_id"], IDENT, "INVALID_APPROVAL_ID")
        if approval_id in _ids(used_approval_ids):
            _fail("APPROVAL_REPLAY")
        if (approval["grant_id"] != grant_id or approval["actor_id"] != actor_id
                or approval["tool"] != tool or approval["workspace"] != workspace
                or approval["args_sha256"] != digest or approval["risk"] != risk):
            _fail("APPROVAL_ACTION_MISMATCH")
        if _source(approval["verified_host_source"]) != actor_source:
            _fail("APPROVAL_SOURCE_MISMATCH")
        approval_expiry = _window(
            approval["issued_at"], approval["expires_at"], current_time,
        )
        if _stamp(approval["issued_at"]) < _stamp(grant["issued_at"]):
            _fail("APPROVAL_PREDATES_GRANT")
        if approval_expiry > grant_expiry:
            _fail("APPROVAL_OUTLIVES_GRANT")
    elif approval is not None:
        _fail("UNEXPECTED_APPROVAL")
    return digest


def evaluate_actor_grant(
    actor: Any, grant: Any, request: Any, *,
    registry: Any, known_actors: Any, now: Any, used_grant_ids: Any = (),
    approval: Any = None, used_approval_ids: Any = (),
) -> dict[str, Any]:
    """Fail closed; never returns ALLOW or execution permission.

    Registry, clock, actor, grant, approvals and replay sets are ALL supplied by
    the caller, so a positive result is only a candidate for host verification.
    A trusted MCP server must re-check everything against its own authority.
    """
    report: dict[str, Any] = {
        "decision": "DENY",
        "reason": "INVALID_INPUT",
        "host_enforcement": False,
        "execution_authorized": False,
        "actor_identity_attested": False,
        "approval_attested": False,
        "replay_protection_attested": False,
        "clock_attested": False,
        "normalized_args_sha256": None,
    }
    try:
        digest = _check(
            actor, grant, request, registry, known_actors, now,
            used_grant_ids, approval, used_approval_ids,
        )
    except ContractInputError as exc:
        report["reason"] = str(exc)
    except (TypeError, ValueError, OverflowError, RecursionError):
        # Invalid caller data must never create a positive authorization.
        report["reason"] = "INVALID_INPUT"
    else:
        report["decision"] = "ELIGIBLE_UNVERIFIED"
        report["reason"] = "STRUCTURAL_MATCH_ONLY"
        report["normalized_args_sha256"] = digest
    return report
