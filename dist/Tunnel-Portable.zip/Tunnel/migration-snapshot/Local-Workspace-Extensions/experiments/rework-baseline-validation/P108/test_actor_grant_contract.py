"""P108 adversarial tests: all checks are offline and never authorize MCP."""
import copy
import math
import unittest
from concurrent.futures import ThreadPoolExecutor

from actor_grant_contract import (
    ContractInputError,
    evaluate_actor_grant,
    normalized_args_sha256,
)


class ActorGrantContractTests(unittest.TestCase):
    def setUp(self):
        self.actor = {
            "actor_id": "actor-dev1",
            "role": "developer-1",
            "workspaces": ["projects", "scene-edit"],
            "verified_host_source": "host:demo-issuer",
        }
        self.request = {
            "actor_id": "actor-dev1",
            "claimed_role": "developer-1",
            "tool": "read_file",
            "workspace": "projects",
            "args": {"path": "src/файл.py", "limit": 12},
            "risk": "R0",
        }
        self.registry = {"read_file": "R0", "write_file": "R2", "read_status": "R1"}
        self.grant = {
            "grant_id": "grant-0001",
            "actor_id": "actor-dev1",
            "role": "developer-1",
            "tool": "read_file",
            "workspace": "projects",
            "args_sha256": normalized_args_sha256(self.request["args"]),
            "risk": "R0",
            "issued_at": "2026-11-01T20:59:00Z",
            "expires_at": "2026-11-01T21:04:00Z",
            "verified_host_source": "host:demo-issuer",
        }
        self.now = "2026-11-01T21:00:00Z"

    def evaluate(self, *, actor=None, grant=None, request=None, registry=None,
                 known_actors=None, now=None, used_grant_ids=(), approval=None,
                 used_approval_ids=()):
        if known_actors is None:
            known_actors = {"actor-dev1": {
                "role": "developer-1", "workspaces": ["projects", "scene-edit"],
                "verified_host_source": "host:demo-issuer",
            }}
        return evaluate_actor_grant(
            self.actor if actor is None else actor,
            self.grant if grant is None else grant,
            self.request if request is None else request,
            registry=self.registry if registry is None else registry,
            known_actors=known_actors,
            now=self.now if now is None else now,
            used_grant_ids=used_grant_ids,
            approval=approval,
            used_approval_ids=used_approval_ids,
        )

    def denied(self, reason, **kwargs):
        report = self.evaluate(**kwargs)
        self.assertEqual(report["decision"], "DENY", report)
        self.assertEqual(report["reason"], reason, report)
        self.assertFalse(report["execution_authorized"])
        self.assertFalse(report["host_enforcement"])
        self.assertFalse(report["actor_identity_attested"])
        return report

    def r2(self):
        request = dict(self.request, tool="write_file", risk="R2")
        grant = dict(self.grant, tool="write_file", risk="R2")
        approval = {
            "approval_id": "approval-0001",
            "grant_id": "grant-0001",
            "actor_id": "actor-dev1",
            "tool": "write_file",
            "workspace": "projects",
            "args_sha256": grant["args_sha256"],
            "risk": "R2",
            "issued_at": "2026-11-01T20:59:30Z",
            "expires_at": "2026-11-01T21:03:00Z",
            "verified_host_source": "host:demo-issuer",
        }
        return request, grant, approval

    def test_all_five_roles_have_only_structural_eligibility(self):
        for role in ("developer-1", "developer-2", "developer-3",
                     "developer-4", "architect-reviewer"):
            with self.subTest(role=role):
                actor = dict(self.actor, role=role)
                request = dict(self.request, claimed_role=role)
                grant = dict(self.grant, role=role)
                known = {"actor-dev1": {
                    "role": role, "workspaces": ["projects", "scene-edit"],
                    "verified_host_source": "host:demo-issuer",
                }}
                result = self.evaluate(actor=actor, request=request, grant=grant,
                                       known_actors=known)
                self.assertEqual(result["decision"], "ELIGIBLE_UNVERIFIED")
                self.assertEqual(result["reason"], "STRUCTURAL_MATCH_ONLY")
                for field in ("host_enforcement", "execution_authorized",
                              "actor_identity_attested", "approval_attested",
                              "replay_protection_attested", "clock_attested"):
                    self.assertIs(result[field], False)

    def test_deterministic_report_and_no_mutation(self):
        before = copy.deepcopy((self.actor, self.grant, self.request, self.registry))
        self.assertEqual(self.evaluate(), self.evaluate())
        self.assertEqual(before, (self.actor, self.grant, self.request, self.registry))

    def test_r1_is_structurally_eligible_without_owner_approval(self):
        self.request["tool"] = self.grant["tool"] = "read_status"
        self.request["risk"] = self.grant["risk"] = "R1"
        self.assertEqual(self.evaluate()["decision"], "ELIGIBLE_UNVERIFIED")

    def test_unknown_actor(self):
        actor = dict(self.actor)
        del actor["actor_id"]
        self.denied("INVALID_FIELDS", actor=actor)
        self.denied("UNKNOWN_ACTOR", known_actors={})

    def test_actor_registry_mismatch(self):
        known = {"actor-dev1": {
            "role": "architect-reviewer", "workspaces": ["projects", "scene-edit"],
            "verified_host_source": "host:demo-issuer",
        }}
        self.denied("ACTOR_REGISTRY_MISMATCH", known_actors=known)

    def test_invalid_actor_registry(self):
        self.denied("INVALID_ACTOR_REGISTRY", known_actors={"bad id": {}})
        self.denied("INVALID_ACTOR_REGISTRY", known_actors={"actor-dev1": {
            "role": True, "workspaces": ["projects"],
            "verified_host_source": "host:demo-issuer",
        }})

    def test_invalid_actor_identity(self):
        actor = dict(self.actor, actor_id="bad actor\n")
        self.denied("UNKNOWN_ACTOR", actor=actor)

    def test_forged_reviewer_role_string(self):
        self.denied("ROLE_SPOOF", request=dict(self.request, claimed_role="architect-reviewer"))

    def test_grant_actor_role_spoof(self):
        self.denied("GRANT_ACTOR_MISMATCH", grant=dict(self.grant, role="architect-reviewer"))

    def test_grant_actor_id_mismatch(self):
        self.denied("GRANT_ACTOR_MISMATCH", grant=dict(self.grant, actor_id="actor-other"))

    def test_request_actor_id_mismatch(self):
        self.denied("ACTOR_MISMATCH", request=dict(self.request, actor_id="actor-other"))

    def test_missing_and_false_host_source(self):
        for source in ("", "caller-claims-host", False, None, "host:x"):
            with self.subTest(source=source):
                self.denied("MISSING_HOST_PROVENANCE",
                            actor=dict(self.actor, verified_host_source=source))

    def test_grant_source_mismatch(self):
        self.denied("HOST_SOURCE_MISMATCH",
                    grant=dict(self.grant, verified_host_source="host:other-issuer"))

    def test_unknown_tool(self):
        self.denied("UNKNOWN_TOOL", request=dict(self.request, tool="erase_everything"))

    def test_generic_executor_cannot_bypass_wrapper(self):
        for tool in ("run_script", "run_command", "powershell", "docker_exec"):
            with self.subTest(tool=tool):
                req = dict(self.request, tool=tool)
                grant = dict(self.grant, tool=tool)
                self.denied("UNRESTRICTED_EXECUTOR", request=req, grant=grant,
                            registry={tool: "R0"})

    def test_workspace_out_of_scope(self):
        self.denied("WORKSPACE_OUT_OF_SCOPE",
                    request=dict(self.request, workspace="personal"))

    def test_grant_workspace_mismatch(self):
        self.denied("GRANT_SCOPE_MISMATCH",
                    grant=dict(self.grant, workspace="scene-edit"))

    def test_duplicate_actor_scope_denied(self):
        self.denied("INVALID_ACTOR_SCOPE",
                    actor=dict(self.actor, workspaces=["projects", "projects"]))

    def test_missing_or_bool_risk_denied(self):
        for risk in (None, True, False, 0, 1, "", "R4", "r2"):
            with self.subTest(risk=risk):
                self.denied("INVALID_RISK", request=dict(self.request, risk=risk))
        req = dict(self.request)
        del req["risk"]
        self.denied("INVALID_FIELDS", request=req)

    def test_registry_risk_mismatch(self):
        self.denied("RISK_MISMATCH", registry={"read_file": "R2"})

    def test_grant_risk_mismatch(self):
        self.denied("GRANT_RISK_MISMATCH",
                    grant=dict(self.grant, risk="R1"))

    def test_bad_registry(self):
        for registry in ({}, {"read_file": True}, {"bad name": "R0"}):
            with self.subTest(registry=registry):
                self.denied("INVALID_REGISTRY" if registry == {} or "bad name" in registry
                            else "INVALID_RISK", registry=registry)

    def test_grant_argument_tampering(self):
        req = copy.deepcopy(self.request)
        req["args"]["limit"] = 13
        self.denied("GRANT_ARGUMENT_MISMATCH", request=req)

    def test_bad_grant_digest(self):
        self.denied("INVALID_GRANT_DIGEST", grant=dict(self.grant, args_sha256="abc"))

    def test_stale_grant(self):
        self.denied("GRANT_EXPIRED", now="2026-11-01T21:04:00Z")

    def test_grant_future_issued(self):
        self.denied("GRANT_NOT_YET_VALID", now="2026-11-01T20:58:59Z")

    def test_grant_overlong_ttl(self):
        self.denied("INVALID_GRANT_WINDOW",
                    grant=dict(self.grant, expires_at="2026-11-01T21:06:00Z"))

    def test_grant_reverse_window(self):
        self.denied("INVALID_GRANT_WINDOW",
                    grant=dict(self.grant, expires_at="2026-11-01T20:58:00Z"))

    def test_grant_replay(self):
        self.denied("GRANT_REPLAY", used_grant_ids=["grant-0001"])

    def test_replay_set_malformed(self):
        self.denied("INVALID_REPLAY_SET", used_grant_ids=["grant-0001", "grant-0001"])
        self.denied("INVALID_REPLAY_SET", used_grant_ids="grant-0001")

    def test_missing_r2_approval(self):
        req, grant, _ = self.r2()
        self.denied("INVALID_RECORD", request=req, grant=grant)

    def test_r2_approval_structurally_valid_but_not_authorized(self):
        req, grant, approval = self.r2()
        report = self.evaluate(request=req, grant=grant, approval=approval)
        self.assertEqual(report["decision"], "ELIGIBLE_UNVERIFIED")
        self.assertFalse(report["approval_attested"])
        self.assertFalse(report["execution_authorized"])

    def test_r2_approval_wrong_action(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_ACTION_MISMATCH", request=req, grant=grant,
                    approval=dict(approval, tool="delete_file"))

    def test_r2_approval_wrong_digest(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_ACTION_MISMATCH", request=req, grant=grant,
                    approval=dict(approval, args_sha256="0" * 64))

    def test_r2_approval_wrong_actor(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_ACTION_MISMATCH", request=req, grant=grant,
                    approval=dict(approval, actor_id="actor-other"))

    def test_r2_approval_missing_provenance(self):
        req, grant, approval = self.r2()
        self.denied("MISSING_HOST_PROVENANCE", request=req, grant=grant,
                    approval=dict(approval, verified_host_source=""))

    def test_r2_approval_source_mismatch(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_SOURCE_MISMATCH", request=req, grant=grant,
                    approval=dict(approval, verified_host_source="host:other-issuer"))

    def test_r2_approval_expired(self):
        req, grant, approval = self.r2()
        self.denied("GRANT_EXPIRED", request=req, grant=grant,
                    approval=dict(approval, expires_at="2026-11-01T20:59:45Z"))

    def test_r2_approval_outlives_grant(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_OUTLIVES_GRANT", request=req, grant=grant,
                    approval=dict(approval, expires_at="2026-11-01T21:04:30Z"))

    def test_r2_approval_predates_grant(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_PREDATES_GRANT", request=req, grant=grant,
                    approval=dict(approval, issued_at="2026-11-01T20:58:00Z"))

    def test_r2_approval_replay(self):
        req, grant, approval = self.r2()
        self.denied("APPROVAL_REPLAY", request=req, grant=grant,
                    approval=approval, used_approval_ids=["approval-0001"])

    def test_r3_disabled_even_with_matching_approval(self):
        req, grant, approval = self.r2()
        req["risk"] = grant["risk"] = approval["risk"] = "R3"
        self.denied("PRIVILEGED_BROKER_REQUIRED", request=req, grant=grant,
                    registry={"write_file": "R3"}, approval=approval)

    def test_unexpected_approval_for_read(self):
        _, _, approval = self.r2()
        self.denied("UNEXPECTED_APPROVAL", approval=approval)

    def test_timezone_offsets_are_compared_as_instants(self):
        self.assertEqual(
            self.evaluate(now="2026-11-01T16:00:00-05:00")["decision"],
            "ELIGIBLE_UNVERIFIED",
        )

    def test_invalid_timestamp(self):
        for value in ("2026-11-01T21:00:00", "2026-99-99T21:00:00Z",
                      "2026-11-01T21:00:00+99:99", True):
            with self.subTest(value=value):
                self.denied("INVALID_TIMESTAMP", now=value)

    def test_unicode_nfc_and_order_digest(self):
        self.assertEqual(
            normalized_args_sha256({"text": "е\u0308", "n": 2}),
            normalized_args_sha256({"n": 2, "text": "ё"}),
        )

    def test_duplicate_normalized_key(self):
        with self.assertRaisesRegex(ContractInputError, "DUPLICATE_NORMALIZED_KEY"):
            normalized_args_sha256({"e\u0301": 1, "é": 2})
        with self.assertRaisesRegex(ContractInputError, "DUPLICATE_NORMALIZED_KEY"):
            normalized_args_sha256({"path": "a", "PATH": "b"})

    def test_unsafe_paths_fail_closed(self):
        for value in ("../secret", "src/../secret", "src/%2e%2e%2fsecret",
                      "src/ｃｏｎ.txt", "C:\\Windows\\win.ini",
                      "//server/share", "\\\\server\\share", "src//bad",
                      "src/CONIN$", "src/COM¹.txt", "src/LPT³",
                      "src/file.", "~/.ssh/id_rsa"):
            with self.subTest(path=value):
                req = copy.deepcopy(self.request)
                req["args"]["path"] = value
                self.denied("UNSAFE_ARGUMENT_PATH", request=req)

    def test_path_aliases_cannot_bypass_lexical_guard(self):
        for key in ("file_path", "destination_path", "workdir", "output_file",
                    "source", "target", "folder", "filepath"):
            with self.subTest(key=key):
                req = copy.deepcopy(self.request)
                req["args"][key] = "../private"
                self.denied("UNSAFE_ARGUMENT_PATH", request=req)
        req = copy.deepcopy(self.request)
        req["args"]["options"] = {"destination_path": "C:\\Windows\\win.ini"}
        self.denied("UNSAFE_ARGUMENT_PATH", request=req)

    def test_invalid_arg_types(self):
        for value in (float("nan"), math.inf, 1.5, b"secret", object()):
            with self.subTest(value=type(value).__name__):
                req = copy.deepcopy(self.request)
                req["args"]["limit"] = value
                self.denied("INVALID_ARGUMENT_TYPE", request=req)

    def test_oversized_arguments(self):
        req = copy.deepcopy(self.request)
        req["args"]["text"] = "a" * 5000
        self.denied("ARGUMENT_LIMIT", request=req)

    def test_oversized_collection(self):
        req = copy.deepcopy(self.request)
        req["args"]["values"] = list(range(129))
        self.denied("ARGUMENT_LIMIT", request=req)

    def test_non_json_object(self):
        self.denied("INVALID_RECORD", request=["not", "a", "record"])

    def test_scalar_request_arguments_rejected(self):
        for args in (None, True, 5, ["path", "safe"]):
            with self.subTest(args=args):
                self.denied("INVALID_ARGUMENT_TYPE",
                            request=dict(self.request, args=args))

    def test_malformed_unused_approval_replay_set_rejected(self):
        self.denied("INVALID_REPLAY_SET", used_approval_ids="not-a-list")

    def test_bidi_and_control_characters_rejected(self):
        for value in ("safe\u202eexe", "file\u007f.txt", "line\nsecond"):
            with self.subTest(value=repr(value)):
                req = copy.deepcopy(self.request)
                req["args"]["text"] = value
                self.denied("INVALID_ARGUMENT_TEXT", request=req)

    def test_no_sensitive_input_echoed_in_denial(self):
        req = copy.deepcopy(self.request)
        req["args"]["token"] = "secret-should-not-appear"
        output = str(self.evaluate(request=req))
        self.assertNotIn("secret-should-not-appear", output)
        self.assertNotIn("actor-dev1", output)

    def test_thread_safe_pure_determinism(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: self.evaluate(), range(50)))
        self.assertEqual(results, [results[0]] * 50)
        self.assertFalse(results[0]["replay_protection_attested"])


if __name__ == "__main__":
    unittest.main()
