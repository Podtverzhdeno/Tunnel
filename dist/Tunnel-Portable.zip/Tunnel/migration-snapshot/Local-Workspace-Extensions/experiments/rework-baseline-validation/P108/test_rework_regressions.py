import unittest
from test_actor_grant_contract import ActorGrantContractTests
class ReworkRegression(unittest.TestCase):
    def test_namespaced_executor_does_not_look_like_safe_tool(self):
        f=ActorGrantContractTests();f.setUp()
        for tool in ("local_workspace.run_script","local_workspace.run_command","plugin.run_script"):
            with self.subTest(tool=tool):
                request=dict(f.request,tool=tool)
                grant=dict(f.grant,tool=tool)
                registry={**f.registry,tool:"R0"}
                out=f.evaluate(request=request,grant=grant,registry=registry)
                self.assertEqual(out["decision"],"DENY",out)
                self.assertEqual(out["reason"],"UNRESTRICTED_EXECUTOR",out)
