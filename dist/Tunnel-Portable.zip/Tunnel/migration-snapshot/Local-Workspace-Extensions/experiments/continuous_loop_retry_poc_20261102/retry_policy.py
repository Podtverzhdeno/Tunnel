"""Offline, fail-closed retry decision prototype for feature developer-1:F07.

This module NEVER calls tools, providers, or the live coordinator. Input host
attestation is synthetic unless a future independently reviewed trusted host
adapter supplies it. A boolean in a payload is NOT an authentication boundary.
"""
from dataclasses import dataclass
from enum import Enum


class Decision(str, Enum):
    SAFE_RETRY = "SAFE_RETRY"
    RECONCILE = "OUTCOME_UNKNOWN_RECONCILE"
    STOP = "STOP"


@dataclass(frozen=True)
class OperationPolicy:
    """A policy that must be loaded from a trusted, immutable host registry."""
    operation_id: str
    read_only: bool
    idempotent: bool
    max_retries: int = 2


@dataclass(frozen=True)
class Evidence:
    """Synthetic proof for offline use; not remotely verifiable in this module."""
    state: str  # NOT_DISPATCHED | DISPATCHED | UNKNOWN
    trusted_pre_dispatch_proof: bool = False
    receipt: str = "NONE"  # NONE | VERIFIED_COMMIT | VERIFIED_REJECTION
    error_code: str = "UNKNOWN"
    claimed_retryable: bool = False  # untrusted input, deliberately ignored


@dataclass(frozen=True)
class Result:
    decision: Decision
    reason: str


def classify(policy: OperationPolicy, evidence: Evidence, *, retry_count: int = 0) -> Result:
    """Return a bounded advisory outcome without any side effects.

    No external field, including claimed_retryable, grants authority.
    A real host must attest both the policy identity and pre-dispatch proof.
    """
    if (not isinstance(policy, OperationPolicy)
            or not isinstance(evidence, Evidence)
            or not isinstance(retry_count, int)
            or isinstance(retry_count, bool)):
        return Result(Decision.RECONCILE, "INVALID_INPUT")
    if (not isinstance(policy.operation_id, str)
            or not policy.operation_id
            or len(policy.operation_id) > 128
            or type(policy.read_only) is not bool
            or type(policy.idempotent) is not bool
            or type(policy.max_retries) is not int
            or not 0 <= policy.max_retries <= 5
            or not 0 <= retry_count <= 100):
        return Result(Decision.RECONCILE, "INVALID_POLICY_OR_BUDGET")
    if (not isinstance(evidence.state, str)
            or not isinstance(evidence.receipt, str)
            or not isinstance(evidence.error_code, str)
            or type(evidence.trusted_pre_dispatch_proof) is not bool
            or type(evidence.claimed_retryable) is not bool):
        return Result(Decision.RECONCILE, "MALFORMED_EVIDENCE")
    if (evidence.state not in {"NOT_DISPATCHED", "DISPATCHED", "UNKNOWN"}
            or evidence.receipt not in {"NONE", "VERIFIED_COMMIT", "VERIFIED_REJECTION"}
            or len(evidence.error_code) > 64):
        return Result(Decision.RECONCILE, "UNRECOGNIZED_EVIDENCE")
    if evidence.receipt == "VERIFIED_COMMIT":
        if evidence.state == "NOT_DISPATCHED" and evidence.trusted_pre_dispatch_proof:
            return Result(Decision.RECONCILE, "CONFLICTING_PROOFS")
        return Result(Decision.STOP, "ALREADY_COMMITTED")
    if evidence.state != "NOT_DISPATCHED":
        return Result(Decision.RECONCILE, "MAY_HAVE_EXECUTED")
    if not evidence.trusted_pre_dispatch_proof:
        return Result(Decision.RECONCILE, "NO_TRUSTED_PRE_DISPATCH_PROOF")
    if evidence.receipt != "NONE":
        return Result(Decision.RECONCILE, "CONFLICTING_PRE_DISPATCH_RECEIPT")
    if not (policy.read_only and policy.idempotent):
        return Result(Decision.RECONCILE, "NOT_PROVEN_SAFE_OPERATION")
    if evidence.error_code not in {"HTTP_429", "PROVIDER_UNAVAILABLE"}:
        return Result(Decision.RECONCILE, "UNKNOWN_RETRY_SEMANTICS")
    if retry_count >= policy.max_retries:
        return Result(Decision.STOP, "RETRY_BUDGET_EXHAUSTED")
    return Result(Decision.SAFE_RETRY, "VERIFIED_PRE_DISPATCH_READ_ONLY")
