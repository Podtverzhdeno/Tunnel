"""Negative controls for the offline retry classifier; no live effects."""
import dataclasses
import unittest

from retry_policy import Decision, Evidence, OperationPolicy, classify


READ = OperationPolicy("get_state", read_only=True, idempotent=True, max_retries=2)
WRITE = OperationPolicy("write_state", read_only=False, idempotent=False, max_retries=2)


class RetryPolicyTests(unittest.TestCase):
    def test_one_hundred_lost_receipt_after_possible_commit_are_not_retried(self):
        """100 deterministic post-dispatch ambiguities must NEVER be replayed."""
        for i in range(100):
            with self.subTest(case=i):
                evidence = Evidence(
                    state=("DISPATCHED" if i % 2 else "UNKNOWN"),
                    trusted_pre_dispatch_proof=False,
                    receipt="NONE",
                    error_code=["HTTP_429", "TIMEOUT", "PROVIDER_UNAVAILABLE", "SESSION_TERMINATED"][i % 4],
                    claimed_retryable=True,
                )
                p = READ if i % 3 else WRITE
                self.assertIs(classify(p, evidence, retry_count=i % 3).decision, Decision.RECONCILE)

    def test_trusted_pre_dispatch_readonly_retries_bounded(self):
        evidence = Evidence("NOT_DISPATCHED", True, "NONE", "HTTP_429")
        self.assertIs(classify(READ, evidence).decision, Decision.SAFE_RETRY)
        self.assertIs(classify(READ, evidence, retry_count=1).decision, Decision.SAFE_RETRY)
        self.assertIs(classify(READ, evidence, retry_count=2).decision, Decision.STOP)

    def test_unknown_provider_error_does_not_retry(self):
        for code in ("TIMEOUT", "SESSION_TERMINATED", "", "PAYLOAD_MALFORMED", "DENIED"):
            with self.subTest(code=code):
                ev = Evidence("NOT_DISPATCHED", True, "NONE", code, True)
                self.assertIs(classify(READ, ev).decision, Decision.RECONCILE)

    def test_claimed_retryable_untrusted(self):
        ev = Evidence("DISPATCHED", False, "NONE", "HTTP_429", claimed_retryable=True)
        self.assertIs(classify(READ, ev).decision, Decision.RECONCILE)

    def test_missing_host_proof_never_retry(self):
        ev = Evidence("NOT_DISPATCHED", False, "NONE", "HTTP_429", True)
        self.assertIs(classify(READ, ev).decision, Decision.RECONCILE)

    def test_proved_write_pre_dispatch_never_auto_retry(self):
        ev = Evidence("NOT_DISPATCHED", True, "NONE", "HTTP_429", True)
        self.assertIs(classify(WRITE, ev).decision, Decision.RECONCILE)

    def test_committed_receipt_never_retry(self):
        ev = Evidence("DISPATCHED", False, "VERIFIED_COMMIT", "TIMEOUT", True)
        self.assertIs(classify(READ, ev).decision, Decision.STOP)

    def test_contradictory_commit_and_no_dispatch_reconcile(self):
        ev = Evidence("NOT_DISPATCHED", True, "VERIFIED_COMMIT", "HTTP_429", True)
        self.assertIs(classify(READ, ev).decision, Decision.RECONCILE)

    def test_bad_budget_fail_closed(self):
        ev = Evidence("NOT_DISPATCHED", True, "NONE", "HTTP_429")
        for count in (True, -1, 101, 0.1):
            with self.subTest(count=count):
                self.assertIs(classify(READ, ev, retry_count=count).decision, Decision.RECONCILE)
        for max_retries in (True, -1, 6, "2"):
            with self.subTest(max_retries=max_retries):
                p = dataclasses.replace(READ, max_retries=max_retries)
                self.assertIs(classify(p, ev).decision, Decision.RECONCILE)

    def test_malformed_fields_fail_closed(self):
        valid = Evidence("NOT_DISPATCHED", True, "NONE", "HTTP_429")
        for field, value in (("state", None), ("state", "IN_FLIGHT"),
                             ("receipt", "INVALID"), ("error_code", object()),
                             ("trusted_pre_dispatch_proof", "yes"),
                             ("claimed_retryable", 1)):
            with self.subTest(field=field):
                ev = dataclasses.replace(valid, **{field: value})
                self.assertIs(classify(READ, ev).decision, Decision.RECONCILE)

    def test_readonly_nonidempotent_fails(self):
        p = dataclasses.replace(READ, idempotent=False)
        ev = Evidence("NOT_DISPATCHED", True, "NONE", "HTTP_429")
        self.assertIs(classify(p, ev).decision, Decision.RECONCILE)

    def test_pure_deterministic_without_side_effects(self):
        ev = Evidence("NOT_DISPATCHED", True, "NONE", "PROVIDER_UNAVAILABLE")
        prior = classify(READ, ev)
        self.assertEqual([classify(READ, ev) for _ in range(100)], [prior] * 100)


if __name__ == "__main__":
    unittest.main()
