"""Offline versioned MCP/CLI contract canary (developer-1:F03).

Validates shape and known state transitions; it does not authenticate the
sender, establish leases, verify job execution, or authorize host privileges.
"""
from dataclasses import dataclass
from enum import Enum
import re


class Verdict(str, Enum):
    COMPATIBLE = "SHAPE_COMPATIBLE_ONLY"
    INCOMPLETE = "INCOMPLETE"
    FAIL_CLOSED = "FAIL_CLOSED"


@dataclass(frozen=True)
class Result:
    verdict: Verdict
    reason: str


_RE = re.compile(r"^1[.](0|1|2)$")
_FIELDS = {
    "job_status": {
        "job_id": str, "status": str, "returncode": int, "elapsed_seconds": float,
    },
    "job_output": {
        "job_id": str, "status": str, "next_offset": int, "has_more": bool,
    },
    "lease": {
        "task_id": str, "role": str, "status": str, "expires_at_utc": str,
    },
}


def check(payload: object, *, expected_kind: str) -> Result:
    """Strictly validate critical fields, allow optional additive fields."""
    if (not isinstance(payload, dict)
            or not isinstance(expected_kind, str)
            or expected_kind not in _FIELDS):
        return Result(Verdict.FAIL_CLOSED, "INVALID_ENVELOPE")
    version, kind, data = (
        payload.get("schema_version"), payload.get("kind"), payload.get("payload")
    )
    if not isinstance(version, str) or _RE.fullmatch(version) is None:
        return Result(Verdict.FAIL_CLOSED, "UNKNOWN_SCHEMA_VERSION")
    if kind != expected_kind or not isinstance(data, dict):
        return Result(Verdict.FAIL_CLOSED, "KIND_OR_BODY_MISMATCH")
    for field, typ in _FIELDS[expected_kind].items():
        if field not in data:
            return Result(Verdict.FAIL_CLOSED, "MISSING_CRITICAL_FIELD:" + field)
        val = data[field]
        if typ is float:
            if type(val) not in {float, int} or val < 0:
                return Result(Verdict.FAIL_CLOSED, "INVALID_CRITICAL_FIELD:" + field)
        elif (expected_kind == "job_status" and field == "returncode"
              and val is None and data.get("status") == "running"):
            continue
        elif type(val) is not typ:
            return Result(Verdict.FAIL_CLOSED, "INVALID_CRITICAL_FIELD:" + field)
        elif typ is str and (not val or len(val) > 256):
            return Result(Verdict.FAIL_CLOSED, "INVALID_CRITICAL_FIELD:" + field)
    if expected_kind == "job_status":
        status = data["status"]
        if status not in {"completed", "running", "failed"}:
            return Result(Verdict.FAIL_CLOSED, "UNKNOWN_JOB_STATUS")
        if status != "completed":
            return Result(Verdict.INCOMPLETE, "JOB_NOT_COMPLETED")
        if data["returncode"] != 0:
            return Result(Verdict.FAIL_CLOSED, "JOB_EXIT_NONZERO")
    elif expected_kind == "job_output":
        status = data["status"]
        if status not in {"completed", "running", "failed"}:
            return Result(Verdict.FAIL_CLOSED, "UNKNOWN_OUTPUT_STATUS")
        if status != "completed" or data["has_more"]:
            return Result(Verdict.INCOMPLETE, "OUTPUT_NOT_FINAL")
    else:
        # An active metadata entry is NOT a grant and does not verify the actor.
        if data["status"] not in {"active", "expired", "released", "denied"}:
            return Result(Verdict.FAIL_CLOSED, "UNKNOWN_LEASE_STATUS")
        if data["status"] != "active":
            return Result(Verdict.INCOMPLETE, "LEASE_NOT_ACTIVE")
    return Result(Verdict.COMPATIBLE, "VERSIONED_FIELDS_CONSISTENT")
