"""Version-pair and 12-field schema-drift regression matrix."""
import copy
import unittest

from schema_canary import Verdict, check


def sample(kind, version="1.0"):
    bodies = {
        "job_status": {"job_id": "j1", "status": "completed",
                       "returncode": 0, "elapsed_seconds": 2.0},
        "job_output": {"job_id": "j1", "status": "completed",
                       "next_offset": 10, "has_more": False},
        "lease": {"task_id": "P104", "role": "developer-1",
                  "status": "active", "expires_at_utc": "2026-11-02T18:00:00Z"},
    }
    return {"schema_version": version, "kind": kind, "payload": bodies[kind]}


KINDS_FIELDS = (
    ("job_status", "job_id"), ("job_status", "status"),
    ("job_status", "returncode"), ("job_status", "elapsed_seconds"),
    ("job_output", "job_id"), ("job_output", "status"),
    ("job_output", "next_offset"), ("job_output", "has_more"),
    ("lease", "task_id"), ("lease", "role"),
    ("lease", "status"), ("lease", "expires_at_utc"),
)


class CanaryTests(unittest.TestCase):
    def test_versioned_36_missing_critical_fields_fail_closed(self):
        for version in ("1.0", "1.1", "1.2"):
            for kind, field in KINDS_FIELDS:
                with self.subTest(version=version, kind=kind, field=field):
                    obj = sample(kind, version)
                    del obj["payload"][field]
                    self.assertIs(check(obj, expected_kind=kind).verdict, Verdict.FAIL_CLOSED)

    def test_3_version_pairs_compatible(self):
        for version in ("1.0", "1.1", "1.2"):
            for kind in ("job_status", "job_output", "lease"):
                with self.subTest(kind=kind, version=version):
                    self.assertIs(check(sample(kind, version), expected_kind=kind).verdict, Verdict.COMPATIBLE)

    def test_unknown_major_rejected(self):
        self.assertIs(check(sample("job_status", "2.0"), expected_kind="job_status").verdict, Verdict.FAIL_CLOSED)

    def test_unknown_minor_rejected(self):
        self.assertIs(check(sample("job_status", "1.99"), expected_kind="job_status").verdict, Verdict.FAIL_CLOSED)

    def test_missing_returncode_rejected(self):
        obj = sample("job_status")
        obj["payload"]["returncode"] = None
        self.assertIs(check(obj, expected_kind="job_status").verdict, Verdict.FAIL_CLOSED)

    def test_denied_lease_is_not_grant(self):
        obj = sample("lease")
        obj["payload"]["status"] = "denied"
        self.assertIs(check(obj, expected_kind="lease").verdict, Verdict.INCOMPLETE)

    def test_unknown_denial_status_fail_closed(self):
        obj = sample("lease")
        obj["payload"]["status"] = "DENIED_NEW"
        self.assertIs(check(obj, expected_kind="lease").verdict, Verdict.FAIL_CLOSED)

    def test_nonzero_returncode_not_success(self):
        obj = sample("job_status")
        obj["payload"]["returncode"] = 3
        self.assertIs(check(obj, expected_kind="job_status").verdict, Verdict.FAIL_CLOSED)

    def test_running_job_does_not_count_success(self):
        obj = sample("job_status")
        obj["payload"]["status"] = "running"
        self.assertIs(check(obj, expected_kind="job_status").verdict, Verdict.INCOMPLETE)

    def test_running_job_with_null_returncode_is_incomplete(self):
        obj = sample("job_status")
        obj["payload"]["status"] = "running"
        obj["payload"]["returncode"] = None
        self.assertIs(check(obj, expected_kind="job_status").verdict, Verdict.INCOMPLETE)

    def test_incremental_output_does_not_count_success(self):
        obj = sample("job_output")
        obj["payload"]["has_more"] = True
        self.assertIs(check(obj, expected_kind="job_output").verdict, Verdict.INCOMPLETE)

    def test_optional_additive_field_allowed(self):
        obj = sample("job_status")
        obj["payload"]["debug_metadata"] = {"extra": "safe to ignore"}
        self.assertIs(check(obj, expected_kind="job_status").verdict, Verdict.COMPATIBLE)

    def test_wrong_kind_rejected(self):
        self.assertIs(check(sample("job_status"), expected_kind="lease").verdict, Verdict.FAIL_CLOSED)

    def test_critical_type_confusion_rejected(self):
        obj = sample("job_output")
        obj["payload"]["next_offset"] = False
        self.assertIs(check(obj, expected_kind="job_output").verdict, Verdict.FAIL_CLOSED)


if __name__ == "__main__":
    unittest.main()
