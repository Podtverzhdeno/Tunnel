"""Approval primitives for an eventually host-enforced MCP mutation broker.

SECURITY NOTE: The approval issuer must be a trusted local foreground UI, and
the caller identity must come from authenticated MCP context. Existing unrestricted
run_script/run_command bypasses this module; it is not a security boundary until
those tools are disabled/scoped in the actual Local Workspace MCP server.
"""
import hashlib
from contextlib import closing
import hmac
import secrets
import sqlite3
import time
from pathlib import Path


class ApprovalError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


class ApprovalStore:
    def __init__(self, database, issuer_is_trusted, clock=None):
        if not callable(issuer_is_trusted):
            raise ValueError("A trusted local approval issuer callback is required")
        self.database = Path(database)
        self.issuer_is_trusted = issuer_is_trusted
        self.clock = clock or time.time
        with closing(self._connect()) as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS approvals (
                    token_hash TEXT PRIMARY KEY,
                    actor TEXT NOT NULL,
                    workspace TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    plan_hash TEXT NOT NULL,
                    expires_at REAL NOT NULL,
                    consumed_at REAL
                )
            """)

    def _connect(self):
        db = sqlite3.connect(str(self.database), timeout=5, isolation_level=None)
        db.execute("PRAGMA busy_timeout = 5000")
        return db

    def issue_from_trusted_ui(self, *, actor, workspace, operation, plan_hash, ttl_seconds=120):
        if not self.issuer_is_trusted():
            raise ApprovalError("ISSUER_DENIED", "Approval must come from the trusted UI")
        if not 1 <= ttl_seconds <= 300:
            raise ApprovalError("TTL_INVALID", "Approval TTL must be 1..300 seconds")
        if not all(isinstance(x, str) and 1 <= len(x) <= 512
                   for x in (actor, workspace, operation, plan_hash)):
            raise ApprovalError("SCOPE_INVALID", "Approval target is invalid")
        if len(plan_hash) != 64 or any(ch not in "0123456789abcdef" for ch in plan_hash):
            raise ApprovalError("SCOPE_INVALID", "Plan SHA-256 must be lowercase hexadecimal")
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        now = self.clock()
        with closing(self._connect()) as db:
            db.execute("""
                INSERT INTO approvals (
                    token_hash, actor, workspace, operation, plan_hash,
                    expires_at, consumed_at
                ) VALUES (?,?,?,?,?,?,NULL)
            """, (token_hash, actor, workspace, operation, plan_hash, now + ttl_seconds))
        return {"approval_token": token, "expires_at": now + ttl_seconds}

    def consume(self, *, token, actor, workspace, operation, plan_hash):
        if not isinstance(token, str) or len(token) > 256:
            raise ApprovalError("APPROVAL_REQUIRED", "Missing or malformed trusted approval")
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        db = self._connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("""
                SELECT actor, workspace, operation, plan_hash, expires_at, consumed_at
                FROM approvals WHERE token_hash=?
            """, (token_hash,)).fetchone()
            if row is None:
                raise ApprovalError("APPROVAL_REQUIRED", "Approval does not exist")
            if row[5] is not None:
                raise ApprovalError("APPROVAL_REPLAY", "Approval already consumed")
            if self.clock() >= row[4]:
                raise ApprovalError("APPROVAL_EXPIRED", "Approval expired")
            if not all(hmac.compare_digest(str(actual), str(expected)) for actual, expected
                       in zip(row[:4], (actor, workspace, operation, plan_hash))):
                raise ApprovalError("APPROVAL_SCOPE", "Approval is bound to a different operation")
            db.execute("UPDATE approvals SET consumed_at=? WHERE token_hash=? AND consumed_at IS NULL",
                       (self.clock(), token_hash))
            db.execute("COMMIT")
            return True
        except BaseException:
            db.execute("ROLLBACK")
            raise
        finally:
            db.close()
