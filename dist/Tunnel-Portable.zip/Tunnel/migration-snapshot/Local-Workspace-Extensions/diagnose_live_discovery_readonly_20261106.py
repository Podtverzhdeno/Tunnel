"""Read-only live probe for 2026-07-28 compatibility; prints only status and error code.
No auth material, credentials, file listings, tools/call, or mutations.
"""
import json,urllib.request,urllib.error
URL="http://127.0.0.1:8765/mcp"
def probe(method,modern=False):
    msg={"jsonrpc":"2.0","id":771,"method":method,"params":{}}
    hdr={"Content-Type":"application/json","Accept":"application/json, text/event-stream"}
    if modern:
        hdr.update({"Mcp-Protocol-Version":"2026-07-28","Mcp-Method":method})
        msg["params"]["_meta"]={"io.modelcontextprotocol/protocolVersion":"2026-07-28",
                                 "io.modelcontextprotocol/clientCapabilities":{}}
    elif method=="initialize":
        msg["params"]={"protocolVersion":"2025-11-25","capabilities":{},
                       "clientInfo":{"name":"local-readonly-probe","version":"1"}}
    req=urllib.request.Request(URL,data=json.dumps(msg).encode(),headers=hdr,method="POST")
    try:
        with urllib.request.urlopen(req,timeout=6) as r:
            status=r.status; body=json.load(r)
    except urllib.error.HTTPError as exc:
        status=exc.code
        try: body=json.loads(exc.read(40000))
        except ValueError: body={}
    except Exception as exc:
        print("probe",method,modern,"error",type(exc).__name__);return
    error=body.get("error") if isinstance(body,dict) else {}
    if not isinstance(error,dict):error={"message":str(error)[:100]}
    result=body.get("result") if isinstance(body,dict) else {}
    print("probe",method,modern,"HTTP",status,"error_code",error.get("code"),
          "error_kind",error.get("message","")[:80],
          "resultType",result.get("resultType") if isinstance(result,dict) else None,
          "protocol",result.get("protocolVersion") if isinstance(result,dict) else None)
probe("initialize")
probe("server/discover",True)
probe("tools/list",True)
