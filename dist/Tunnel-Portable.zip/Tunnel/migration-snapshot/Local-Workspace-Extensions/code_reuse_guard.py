"""Repository-scoped, standard-library AST reuse guard for multi-agent coding.

Separate concerns:
* HARD blockers: substantial, exactly equivalent normalized function bodies
  newly authored in different production modules. Reviewer must refuse merge.
* ADVISORY: highly similar bodies needing architectural inspection, never
  automatically rejected as semantic duplicates.
* PRESUBMIT: use the same guard before code submission for early feedback.

No embeddings/LLM judgement, no network, no source edits, no tokens, no
developer-supplied skip/waiver. An exact clone gate is not a proof of code
correctness or a complete semantic duplicate detector.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import re
from functools import lru_cache
from collections import Counter
from pathlib import Path

MAX_SOURCE_BYTES = 2 * 1024 * 1024
MAX_MODULES = 350
MAX_NORMALIZED_FUNCTIONS = 8000
MAX_COMPARE_PAIRS = 500_000
MIN_BODY_NODES = 35
MIN_BODY_STATEMENTS = 3
MIN_NEAR_NODES = 70
NEAR_JACCARD = 0.91
NAME = re.compile(r"(?:[a-z][a-z0-9_]*|test_[a-z][a-z0-9_]*)\.py\Z")


class ReuseGuardError(ValueError):
    pass


def _checked_source_text(path: Path) -> str:
    """Always read current content; never trust mtime alone for cache reuse."""
    if (path.is_symlink() or getattr(path, "is_junction", lambda: False)() or
            not path.is_file() or path.stat().st_size > MAX_SOURCE_BYTES):
        raise ReuseGuardError("UNSAFE_SOURCE_FILE")
    try:
        content = path.read_text(encoding="utf-8", errors="strict")
        if len(content.encode("utf-8")) > MAX_SOURCE_BYTES:
            raise ReuseGuardError("UNSAFE_SOURCE_FILE")
        return content
    except UnicodeError as exc:
        raise ReuseGuardError("SOURCE_PARSE_FAILED:" + path.name) from exc


def _load_module(path: Path) -> ast.Module:
    try:
        return ast.parse(_checked_source_text(path), filename=path.name)
    except ReuseGuardError:
        raise
    except (SyntaxError, UnicodeError, ValueError, RecursionError) as exc:
        raise ReuseGuardError("SOURCE_PARSE_FAILED:" + path.name) from exc


def _functions(tree):
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            yield node.name, node
        if isinstance(node,ast.ClassDef):
            for meth in node.body:
                if isinstance(meth,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    yield node.name+"."+meth.name,meth


def _normalize_function(node):
    """Preserve APIs, constants and control flow while renaming local bindings.

    Local variable renames cannot make duplicated logic appear different,
    but differing called APIs and literal values remain distinct.
    """
    body=list(node.body)
    if body and isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):
        body=body[1:]
    if len(body)<MIN_BODY_STATEMENTS:
        return None
    size=sum(1 for stmt in body for _ in ast.walk(stmt))
    if size<MIN_BODY_NODES:
        return None
    param_names=[x.arg for x in (node.args.posonlyargs+node.args.args+node.args.kwonlyargs)]
    if node.args.vararg:param_names.append(node.args.vararg.arg)
    if node.args.kwarg:param_names.append(node.args.kwarg.arg)
    # Assignments inside nested lambdas/comprehensions have their own scope;
    # fail toward under-detection instead of treating their names as globals.
    names=dict((x,"_local_"+str(i)) for i,x in enumerate(param_names))
    class Locals(ast.NodeVisitor):
        def visit_ExceptHandler(self,n):
            if n.name is not None and n.name not in names:
                names[n.name]="_local_"+str(len(names))
            self.generic_visit(n)
        def visit_Import(self,n):
            for alias in n.names:
                bound=alias.asname or alias.name.split(".",1)[0]
                if bound not in names:names[bound]="_local_"+str(len(names))
        def visit_ImportFrom(self,n):
            for alias in n.names:
                if alias.name=="*":continue
                bound=alias.asname or alias.name
                if bound not in names:names[bound]="_local_"+str(len(names))
        def visit_Name(self,n):
            if isinstance(n.ctx,(ast.Store,ast.Del)) and n.id not in names:
                names[n.id]="_local_"+str(len(names))
        def visit_FunctionDef(self,n):pass
        def visit_AsyncFunctionDef(self,n):pass
        def visit_ClassDef(self,n):pass
        def visit_Lambda(self,n):pass
    visitor=Locals()
    for stmt in body:visitor.visit(stmt)
    class Rename(ast.NodeTransformer):
        def visit_ExceptHandler(self,n):
            if n.name in names:n.name=names[n.name]
            return self.generic_visit(n)
        def visit_Import(self,n):
            for alias in n.names:
                if alias.asname in names:alias.asname=names[alias.asname]
            return n
        def visit_ImportFrom(self,n):
            for alias in n.names:
                if alias.asname in names:alias.asname=names[alias.asname]
            return n
        def visit_Name(self,n):
            if n.id in names:
                n.id=names[n.id]
            return n
        def visit_FunctionDef(self,n):return n
        def visit_AsyncFunctionDef(self,n):return n
        def visit_ClassDef(self,n):return n
        def visit_Lambda(self,n):return n
    cloned=ast.Module(body=copy.deepcopy(body),type_ignores=[])
    normalized=Rename().visit(cloned).body
    # Defaults, parameter kinds, decorators and async semantics may change
    # a function's contract even when its statement body looks identical.
    # Include them in the HARD-clone fingerprint to avoid false rejections.
    signature={
        "async":isinstance(node,ast.AsyncFunctionDef),
        "posonly":len(node.args.posonlyargs),
        "positional":len(node.args.args),
        "kwonly":len(node.args.kwonlyargs),
        "vararg":node.args.vararg is not None,
        "kwarg":node.args.kwarg is not None,
        "param_annotations":[ast.dump(x.annotation, include_attributes=False) if x.annotation else None for x in (node.args.posonlyargs+node.args.args+node.args.kwonlyargs)],
        "vararg_annotation":(ast.dump(node.args.vararg.annotation, include_attributes=False) if node.args.vararg and node.args.vararg.annotation else None),
        "kwarg_annotation":(ast.dump(node.args.kwarg.annotation, include_attributes=False) if node.args.kwarg and node.args.kwarg.annotation else None),
        "return_annotation":(ast.dump(node.returns, include_attributes=False) if node.returns else None),
        "defaults":[ast.dump(x,include_attributes=False) for x in node.args.defaults],
        "kw_defaults":[ast.dump(x,include_attributes=False) if x else None for x in node.args.kw_defaults],
        "decorators":[ast.dump(x,include_attributes=False) for x in node.decorator_list],
    }
    rendered=json.dumps(signature,sort_keys=True)+ast.dump(
        ast.Module(body=normalized,type_ignores=[]),include_attributes=False)
    digest=hashlib.sha256(rendered.encode("utf-8")).hexdigest()
    tokens=Counter()
    for stmt in normalized:
        for n in ast.walk(stmt):
            if isinstance(n,ast.Call):
                if isinstance(n.func,ast.Name):tokens["call:"+n.func.id]+=2
                elif isinstance(n.func,ast.Attribute):tokens["callattr:"+n.func.attr]+=2
            elif isinstance(n,(ast.If,ast.For,ast.AsyncFor,ast.While,
                               ast.Try,ast.With,ast.Return,ast.Raise,
                               ast.Compare,ast.BoolOp,ast.ListComp,
                               ast.DictComp,ast.Assign)):
                tokens[type(n).__name__]+=1
            elif isinstance(n,ast.Attribute):
                tokens["attr:"+n.attr]+=1
    return {"hash":digest,"tokens":tokens,"node_count":size,
            "statement_count":len(body)}


def _entries(name,tree):
    for symbol,node in _functions(tree):
        meta=_normalize_function(node)
        if meta:
            yield {"file":name,"symbol":symbol,"line":node.lineno,**meta}


# Bounded in-memory cache for repeated READ-ONLY queue previews. A fresh
# source read is part of EVERY lookup; only its exact content may reuse AST
# normalization. No persistent cache, timestamps, approval result, or QC skips.
MAX_CACHED_SOURCE_CHARS = 96 * 1024


@lru_cache(maxsize=96)
def _cached_main_entries(name: str, content: str):
    try:
        return tuple(_entries(name, ast.parse(content, filename=name)))
    except (SyntaxError, UnicodeError, ValueError, RecursionError) as exc:
        raise ReuseGuardError("SOURCE_PARSE_FAILED:" + name) from exc


def _main_entries(path: Path):
    source = _checked_source_text(path)
    if len(source) > MAX_CACHED_SOURCE_CHARS:
        try:
            return tuple(_entries(path.name, ast.parse(source, filename=path.name)))
        except (SyntaxError, UnicodeError, ValueError, RecursionError) as exc:
            raise ReuseGuardError("SOURCE_PARSE_FAILED:" + path.name) from exc
    return _cached_main_entries(path.name, source)


def _similarity(a,b):
    x,y=a["tokens"],b["tokens"]
    union=sum((x|y).values())
    return sum((x&y).values())/union if union else 0


def audit(root, candidate_files, *, include_near=True):
    """Compare candidate modules against existing production main and each other.

    root and paths must already be authorized. Only top-level *.py production
    modules are considered. No .agent-team snapshots, test fixtures or assets.
    """
    root=Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ReuseGuardError("UNSAFE_PROJECT_ROOT")
    if not isinstance(candidate_files,dict) or not 1<=len(candidate_files)<=6:
        raise ReuseGuardError("INVALID_CANDIDATE_SET")
    candidates={}
    for name,path in candidate_files.items():
        if (type(name) is not str or not NAME.fullmatch(name) or
            name.startswith("test_") or name in candidates):
            raise ReuseGuardError("INVALID_CANDIDATE_NAME")
        candidates[name]=_load_module(Path(path))
    main=[]
    count=0
    for path in sorted(root.glob("*.py")):
        if path.name.startswith("test_") or path.name in candidates:continue
        if not NAME.fullmatch(path.name):continue
        count+=1
        if count>MAX_MODULES:
            raise ReuseGuardError("SOURCE_INDEX_CAP_EXCEEDED")
        for item in _main_entries(path):
            if len(main)>=MAX_NORMALIZED_FUNCTIONS:
                raise ReuseGuardError("FUNCTION_INDEX_CAP_EXCEEDED")
            main.append(item)
    source=[]
    for name,tree in sorted(candidates.items()):
        for item in _entries(name,tree):
            if len(main)+len(source)>=MAX_NORMALIZED_FUNCTIONS:
                raise ReuseGuardError("FUNCTION_INDEX_CAP_EXCEEDED")
            source.append(item)
    hard=[]; review=[]
    compared_pairs=0
    for i,item in enumerate(source):
        for other in main+source[:i]:
            compared_pairs+=1
            if compared_pairs>MAX_COMPARE_PAIRS:
                raise ReuseGuardError("COMPARISON_BUDGET_EXCEEDED")
            # Earlier candidate functions, including those in the same module,
            # are eligible for an exact structural clone check.
            left={"file":item["file"],"symbol":item["symbol"],"line":item["line"]}
            right={"file":other["file"],"symbol":other["symbol"],"line":other["line"]}
            if item["hash"]==other["hash"]:
                hard.append({"code":"EXACT_DUPLICATE_IMPLEMENTATION",
                             "candidate":left,"existing":right,
                             "body_sha256":item["hash"]})
            elif (include_near and item["node_count"]>=MIN_NEAR_NODES
                  and other["node_count"]>=MIN_NEAR_NODES):
                s=_similarity(item,other)
                if s>=NEAR_JACCARD:
                    review.append({"code":"POSSIBLE_REIMPLEMENTATION_REVIEW",
                                   "candidate":left,"existing":right,
                                   "heuristic_similarity":round(s,4)})
    return {
        "schema":"agent-code-reuse-guard-v1",
        "decision":"BLOCK" if hard else "REVIEW" if review else "PASS",
        "hard_blockers":hard[:40],
        "review_findings":review[:40],
        "hard_findings_truncated":len(hard)>40,
        "review_findings_truncated":len(review)>40,
        "scanned_main_modules":count,
        "indexed_production_functions":len(main)+len(source),
        "compared_function_pairs":compared_pairs,
        "candidate_production_functions":len(source),
        "candidate_test_files_excluded":True,
        "no_mutations":True,
        "semantic_equivalence_proven":False,
    }


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",required=True)
    parser.add_argument("--candidate",action="append",required=True,
                        metavar="NAME=PATH")
    parser.add_argument("--no-near",action="store_true")
    args=parser.parse_args(argv)
    try:
        candidates={}
        for spec in args.candidate:
            if "=" not in spec:raise ReuseGuardError("CANDIDATE_ARGUMENT_INVALID")
            name,path=spec.split("=",1)
            if name in candidates:raise ReuseGuardError("DUPLICATE_CANDIDATE_ARGUMENT")
            candidates[name]=path
        result=audit(args.root,candidates,include_near=not args.no_near)
        print(json.dumps({"ok":result["decision"]!="BLOCK","data":result}))
        return 2 if result["decision"]=="BLOCK" else 0
    except (ReuseGuardError,OSError) as exc:
        print(json.dumps({"ok":False,"error":str(exc)[:180]}))
        return 2


if __name__=="__main__":
    raise SystemExit(main())
