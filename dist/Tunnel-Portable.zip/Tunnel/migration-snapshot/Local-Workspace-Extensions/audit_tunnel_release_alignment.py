"""Read-only audit: compute Git blob SHA1 for all ZIP members in the local published distribution."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent.parent/"Tunnel-release-staging"
dist=root/"dist"
names=("Tunnel-Complete-Windows.zip","Local-Workspace-MCP.zip",
       "New-Chat-Smoke-Test.zip","Web-Companion-Extension.zip")
result={}
for n in names:
    path=dist/n
    data=path.read_bytes()
    row={"archive_sha256":hashlib.sha256(data).hexdigest(),
         "archive_size":len(data),"members":{}}
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            b=z.read(name)
            blob=hashlib.sha1(b"blob "+str(len(b)).encode("ascii")+b"\x00"+b).hexdigest()
            row["members"][name]={"git_blob_sha":blob,"bytes":len(b)}
    result[n]=row
print(json.dumps({"ok":True,"archives":result},ensure_ascii=True,separators=(",",":")))
