"""Read-only logistics routing for scheduled coding and independent QA.

Composes existing coordinator/peer/support/triage APIs. Does not claim work,
make approvals, update SQLite, or pretend that optional QA is a real lease.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPERIMENT = ROOT / "experiments" / "chat_only_run"
if str(EXPERIMENT) not in sys.path:
    sys.path.insert(0, str(EXPERIMENT))

ROLES = ("developer-1", "developer-2", "developer-3", "developer-4")
SHARED = frozenset(("developer-3", "developer-4"))
MAX_QUEUE = 500
MAX_REPORTS = 1500
REPORT_RE = re.compile(r"logistics_secondpass_(P[0-9]{3})_([0-9a-f]{64})_(developer-[1-4])\.json\Z")
DIGEST_RE = re.compile(r"[0-9a-f]{64}\Z")


class DispatchError(ValueError):
    pass


def _is_task_id(task_id):
    return isinstance(task_id, str) and len(task_id) == 4 and task_id[0] == "P" and task_id[1:].isdigit()


def read_secondpass_receipts(report_dir):
    """Advisory dedup only; never turns a report into an accepted QA receipt."""
    report_dir = Path(report_dir)
    if report_dir.is_symlink() or getattr(report_dir, "is_junction", lambda: False)():
        raise DispatchError("UNSAFE_REPORT_DIRECTORY")
    if not report_dir.is_dir():
        return set()
    files = list(report_dir.glob("logistics_secondpass_*.json"))
    if len(files) > MAX_REPORTS:
        raise DispatchError("UNBOUNDED_SECOND_PASS_LEDGER")
    finished = set()
    for path in files:
        match = REPORT_RE.fullmatch(path.name)
        if match is None:
            raise DispatchError("MALFORMED_SECOND_PASS_FILENAME")
        if path.is_symlink() or getattr(path, "is_junction", lambda: False)():
            raise DispatchError("UNSAFE_SECOND_PASS_RECEIPT")
        if not path.is_file() or path.stat().st_size > 16384:
            raise DispatchError("INVALID_SECOND_PASS_FILE")
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeError, ValueError, OSError) as exc:
            raise DispatchError("INVALID_SECOND_PASS_JSON") from exc
        task_id, source_digest, role = match.groups()
        if (not isinstance(doc, dict)
                or doc.get("schema") != "logistics-secondpass-advisory-v1"
                or doc.get("task_id") != task_id
                or doc.get("source_digest") != source_digest
                or doc.get("role") != role
                or not isinstance(doc.get("new_negative_case"), str)
                or len(doc["new_negative_case"].strip()) < 35
                or not isinstance(doc.get("checks"), list)
                or not doc["checks"]
                or doc.get("formal_accept") is not False):
            raise DispatchError("INVALID_SECOND_PASS_RECEIPT")
        finished.add((task_id, source_digest))
    return finished


def decide(peer_plans, support_plans, triage, authors, peer_records, *, source_digests=None, completed_secondpass=()):
    """Pure no-side-effect lane selection. Role identity is *not* attested."""
    if not all(isinstance(x, dict) for x in
               (peer_plans, support_plans, triage, authors, peer_records)):
        raise DispatchError("INVALID_SNAPSHOT")
    if set(peer_plans) != set(ROLES) or set(support_plans) != set(ROLES):
        raise DispatchError("MISSING_ROLE_SNAPSHOT")
    waiting = triage.get("waiting_oldest_first")
    reviewing = triage.get("reviewing_lease_holders")
    if not isinstance(waiting, list) or not isinstance(reviewing, list):
        raise DispatchError("INVALID_REVIEW_TRIAGE")
    if len(waiting) + len(reviewing) > MAX_QUEUE:
        raise DispatchError("UNBOUNDED_REVIEW_QUEUE")
    report = {}
    candidates_for_optional = []
    for role in ROLES:
        peer, support = peer_plans[role], support_plans[role]
        if not isinstance(peer, dict) or not isinstance(support, dict):
            raise DispatchError("INVALID_ROLE_PLAN")
        coding = peer.get("recommended_code_task")
        next_peer = peer.get("recommended_peer_task")
        next_support = support.get("recommended_support_task")
        if coding is not None and not _is_task_id(coding):
            raise DispatchError("INVALID_CODING_CANDIDATE")
        if next_peer is not None and not _is_task_id(next_peer):
            raise DispatchError("INVALID_PEER_CANDIDATE")
        if next_support is not None and (not isinstance(next_support, dict)
                                         or not isinstance(next_support.get("work_key"), str)):
            raise DispatchError("INVALID_SUPPORT_CANDIDATE")
        active = support.get("active_support_tasks") or []
        if not isinstance(active, list):
            raise DispatchError("INVALID_ACTIVE_SUPPORT")
        mode = support.get("mode")
        if coding:
            item = ("CODING_CANDIDATE", coding, "Fresh task-scoped lease, host identity, and complete QA required")
        elif next_peer:
            item = ("CLAIMABLE_PEER_REVIEW_CANDIDATE", next_peer, "Separate legitimate peer lease and anti-self-review required")
        elif mode == "resume_support" or active:
            item = ("RESUME_SUPPORT_WITH_ORIGINAL_TOKEN", None, "Use the original valid advisory token; never claim a second task")
        elif mode == "architect_support" and next_support:
            item = ("CLAIMABLE_ARCHITECT_SUPPORT_CANDIDATE", next_support["work_key"], "Advisory-only support lease; verify SHA and independence")
        elif mode not in ("idle", "architect_support", "coding", "peer_review"):
            raise DispatchError("UNKNOWN_SUPPORT_MODE")
        else:
            item = ("NO_CLAIMABLE_WORK", None, "All legal claimable lanes exhausted")
        report[role] = {
            "lane": item[0], "task_or_key": item[1], "condition": item[2],
            "review_permissions": "ADVISORY_ONLY",
            "host_actor_authenticated": False,
            "may_formally_accept_or_merge": False,
        }
        if item[0] == "NO_CLAIMABLE_WORK":
            candidates_for_optional.append(role)
    used = set()
    suggestions = 0
    # Optional follow-ups are NOT claims or work authorizations. Avoid assigning
    # the same live review twice or reviewing the shared D3+D4 authors.
    review_items = list(waiting) + [
        x for x in reviewing if x.get("lease_state") == "EXPIRED"
    ]
    for role in candidates_for_optional:
        excluded = SHARED if role in SHARED else {role}
        eligible = []
        for item in review_items:
            task_id = item.get("task_id")
            author = item.get("author_role")
            if not _is_task_id(task_id) or task_id in used or author not in ROLES:
                continue
            source_digest = source_digests.get(task_id) if source_digests is not None else None
            if source_digests is not None and (not isinstance(source_digest, str) or not DIGEST_RE.fullmatch(source_digest)):
                continue  # Unverifiable original source: never propose optional QA.
            if source_digest is not None and (task_id, source_digest) in completed_secondpass:
                continue  # An advisory pass on this exact candidate revision already exists.
            past_authors = authors.get(task_id, ())
            if (not isinstance(past_authors, (list, tuple, set, frozenset))
                    or any(a not in ROLES for a in past_authors)):
                raise DispatchError("INVALID_AUTHOR_HISTORY")
            if (set(past_authors) | {author}) & excluded:
                continue
            peer = peer_records.get(task_id, {})
            if not isinstance(peer, dict):
                raise DispatchError("INVALID_PEER_EVIDENCE")
            # A negative peer verdict is an urgency hint, not independently
            # verified truth. Age breaks ties to avoid oldest-task starvation.
            priority = 0 if peer.get("verdict") == "CHANGES_REQUESTED" else 1
            age = item.get("queued_minutes")
            safe_age = age if isinstance(age, (int, float)) and not isinstance(age, bool) and 0 <= age <= 1e7 else 0
            eligible.append((priority, -safe_age, task_id))
        if not eligible:
            continue
        _, _, candidate = min(eligible)
        used.add(candidate)
        suggestions += 1
        digest = source_digests.get(candidate) if source_digests is not None else None
        output_file = ("logistics_secondpass_" + candidate + "_" + digest + "_" + role + ".json"
                       if digest is not None else None)
        report[role].update({
            "lane": "OPTIONAL_NOVEL_SECOND_PASS_ADVISORY",
            "task_or_key": candidate,
            "source_digest": digest,
            "advisory_report_path": ".agent-team/reports/" + output_file if output_file else None,
            "condition": "Only if a genuinely new falsifiable negative case exists; verify source SHA and past evidence FIRST. No claim, lease, approval or duplicate tests. If written, use the uniquely named advisory report path and never overwrite.",
            "not_a_peer_lease": True,
            "guaranteed_useful_work": False,
        })
    review_count = triage.get("review_waiting")
    if type(review_count) is not int or review_count < 0:
        raise DispatchError("INVALID_REVIEW_COUNT")
    return {
        "schema": "agent-logistics-dispatch-v1",
        "read_only": True,
        "owner_approval_granted": False,
        "host_actor_authenticated": False,
        "formal_review_authorized": False,
        "tasks_waiting_for_architect": review_count,
        "optional_non_leased_suggestions": suggestions,
        "roles": report,
        "coordination": {
            "priority": "authorized code > independent peer > architect-support > one novel advisory > truthful idle",
            "after_every_task": "recheck code FIRST and then available independent review",
            "review_backlog_does_not_equal_unclaimed_peer_work": True,
            "P085_host_identity_blocks_formal_review": True,
            "next_owner_action": "Resolve trusted reviewer P085 and verify roadmap/foreground owner admission separately; do not auto-approve.",
        },
    }


def snapshot():
    # Existing modules own all SQL, source fingerprints and permission checks.
    from peer_review_switch import get_live, read_peer_state, plan as peer_plan, fingerprint
    from architect_support import plan as support_plan
    from review_queue_triage import analyze, snapshot as triage_snapshot
    tasks, authors = get_live()
    peers = read_peer_state()
    triage = analyze(triage_snapshot())
    peer = {role: peer_plan(role) for role in ROLES}
    support = {role: support_plan(role) for role in ROLES}
    revisions = {}
    for task_id, item in tasks.items():
        if item.get("status") not in ("review", "reviewing"):
            continue
        try:
            revisions[task_id] = fingerprint(item)
        except (OSError, ValueError, TypeError):
            pass  # Unverifiable sources can never become optional QA targets.
    receipts = read_secondpass_receipts(ROOT / ".agent-team" / "reports")
    return decide(peer, support, triage, authors, peers,
                  source_digests=revisions, completed_secondpass=receipts)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args(argv)
    try:
        result = snapshot()
    except (DispatchError, OSError, ValueError, RuntimeError) as exc:
        print(json.dumps({"ok": False, "error": type(exc).__name__ + ":" + str(exc)[:160]}))
        return 2
    print(json.dumps({"ok": True, "data": result}, ensure_ascii=True,
                     indent=2 if args.pretty else None))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
