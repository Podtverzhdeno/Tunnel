# Local Workspace Extensions — MCP / Docker / PostgreSQL

**Статус:** код и тесты созданы локально в `projects/Local-Workspace-Extensions`. Вызывается уже сейчас через существующий `Local Workspace.run_script`. Для появления самостоятельных MCP tools надо импортировать `mcp_adapter.register_tools(mcp)` в действующий MCP-сервер и перезапустить его. Исходник сервера **вне предоставленного workspace**, поэтому эта регистрация пока не произведена.

## PC Toolbox (новое: терминал и 12 диагностических инструментов)

Рабочий Windows PC доступен через уже подключённый Local Workspace MCP. Создан `pc_toolbox.py` с безопасными терминальными шаблонами, системными метриками, процессами, проверкой портов, поиском по коду, хешированием, AST, Git-картой, предпросмотром тестов и FFprobe. Полные вызовы и ограничения: [docs/PC_TOOLBOX.md](docs/PC_TOOLBOX.md).

**Нативная регистрация:** создан `pc_host_extension.py` для встраивания только 12 новых команд в действующий сервер, а `native_pc_extension_mcp.py` прошёл реальный MCP wire-тест (12/12 инструментов и 7 проверок). Действующий сервер ChatGPT пока не обновлён: его исходный каталог недоступен в workspace `projects`. Точные инструкции, безопасный откат: [docs/MCP_PC_ACTIVATION.md](docs/MCP_PC_ACTIVATION.md).

Вызов из этого чата: `Local Workspace.run_script(path="Local-Workspace-Extensions/pc_toolbox.py", cwd="Local-Workspace-Extensions", args=["terminal","python_version"], workspace="projects")`; затем проверить `job_status` и `job_output`. `mcp_adapter.register_tools` содержит 30 read-only/preview определений, но новые нативные MCP tools **не установлены в работающий host**: для этого требуется интеграция в исходный код запущенного сервера. Никаких shell=True или повышения прав.

## Как вызвать из ChatGPT

Используйте Local Workspace `run_script`:
- `workspace="projects"`
- `path="Local-Workspace-Extensions/ops.py"`
- `cwd="Local-Workspace-Extensions"`
- `args=["docker_stats"]` или другие параметры ниже.

`run_script` возвращает `job_id`, затем `job_status(ident=job_id)` и `job_output(ident=job_id)`. Из поля `job_output.text` разбирается JSON. ASCII-safe JSON восстанавливает русский текст после декодирования `\\uXXXX`.

| Action / args | Назначение | Изменяет состояние? |
| --- | --- | --- |
| `read_text Scheduled-Agent-Harness/harness.py --start-line 1 --max-lines 100` | UTF-8 текст с нумерованными строками/SHA256 | Нет |
| `docker_status`, `docker_ps` | Docker Engine и контейнеры | Нет |
| `docker_logs mycontainer --tail 100` | Последние логи контейнера | Нет |
| `docker_service_logs project/compose.yml backend --tail 100` | Логи Compose-сервиса | Нет |
| `docker_stats`, `docker_stats --container mycontainer` | CPU/RAM/сетевые метрики | Нет |
| `postgres_ping`, `postgres_status` | Готовность локального PostgreSQL | Нет |
| `postgres_schema --user admin --database appdb --schema public --limit 100` | Список таблиц/полей, требует доступ к БД | Нет |
| `postgres_query_ro "SELECT * FROM public.items" --user mcp_readonly --database appdb --limit 50` | Ограниченный SELECT; JSON-объекты | Только чтение SQL* |
| `http_healthcheck http://127.0.0.1:8080/health` | HTTP status localhost, без redirect/proxy | Нет |
| `port_inspect 5432` | Открытый TCP-порт и Windows PID | Нет |
| `compose_up project/compose.yml backend` | План запуска Compose | Нет |
| `compose_down project/compose.yml` | План остановки Compose | Нет |
| `service_stack_up project/compose.yml backend --health-url http://127.0.0.1:8080/health --postgres-check` | План запуска и проверок | Нет |

`compose_up`, `compose_down`, `service_stack_up` с `--apply` **реально изменяют инфраструктуру**; это доступно только из CLI и требует отдельного явного разрешения владельца на конкретное действие. В MCP-адаптере зарегистрированы только **preview** функции, без `--apply`. `compose_down --apply` остановит весь Compose-проект без удаления named volumes; возможна потеря доступности, поэтому требуется отдельное подтверждение.

* `postgres_query_ro` не даёт абсолютной гарантии против побочных эффектов пользовательских функций SQL; используйте только выделенную роль с минимальными `SELECT` grants и не позволяйте ей выполнять опасные функции. SELECT проверяется статически, ограничен 200 строками, 3-секундным timeout, транзакцией `READ ONLY` и проверкой запрета повышенных ролей. В SQL запрещены multiple statements, комментарии, DDL/DML и вызовы ряда опасных функций. Допустима только локальная БД. Для аутентификации предоставьте Postgres секрет через системный механизм `.pgpass`/секрет-хранилище процесса: **не кладите пароль в args или код**. Ограничения SQL важнее одного лишь `BEGIN READ ONLY`.

## Схема подключения отдельного SQL-пользователя

Ниже пример для DBA, **не исполнять автоматически**. Предварительно замените appdb, public, safe_table на свои.

```sql
CREATE ROLE mcp_readonly LOGIN NOINHERIT;
GRANT CONNECT ON DATABASE appdb TO mcp_readonly;
GRANT USAGE ON SCHEMA public TO mcp_readonly;
GRANT SELECT ON TABLE public.safe_table TO mcp_readonly;
-- Настроить пароль роли в секрет-хранилище и передать клиенту безопасным способом
```

Не выдавайте `SUPERUSER`, `CREATEDB`, `CREATEROLE`, `BYPASSRLS` и членство в `pg_read_server_files`, `pg_write_server_files`, `pg_execute_server_program`. Не используйте для агента `postgres`.

## Регистрация в существующем FastMCP

После того как исходный каталог MCP-сервера станет доступен, в его коде (после создания объекта `mcp`) добавьте:

```python
import sys
sys.path.insert(0, r"C:\Users\user\IdeaProjects\Local-Workspace-Extensions")
from mcp_adapter import register_tools

register_tools(mcp)
```

Это зарегистрирует **30 read-only/preview MCP tools** (18 базовых + 12 PC Toolbox), включая три новых spec-preview/status/validation. На этапе запуска сервера и через `tools/list` отдельно проверьте, что они реально видны; тест FakeMCP проверяет только совместимость декораторов, не настоящую серверную регистрацию.

## Ограничения безопасности

- Все файлы и Compose-файлы должны оставаться в workspace `projects`; symlink escapes блокируются.
- `read_text`: UTF-8, до 2 МиБ/файл, 200 строк/вызов, 32 КиБ/ответ, запрет приватных ключей и `.env`.
- Никаких `shell=True`. Имя Docker-контейнера и сервиса валидируется, возможные параметры начинающиеся с `--` запрещаются.
- Все сетевые проверки допускают только `localhost` / `127.0.0.1` / `::1`. HTTP redirects и proxy отключены.
- Docker logs имеют **best-effort** маскировку известных шаблонов credentials; не гарантируется полное удаление секретов из произвольных логов.
- Результаты stdout ограничены по объёму, PostgreSQL большие ответы возвращают `OUTPUT_TOO_LARGE`.
- Для команд изменения Compose необходима проверка реального YAML/volume mounts, owner approval и аудит.
- Дамп PostgreSQL (`pg_dump`) сознательно не добавлен к автоматически доступным инструментам: backup содержит данные и требует отдельной политики шифрования, хранения и прав.

## Проверки, 2026-11-01

- `python -m unittest discover` в `Local-Workspace-Extensions`: 116 тестов: 113 PASS, 3 SKIP (результат 2026-11-01; актуальный отчёт — docs/VERIFICATION_MANUAL_RECONCILE_2026-11-01.md) (Windows symlink).
- Read_text: реальный `Scheduled-Agent-Harness/harness.py` прочитан, 312 строк.
- Docker Engine: отвечает, версия 27.3.1; `docker_stats` возвращает пустой список, активных контейнеров нет.
- PostgreSQL: `127.0.0.1:5432` принимает подключения, порт занимает PID 6492 в момент проверки.
- `postgres_schema` на роли `postgres` без credentials: обоснованный отказ `fe_sendauth: no password supplied`. Положительный SQL E2E пока **не подтверждён**.
- `postgres_query_ro` под `postgres`: ожидаемый отказ `ROLE_DENIED`.
- `http_healthcheck http://127.0.0.1:8765/health`: endpoint возвращает 404, это не означает остановку MCP.
- Контролируемые Compose-тесты проверены через mock без запуска контейнеров.

## Восстановление зависшего создания спецификации

`owner_reconcile.py` — отдельная интерактивная локальная команда для подтверждённого завершения SQLite-записи после сбоя. Используется только если состояние `reconciliation_required`, все исходно запланированные файлы совпадают по SHA-256, OpenSpec и SDD проходят проверку и владелец подтверждает точную операцию в Windows Terminal. Не переписывает проектные файлы и не выполняет повторное создание. Верификация: сценарии частичной записи, concurrent-edit, отказ, неинтерактивный вызов и полный реальный OpenSpec E2E на временном проекте. Подробности: `docs/APPROVAL_WORKFLOW.md`.

## Локальное подтверждение создания OpenSpec + SDD

Добавлены `spec_approval_queue.py` и `owner_approve.py`. Нативные `spec_create_prepare`, `spec_create_request_status`, `spec_create_after_approval` используют локальную SQLite-очередь с привязкой к исходному JSON-файлу, проекту, SHA-256 плана и сроку действия 15 минут. Подтверждение требует интерактивного терминала пользователя; запуск из фонового `run_script` реально вернул `INTERACTIVE_REQUIRED`. Повтор успешного создания идемпотентен; технический сценарий проверен по MCP на временном проекте, подтверждение в тесте имитировалось. Схема и её ограничения: `docs/APPROVAL_WORKFLOW.md`. Это не замена серверной изоляции при сохранении неограниченных универсальных команд.

Личный плагин Local Workspace обновлён до 1.0.4 и содержит скилл `local-openspec-sdd`, позволяющий пользоваться CLI workflow без подключения отдельного сервера. Плагин привязан к своему существующему App; его серверный исходный код не входит в загружаемый пакет.

## Возобновление работы агентов по чекпоинтам

В пятиагентный координатор добавлена CLI-команда `checkpoint` с полями `done / next / tests / blockers`, timestamp UTC, idempotent request ID, проверкой роли и lease. Последний чекпоинт отображается в `agent_team.py status`, история — в `agent_team.py history TASK_ID`. Незавершённая задача сохраняет эти данные на следующий часовой запуск. Новое требование FR-037 / P079 описано в OpenSpec + SDD. Промпты всех четырёх плановых карточек обновлены. Подробности: `docs/FIVE_AGENT_TEAM.md`.

## Полный SDD развития мультиагентной системы

`specs/001-local-pc-agent-tooling/MASTER_SDD.md` — мастер-спецификация развития **системы агентов, разрабатывающих собственную систему**, и агентной автоматизации монтажа. Дополнительно: `ARCHITECTURE_V2.md` (технический дизайн), `IMPLEMENTATION_BACKLOG.md` (44 задачи с зависимостями и приёмкой), `roadmap_tasks.json` (проверяемый граф), `checklists/multiagent-definition-of-done.md` (DoD/безопасность). Первые P104–P107 поставлены в SQLite-очередь четырём разработчикам, следующие 40 ждут принятых предшественников. Проверить: `python sdd_roadmap_check.py` + `python agent_team.py overview`. Реальный серверный host-identity контроль P085 ещё открыт; задачи не могут самостоятельно повышать свои права.

## Учёт входных и выходных токенов агентов

Реализован локальный учёт `input_tokens` и `output_tokens` отдельно по 5 ролям, задачам, моделям и дням: `python agent_team.py usage-report`. Для просмотра на ПК: `python agent_team.py usage-export` создаёт `.agent-team/reports/token_usage_latest.html` и `.csv`. Если LLM SDK/API вернул реальные usage counters, текущий агент может импортировать их с собственной task lease из фиксированного JSON-файла через `usage-import`. **ChatGPT Scheduled Automations не предоставляет через доступный API точные input/output токены**, поэтому прошлые и неоснащённые метриками запуски отображаются как неизвестные, а не 0. Подробнее: `docs/AGENT_TOKEN_USAGE.md`.

## Очередь на второй цикл агентов

В команду добавлены независимые задания P018 (OpenSpec-to-test traceability), P021 (dependency review offline), P033 (media inventory) и P034 (scene manifests), по одному для каждого разработчика. Файлы не пересекаются. Доступ к новым заданиям определяется SQLite: сначала собственная недоделанная задача и её замечания Reviewer, затем новая задача своей роли. Реализация P034 предназначена для проверяемой постановки отдельной сценки монтажа (цель, зависимости, артефакты, критерии), а не для несанкционированного рендера.

Для надёжных продолжений после часового перерыва исправлен путь `checkpoint-file`: агент сохраняет UTF-8 JSON `agent_progress.json` в своём sandbox через `write_file` и передаёт в `run_script` только роль, task ID, lease и request ID. SQLite проверяет полномочия активной задачи и идемпотентность. Подробнее: `docs/FIVE_AGENT_TEAM.md`.

## Пять ролей разработки по OpenSpec + SDD

Координатор `agent_team.py` и JSON-бэклог `team_seed.json` образуют 4 изолированные дорожки разработки и пятый архитектурный review. Очередь в `.agent-team/team.sqlite3` фиксирует владельца, статус, последний UTC-update, lease, тестовые evidence, комментарии review и историю событий. Каждый разработчик пишет только в `.agent-team/workspaces/developer-N/Pxxx`; reviewer запускает sandbox unittest, `spec_check.py`, настоящий OpenSpec strict и переносит только allowlisted Python source с SHA preconditions. Менеджер отвергает изменения вне deliverables и небезопасное переиспользование задач. Отдельные команды `status`, `history`, `acquire`, `heartbeat`, `submit`, `review`, `rebase-spec`, `gate-check`.

Подробная инструкция, права и расписание: `docs/FIVE_AGENT_TEAM.md`. В текущем плане доступно максимум пять активных автоматизаций, поэтому пять ролей используют четыре hourly-карточки (Dev3 и Dev4 работают последовательно в одной). Существующую ежедневную задачу IT/AI-сертификатов не отключали. Реальные scheduled-результаты будут подтверждаться только фактическими запусками; code file sandbox не гарантирует изоляцию прав Windows.

## Нативный MCP SDK 2.3.0 (отдельный сервер)

Создан `native_spec_mcp.py`, работает через stdio с официальным MCP SDK 2.3.0 в изолированной `.venv`. Проверены настоящим MCP-клиентом: `tools/list`, 9 инструментов (5 для чтения/анализа, 3 для подтверждаемого создания и 1 для диагностики восстановления), `tools/call` status / inline preview / строгая OpenSpec-проверка, негативные вызовы с `isError`, пути вне workspace запрещены. Подробная инструкция: `docs/MCP_INSTALL.md`, пример конфигурации: `mcp.json.example`. Это **отдельный MCP-процесс**, не регистрация в существующем Local Workspace туннеле на 8765. В ChatGPT web появится только после подключения через поддерживаемый локальный мост/хост.

Прямой CLI `spec_create --apply` **отключён**. Через `ops.py` доступны `spec_request_prepare`, `spec_request_status`, `spec_request_execute` с подтверждением в `owner_approve.py`. Полноценные ограничения свободных системных команд требуют изменения исходного MCP-сервера.

## Инструмент создания OpenSpec + SDD (2026-11-01)

Добавлен `approval_broker.py`: одноразовые разрешения, привязка к пользователю/рабочему каталогу/операции/SHA-256, срок действия до 5 минут и SQLite-хранилище только хешей токенов. `approved_spec_tools.py` готовит регистрацию `spec_change_create` ТОЛЬКО с доверенным серверным источником identity и подтверждений. Поскольку серверный код ещё недоступен, этот модуль не устанавливает настоящую границу доступа и не подключён к работающему MCP.


Создан `spec_tools.py`, подключён к `ops.py`. Доступны `spec_preview`, `spec_validate`, `spec_status` и очередь согласования `spec_request_prepare/status/execute` вместо прямого `spec_create --apply` (старое действие теперь возвращает ошибку). Полное руководство: `docs/SPEC_TOOL_GUIDE.md`; локальный агентный скилл: `skills/spec-workflow/SKILL.md`. Нативная запись через MCP отключена до реализации host approval broker; вызовы через `run_script` возможны в текущем окружении.

Проведена практическая генерация: `openspec/changes/add-spec-creator/` и `specs/002-add-spec-creator/` (10 новых файлов), исходный OpenSpec 1.14.3 признал change валидным. Инструмент проверяет точную связь требований с SDD FR-индексом. Пример входного брифа: `requests/add-spec-creator.json`.

## Спецификация OpenSpec + SDD (2026-11-01)

Расширение локального MCP теперь документировано как отдельный change: `openspec/changes/local-pc-agent-tooling/`. В нём 10 capability-спек (82 требования, 82 WHEN/THEN сценария), proposal, design и task tracker. SDD-артефакты: `specs/001-local-pc-agent-tooling/`; конституция: `.specify/memory/constitution.md`.

- `AGENTS.md` — краткая инструкция новому агенту.
- `docs/PRIORITIES_RU.md` — 15 наиболее полезных направлений.
- `docs/TOOL_CATALOG.md` — 62 кандидатных инструмента.
- `docs/SDD_ADOPTION.md` — правила единого источника требований.
- `python spec_check.py` — структурный контроль 10 OpenSpec-спек и SDD-справочника.

Эти материалы **созданы локально**. Уже установленный OpenSpec CLI 1.14.3 успешно проверил change через `openspec validate local-pc-agent-tooling --strict`. GitHub Spec Kit CLI (`specify`) не обнаружен; нативная регистрация FastMCP-инструментов в работающем сервере не проводилась. Прежде чем допускать новые изменяющие состояние инструменты, нужен host-level approval broker.

## Следующий приоритет

1. Дать доступ к директории настоящего MCP-сервера и импортировать адаптер.
2. Создать отдельную read-only роль Postgres, настроить доступ без передачи пароля в чат и выполнить реальный SELECT E2E.
3. Опционально добавить управляемые host-approved `compose_up_apply` и `compose_down_apply` через подтверждение в UI, аудит и владельца ресурса.
4. Сделать безопасный `postgres_backup`: зашифрованный дамп, строгая директория, ротация, контроль восстановления.
