#requires -Version 5.1
<#
.SYNOPSIS
  Owner-foreground P085 Windows service REGISTRATION; dry-run by default.
.DESCRIPTION
  Registers ONLY a new MANUAL, STOPPED service under a separately provisioned
  local non-administrator account. -Apply is interactive, elevated, SHA-pinned
  and does not start the service, create accounts/keys, alter ACLs, authorize
  merge, or change the existing MCP process. DO NOT run from an agent-writable
  source tree as administrator without independent owner code review.
  Input pins must originate from independently inspected protected artifacts.
#>
[CmdletBinding()]
param(
  [switch]$Apply,
  [Parameter(Mandatory=$true)][string]$ExpectedServiceSid,
  [Parameter(Mandatory=$true)][string]$TrustedPythonPath,
  [Parameter(Mandatory=$true)][string]$ExpectedPythonSha256,
  [Parameter(Mandatory=$true)][string]$ExpectedEntrypointSha256,
  [Parameter(Mandatory=$true)][string]$ExpectedOverlappedSha256,
  [Parameter(Mandatory=$true)][string]$ExpectedStageReceiptSha256,
  [Parameter(Mandatory=$true)][string]$ExpectedInstallerSha256
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$serviceName='P085ProtectedReviewer'
if ($ExpectedServiceSid -cnotmatch '^S-1-5-21-(?:[0-9]+-){3}[0-9]+$') {
  throw 'SERVICE_ROLE_SID_NOT_LOCAL_USER'
}
foreach ($digest in @(
    $ExpectedPythonSha256,$ExpectedEntrypointSha256,
    $ExpectedOverlappedSha256,$ExpectedStageReceiptSha256,
    $ExpectedInstallerSha256)) {
  if ($digest -cnotmatch '^[a-fA-F0-9]{64}$') {
    throw 'OWNER_SOURCE_PIN_INVALID'
  }
}
if ([string]::IsNullOrWhiteSpace($env:ProgramData)) {
  throw 'PROGRAMDATA_UNAVAILABLE'
}
# An elevated process can inherit a caller-modified ProgramData variable.
# Resolve the OS common-data known folder independently and reject spoofing.
$actualCommonData=[IO.Path]::GetFullPath(
    [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::CommonApplicationData))
$configuredCommonData=[IO.Path]::GetFullPath($env:ProgramData)
if (-not [string]::Equals($actualCommonData.TrimEnd('\'),
                         $configuredCommonData.TrimEnd('\'),
                         [StringComparison]::OrdinalIgnoreCase)) {
  throw 'PROGRAMDATA_ENV_OVERRIDE_REJECTED'
}
$root=[IO.Path]::GetFullPath((Join-Path $actualCommonData $serviceName))
$code=Join-Path $root 'code'
$package=Join-Path $code 'workspace_mcp'
$trusted=Join-Path $code 'p085_trusted'
$private=Join-Path $root 'private_state'
$entry=Join-Path $code 'p085_reviewer_service.py'
$overlapped=Join-Path $package 'win_pipe_overlapped.py'
$receipt=Join-Path $root 'STAGE_RECEIPT.json'
# Reject UNC paths, drive-relative paths, device namespace, alternate
# data streams and environment-variable/control-character ambiguities. A
# Windows service must launch a local, absolute, owner-pinned .exe directly.
if ($TrustedPythonPath -cnotmatch '^[A-Za-z]:\\' -or
    $TrustedPythonPath -match '[\x00-\x1F"%]' -or
    $TrustedPythonPath.Substring(2).Contains(':')) {
  throw 'SERVICE_IMAGEPATH_UNSAFE'
}
$python=[IO.Path]::GetFullPath($TrustedPythonPath)
if ($python.IndexOf('"') -ge 0 -or $entry.IndexOf('"') -ge 0 -or
    -not $python.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase)) {
  throw 'SERVICE_IMAGEPATH_UNSAFE'
}
$programRoot=[IO.Path]::GetFullPath($env:ProgramData)
$prefix=$programRoot.TrimEnd('\')+'\'
if (-not $root.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {
  throw 'SERVICE_STAGE_OUTSIDE_PROGRAMDATA'
}
function Assert-OrdinaryPath([string]$Path,[bool]$Directory) {
  if ($Directory) {
    if (-not [IO.Directory]::Exists($Path)) { throw 'PROTECTED_STAGE_DIRECTORY_MISSING' }
  } else {
    if (-not [IO.File]::Exists($Path)) { throw 'PROTECTED_STAGE_FILE_MISSING' }
  }
  if (([IO.File]::GetAttributes($Path) -band [IO.FileAttributes]::ReparsePoint)) {
    throw 'PROTECTED_STAGE_REPARSE_POINT_DENIED'
  }
}
# Defense against junction redirection BEFORE reading any stage bytes.
foreach ($dir in @($programRoot,$root,$code,$package,$trusted,$private)) {
  Assert-OrdinaryPath $dir $true
}
# The final executable folder may look protected while one ancestor is
# a junction into attacker-controlled data. Reject each ancestor before
# verifying the executable hash and leaf ACL.
$pythonAncestor=[IO.Path]::GetDirectoryName($python)
$pythonDriveRoot=[IO.Path]::GetPathRoot($python)
while (-not [string]::IsNullOrEmpty($pythonAncestor)) {
  Assert-OrdinaryPath $pythonAncestor $true
  if ([string]::Equals($pythonAncestor.TrimEnd('\'),
                       $pythonDriveRoot.TrimEnd('\'),
                       [StringComparison]::OrdinalIgnoreCase)) { break }
  $nextAncestor=[IO.Path]::GetDirectoryName($pythonAncestor)
  if ([string]::Equals($nextAncestor,$pythonAncestor,
                      [StringComparison]::OrdinalIgnoreCase)) {
    throw 'PYTHON_ANCESTOR_CYCLE'
  }
  $pythonAncestor=$nextAncestor
}
foreach ($file in @($entry,$overlapped,$receipt,$python)) {
  Assert-OrdinaryPath $file $false
}
function Assert-PinnedSha([string]$File,[string]$Expected,[string]$Label) {
  $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $File).Hash
  if ($actual -ine $Expected) { throw ('SHA256_PIN_MISMATCH_'+$Label) }
}
Assert-PinnedSha $python $ExpectedPythonSha256 'PYTHON'
Assert-PinnedSha $entry $ExpectedEntrypointSha256 'ENTRYPOINT'
Assert-PinnedSha $overlapped $ExpectedOverlappedSha256 'OVERLAPPED'
Assert-PinnedSha $receipt $ExpectedStageReceiptSha256 'STAGE_RECEIPT'
function Assert-ImmutableAcl([string]$Path) {
  # Owner-fixed, fail-closed check before registration. Full E2E requires
  # independent OS tests; this source check cannot establish host trust.
  $acl=Get-Acl -LiteralPath $Path -ErrorAction Stop
  $actualOwner=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
  if ($actualOwner -cne 'S-1-5-18' -or -not $acl.AreAccessRulesProtected) {
    throw 'IMMUTABLE_CODE_OWNER_OR_DACL_UNVERIFIED'
  }
  $aces=$acl.GetAccessRules(
      $true,$true,[Security.Principal.SecurityIdentifier])
  $writeMask=[Security.AccessControl.FileSystemRights](
      [int][Security.AccessControl.FileSystemRights]::Write -bor
      [int][Security.AccessControl.FileSystemRights]::Delete -bor
      [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
      [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor
      [int][Security.AccessControl.FileSystemRights]::TakeOwnership)
  $seenSystem=$false
  foreach ($ace in $aces) {
    if ($ace.IsInherited -or
        $ace.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) {
      throw 'IMMUTABLE_CODE_ACL_UNSUPPORTED'
    }
    $sid=$ace.IdentityReference.Value
    if ($sid -notin @('S-1-5-18','S-1-5-32-544',$ExpectedServiceSid)) {
      throw 'IMMUTABLE_CODE_UNTRUSTED_PRINCIPAL'
    }
    if ($sid -eq 'S-1-5-18') { $seenSystem=$true }
    $isWriter=(($ace.FileSystemRights -band $writeMask) -ne 0)
    if ($isWriter -and $sid -ne 'S-1-5-18') {
      throw 'IMMUTABLE_CODE_WRITABLE_BY_NON_SYSTEM'
    }
  }
  if (-not $seenSystem) { throw 'IMMUTABLE_CODE_SYSTEM_ACCESS_MISSING' }
}
# A safe executable leaf and immediate parent are not sufficient: an
# untrusted principal with DELETE_CHILD/WRITE_DAC on a higher ancestor
# may replace or redirect a directory that contains the pinned Python.
# Ancestors can legitimately inherit access rules and be owned by the
# Windows servicing identity, unlike the individually sealed code stage.
# Require trusted owners and reject any non-trusted *writable* ACE.
function Assert-InterpreterAncestorAcl([string]$ExecutablePath) {
  $trustedOwnerSids=@('S-1-5-18','S-1-5-32-544')
  try {
    $servicingSid=([Security.Principal.NTAccount]::new(
      'NT SERVICE\TrustedInstaller')).Translate(
        [Security.Principal.SecurityIdentifier]).Value
    $trustedOwnerSids+= $servicingSid
  } catch {
    throw 'PYTHON_TRUSTEDINSTALLER_IDENTITY_UNRESOLVED'
  }
  $writeMask=[Security.AccessControl.FileSystemRights](
      [int][Security.AccessControl.FileSystemRights]::Write -bor
      [int][Security.AccessControl.FileSystemRights]::Delete -bor
      [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
      [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor
      [int][Security.AccessControl.FileSystemRights]::TakeOwnership)
  $ancestor=[IO.Path]::GetDirectoryName($ExecutablePath)
  $driveRoot=[IO.Path]::GetPathRoot($ExecutablePath)
  while (-not [string]::IsNullOrEmpty($ancestor)) {
    Assert-OrdinaryPath $ancestor $true
    $acl=Get-Acl -LiteralPath $ancestor -ErrorAction Stop
    $ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if ($ownerSid -notin $trustedOwnerSids) {
      throw 'PYTHON_ANCESTOR_OWNER_UNTRUSTED'
    }
    foreach ($ace in $acl.GetAccessRules(
      $true,$true,[Security.Principal.SecurityIdentifier])) {
      if ($ace.AccessControlType -ne
          [Security.AccessControl.AccessControlType]::Allow) {
        throw 'PYTHON_ANCESTOR_ACL_UNSUPPORTED'
      }
      if (($ace.FileSystemRights -band $writeMask) -ne 0 -and
          $ace.IdentityReference.Value -notin $trustedOwnerSids) {
        throw 'PYTHON_ANCESTOR_WRITABLE_BY_UNTRUSTED_SID'
      }
    }
    if ([string]::Equals($ancestor.TrimEnd('\'),$driveRoot.TrimEnd('\'),
                         [StringComparison]::OrdinalIgnoreCase)) {
      break
    }
    $nextAncestor=[IO.Path]::GetDirectoryName($ancestor)
    if ([string]::IsNullOrEmpty($nextAncestor) -or
        [string]::Equals($nextAncestor,$ancestor,
                         [StringComparison]::OrdinalIgnoreCase)) {
      throw 'PYTHON_ANCESTOR_TRAVERSAL_UNVERIFIED'
    }
    $ancestor=$nextAncestor
  }
}
# All potentially hijackable startup paths need protected code and parent
# directories. The private state is checked separately for existence only.
foreach ($item in @($root,$code,$package,$trusted,$entry,$overlapped,$receipt,
                    $python,[IO.Path]::GetDirectoryName($python))) {
  Assert-ImmutableAcl $item
}
Assert-InterpreterAncestorAcl $python
function Assert-PrivateStateAcl([string]$Path) {
  $acl=Get-Acl -LiteralPath $Path -ErrorAction Stop
  if (-not $acl.AreAccessRulesProtected -or
      $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne 'S-1-5-18') {
    throw 'PRIVATE_STATE_OWNER_OR_DACL_UNVERIFIED'
  }
  $writers=@()
  foreach ($ace in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
    if ($ace.IsInherited -or
        $ace.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) {
      throw 'PRIVATE_STATE_UNSUPPORTED_ACE'
    }
    $sid=$ace.IdentityReference.Value
    if ($sid -notin @('S-1-5-18','S-1-5-32-544',$ExpectedServiceSid)) {
      throw 'PRIVATE_STATE_UNTRUSTED_PRINCIPAL'
    }
    $rights=$ace.FileSystemRights
    $writeMask=[Security.AccessControl.FileSystemRights](
      [int][Security.AccessControl.FileSystemRights]::Write -bor
      [int][Security.AccessControl.FileSystemRights]::Delete -bor
      [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
      [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor
      [int][Security.AccessControl.FileSystemRights]::TakeOwnership)
    $isWriter=(($rights -band $writeMask) -ne 0)
    if ($isWriter) {
      $writers+= $sid
      if ($sid -eq 'S-1-5-32-544') { throw 'PRIVATE_STATE_ADMIN_WRITE_DENIED' }
    }
  }
  if ($writers -notcontains $ExpectedServiceSid) {
    throw 'PRIVATE_STATE_BROKER_WRITE_MISSING'
  }
}
Assert-PrivateStateAcl $private
$maxReceiptBytes=16000
if ((Get-Item -LiteralPath $receipt).Length -gt $maxReceiptBytes) {
  throw 'STAGE_RECEIPT_TOO_LARGE'
}
$stageManifest=Get-Content -LiteralPath $receipt -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
if ($stageManifest.schema -cne 'p085-protected-code-receipt-v1' -or
    $stageManifest.service_sid -cne $ExpectedServiceSid -or
    $stageManifest.release_approved -cne $false -or
    $stageManifest.live_mcp_modified -cne $false -or
    $stageManifest.plan_sha256 -cnotmatch '^[a-f0-9]{64}$') {
  throw 'STAGE_RECEIPT_CONTRACT_INVALID'
}
# The installation receipt binds three different real users. Otherwise a
# service can be registered with a seemingly valid SHA even if the archived
# reviewer/worker role identities collapsed to the broker's own SID.
$roleSids=@([string]$stageManifest.service_sid,
            [string]$stageManifest.reviewer_sid,
            [string]$stageManifest.worker_sid)
foreach ($roleSid in $roleSids) {
  if ($roleSid -cnotmatch '^S-1-5-21-(?:[0-9]+-){3}[0-9]+$') {
    throw 'STAGE_RECEIPT_ROLE_SID_INVALID'
  }
}
if (@($roleSids | Select-Object -Unique).Count -ne 3) {
  throw 'STAGE_RECEIPT_ROLE_SID_COLLISION'
}
$expectedNames=@(
  'code/workspace_mcp/__init__.py',
  'code/workspace_mcp/host_pipe_peer.py',
  'code/workspace_mcp/review_grants.py',
  'code/workspace_mcp/review_qa_attestation.py',
  'code/workspace_mcp/review_target_snapshot.py',
  'code/workspace_mcp/review_grant_broker.py',
  'code/workspace_mcp/review_finalizer.py',
  'code/workspace_mcp/trusted_journal_loader.py',
  'code/workspace_mcp/owner_cutover_gate.py',
  'code/workspace_mcp/review_pipe_server.py',
  'code/workspace_mcp/review_pipe_client.py',
  'code/workspace_mcp/win_pipe_overlapped.py',
  'code/p085_reviewer_service.py',
  'code/p085_trusted/review_merge.py'
)
$recorded=@($stageManifest.files)
if ($recorded.Count -ne $expectedNames.Count) {
  throw 'STAGE_RECEIPT_FILE_SET_INVALID'
}
$observedNames=@()
foreach ($fileRecord in $recorded) {
  $name=([string]$fileRecord.relative).Replace('\','/')
  if ($name -notin $expectedNames -or
      $observedNames -contains $name -or
      [string]$fileRecord.sha256 -cnotmatch '^[a-f0-9]{64}$') {
    throw 'STAGE_RECEIPT_FILE_SET_INVALID'
  }
  $observedNames+=$name
  $target=Join-Path $root ($name.Replace('/','\'))
  Assert-OrdinaryPath $target $false
  if ((Get-Item -LiteralPath $target).Length -gt 1048576) {
    throw 'STAGE_CODE_SOURCE_TOO_LARGE'
  }
  Assert-PinnedSha $target ([string]$fileRecord.sha256) 'STAGED_MODULE'
  Assert-ImmutableAcl $target
}
# A recursive file COUNT alone does not reject extra empty folders,
# unexpected script-search paths or reparse-point directories. Validate
# the exact stage tree, without following untrusted junctions recursively.
function Assert-ExactChildNames([string]$Directory,[string[]]$Expected,
                                [string]$FailureCode) {
  $children=@(Get-ChildItem -LiteralPath $Directory -Force -ErrorAction Stop)
  if (@($children | Where-Object {
      $_.Attributes -band [IO.FileAttributes]::ReparsePoint
    }).Count -gt 0) {
    throw 'STAGE_UNEXPECTED_REPARSE_CHILD'
  }
  $names=@($children | ForEach-Object { $_.Name })
  if ($names.Count -ne $Expected.Count -or
      @($names | Where-Object { $_ -cnotin $Expected }).Count -ne 0) {
    throw $FailureCode
  }
}
Assert-ExactChildNames $root @('code','private_state','STAGE_RECEIPT.json') 'STAGE_UNEXPECTED_ROOT_ENTRY'
Assert-ExactChildNames $code @('workspace_mcp','p085_trusted','p085_reviewer_service.py') 'STAGE_UNEXPECTED_CODE_ENTRY'
$expectedPackageNames=@($expectedNames | Where-Object {
    $_.StartsWith('code/workspace_mcp/',[StringComparison]::Ordinal)
  } | ForEach-Object { [IO.Path]::GetFileName($_) })
Assert-ExactChildNames $package $expectedPackageNames 'STAGE_UNEXPECTED_MODULE_ENTRY'
Assert-ExactChildNames $trusted @('review_merge.py') 'STAGE_UNEXPECTED_MODULE_ENTRY'
$codeSubdirs=@(Get-ChildItem -LiteralPath $code -Directory -Force -ErrorAction Stop |
    ForEach-Object { $_.Name })
if ($codeSubdirs.Count -ne 2 -or
    @($codeSubdirs | Where-Object {
      $_ -cnotin @('workspace_mcp','p085_trusted')
    }).Count -ne 0) {
  throw 'STAGE_UNEXPECTED_CODE_DIRECTORIES'
}
if (-not (Get-Command Get-LocalUser -ErrorAction SilentlyContinue) -or
    -not (Get-Command Get-LocalGroupMember -ErrorAction SilentlyContinue)) {
  throw 'LOCAL_ACCOUNT_MODULE_UNAVAILABLE'
}
$localUsers=@(Get-LocalUser -ErrorAction Stop)
$admins=@(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop |
    ForEach-Object { $_.SID.Value })
# Backup Operators (S-1-5-32-551) can receive SeBackupPrivilege and
# SeRestorePrivilege. A non-admin label alone is insufficient for a
# secret-bearing broker or the untrusted worker: prevent such memberships.
# An unavailable privileged-group inventory fails closed before SCM writes.
try {
  $backupOperators=@(Get-LocalGroupMember -SID 'S-1-5-32-551' -ErrorAction Stop |
      ForEach-Object { $_.SID.Value })
} catch {
  throw 'PRIVILEGED_LOCAL_GROUP_INVENTORY_UNVERIFIED'
}
foreach ($roleSid in $roleSids) {
  $actualRoles=@($localUsers | Where-Object { $_.SID.Value -ceq $roleSid })
  if ($actualRoles.Count -ne 1) {
    throw 'STAGE_RECEIPT_ROLE_ACCOUNT_NOT_FOUND'
  }
  if ($admins -contains $roleSid) {
    throw 'STAGE_RECEIPT_ROLE_IS_LOCAL_ADMIN'
  }
  if ($backupOperators -contains $roleSid) {
    throw 'STAGE_RECEIPT_ROLE_IS_BACKUP_OPERATOR'
  }
}
$serviceUsers=@($localUsers | Where-Object {
    $_.SID.Value -ceq $ExpectedServiceSid })
if ($serviceUsers.Count -ne 1) {
  throw 'SERVICE_PRINCIPAL_NOT_FOUND'
}
$user=$serviceUsers[0]
# Disabled principal is not automatically enabled. Owner enables it only
# in a separate approved cutover, after secure credential provisioning.
$existing=Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($null -ne $existing) { throw 'P085_SERVICE_ALREADY_EXISTS' }
$commandLine=('"'+$python+'" -E -s "'+$entry+'" --serve-service')
$plan=[ordered]@{
  schema='p085-owner-service-registration-plan-v1'
  service_name=$serviceName
  requested_apply=[bool]$Apply
  service_registration_only=$true
  auto_start=$false
  user_account_enabled=[bool]$user.Enabled
  staged_code_source_digests_match_receipt=$true
  interpreter_executable_digest_matches_pin=$true
  python_runtime_dependency_manifest_verified=$false
  python_runtime_os_attested=$false
  service_runtime_ready=$false
  immutable_code_acl_observed=$true
  service_identity_independently_attested=$false
  private_qa_issuer_verified=$false
  two_sid_e2e_verified=$false
  owner_approval_verified=$false
  release_authorized=$false
  auto_merge_authorized=$false
  startup_type='Manual'
}
if (-not $Apply) {
  $plan | ConvertTo-Json -Depth 5 -Compress
  return
}
# A UAC-approved command may still originate from an agent-writable repo.
# Require an independently owner-protected copy of this EXACT script and
# a separately reviewed SHA pin before even asking for a service password.
# This is defense in depth, not a signature or trust in the repo itself.
if ([string]::IsNullOrWhiteSpace($PSCommandPath)) {
  throw 'OWNER_PROTECTED_SCRIPT_PATH_REQUIRED'
}
$ownerScriptPath=[IO.Path]::GetFullPath($PSCommandPath)
if ($ownerScriptPath -cnotmatch '^[A-Za-z]:\\' -or
    $ownerScriptPath -match '[\x00-\x1F"%]' -or
    $ownerScriptPath.Substring(2).Contains(':')) {
  throw 'OWNER_PROTECTED_SCRIPT_PATH_INVALID'
}
Assert-OrdinaryPath $ownerScriptPath $false
Assert-ImmutableAcl $ownerScriptPath
Assert-InterpreterAncestorAcl $ownerScriptPath
Assert-PinnedSha $ownerScriptPath $ExpectedInstallerSha256 'OWNER_SCRIPT'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$admin=[Security.Principal.WindowsPrincipal]$identity
if (-not $admin.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw 'OWNER_ELEVATED_TERMINAL_REQUIRED'
}
if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected) {
  throw 'OWNER_FOREGROUND_INTERACTIVE_CONSOLE_REQUIRED'
}
if (-not $user.Enabled) {
  throw 'SERVICE_PRINCIPAL_DISABLED_UNTIL_OWNER_CUTOVER'
}
Write-Host 'REGISTER only P085ProtectedReviewer, Manual/Stopped. NO START, NO MERGE.' -ForegroundColor Yellow
Write-Host 'Inspect the SHA-pinned protected code and service account before continuing.'
$ack=Read-Host 'Type REGISTER-P085-MANUAL-SERVICE to proceed'
if ($ack -cne 'REGISTER-P085-MANUAL-SERVICE') { throw 'OWNER_DECLINED' }
# Password remains in Windows SecureString, never a CLI argument, file or log.
$password=Read-Host 'Service account password (not stored by this script)' -AsSecureString
$username=($env:COMPUTERNAME+'\'+$user.Name)
$credential=New-Object System.Management.Automation.PSCredential($username,$password)
if ($credential.UserName -cne $username) { throw 'CREDENTIAL_IDENTITY_UNEXPECTED' }
New-Service -Name $serviceName -BinaryPathName $commandLine -DisplayName 'P085 Protected Reviewer' -StartupType Manual -Credential $credential -ErrorAction Stop | Out-Null
# Read-only after creation; a successful registration is never cutover.
$registered=Get-Service -Name $serviceName -ErrorAction Stop
if ($registered.Status -ne [ServiceProcess.ServiceControllerStatus]::Stopped) {
  throw 'SERVICE_UNEXPECTEDLY_STARTED'
}
# Verify SCM stored exactly the requested account and command. A failure
# leaves the service registered but blocked for independent owner inspection.
# Never automatically delete/reconfigure it with an agent-supplied identity.
$serviceRecord=Get-CimInstance -ClassName Win32_Service -Filter "Name='P085ProtectedReviewer'" -ErrorAction Stop
if ($null -eq $serviceRecord -or
    $serviceRecord.State -ne 'Stopped' -or
    $serviceRecord.StartMode -ne 'Manual' -or
    $serviceRecord.ServiceType -ne 'Own Process' -or
    [uint32]$serviceRecord.ProcessId -ne 0) {
  throw 'SCM_REGISTERED_SERVICE_SHAPE_UNVERIFIED'
}
if (-not [string]::Equals([string]$serviceRecord.PathName,
                         $commandLine,
                         [StringComparison]::OrdinalIgnoreCase)) {
  throw 'SCM_IMAGEPATH_MISMATCH_AFTER_CREATE'
}
try {
  $recordSid=([Security.Principal.NTAccount]::new(
    [string]$serviceRecord.StartName)).Translate(
      [Security.Principal.SecurityIdentifier]).Value
} catch {
  throw 'SCM_SERVICE_ACCOUNT_UNRESOLVED_AFTER_CREATE'
}
if ($recordSid -cne $ExpectedServiceSid) {
  throw 'SCM_SERVICE_ACCOUNT_MISMATCH_AFTER_CREATE'
}
[pscustomobject]@{
  schema='p085-owner-service-registration-result-v1'
  registered=$true
  state='Stopped'
  release_authorized=$false
  owner_approval_verified=$false
  auto_merge_authorized=$false
  independent_two_sid_e2e_verified=$false
} | ConvertTo-Json -Depth 5 -Compress
