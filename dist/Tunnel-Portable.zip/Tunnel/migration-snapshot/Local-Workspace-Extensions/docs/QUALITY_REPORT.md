# OpenSpec + SDD quality report

## Commands

Through the existing Local Workspace MCP `run_script`, with `workspace="projects"`, `cwd="Local-Workspace-Extensions"` and `path="Local-Workspace-Extensions/ops.py"`:

```text
args=["spec_report","Local-Workspace-Extensions","add-spec-creator","--strict"]
```

Always read the actual `job_status` and `job_output`. This is read-only.
The separate stdio MCP server exposes `spec_quality_report(project, change, strict_validation=true)`. Registration into the *existing* Local Workspace tunnel has not been verified.

## What the report measures

- OpenSpec capability and requirement count, named scenarios, actual WHEN/THEN structure
- SDD `FR-NNN` references and missing tasks
- unresolved `TBD`/FIXME design decisions, missing proposal/design artifacts
- unchecked task counts, distinguishing a checked box from real test evidence
- negative-case **keyword heuristic** (advisory, not proof that coverage is adequate)
- optionally installed OpenSpec strict validation result
- safe summary with bounded findings and no filesystem writes

`spec_structural_ready` means only a static structure gate passed; it does not mean the implementation exists. `implementation_verified` and `release_approved` are deliberately **always false** until a separate evidence/reviewer workflow is built.

## Verified example — add-spec-creator

Observed from `spec_report Local-Workspace-Extensions add-spec-creator --strict`:

| Check | Result |
| --- | --- |
| OpenSpec requirements | 8 |
| Acceptance scenarios | 8 |
| SDD mappings | 8 |
| Strict OpenSpec CLI 1.14.3 | Passed |
| Design placeholders (`TBD`) | 3 |
| Requirements lacking an obvious negative scenario | 4 — review suggestions only |
| Implementation/release evidence | Not verified |

This is a **draft** specification and still needs architectural decisions and owner review.

## Safety and limitations

- Only authorized projects inside `projects`; path traversal and escaping symlinks are rejected.
- The tool does not access personal folders, execute test suites, install dependencies or modify source.
- Large files and repeated requirements are bounded/detected by checks.
- Not a semantic AI reviewer: a grammatically valid `SHALL` requirement may still be a bad requirement.
- Negative tests are inferred by keywords and need human judgment; do not fail a feature solely on that heuristic.
- The structural checker `spec_check.py` now also rejects duplicate `P###` task IDs, preventing accidental task collisions in parallel agent work.

## Next acceptance gates

1. Link all `FR-NNN` to concrete tests and reproducible results, separately label mock and live.
2. Eliminate unresolved design decisions or document explicit risk acceptance.
3. Obtain technical reviewer approval before implementing privileged tools.
4. Use real terminal approval for creation and host-level MCP permissions for OS safety.
