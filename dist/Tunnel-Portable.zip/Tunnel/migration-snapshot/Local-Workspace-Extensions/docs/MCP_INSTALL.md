# Standalone MCP server for specification tools

This is **not** the existing Local Workspace server bound to `127.0.0.1:8765`.
It is a separate local stdio MCP process exposing five read/preview/quality-audit tools and four request-based specification creation/diagnosis tools. Writing a spec requires a separate local-terminal approval.
The current Local Workspace plugin will not automatically discover this process;
the host must explicitly configure and connect the new server.

## Runtime

Python 3.11+; locally isolated environment in `.venv`. Official MCP Python
SDK 2.3.0 (tested on this Windows host) is pinned in `pyproject.toml`.

From `C:\Users\user\IdeaProjects\Local-Workspace-Extensions`:

```powershell
uv venv .venv
uv pip install --python .venv\Scripts\python.exe "mcp==2.3.0"
.venv\Scripts\python.exe native_spec_mcp.py
```

The last command stays open, reading newline-delimited MCP requests on stdin;
it prints no banner to stdout. Terminate from the MCP client.

## Host entry

```json
{
  "mcpServers": {
    "local-spec-workspace": {
      "type": "stdio",
      "command": "C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions\\.venv\\Scripts\\python.exe",
      "args": [
        "C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions\\native_spec_mcp.py"
      ],
      "cwd": "C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions"
    }
  }
}
```

The file `mcp.json.example` contains this connection entry. Use the host's
supported plugin/connector configuration to connect it; do **not** replace
the existing tunnel server or port. The host may use a different config format.

## Tools

- `spec_preview_manifest(manifest_path)`: preview stored JSON brief.
- `spec_preview_inline(manifest_json)`: preview JSON brief supplied in call.
- `spec_status_local(project)`: inspect OpenSpec/SDD paths.
- `spec_validate_local(project, change)`: run installed OpenSpec strict validator.
- `spec_quality_report(project, change, strict_validation=false)`: static quality audit of requirements, negative cases, design TODO/TBD and SDD links; never implies implementation completion.
- `spec_create_prepare(manifest_path, expected_plan_sha256)`: queue a precise plan for local approval; no project files are written.
- `spec_create_request_status(request_id)`: inspect approval request status.
- `spec_create_diagnose(request_id)`: read-only fingerprint check of expected files after interruption, without repairing or retrying.
- `spec_create_diagnose(request_id)`: read-only recovery diagnostics: expected files, SHA-256 matches, missing and changed artifacts; never retries or deletes data.
- `spec_create_after_approval(request_id)`: create the spec only if the local-terminal review approved that unchanged plan; repeat calls replay the saved result.

All project paths are relative to `C:\Users\user\IdeaProjects`; exact root
is derived from `spec_tools.py`. Nothing outside the workspace is granted.

Native project creation is available only through the approval queue; see `docs/APPROVAL_WORKFLOW.md` and local `owner_approve.py`. The legacy CLI `ops.py spec_create ... --apply` has been disabled. The CLI now exposes `spec_request_prepare`, `spec_request_status` and `spec_request_execute`, all using the same local-terminal approval queue. The true Local Workspace backend must restrict general `run_script` / `run_command` operations before this can be considered a hardened OS authorization boundary.

## Verification

Run `python -m unittest discover` in the project. Tests include the native tool
decorator contract. For real MCP verification, launch
`python mcp_wire_check.py` from the SDK environment: it exercises an MCP client
and server over stdio, checks `tools/list`, negative authorization, real OpenSpec creation on a disposable fixture with simulated approval, and safe retry behavior.
Do not interpret a local stdio test as proof this server is connected to ChatGPT.
