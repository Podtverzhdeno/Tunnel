# Autonomous developer ↔ peer review ↔ architect support ↔ feature research

Effective 2026-11-02. This is the live operating contract for the four scheduled ChatGPT chats comprising developer-1, developer-2, combined developer-3+4, and Architect Reviewer.

## Core invariant: only stop for lack of *all* useful authorized work

Every scheduled developer role performs this bounded state machine; begin and end each meaningful unit of work by reading the **current** coordinator and separate evidence ledgers, not by assuming yesterday's prompt is true.

```text
START / AFTER ANY COMPLETED STEP
   │
   ├── coding ready and authorized? ── YES → acquire fresh scoped lease
   │                                      → implement + focused negative tests
   │                                      → full unittest, spec_check, strict OpenSpec
   │                                      → security/reliability/scalability 9D audit
   │                                      → quality_submit.py (guarded) → RECHECK
   │
   ├── eligible independent peer? ── YES → peer_review_switch.py claim
   │                                       → independent source/hash and QA review
   │                                       → report + complete → RECHECK
   │
   ├── 10+ idea portfolio for *this role/wave* not yet validated?
   │       YES → continue/create meaningful 10–20 detailed proposals
   │            → feature_idea_gate.py validate ROLE → RECHECK
   │
   ├── architect support available? ── YES → architect_support.py claim
   │                                       → reproduce reported defect OR inspect
   │                                         reliability/architecture/feature evidence
   │                                       → independent evidence report + complete
   │                                       → RECHECK
   │
   └── no safe authorized task, feature work complete, no support lanes?
           → record real blocker and exit THIS scheduled run.
```

**After any step — check coding again FIRST.** Do not finish just because `agent_team.py plan-work` returns `recommended_task_id=null`. No pointless waiting or duration quotas. Long work is checkpointed without fabricating acceptance and continued on the next scheduled run; ChatGPT model calls do not run continuously between scheduled triggers.

## Architect-support work queue — currently implemented

Read-only for the main queue: `experiments/chat_only_run/architect_support.py`. Advisory claim/completion records live in `.agent-team/architect_support.sqlite3`; each work item has an independent 45-minute SHA-fenced lease and a one-time token. Reports are written in the exact `.agent-team/architect-support-packets/ROLE/{KEY}.json` path returned by claim.

**Durable audit and timings (2026-11-02):** The support coordinator now maintains append-only `support_attempts` rows with `work_key`, role, request ID, source digest, claimed/finished UTC and status `claimed / superseded / completed`. Request IDs cannot be silently recycled after a lease is superseded. The existing `architect_support.py overview` includes `attempt_history` (count, by-role completed/claimed/superseded, average lease-to-report seconds, last 15 attempts). It is a bounded last-500 sample and explicitly marks `truncated=true` if the actual number is greater. **No bearer tokens or raw secrets are included.** Previous work before migration has no trustworthy start timestamp and must remain unmeasured. These durations include model/tool/network waits; they are NOT actual provider token counts, CPU time or LLM-only execution time. The architect checks history and report SHA, not just the agents' final chat text. Candidate support tasks are now generated only from independently hash-verified peer reports and a fully validated architect decision set, not from stale or modified conclusions.

Run using Local Workspace (alias `projects`) with:
```
path=Local-Workspace-Extensions/experiments/chat_only_run/architect_support.py
cwd=Local-Workspace-Extensions/experiments/chat_only_run
args=["plan", ROLE]
```
- After two legitimate architect-support reviews, use `args=["plan",ROLE,"--prefer-features"]` to fairly select a feature-evidence item if available. **Coding and independent peer-review still take priority**, even in this mode.
- When `mode=architect_support`, read `recommended_support_task.work_key` and `source_digest`. Then get an actual fresh non-reused request ID through `agent_team.py new-request ROLE` and call `args=["claim",ROLE,WORK_KEY,REQUEST_ID]`. The returned lease is for *advisory support only*. Never reuse a code or peer lease.
- For `PXXX:regression`: independently **reproduce or refute** the earlier peer finding with an immutable source SHA, a targeted negative test in an isolated temp copy, exact actual job return code and minimal failing input. Refutation is a valuable result. Do not merely repeat a peer report.
- For `PXXX:reliability`: investigate a DIFFERENT concrete failure mode: path traversal, malformed UTF-8, timeouts, parallelism, crash, replay/idempotency, stale lease, unauthorized action. Show an actual falsifiable witness; distinguish a theoretical risk from a reproduced defect.
- For `PXXX:architecture`: assess cohesion, coupling, complexity, operational scalability and QA evidence provenance; show method, specific lines, performance or failure scaling where possible. Do not restate existing checklists.
- For `F:developer-N:FXX:evidence`: independently evaluate one of the 8 Architect-promoted proposals from the current **40-idea** wave, compare at least two alternatives, show how to falsify its baseline/claimed impact, threat and scaling model, empirical experiment plan, and an unambiguous owner decision recommendation. Never evaluate your own feature: developer-3 and developer-4 exclude both roles because they share a ChatGPT run.
- Provide `report_file` as JSON containing EXACT keys:
```json
{
  "work_key": "P110:regression",
  "role": "developer-1",
  "source_digest": "sha256_from_claim",
  "verdict": "CONFIRMED_DEFECT",
  "summary": "At least 100 characters of grounded independent assessment, explaining the reproducible observed contract violation and scope limitations.",
  "findings": ["At least two specific observations of 35+ characters each.", "State precise claim and directly inspect a contrary or corroborating case."],
  "checks": ["At least two concrete tested assertions; include actual run ID and exit code or explicitly state not tested.", "Mention source SHA and focused QA outcome; do not invent tool receipts."],
  "recommendations": ["At least one bounded architect/developer recommendation with a measurable acceptance criterion."],
  "limitations": ["At least one honest limitation; an advisory support report is never a trusted authorization grant."]
}
```
The above is a **shape only**, not an actual evidence report. Allowed verdicts: `CONFIRMED_DEFECT`, `NEGATIVE_TESTS_PASS`, `UNVERIFIED`, `FEATURE_RECOMMENDATION`, `FEATURE_REJECT_RECOMMENDATION`. Use `UNVERIFIED` if the evidence is ambiguous or cannot be reproduced. The automation MUST NOT claim `NEGATIVE_TESTS_PASS` when tests were not actually run.
- Complete with `args=["complete",ROLE,WORK_KEY,LEASE_TOKEN]`; require completed job, rc=0, `ok=true`, then use `args=["overview"]` and `report_matches=true`. Finally re-run `plan ROLE` and return to coding immediately if it becomes available.
- No duplicate reports for an unchanged source/version. New source hashes may reopen appropriate work. The scheduler prevents accidental concurrent duplicate claims, self-review, stale evidence and reuse of completed work. **Single active lease per role:** starting 2026-11-02, `plan ROLE` returns `mode=resume_support` with `active_support_tasks` when the role already holds an unexpired support lease. The agent must complete that report with its ORIGINAL token or let its time-bounded lease expire; it MUST NOT claim a second independent task. New `claim` attempts are rejected twice: once in the preflight and again under `BEGIN IMMEDIATE` to prevent concurrent claims. When `multiple_active_legacy_leases=true`, treat it as a pre-migration overlap: finish existing valid reports and avoid new claims. Legal new coding and peer-review tasks are still checked first, and can preempt advisory work. If an advisory task cannot be completed and the ORIGINAL bearer token is still available, release it explicitly with `architect_support.py abandon ROLE WORK_KEY ORIGINAL_LEASE_TOKEN REASON`. Allowed reason codes: `CODING_PREEMPTED`, `SOURCE_CHANGED`, `INVALID_SOURCE`, `UNABLE_TO_COMPLETE`, `ROLE_WORK_HANDOFF`. The release uses `BEGIN IMMEDIATE` token+role+status CAS, records an `abandoned` attempt and leaves main queue, candidate sources and all formal reviewer state unchanged. It is **not** permission to abandon other agents' work or claim an accept/reject. A malformed old timestamp can be safely released with the correct unchanged token; otherwise it remains blocked pending trusted reconciliation. Never invent, extract, or reconstruct tokens; no script should recover or publish them. Command role names remain **self-declared**; P085 must be resolved at MCP host to establish actual identity.
- If 40 ideas already have valid portfolios and architect has already evaluated them, DO NOT create another arbitrary 40 per hour. Continue empirical validation and benchmarks of the selected proposals using separate feature-evidence items. Generate a new 10+ portfolio only after the canonical seed wave or a separately approved new idea cycle.

## Architect Reviewer collaboration

Architect Reviewer consumes `architect_support.py overview` and the factual JSON reports at BOTH startup and end of its scheduled run. Verify source SHA and independently rerun any claimed critical counterexample before making a technical recommendation. Summarize: confirmed vs refuted vs unverified findings, per-task actionable rework plan, selected feature hypothesis evidence and missing host grants.

Developer assist reports are ADVISORY ONLY: they may prepare a patch, negative witness, acceptance matrix and owner-ready spec brief; they CANNOT call `agent_team.py review accept/reject`, modify other role's sandbox, merge to main, create privileged grants, or admit live queue without actual owner authorization. Architect cannot bypass P085 or simulate foreground terminal owner approval. An architect's reasoned decision may recommend rework, but only the trusted authorized coordinator flow can change formal status.

## Fairness and practical completion

- In each scheduled run: after a coding submit or support completion, recheck plan-work immediately. Alternate different unclaimed review and evidence categories when helpful. After two support reviews, prefer one feature-evidence task using `--prefer-features`; never let speculative ideas block actual code.
- D3+D4 is ONE scheduled ChatGPT invocation and must give both logical roles a fair chance. It must never peer-review either role's task from the shared conversation.
- Work has no arbitrary minimum duration. Finish this invocation when: all scoped work types have been attempted, no lease can be safely obtained, no meaningful independent evidence remains, or the scheduled execution is naturally ending. Persist partial work and exact blockers. Do not spin, perform redundant reviews or claim background work from a completed chat.

## Advisory fallback при недоступной авторизации coding

Если `agent_team.py plan-work` находит coding-задачу, но реальная операция
заблокирована отсутствием подтверждённой role identity на MCP-хосте, ранее
`architect_support.py plan ROLE` бесконечно возвращал `mode=coding`.
Теперь разрешён **только advisory fallback**, без изменения основной очереди:

```powershell
python experiments/chat_only_run/architect_support.py plan developer-3 --blocked-code-host-unverified
```

При наличии действительно свободной **чужой** независимой advisory-задачи
план вернёт `mode=architect_support` с
`coding_candidate_skipped_as_unverified=true`; затем её можно взять строго
под отдельный `architect_support.py claim ROLE WORK_KEY FRESH_REQUEST_ID
--blocked-code-host-unverified`, выполнить настоящий отчёт, пройти
`complete` и вернуться к проверке coding. Если `available_count=0`, нельзя
выдумывать работу или claim. Peer-review по-прежнему приоритетнее advisory.

Флаг **не удостоверяет host actor**, не обходит подтверждение владельца,
не даёт права на код, formal accept/reject или production-сервис. Это
самодекларируемая причина для маршрутизации только *неформальных* проверок;
её нельзя использовать, если разрешённая coding-аренда действительно
доступна и может безопасно выполняться.

## Verification

`python -m unittest discover -q` in `experiments/chat_only_run` includes isolated `test_architect_support.py`, which verifies coding/peer preemption, non-self shared-chat exclusions, lease concurrency, source drift and report evidence. `architect_support.py plan ROLE` and `overview` have read-only behavior. The main repo still needs canonical full `agent_team.py gate-check` after these script/docs updates.
