# Подключение 12 PC Toolbox tools к существующему Local Workspace MCP

## Актуальный способ установки — без архива (2026-11-02)

После проверки реальных файлов `workspace_mcp/tools.py`, `workspace_mcp/http_server.py` и `manage.py` установлена архитектура **кастомного zero-dependency MCP ToolRegistry**, а не FastMCP. Предыдущие `install_pc_tools_in_host.py --guided` и установка через ZIP устарели. **Не использовать их для этого сервера.**

Все необходимые файлы созданы прямо в `C:\Users\user\IdeaProjects\Local-Workspace-Extensions`:

- `install_native_pc.py` — SHA-pinned установщик и восстановление; только интерактивный Windows Terminal владельца.
- `pc_native_registry.py` — регистрация 12 read-only `pc_*` в существующем `ToolRegistry`.
- `pc_toolbox.py` — оригинальная ограниченная реализация PC-диагностик.
- `test_install_native_pc.py`, `test_native_pc_registry.py` — безопасные тесты на временной копии host и фактический JSON-RPC dispatch.
- `run_native_pc_install.ps1` — необязательная PowerShell-обёртка, больше не требует ZIP.

В своём PowerShell:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python install_native_pc.py --preview
python install_native_pc.py --apply
python install_native_pc.py --verify
cd C:\Users\user\Downloads\local-workspace-mcp
python manage.py doctor
```

Во время `--apply` ввести **только после проверки плана** точное `INSTALL <plan_id>`. `manage.py doctor` должен показывать 40 инструментов. Этот `doctor` проверяет создаваемый новый registry **в отдельном локальном процессе**, а не обновление уже работающего сервера.

Для реальной доступности в чате требуется отдельный управляемый рестарт **только MCP-процесса**, после чего заново получить `tools/list` в ChatGPT. Не перезапускать туннель без необходимости. Установщик и ChatGPT-агент не перезапускают процессы.

Если возникла ошибка, **не перезапускать** сервер до восстановления/диагностики. После успешной установки откат:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python install_native_pc.py --rollback
```

Откат требует точную фразу `ROLLBACK <rollback_id>`, сравнивает байты установленной версии и бэкапа и отказывает, если их изменили. При любых ошибках для уже частично установленных файлов — остановиться и выполнить ручную сверку, не перезаписывая чужую работу.

---


Состояние на 2026-11-02: **код и реальные MCP wire-тесты готовы, активный сервер ChatGPT ещё НЕ обновлён**.

## Проверено

- `pc_host_extension.py` регистрирует **ровно 12 новых инструментов**, не перезаписывая существующие.
- `native_pc_extension_mcp.py` — отдельный MCP stdio стенд для проверки именно 12 функций.
- `native_pc_mcp.py` — альтернативный самостоятельный stdio MCP со всеми 30 функциями (`mcp_adapter.py`: 18 старых + 12 новых).
- `python run_pc_mcp_wire.py --extension-only` — реальная проверка MCP SDK: `tools/list` 12, `tools/call` безопасных команд, отказ в shell/traversal. **7 проверок PASS.**
- `python run_pc_mcp_wire.py` — альтернативный stdio сервер: `tools/list` 30, **7 проверок PASS.**
- Текущий ChatGPT-коннектор `Local Workspace` по-прежнему показывает 28 исходных backend tools. Проверка нового изолированного server **не означает**, что они появились в ChatGPT.

## Исправление обнаружения сервера (после `candidate_entrypoints: []`)

Первая версия ошибочно требовала буквальный вызов `mcp.run()` / `server.run()` в том же Python-файле. Реальные MCP-мосты часто используют `FastMCP(...)` с последующей публикацией ASGI приложения через `uvicorn` или фабрику, поэтому поиск мог возвращать пустой список при наличии рабочего сервера.

Теперь `pc_host_detector.py` выполняет **статический AST-анализ Python**: определяет место создания `FastMCP`/`MCPServer` (в том числе `as`-алиасы и многострочные вызовы) и вставляет регистрацию **непосредственно после конструктора**, до ASGI-приложения или другой точки запуска. Код найденных файлов не исполняется. Если конструкторов несколько или нет ни одного, патч запрещён.

Режим поиска выводит `diagnostics` с именами файлов, статическими признаками `mcp_or_asgi_import` и `server_or_asgi_startup`, `inspected_python_files` и `other_runtime_candidates` (Node/TypeScript MCP). Никаких переменных окружения, исходного кода файлов или секретов в диагностике нет. Если `other_runtime_candidates` заполнен, **Python-патч не применяется к JS/TS**, для этого нужен отдельный адаптер.

Снова запусти из обычного Windows Terminal:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python install_pc_tools_in_host.py --guided
```

Если он опять выдаст `EXPLICIT_ENTRYPOINT_REQUIRED`, пришли **только JSON диагностики**, чтобы точно определить способ запуска. Если найдет ровно один кандидат, покажет предпросмотр и фразу подтверждения установки, но не перезапустит сервер.

## Проверенный локальный установщик (только Windows Terminal)

Создан `install_pc_tools_in_host.py`. Он работает лишь из настоящего интерактивного терминала владельца и **отказывает при запуске через MCP**, в том числе для `--discover` и предварительного просмотра. Поддержаны: обнаружение кандидатов внутри `Downloads\\local-workspace-mcp`, предварительный просмотр без записи, проверка SHA-256 плана, точная фраза подтверждения `INSTALL <plan_id>`, резервная копия исходника, атомарная запись и отказ при конкурентном изменении. При неоднозначной точке входа ничего не меняется.

Самый короткий путь после проверки локального каталога исходников — **одна команда в Windows Terminal** (самостоятельно выбирает entrypoint только при одном найденном кандидате, печатает SHA-план и требует точную фразу подтверждения):

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python install_pc_tools_in_host.py --guided
```

Режим `--guided` не пытается выбрать файл при нескольких кандидатах, а возвращает `EXPLICIT_ENTRYPOINT_REQUIRED`. Если это произошло, необходимо указать точное имя после просмотра `--discover`. Результат `patched:true` всё ещё требует контролируемого перезапуска настоящего MCP-сервера: сам установщик **не перезапускает ни сервер, ни туннель**.

После того как локальный сервер и путь его исходников подтверждены **самим владельцем ПК**, доступен и пошаговый вариант из Windows Terminal:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python install_pc_tools_in_host.py --discover
python install_pc_tools_in_host.py --entrypoint ИМЯ_НАЙДЕННОГО_ФАЙЛА.py
python install_pc_tools_in_host.py --entrypoint ИМЯ_НАЙДЕННОГО_ФАЙЛА.py --apply --plan-id ПОЛУЧЕННЫЙ_PLAN_ID
```

Нужно точно подобрать entrypoint по `--discover`; **не запускать `--apply` до проверки предпросмотра и фактической точки входа**. Установщик не перезапускает сервер/туннель, а результат `patched:true` не свидетельствует о регистрации в уже работающем ChatGPT. Для проверки синтаксиса кода патча и поведения установщика добавлен `test_install_pc_tools_in_host.py` с временными фикстурами. После операторского обновления необходим отдельный контролируемый рестарт самого MCP процесса и реальное подтверждение `tools/list` из ChatGPT.

## Встраивание именно в работающий сервер

Нужно открыть исходный Python-файл **запущенного** Local Workspace MCP сервера (тот, к которому проксируется действующий tunnel-client). Он находится **за пределами разрешённого workspace `projects`**, поэтому автоматическая запись/перезапуск через текущий Local Workspace невозможны без предоставления соответствующего каталога как отдельного workspace. Не пытаться обходить границу через `run_script`, поиск секретов, DLL injection или выполнение команд в обход разрешённых путей.

Когда код сервера станет доступен через разрешённый workspace, добавить непосредственно после создания MCP server object и **до** его старта/обработки запроса:

```python
import sys

PROJECT_PC_TOOLS = r"C:\Users\user\IdeaProjects\Local-Workspace-Extensions"
if PROJECT_PC_TOOLS not in sys.path:
    sys.path.insert(0, PROJECT_PC_TOOLS)

from pc_host_extension import register_pc_tools

registered_pc_tools = register_pc_tools(mcp)
assert len(registered_pc_tools) == 12
```

Заменить `mcp` на фактическую переменную FastMCP/MCPServer (например `server`). **Не вызывать одновременно** `register_tools(mcp)` из `mcp_adapter.py`, иначе попытка двойной регистрации двенадцати функций может привести к ошибке. Не выполнять код до создания server object. Нужен только стандартный Python, библиотека MCP на самом действующем хосте уже должна быть установлена.

Перед развертыванием: бэкап точного server-entrypoint и конфигурации туннеля, SHA-256 исходных файлов, синтаксическая проверка модуля, тестирование на отдельном временном порту/транспорте, сверка ожидаемых 28+12 имен, подтверждение что политика host-actor permissions и R2 owner approval не расширена. Затем контролируемая замена только одного серверного процесса с проверкой живых соединений; не перезапускать tunnel-client автоматически. Если server registration не стартует, немедленно вернуть исходный entrypoint и восстановить сервис.

## Откат установки при ошибке после обновления

Добавлен самостоятельный `recover_pc_tools_in_host.py`, работающий **только из интерактивного Windows Terminal**. Он не перезапускает MCP-хост, не меняет туннель, не читает Downloads по запросу удалённого MCP-агента. Перед восстановлением проверяет, что актуальные байты Python entrypoint *точно совпадают* с результатом применения нашего патча к исходному резервному файлу. Если пользователь или другой процесс изменил исходник после установки, восстановление блокируется и не затирает чужие изменения.

Установщик в успешном ответе выводит `backup`. В Windows Terminal выполни, подставив относительный entrypoint и **имя** резервной копии из этого ответа:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python recover_pc_tools_in_host.py --entrypoint ИМЯ_НАЙДЕННОГО_ФАЙЛА.py --backup ИМЯ_ФАЙЛА_SHA.bak
```

Это только проверка, она выдаст `restore_plan_id`, но ничего не перепишет. Для атомарного восстановления:

```powershell
python recover_pc_tools_in_host.py --entrypoint ИМЯ_НАЙДЕННОГО_ФАЙЛА.py --backup ИМЯ_ФАЙЛА_SHA.bak --restore --plan-id ПОЛУЧЕННЫЙ_RESTORE_PLAN_ID
```

Потребуется ввести точную фразу `RESTORE <restore_plan_id>`. Если после восстановления уже работал обновлённый процесс, необходимо отдельно безопасно перезапустить сам сервер и проверить `tools/list`. Не удаляй резервную копию до успешного восстановления работы сервера и проверки старых команд. Тесты: `python -m unittest test_install_pc_tools_in_host test_recover_pc_tools_in_host`.

## Что проверить после настоящего развертывания

1. Реальный `tools/list` из **того же ChatGPT подключения** показывает прежние 28 и новые двенадцать `pc_*` (если старый список не менялся, ожидается 40).
2. Вызов `pc_terminal_preset("python_version")` через ChatGPT возвращает настоящую версию Python.
3. `pc_python_syntax("pc_toolbox.py")` возвращает `valid=true`.
4. `pc_terminal_preset("powershell -Command ...")` и `pc_file_fingerprint("../secret")` возвращают явный отказ.
5. Прежние `run_script`, `run_command`, `job_status`, `job_output` остаются работоспособными, равно как существующая пятиагентная очередь.
6. Подтверждено, что host grant, owner approval и роль agent-team не выводятся из строки роли или самого существования инструмента.

## Ключевое ограничение

`pc_host_extension.py` — определение набора инструментов, **не серверный механизм разрешений**. Исходный MCP хост всё ещё предоставляет широкие `run_script` и `run_command`. Чтобы создать безопасный многопользовательский/мультиагентный хост, в самом сервере необходимо enforce per-tool grants и отдельный operator approval. Простая регистрация 12 безопасных обёрток этого не решает.

### Если изменить существующий хост пока невозможно

Можно вручную добавить другой сервер по `mcp_pc_stdio.json.example` в клиент, который поддерживает локальный stdio MCP (это **не** автоматическое подключение к веб-ChatGPT). Изолированная проверка `native_pc_extension_mcp.py` уже выполнена. Подмена действующего tunnel-client без отдельного плана запрещена.
