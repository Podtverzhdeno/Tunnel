# Пять ролей Scheduled OpenSpec/SDD — факт проверки 2026-11-01

## Конфигурация

Проект: `C:\Users\user\IdeaProjects\Local-Workspace-Extensions`. Старый `Scheduled-Agent-Harness` и его SQLite оставлены без модификации.

Запущена **конфигурация** пяти ролей: `developer-1`, `developer-2`, `developer-3`, `developer-4`, `architect-reviewer`. Действующие Scheduled Tasks реально обновлены или созданы, но результатов будущих hourly запусков на момент настройки ещё нет.

| Запланированная карточка | ID | Запуск UTC | Роли | Статус |
| --- | --- | --- | --- | --- |
| OpenSpec — Developer 1 | 6ae6ba8a7edc8191a021b55a9ef1b595 | каждый час :10 | developer-1 | enabled |
| OpenSpec — Developers 3+4 | 6ae74da5c4548191b605d0566bfa56cf | каждый час :20 | developer-3 **затем** developer-4 | enabled |
| OpenSpec — Developer 2 | 6ae6ba8b5d4c8191853883318aae7411 | каждый час :30 | developer-2 | enabled |
| OpenSpec — Architect Reviewer | 6ae6ba8c7c1081919402e9d8bb58f0d7 | каждый час :50 | architect-reviewer | enabled |

Активная задача `IT/AI сертификаты` сохранена. Планировщик вернул `too_many_active_automations`, максимум пять активных записей. Поэтому четыре разработчика фактически распределены по **трём** hourly-карточкам, а reviewer занимает четвёртую. Это **не пять независимых ChatGPT-процессов**: developer-3 и developer-4 исполняются последовательно в одном scheduled запуске. Для пяти отдельных карточек нужен освобождённый слот и отдельное согласование остановки другой автоматизации.

## Реализация

- `agent_team.py` — SQLite-контур, пять ролей, atomic leases, 50-минутный TTL, request-id replay, heartbeat, owner-first reacquire, state transitions available/working/reviewing/rework/done.
- `team_seed.json` — четыре стартовые независимые задачи P009, P010, P015, P016, каждая со ссылкой на актуальный OpenSpec requirement и непересекающимися Python deliverables.
- `.agent-team/workspaces/<developer>/<task>` — рабочие копии Python и актуальных OpenSpec/SDD документов. На новом запуске незавершённый task reacquire-ится с прежней sandbox и новой lease. Статус содержит `activity_at`, owner, `submitted_at`, `reviewed_at`, `lease_until` и review notes; история событий хранится в SQLite.
- Reviewer допускает перенос кода в исходный проект только по перечисленным deliverables и при совпадении исходных SHA-256, отсутствии изменений других Python-файлов в sandbox, успешном unittest, успешном `spec_check.py` и реальной строгой проверке OpenSpec.
- При изменении OpenSpec reviewer может выполнить `rebase-spec` для истекшей/возвращённой задачи: обновить только справочные документы, сохранить код и передать задачу на переработку.
- Запрещены собственные Git push/commit, Docker/Postgres операции, секреты и глобальные изменения. Это **логическая файловая изоляция**, а не отдельные Windows-пользователи или sandbox ОС; unrestricted Local Workspace tools нуждаются в host-level policy.

## Проверка результата

- `python -m unittest discover`: **132 tests, 129 PASS, 3 SKIP**, exit 0.
- `python agent_team.py gate-check`: main unittest, spec_check и OpenSpec strict — все exit 0.
- `python spec_check.py`: **10 capability specs, 90 требований, 92 сценария, 36 FR, 34 SDD tasks, 79 OpenSpec P-tasks**, ошибок 0.
- `openspec validate local-pc-agent-tooling --strict`: PASS (OpenSpec 1.14.3).
- `python agent_team.py init` второй раз: **added=0**; дублирующей загрузки задач нет.
- `python agent_team.py status`: четыре задачи в available, никто не утверждает, что код уже написан scheduled-агентом.
- `automations.peek`: четыре команды OpenSpec включены, плюс сохранённая активная `IT/AI сертификаты`.

## Ещё не проверено

Будущие hourly ChatGPT executions, действительный код от scheduled Developers, real reviewer merge, продолжение после реального часового перерыва и OS-level изоляция. Эти этапы нельзя считать выполненными, пока в SQLite и логах реального запуска не будет доказательств.

## Как смотреть прогресс

Через Local Workspace `run_script`, путь `Local-Workspace-Extensions/agent_team.py`, cwd `Local-Workspace-Extensions`:
- `args=["status"]` — вся команда, последние события и даты активности;
- `args=["history","P009"]` — кто и когда занимался задачей и какие оставил комментарии;
- `args=["gate-check"]` — реальная проверка QA;
- `args=["init"]` — добавление только новых независимых spec-backed задач из `team_seed.json`.
