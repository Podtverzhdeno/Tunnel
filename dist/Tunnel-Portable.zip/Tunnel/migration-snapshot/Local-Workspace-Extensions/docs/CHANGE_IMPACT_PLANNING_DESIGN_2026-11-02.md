# SDD design supplement — Change Impact, Explainability & Safe Planning

**Date:** 2026-11-02  
**Status:** NON-NORMATIVE / owner approval required for canonical OpenSpec+SDD.  
**Manifest:** `requests/add-agent-change-impact-planning.json`  
**Proposed change:** `openspec/changes/add-agent-change-impact-planning`  
**Authority:** none. This file does not seed tickets, confer permissions, update the MCP host, edit live SQLite, or certify a release.

## 0. Why this is a distinct capability

Current `spec_check.py` / `spec_traceability.py` / `sdd_roadmap_check.py` establish static consistency and selected evidence links. `agent_team.py` is the authoritative queue and lease coordinator. `agent_logistics_dispatch.py`, `review_readiness_matrix.py`, `review_queue_triage.py`, `agent_responsibility_guard.py` and `task_reuse_preflight.py` already provide valuable task and code signals. The new capability SHALL *compose* those observations **before** a change is admitted or reviewed, without copying policy implementation.

The missing operator question: **“If we change this SHALL, owner contract or public API, exactly what becomes stale, what can continue independently, and which non-optional tests must run?”** A plain FR crosswalk cannot reliably answer transitive, time-dependent impact or compare alternative orders.

**Strict exclusion boundaries:**
- P085 and `host_role_policy.py` own actual trusted host identity and capability enforcement. No new authentication broker.
- `agent_team.py` owns queue state, lease fencing, acceptance state and task ownership. No second task table, allocator or authoritative READY decision.
- Existing `review_merge.py` / MergeIntent remain the only promotion mechanism. Simulation never invokes them.
- `spec_traceability.py` owns requirement-to-evidence reference validation. Impact planner only consumes verified results.
- Existing long-term memory, durable-step journal and repair-loop proposals remain separate `add-durable-agent-memory` and `add-agent-reliability-qa` changes, and require their own approvals. No duplicate step journal or QA runner here.
- All output is advisory, not a replacement for independent QA, existing official OpenSpec strict validation or final source SHA checking.

## 1. Requirement-to-implementation crosswalk

| Requirement | Current source of truth | New bounded adapter | Negative acceptance |
| --- | --- | --- | --- |
| CI-01 revision snapshot | OpenSpec + SDD + file SHA + SQLite read snapshot | `change_impact.py snapshot` (proposed) | concurrent drift -> STALE_SNAPSHOT |
| CI-02 transitive invalidation | roadmap dependencies, responsibility owner contracts, import/API graph | `change_impact.py analyze` | unknown import -> UNKNOWN_IMPACT |
| CI-03 bounds/caching | existing import/traceability scans | revision-keyed advisory cache only | truncated -> PARTIAL |
| EX-01 predicate explanation | `agent_team.py plan-work` and readiness tools | `decision_explain.py preview` | blocked predecessor remains explicit |
| EX-02 no simulated authority | host P085 / coordinator lease and review APIs | purely read-only service boundary | forged actor cannot mutate |
| EX-03 policy consistency | canonical readiness predicate versions | snapshot + contract tests | policy rename -> POLICY_DRIFT |
| SIM-01 scenario runner | `agent_team.py` snapshot; disposable SQLite fixtures | `planning_simulator.py` (proposed) | production DB not writable |
| SIM-02 deadlock/fairness | dependency DAG, ownership contracts | bounded deterministic fixture simulator | conflict not dispatchable |
| SIM-03 metric provenance | run history / measured receipts | `simulation_report` adapter | forecast never labelled measured |
| RV-01 mandatory floor | existing quality_submit / reviewer / host trust | `risk_validation_plan.py` | timeout never becomes PASS |
| RV-02 risk provenance | historical negative findings + code graph | advisory factor score | UNKNOWN_HIGH for uncertain effects |
| RV-03 manifest hashes | test index, spec SHA, env and source receipts | deterministic test manifest | planned-not-run remains red |

**Numbering note:** CI/EX/SIM/RV are *design shorthand*, not canonical FR numbers. Canonical FR IDs are generated only by the owner-approved spec workflow. Never merge these IDs into the live roadmap without an explicit approved mapping.

## 2. Data model — typed, versioned, reproducible

### 2.1 ChangeImpactSnapshotV1

```json
{
  "schema_version": 1,
  "snapshot_id": "sha256:<canonical-serialization-of-content>",
  "project": "Local-Workspace-Extensions",
  "read_only": true,
  "captured_at": "UTC ISO-8601",
  "consistency": "BEST_EFFORT_REVALIDATED",
  "source_revision": {
    "openspec_sha256": "<hex>",
    "sdd_sha256": "<hex>",
    "roadmap_sha256": "<hex>",
    "coordinator_read_revision": "<opaque-or-null>",
    "policy_sha256": "<hex-or-null>"
  },
  "graph": {
    "nodes": [{"id": "req:...", "kind": "requirement", "sha256": "<hex-or-null>"}],
    "edges": [{"from": "req:...", "to": "task:...", "kind": "declared_dependency"}]
  },
  "coverage": {
    "inspected_nodes": 0,
    "uninspected_nodes": 0,
    "unknown_edges": 0,
    "truncated": false
  },
  "status": "COMPLETE",
  "warnings": []
}
```

`captured_at` is metadata and MUST NOT influence `snapshot_id`; canonical deterministic payload excludes wall clock, volatile temp paths, machine-specific absolute paths and secret values. JSON stable serialization: UTF-8, sorted keys, fixed separator and normalized relative paths; never assume file mtimes establish identity. There is no atomic read transaction spanning NTFS and SQLite. Read metadata, open SQLite in a read-only transaction, collect file SHA and *re-read SHA* at end. If any source drift is detected, return STALE_SNAPSHOT. If drift is unobservable, report BEST_EFFORT_REVALIDATED, not `ATOMIC`.

Node kinds: requirement, capability, owner-contract, module, public-api, task, test, qa-witness, reviewer-receipt, grant-status. Edges: implements, depends_on, owns, imports, verifies, attests_to, supersedes. There is **no** public key, lease token, owner terminal approval secret or raw prompt in this model.

### 2.2 ImpactReportV1

```json
{
  "schema_version": 1,
  "base_snapshot": "<sha256>",
  "proposed_change_sha256": "<sha256>",
  "impact_status": "REVALIDATION_REQUIRED",
  "direct": ["req:FR-..."],
  "transitive": ["task:P...", "test:...", "qa-witness:..."],
  "unresolved": [{"node": "module:...", "reason": "DYNAMIC_IMPORT_UNKNOWN"}],
  "required_rechecks": ["openspec_strict", "contract_owner", "negative_qa", "reviewer_final_sha"],
  "unaffected_basis": [{"node": "task:P...", "evidence": ["..."]}],
  "bounds": {"node_limit": 10000, "max_depth": 64, "time_budget_ms": 10000},
  "coverage": {"inspected": 0, "skipped": 0},
  "authority": "ADVISORY_ONLY"
}
```

`unaffected_basis` must contain a *verified disjoint dependency proof*, not merely absence of a known edge. Unknown import/ownership means `unresolved`, not unaffected. If a hash is missing, report UNKNOWN. A changed `SHALL` invalidates the acceptance evidence for precisely that requirement and known downstream links, not all unrelated tasks by default.

### 2.3 DecisionExplanationV1

```json
{
  "schema_version": 1,
  "snapshot_id": "<sha256>",
  "task_id": "P...",
  "decision": "BLOCKED_DEPENDENCY",
  "authority": "ADVISORY_ONLY",
  "policy_digest": "<sha256>",
  "reasons": [
    {
      "predicate_id": "dependency.accepted_sha",
      "result": "FALSE",
      "upstream_ref": "P...",
      "required_evidence": "independent_acceptance_receipt",
      "provenance": "<file-or-receipt-id>"
    }
  ],
  "unverified": ["host_identity"],
  "would_execute": false
}
```

Allowed decisions: `READY_ADVISORY`, `BLOCKED_DEPENDENCY`, `BLOCKED_SPEC`, `BLOCKED_SECURITY`, `BLOCKED_OWNER`, `BLOCKED_RESOURCE`, `CONFLICTING_OUTPUT`, `NEEDS_RECONCILIATION`, `UNKNOWN_EVIDENCE`, `STALE_SNAPSHOT`. Do **not** publish `READY` alone. Prefer existing coordinator enum if it can be imported read-only without side effects; if not, a static mapping plus drift test is the only accepted temporary adapter. The output cannot be submitted to coordinator as lease/token.

### 2.4 ScenarioReportV1 and ValidationPlanV1

A simulation report needs: immutable fixture digest, scenario name/seed, policy digest, input queue digest, measured baseline provenance, `MODEL_ONLY` projected results, inspection coverage, conflict/deadlock/fairness diagnostics, and an explicit `mutation_count: 0`. Validation plan needs: source/spec/test inventory SHA, risk factor breakdown, mandatory checks, additional checks, nonexecuted checks, recorded executed-receipt references (if externally verified), `INCOMPLETE_VERIFICATION` when any required check lacks evidence. Neither object asserts an owner grant.

## 3. Algorithms and operational complexity

**Impact graph:**
1. Parse bounded static sources and record origin+SHA for each fact. Use the existing validators instead of a new parser for canonical FR mappings.
2. Build adjacency maps once (declared dependencies, contracts, import edges); use typed `unknown_edge` records instead of guessing.
3. Detect duplicate/conflicting IDs; stop with `CONFLICTING_INPUT`, never choose a random owner.
4. Identify changed requirements by normalized canonical digest, not file line numbers; detect split/merge/rename as `MANUAL_REMAP_REQUIRED`.
5. Breadth-first or topological traversal from changed nodes with visited set; detect strongly connected components or report cycles; return direct, transitive, unresolved and out-of-scope separately.
6. Cache **only advisory discovery** by tuple (source SHA, spec SHA, dependency graph SHA, policy SHA, scanner version). Any mismatch invalidates. Final independent review never consumes cached PASS as authority.

Expected memory O(V+E) and time O(V+E), subject to explicit caps. A partial traversal must expose skipped and unknown counts. A service crash returns no green status.

**Predicate explanations:** bind read-only snapshots of existing predicate results; stable sort reasons by policy order and ID. A hard block dominates advisory scoring. If current coordinator logic cannot provide machine-readable predicate evidence, label UNKNOWN and file a narrowly scoped adapter ticket. Do not copy business conditions into an independently evolving rule engine.

**Simulation:** clone immutable task state into in-memory/disposable fixture, freeze deterministic tie-break order, run existing eligibility preflight semantics through a stateless adapter. Stop on iteration/time budget. Never import untrusted candidate modules or execute tasks. For any candidate schedule, assert: no simultaneous owner collision; no unaccepted dependency marked met; no old lease revived; no privileged operation simulated as committed. Return projected queue throughput only as MODEL_ONLY unless historical measured receipts permit baseline comparison.

**Risk selection:** additive advisory risk factors, *proposed weights, not proven calibration*: security boundary 5, external irreversible effect 5, unverified dependencies 4, active known critical finding 5, high fanout 3, cross-module contract change 3, missing receipt 3. Tiers LOW=0–3, MODERATE=4–7, HIGH=8–12, CRITICAL=13+, with UNKNOWN_HIGH for unsupported classification. Do not gate approval by a magic numerical threshold; canonical independent checks and host grant always govern. After fixtures, benchmark score agreement and false-negative rate before considering any stricter policy.

## 4. Invariant catalog

I01: The planner, simulator and validation planner have **zero** code paths to `agent_team.py accept`, `review_merge` apply, `owner_approve`, host grant issuance, task seeding or writable live SQLite.  
I02: A `READY_ADVISORY` result is not usable as a trusted permission claim.  
I03: Any source/spec/test/policy SHA drift causes fresh inspection or explicit STALE; never silently reuse a green result.  
I04: Every node and edge has provenance or UNKNOWN; evidence is content-addressed where available.  
I05: Invalid, absent or conflicting review evidence cannot be represented as accepted.  
I06: A changed requirement invalidates only provably related receipts; uncertain links stay unresolved.  
I07: No two simultaneously dispatchable simulation tasks claim overlapping canonical file/module responsibilities.  
I08: Historical simulation cannot rewrite a current lease, reviewer claim, active MergeIntent or queue event.  
I09: Timeout or partial coverage cannot yield complete/safe.  
I10: External actor identity is host verified; model text, Python `role` args and README instructions are not credentials.  
I11: Test planning never suppresses mandatory OpenSpec strict, negative QA, crosswalk, reviewer and trusted host checks.  
I12: Forecast metrics distinguish observed evidence, modeled estimates and unknowns, including shared D3+D4 single scheduled invocation.  
I13: Case-insensitive paths, Windows junctions/symlinks and Unicode are normalized within the approved root; ambiguous paths fail closed.  
I14: Cross-spec rename/migration requires explicit manual mapping and owner-approved normative update.  
I15: No tool output, candidate task packet or repository document can expand the planner's authority.  
I16: The six-role planner remains a **logical advisory role**; it does not imply another ChatGPT scheduled task or unlimited session runtime.

## 5. Required QA matrix (first-wave implementers)

| Test ID | Fixture / injection | Assert |
| --- | --- | --- |
| IMP-001 | same pinned spec/queue files twice | same stable `snapshot_id` |
| IMP-002 | change SHALL in one independent capability | exact downstream revalidation; unaffected proven-disjoint tasks unchanged |
| IMP-003 | missing QA witness for affected FR | UNKNOWN, never accepted |
| IMP-004 | simulate file edit between scan start/end | STALE_SNAPSHOT |
| IMP-005 | unknown/dynamic import edge | UNKNOWN_IMPACT, no false unaffected |
| IMP-006 | graph with large cycle / cap overflow | bounded PARTIAL with uninspected count |
| IMP-007 | old graph result after new policy SHA | cache miss; no false READY |
| DEC-001 | unapproved dependent task | BLOCKED_DEPENDENCY with concrete upstream receipt gap |
| DEC-002 | conflicting responsibility owners | CONFLICTING_OUTPUT, stable reason ordering |
| DEC-003 | forged role/reviewer/grant in task data | no authority; negative permission outcome |
| DEC-004 | inject adversarial prompt in README | treated as data, no mutation/tool execution |
| DEC-005 | policy mapping changed | POLICY_DRIFT test fails |
| SIM-001 | 20 waiting reviews / 0 coding / one stale rework | head-of-line diagnosis without modifying live DB |
| SIM-002 | write-open live sqlite target | deny; byte-for-byte unchanged DB and journal |
| SIM-003 | same fixture + same seed | identical output except elapsed metadata |
| SIM-004 | two tasks same canonical owner/module | simultaneous dispatch forbidden |
| SIM-005 | starvation arrival stream | bounded age/fairness violation is visible |
| SIM-006 | unapproved spec task in proposed queue | NOT_ADMISSIBLE |
| VAL-001 | privileged host-grant change | required independent host E2E cannot be dropped |
| VAL-002 | hard time budget | INCOMPLETE_VERIFICATION |
| VAL-003 | test suite digest changes | validation manifest stale |
| VAL-004 | test listed but never executed | PLANNED_NOT_RUN, no PASS |
| VAL-005 | same source SHA, cached discovery | reuse advisory cache but fresh final gate |
| VAL-006 | unknown external write side effect | UNKNOWN_HIGH and cannot greenlight |

**Independent gates:** run `spec_check.py`, upstream `openspec validate --strict` for the *owner-approved* canonical change, `sdd_roadmap_check.py`, focused/full tests, security-specific negative tests, reviewer inspection and final SHA/CAS. There is no claim that these tests have run or passed merely because they are listed here.

## 6. SDD task breakdown — proposed, not live P IDs

| Proposed ID | Responsibility | Inputs | Deliverables | Exit criterion | Dependency |
| --- | --- | --- | --- | --- | --- |
| CP-01 | Contract inventory | canonical validators, approval path | reviewed ownership map and policy predicate catalog | no duplicated authority | owner-approved new spec |
| CP-02 | Snapshot / drift detector | OpenSpec, SDD, read-only SQLite | typed snapshot + hash stability tests | IMP-001,003,004,006 | CP-01 |
| CP-03 | Impact DAG | CP-02, existing ownership/import graph | transitive analyzer + unknown edges | IMP-002,005,007 | CP-02 |
| CP-04 | Explainability adapter | coordinator preflight, QA matrix | reason-coded read-only decision | DEC-001..005 | CP-01,CP-02 |
| CP-05 | Fixture-only scheduler sandbox | read-only snapshots, disposable SQLite | deterministic what-if evaluator | SIM-001..006 | CP-02, CP-04 |
| CP-06 | Risk planner | known negative QA, test index | risk factors + selection manifest | VAL-001..006 | CP-03, CP-04 |
| CP-07 | Independent system review | all above exact SHAs | published evidence report and negative findings | 24/24 named negative/positive cases or explicit FAIL | CP-03..06 |
| CP-08 | Operational canary | approved host and release receipts | baseline vs candidate observed metrics; rollback plan | owner release decision | P085 host proof + CP-07 |

**Disjointness:** CP-02/03 own the new advisory read-model; CP-04 *adapts* coordinator predicates; CP-05 fixtures only; CP-06 advisory validation. Do not let parallel developers edit existing coordinator/validator core files simultaneously. Existing accepted source+test SHA wins over speculative implementation. Assign real owners only via approved task admission and current lease fences.

## 7. Acceptance and measured success (targets, NOT observed)

- **Correctness:** 100% of supplied fixture cases produce specified typed outcomes; no known false-green on adversarial scenarios. Any false-green blocks release.
- **No side effects:** live SQLite, source and journal byte hashes unchanged after every dry-run; note that externally busy WAL can change independently, so use a quiescent disposable fixture for assertable hash tests.
- **Determinism:** identical inputs+policy produce the same canonical result hash across 20 repeated runs in controlled environment; exclude timestamps.
- **Coverage:** 100% of reported nodes are explicitly verified or marked UNKNOWN/PARTIAL, with exact uninspected counts.
- **Time budget:** target <=10s for graph up to 10k nodes/50k edges on the reference machine; benchmark first and revise, never report as measured until proven.
- **Reviewer value:** compare baseline vs with impact packets on the same fixed fixture: QA minutes, false-green rate, rediagnosis count, starvation and accepted tasks per reviewer-hour. Do not call simulated throughput measured.
- **Productivity:** a task known to be independent of a blocked task remains advisory-ready, but acquiring it still requires canonical approval and lease.
- **Rollback:** remove/disable only advisory adapters and caches; no schema migration required for first release; never alter MergeIntent or accepted receipts.
- **Security:** explicit attempts to escalate from advisory outputs and universal runner are refused by the actual host before *privileged production release*. P085 remains a release gate even if advisory dry-runs pass.

## 8. Rationale / ADR proposals

**ADR-CP1: Read model, not new coordinator.** This avoids split brain and preserves reviewer provenance. Cost: read-only adapters may need version management.

**ADR-CP2: Content SHA not wall-clock mtime.** Windows file timestamps can be insufficient for consistency and old reports outlive a policy change. Cost: bounded extra disk reads.

**ADR-CP3: Conservative unknown propagation.** Better a small overapproximation than a false-safe acceptance. Cost: higher manual triage load; track with measured false-positive rate.

**ADR-CP4: Fixture simulation before live policies.** Predictive scheduling cannot prove production behavior; deterministic fixture trials enable negative tests without touching live leases.

**ADR-CP5: Test optimization is advisory-only.** Risk tier may schedule extra coverage and bounded exploratory testing, never strip mandatory evidence from the canonical review gate.

**ADR-CP6: Optional future cross-team export.** Cross-team events may contain accepted artifact SHA and external source URI only after a separate threat model. No global mutable task database or implicit authority federation.

## 9. Explicit outstanding decisions (do not fill by speculation)

D01: Whether existing coordinator can expose a stable read-only policy predicate API without side effects.  
D02: Exact normalized requirement identity scheme across rename/split/merge.  
D03: Maximum safe data volume and latency on the actual Windows machine.  
D04: Which existing QA receipts carry authoritative source/test/environment digests.  
D05: How static imports and dynamic plugin loading are classified in existing guards.  
D06: Whether revision snapshots can be collected atomically from a real persistent store; until then best-effort with drift checks only.  
D07: Who independently verifies the P085 host bypass tests after actual MCP host source changes.  
D08: Which of the existing owner-ready queues may legally incorporate CP tasks after owner approval.  
D09: Risk score calibration / measured false negative baseline.  
D10: Owner acceptance of exact generated OpenSpec/SDD plan, including the proposed feature index.

## 10. Release sequence and explicit stop conditions

1. Owner reviews the exact `spec_preview` file manifest and plan hash in foreground Terminal; spec generator creates canonical files only after approved request.
2. Independent architecture review eliminates responsibility overlap with `add-agent-foundation-hardening`, existing 72-idea portfolio and pending reliability/memory changes.
3. One owner-approved, lease-scoped agent implements CP-01/02 against disposable fixtures, independently tests failures, then others can tackle disjoint CP-03/04/05/06.
4. Reviewer checks source/spec/test SHA, negative QA and report provenance. A successful test runner exit alone is not a trusted host receipt.
5. P085 actual host role enforcement + Windows hostile E2E must be proven before any privileged release. No model-generated signature substitutes for genuine host-verified actor grant.
6. Any stale snapshot, unexplained gap, partial evaluation, inconclusive test, suspicious role or live-state drift becomes **BLOCKED or RECONCILIATION_REQUIRED**. Never autorefresh a dangerous write.
7. Preserve rollback and old accepted states; production promotion uses only existing authorized merge/release path.

**Result of this document:** an implementation-grade design and test strategy for approval consideration. It is not a code implementation and not evidence of official spec acceptance.
