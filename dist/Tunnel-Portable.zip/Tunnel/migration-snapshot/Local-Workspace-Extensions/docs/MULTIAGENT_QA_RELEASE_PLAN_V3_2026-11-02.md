# Multiagent SDD V3 — Acceptance, chaos verification and phased delivery

Date: 2026-11-02  
Status: PROPOSED / not implemented, not production-certified  
Companions:
- docs/MULTIAGENT_ARCHITECTURE_SDD_V3_2026-11-02.md
- docs/MULTIAGENT_TYPED_CONTRACTS_V3_2026-11-02.md
- docs/MULTIAGENT_ACCEPTANCE_CATALOG_V3.json (16 requirement anchors × 4 tests = 64 planned cases)
- docs/CHANGE_IMPACT_PLANNING_DESIGN_2026-11-02.md
- docs/SPEC_TRACEABILITY_REMEDIATION_2026-11-02.md

## 1. Definition of verified completion

"Spec written" means the proposal is stored and structurally valid; it does **not** mean implementation verified. "Implementation verified" requires actual source revision, exact test execution, independent QA and review of this change's precise scope. "Safe to release" additionally requires trust boundary proof at the real MCP host, owner-authorized release, rollback canary and all negative host E2E. Do not collapse these statuses.

Evidence levels:
E0 IDEA: model proposal or conversation; no execution or authority.
E1 STATIC: code/docs/SDD source inspected with SHA; no proof of runtime behavior.
E2 LOCAL_VERIFIED: independently executed fixture and code QA on identified source SHA; still not trusted host-level capability proof.
E3 HOST_ATTESTED: actual host principal and effect scope verified, non-secret signed/attested origin and real OS/process isolation checks passed.
E4 OWNER_RELEASED: explicit human release authorization + canary + rollback receipt.

No result may be promoted from E1 to E3 merely by checksum, ChatGPT prompt, local self-signed Python receipt or arbitrary CLI role string.

## 2. Test catalog contract

64 planned tests are in the machine-readable JSON catalog. Each test must record:
- test ID and S3 requirement anchor;
- canonical component/owner;
- explicit Given, When, Then and independent oracle;
- fixture class: offline/disposable, integration, actual MCP host or real scheduled run;
- exact source and spec revisions;
- run ID, verified command, environment hash, start/end observation;
- observed outcome and classification; evidence pointer or reason NOT_RUN;
- responsible independent reviewer and source SHA recheck before acceptance.

Original JSON has execution_status=PLANNED_NOT_RUN for every case; no agent may rewrite a test row as PASS without an actual verifiable receipt in the canonical testing channel.

### Test families

| Family | Requirement(s) | Planned cases | Minimum verification |
| --- | --- | ---: | --- |
| SEC-ACTOR | S3-01, S3-14, S3-15 | 12 | real host negative tests, owner approval |
| COORD-DAG / OWNERS | S3-02, S3-03, S3-09 | 12 | real coordinator on disposable SQLite fixtures |
| RECOVERY | S3-04, S3-05, S3-07 | 12 | crash injection, journal/file hash reconciliation |
| QUALITY | S3-06, S3-08, S3-16 | 12 | external independent QA and anti-self-review |
| CONTROLS | S3-10, S3-11, S3-12, S3-13 | 16 | bounded read-only fixtures and observed telemetry |
| TOTAL | S3-01..16 | 64 | all planned, no inferred passes |

Test families are independently executable in stages, but release cannot be declared while any mandatory host-negative proof is missing.

## 3. Chaos injection plan

CA-01 Crash before coordinator SQL transaction begins: no task state changed.
CA-02 Crash after lease row update before transaction commit: transaction rollback; no ghost lease.
CA-03 Concurrent acquire by two roles for the same task: only one current owner.
CA-04 Source SHA changed while sandbox was being prepared: stale source identified before effects.
CA-05 Expired token from prior invocation tries to checkpoint: no state mutation.
CA-06 Lost tool response for read-only operation: allowed bounded read-only retry.
CA-07 Lost tool response after external write entered IN_FLIGHT: reconciliation required, no repeated write.
CA-08 Crash after first file promotion before other files: MergeIntent retained; no false accepted status.
CA-09 SQLite commit failure after file promotion: intent state inspected; owner-led reconciliation.
CA-10 Crash after acceptance commit before journal cleanup: preserve completed acceptance; no duplicate receipt.
CA-11 Actual MCP host loses principal context across reconnect: privileged writes denied until new verified grant.
CA-12 Grant revoked during delayed job: host must enforce suitable action boundary, stop or deny next privileged step; cannot assume cancellation has undone completed effects.
CA-13 Windows junction target changes between preview and write: actual host path/handle enforcement rejects escape.
CA-14 Bogus reviewer actor sent as CLI arg: host denies privileged accept even if coordinator role text matches.
CA-15 Candidate test alters Python import hooks to skip security checks: independent test runner identifies tampering or blocks release.
CA-16 Duplicate task IDs in newly proposed seed: reject entire unapproved admission transaction; do not partially insert.
CA-17 Concurrent competing owner contracts for one module: at most one permitted; no parallel canonical write.
CA-18 Candidate spec changes while review is running: old receipt becomes stale, no automatic acceptance.
CA-19 Known critical negative witness reports bug on exact source SHA: no green release even if cached matrix says ready.
CA-20 Pipeline sees a nonzero test-runner exit with incomplete logs: return UNKNOWN/FAIL, not "not executed".
CA-21 Negative test returns zero when reproducing a bug: candidate is blocked, not PASS.
CA-22 Both developers on shared D3+4 card attempt peer acceptance of each other: independently denied.
CA-23 Head-of-line blocked rework + separate legal task: scheduler can propose latter but cannot steal former lease.
CA-24 All legal work exhausted: report no-safe-work, do not invent tickets or extra platform invocations.
CA-25 Queue is large, graph scan reaches cap: report PARTIAL with uninspected count.
CA-26 A Graph cycle is injected: bounded detection, no infinite loop.
CA-27 Provider token field absent: unknown usage, not zero.
CA-28 Platform scheduled invocation exits while host test job continues: task reports job status UNKNOWN until independently observed.
CA-29 User edits unrelated dirty worktree: no reset, branch checkout, forced merge or overwrite.
CA-30 Agent proposes to update its own host security policy: owner release + separate attestation required.

Test harness MUST use disposable fixtures, isolated task sandboxes, bounded jobs and no real external writes until explicitly authorized. Chaos case statements are required negative scenarios, NOT observations that such tests have passed.

## 4. Security assurance gates

**SA-0 Inventory:** enumerate actual connected Local Workspace MCP tools and exact privileged entrypoints. Source path and host process/version are evidence, not assumptions.

**SA-1 Principal:** demonstrate real connection-bound actor identity and denial for arbitrary "architect-reviewer" role strings; test lost/replayed/expired grants.

**SA-2 Complete mediation:** every mutation-capable operation, including general scripts, commands, unsafe Docker/SQL/Git, source edits, review and spec creation, uses the same host policy. Zero bypasses in a curated adversarial suite.

**SA-3 Resource isolation:** Windows reparse/junction/UNC/device path cases, process tree ownership, symlink race, shell invocation constraints, network egress and sensitive material redaction.

**SA-4 Owner authority:** foreground approval exact plan digest; invalid/expired/revoked request cannot create canonical spec or authorize release.

**SA-5 Independence:** developer code cannot alter the independent reviewer and its security-critical verifier in the same acceptance trust domain; separate final QA and actual host evidence.

**SA-6 Release:** on- and off-path smoke tests, bounded canary, rollback drill with source hashes and no unintended state loss.

P085 is the existing canonical implementation responsibility for SA-0..3. A new planning tool shall not create a duplicate host broker.

## 5. Consistency, liveness and performance

### 5.1 Safety versus liveness

Safety properties: wrong actor cannot write, no stale accepted source, no duplicate non-idempotent effect, no conflicting ownership, no false reviewer identity. Safety failures are P0 release blockers.

Liveness properties: independent work can progress despite unrelated blockers, crashed reviews are diagnosable, genuine ready work is not perpetually starved. These need fair selection and recorded progress but **may not** weaken safety gates.

Formal caution: arbitrary external APIs and filesystem+SQLite cannot provide unconditional exactly-once effects. Target exactly-once *observable coordinator state* for idempotent/atomic operations and reconciliation for ambiguous side effects. Do not claim global exactly once.

### 5.2 Benchmark suite (hypotheses, not current numbers)

B-01 Source graph: small (100 nodes/300 edges), medium (1k/5k), large (10k/50k), dense with cycles and unknown import edges.
B-02 Queue planner: 10/100/1000 tasks; 0%, 20%, 60%, 90% review backlog; 2-20% owner conflicts.
B-03 Crash recovery: random deterministic injection positions before/after coordinator transaction, file rename, MergeIntent commit and receipt cleanup.
B-04 Reviewer QA: 21-task fixed queue fixture with 0/1/5 known critical findings, stale SHA, negative case requiring independent runner.
B-05 Scheduled cycle: bounded synthetic run times 30s/2min/10min, simulate abrupt platform stop; do not claim ability to set actual ChatGPT runtime.
B-06 Cache: stable revision, 1 changed test, 1 changed source, 1 changed policy, 1 changed dependency lockfile.
B-07 Memory: resume packet scale 1/100/1000 checkpoints, no credential leakage and bounded context.
B-08 Shared-card accounting: developer 3 and 4 produce distinct task receipts in one observed invocation, counted once for platform run.

For every benchmark report p50/p95 latency, RSS memory, CPU/test seconds, fixture digest, OS/Python version, false-ready rate, false-block rate and evidence coverage. Run controlled matched workloads; never compare one warm run to a different cold run and call it improvement.

### 5.3 Operational metrics

| Metric | Numerator/denominator | Safety caveat |
| --- | --- | --- |
| accepted useful tasks / observed invocation | exact independently accepted source changes / real observed runs | not all commits or ideas |
| p95 review age | per-task submitted_at to accepted/reworked_at | missing timestamps excluded with coverage |
| false-ready rate | confirmed wrongly-ready advisory classifications / reviewed candidate readiness events | report uncertainty and sample count |
| known-critical defect escape | accepted candidate SHAs with known critical negative witnesses / accepted candidate SHAs | target zero on covered suite |
| lost work after disconnect | verified safe steps repeated or unaccounted / verified steps before reconnect | must observe both intervals |
| rework amplification | repeated QA/test seconds / first QA/test seconds for same source family | source SHA and environment must match |
| idle reason distribution | observed no-safe-work, blocked-owner, blocked-host, blocked-spec, blocked-QA counts / observed role cycles | do not count unscheduled time as idle working time |
| owner conflict rate | rejected ownership collisions / candidate overlapping tasks | distinguish false-positive conflict review |
| evidence coverage | independently verified required check count / required check count | plan-only is not executed |
| source drift rate | stale source discovery events / verified attempted handoffs | no phantom drift from missing SHA |
| host authorization coverage | privileged entrypoints with real host negative E2E / enumerated privileged entrypoints | unknown => release blocked |
| token usage coverage | provider-returned token receipts / eligible observed calls | ChatGPT usage not known from prompts |

Targets should be declared only after collecting baseline. "100% safety negative tests passed" requires a complete and reviewed threat model, not merely a denominator of tests that happened to run.

## 6. SDD traceability closure

The previous static report found 99 OpenSpec requirements but 43 explicit FR mappings in the local-pc-agent-tooling change, and a parser problem falsely reported 26 FR/task gaps because it did not parse grouped [FR-001,FR-002] references.

Specification remediation acceptance:
1. Correct the existing spec_analyzer parser to recognize grouped task references and only real checklist task syntax; no insertion of fake duplicate tags.
2. Emit total unmapped OpenSpec requirements, reported sample count, truncation and unique source SHA.
3. Independently review and classify 56 potentially unmapped requirements rather than auto-generating 56 duplicative new FRs.
4. Preserve existing FR numbers and all accepted task evidence.
5. Include source SHA, test receipts, reviewer provenance and status distinctions in reports.
6. Before claiming complete specification mapping, execute OpenSpec strict and the repaired crosswalk against the same immutable revision.
7. Any normative change after current approval follows foreground owner exact-plan approval; this report cannot override it.

See docs/SPEC_TRACEABILITY_REMEDIATION_2026-11-02.md for the detailed step-by-step plan.

## 7. Work packages and ownership (proposed, no live P IDs)

| Proposed package | Detailed design input | Output | External gate |
| --- | --- | --- | --- |
| V3-A | spec parser false positives + 56 coverage gaps | exact gap ledger and reviewed mapping proposal | owner approval before normative edits |
| V3-B | P085 actor/tool privilege inventory | host boundary and red-team design | host owner/release approval |
| V3-C | responsibility/reuse contracts | conflict/clone/API test fixtures | independent review |
| V3-D | task transaction state and fencing | lease/replay invariant tests | approved coordinator migration if needed |
| V3-E | durable intent and recoverability | crash matrix with MergeIntent reuse | owner recovery workflow |
| V3-F | impact/read-only planner | deterministic graph + reason codes | existing change-impact request owner approval |
| V3-G | independent QA/negative witness | typed evidence and run classification | P085 host proof for privilege-related claims |
| V3-H | fair throughput/watchdog | bounded scheduler fixture experiment | owner-approved queue admissions only |
| V3-I | observed-run/token telemetry | coverage metrics and baseline | independent provider provenance |
| V3-J | Windows E2E/canary and rollback | release-ready evidence dossier | explicit owner release authorization |

Sequential critical path: V3-A + V3-B -> V3-D + V3-G -> V3-E -> V3-J. V3-C, V3-F, V3-H, V3-I can progress independently in read-only/disposable fixtures, subject to owner approved task leases. Do not infer that these proposed packages have assigned developer roles or queue IDs.

## 8. Integration phases and go/no-go

Stage 0 READ_ONLY: source inventory, decision log, exact current SHA, fake-positive gap proof, no changes.
Stage 1 FIXTURE_FIRST: isolated SQLite, static graph and parser regression, no host privileges or external effects.
Stage 2 VERIFIED_QA: independent test execution; input hashes and known-negative regression; no release claims.
Stage 3 TRUSTED_HOST: owner-approved host grant wiring, all privileged entrypoints denied by default, real Windows E2E.
Stage 4 CONTROLLED_CANARY: owner-approved small scoped task, measured useful output, stable source receipt and deliberate rollback injection.
Stage 5 BROADER_ADOPTION: only if 64-case coverage is adjudicated, all applicable high-severity negatives pass, zero known unsafe bypass and explicit owner release.

No-go if any one of:
- actual host allows an unauthorized mutation through broad script/command;
- reviewer can accept self-authored work using model-supplied role;
- known critical witness current SHA ignored;
- partial file promotion falsely accepted;
- missing/unknown source/hash incorrectly treated as PASS;
- task cross-owner collision not blocked;
- failed recovery performs an ambiguous external write twice;
- owner approval cannot be tied to exact canonical spec/action digest;
- test or spec output misleadingly claims measured ChatGPT tokens or guaranteed 60-minute execution;
- mandatory QA is silently skipped by a risk score or cache.

## 9. Required independent review questions

R-01 Which current source module owns each behavior? Have we accidentally built a second coordinator, grant service, reviewer or graph checker?
R-02 Are the real connection actor and OS capabilities enforced at the actual host, not just helper Python?
R-03 What irreversible effect can happen, and is it safely idempotent or reconciled?
R-04 What precise SHA and environment did each test examine?
R-05 Can a reviewer/agent manipulate the evidence verifier in the same trust domain?
R-06 Can source or spec drift after a green preview?
R-07 Does a lease conflict race preserve exactly one owner?
R-08 Are code and responsibility overlap checked beyond file paths?
R-09 Is any security-critical dynamic dependency reported UNKNOWN rather than safe?
R-10 Does the planner stop honestly when no legal work remains?
R-11 Are historical accepted records preserved, not rewritten to satisfy new tests?
R-12 Can rollback preserve unrelated user changes and recover journal uncertainty?

## 10. Final completion worksheet

For each of S3-01..16:
- [ ] Associated owner-approved OpenSpec requirement and SDD FR ID are known.
- [ ] At least one accepted, scoped implementation task references the FR.
- [ ] Each of four catalog test IDs has actual evidence or explicit NOT_RUN with reason.
- [ ] Current source/spec/test digests match evidence.
- [ ] Required negative cases have independent executed witnesses.
- [ ] Host privilege claims, where relevant, are proven at the actual host.
- [ ] Independent reviewer has verified separation from authors.
- [ ] Relevant current release gates and owner decision are documented.
- [ ] No unresolved critical findings for that exact source.
- [ ] Rollback/recovery has evidence at this exact revision.

The present state of this worksheet is **all unchecked**. This is intentional: documents and planned test cases are not completed implementation evidence.