# P085 — независимая негативная проверка типов доверенного состояния (02.11.2026)

## Границы проверки

Проверена только **локальная импортированная копия** `mcp-host-source/`. Работающий MCP на `127.0.0.1:8765`, туннель, live SQLite coordinator, пользовательские гранты, секреты, существующие leases и production server НЕ менялись. Код `review_grants.py` до этого шага не был подключён к доверенной аутентификации пяти ChatGPT-ролей; устранение дефекта офлайн-валидатора НЕ закрывает P085.

## Воспроизводимый дефект

В `workspace_mcp/review_grants.py::verify` до изменения проверялся экземпляр `ReviewTarget`, но **не проверялись фактические runtime-типы его полей**. Аннотации frozen dataclass не запрещают `review_lease_active="true"`, `merge_intent_pending=0`, `revision=4.0` или `author_actor_id=None`. Python truthiness/equality могла пропускать некорректный вход как приемлемый target snapshot.

Прямой синтетический тест `experiments/p085_grant_negative_20261102/test_untrusted_target_fail_closed.py` воспроизвёл **14 отказов отрицательных утверждений**: исходный валидатор возвращал нормальный результат, когда должен был выдавать `GrantDenied`. Это воспроизведение границы проверки входных значений, **не доказанный реальный privilege escalation**: корректный отдельный trusted-host может гарантировать типы до вызова, но defense-in-depth обязана отвергать испорченные snapshots.

## Исправление

В `mcp-host-source/workspace_mcp/review_grants.py` добавлена строго типизированная валидация всех полей `ReviewTarget` до проверки scope/replay: identity/workspace/task strings с установленными patterns, строго целочисленная revision, SHA-256, **строго bool** для признаков review lease и merge intent, обязательный валидный author actor ID.

- Новый SHA `review_grants.py`: `61338db7deeb00202009492242f42bd2bf9ffeba60089e6b5410c3526b7c44c4` на момент изменения; исходный SHA для CAS: `765bb0fb0293347ec19ab1af8d952ba7975ab66709947f57a135001c3b106508`.
- Добавлен изолированный негативный witness: `experiments/p085_grant_negative_20261102/test_untrusted_target_fail_closed.py`.
- Добавлен компактный test в импортированный host suite: `mcp-host-source/tests/test_p085_target_type_regression.py`; регрессия проверяет 14 повреждённых snapshot-значений через существующие fixture.

## Проверки (фактически выполненные)

| Проверка | Результат |
|---|---|
| Independent negative witness | 5 unittest methods, **PASS**, Local Workspace job `3ef49567f1544ffda15b5a31f6742963`, rc=0 |
| Mirror `python -m unittest discover -s tests -q` | **55 tests, 1 skipped, 0 fail**, job `4df7ade16ac845288a36c5c3dc4b3504`, rc=0 |
| `ops.py spec_validate Local-Workspace-Extensions add-agent-foundation-hardening` | **OpenSpec strict PASS**, 12 FR / 36 scenarios / 12 mappings, job `e95ea6aafc504153a77899e51e8efe33`, rc=0 |

Конкурирующая работа над observer HTTP gate была обнаружена по меняющимся SHA и **не перезаписывалась**. На момент повторной проверки `make_handler` уже вызывает `registry.assert_safe_http_profile()`, а tests/negative-cases реализованы другим исполнителем. Все наши изменения ограничены отдельным `review_grants.py` со строгим SHA-CAS и двумя уникальными тестовыми файлами; их проверка не является производственным выпуском.

## До закрытия P085

1. Доверенная аутентификация и разграничение доступа должны выполняться **в отдельном защищённом OS principal/host broker**, а не через клиентскую строку `role`.
2. Реальная reviewer authorization требует полноценного Windows ACL/SID, grant issuer с отзывом, replay recovery, авторитетного snapshot статуса/author и запрета универсальных privileged runners.
3. Перед production rollout — независимые Windows cross-user E2E, отказ при spoof/replay/stale state, backup/rollback и отдельное согласование владельца. Не подменять работающий сервер из чата.
