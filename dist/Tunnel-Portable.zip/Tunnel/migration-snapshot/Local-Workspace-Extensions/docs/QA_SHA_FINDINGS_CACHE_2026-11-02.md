# SHA-bound negative QA + bounded source normalization cache (2026-11-02)

**Implemented in Local-Workspace-Extensions. Non-normative implementation evidence; no spec, queue, or privileged reviewer transition was executed.**

## Actual change

- `review_findings_registry.py` contains three curated negative QA findings for P152, P153 and P159, fixed to the **actual** candidate source SHA-256 and the SHA-256 of the independent architect evidence report `.agent-team/reports/architect_independent_QA_20261102T1515Z.md`. It loads no candidate modules, uses only bounded regular-file byte reads and refuses linked and unsafe paths.
- `review_readiness_matrix.py` checks that evidence as a **separate advisory gate**. Matching SHA yields `BLOCKED_KNOWN_NEGATIVE_QA`; changed candidate or evidence SHA yields `FINDING_REVERIFICATION_REQUIRED`. No catalogued evidence is `NO_CATALOGUED_FINDING`, never a QA pass.
- `code_reuse_guard.py` uses a small, process-local LRU (96 normalized main-source entries; maximum ~96 KiB text per entry). The current source is read and bounded on **every** audit; cache keys include complete source contents and module name, not mtime/size or developer assertions. Candidate modules are never stored in this main-source cache. This speeds repeated read-only queue preview operations while preserving direct accept-time AST clone checks against current bytes. Nothing is written to disk and no previously green QA is reused.
- `agent_reuse_ci_gate.py` now runs the negative-evidence/matrix/cache test suites in addition to the existing owner/reuse regressions.

## Verified evidence

- Real queue after changes: **17** `READY_FOR_INDEPENDENT_QA`, **3** `BLOCKED_KNOWN_NEGATIVE_QA` (P152, P153, P159), **1** `EXPIRED_LEASE_REACQUISITION_REQUIRED` (P111). `remaining_uninspected=0`. Those 17 are not approved; separate negative tests can still reveal issues.
- `test_review_findings_registry.py`: 10 tests, 1 skip, pass. No untrusted candidate executed.
- `test_reuse_cache_invalidation.py`: 6 tests pass. Includes cached exact duplicate detection, changed source with **same size and spoofed mtime** invalidation, new clone after clean scan, syntax failure and no disk writes.
- `test_code_reuse_guard.py`: 26 tests, 1 skip, pass. Legacy oversized-source error contract preserved after fixing an initial test failure.
- `agent_reuse_ci_gate.py`: PASS; core 163 tests (5 skipped), contract 19 (1 skipped), import-graph 10 (1 skipped); canonical clone baseline scanned 93 modules/404 eligible functions, 0 hard cross-module matches and 0 near matches.
- `agent_team.py gate-check`: 1462 tests (37 skipped), `spec_check` exit 0, `openspec validate local-pc-agent-tooling --strict` exit 0.
- Matrix wall-clock on the same host: one pre-cache invocation 38.5s, two observed post-cache invocations 3.67s and 16.24s. **Not controlled**: simultaneous MCP jobs and filesystem state can differ; do not claim deterministic improvement or extrapolate a guaranteed speedup. The LRU hit/invalidation regression is deterministic.

## Trust boundary and limitations

- The evidence report and source files are local; their SHA match guarantees byte equality with previously reviewed material, NOT independently authenticated review actor identity. P085 remains open.
- The negative finding registry is deliberately conservative and **advisory**: it does not change `agent_team.review accept/reject`, authorize an actor or bypass independent review; formal accept code still requires the canonical authority and checks.
- Cataloguing only three reproducible critical issues does not imply every other submitted task is free of defects; more evidence must be curated after independent review. A changed SHA must be retested, and a now-redacted or missing report must never silently become a clean PASS.
- Cache is in-memory only, intentionally lost at restart; no unsafe cross-invocation persistent success cache. Source snapshots may drift between a read-only matrix and subsequent action; final reviewer must recheck SHA and QA at the transactional boundary.
- No host identity, merge intent, live lease, owner approval, candidate sandbox or parent Git was altered.

## Next safe work

1. Expand curated SHA findings through independent human-reviewed structured evidence, without inferring positive QA from absence of findings.
2. Host-enforce P085 trusted reviewer grants before enabling autonomous formal accept/reject.
3. Introduce WIP/backpressure and dependency-aware formal review scheduling via separately owner-approved OpenSpec/SDD. Benchmark end-to-end accepted throughput before claiming optimization.
