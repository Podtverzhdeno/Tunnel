# MCP `server/discover` HTTP 400 — подтверждённая причина и исправление (06.11.2026)

## Фактический диагноз
Tunnel Client v0.0.19 доставляет RPC `server/discover` до локального MCP. Логи показывают `upstream_status=400` от `target_http`, а не ошибку транспорта. Прямой read-only запрос на `127.0.0.1:8765/mcp` (job `59b6413e899142c480c1cef354762fa5`, rc0) вернул:
- Legacy `initialize` version `2025-11-25`: HTTP 200.
- Modern `server/discover` version `2026-07-28`: HTTP 400, `Unsupported MCP protocol version`.
- Modern `tools/list`: HTTP 400, `Unsupported MCP protocol version`.

Прямая `GET /healthz` (job `4cc2531c44954605a95af2561f3cf725`, rc0) показывает 28 активных инструментов, тогда как защищённая ветка observer имеет 6. Поэтому автоматическая замена рабочего 28-tool сервера на 6-tool observer **не допускается**. Живой процесс во время этого изменения не перезапускался и не менялся.

Причина: существующий `http_server.py` распознавал только `2025-11-25 / 2025-06-18 / 2025-03-26`, а ChatGPT присылает stateless MCP `2026-07-28` с `server/discover`. Новая спецификация требует этот метод, per-request `_meta` и `Mcp-Method` / `Mcp-Name` заголовки.

Источники: 
- https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/server/discover.mdx
- https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/basic/versioning.mdx
- https://github.com/openai/tunnel-client/issues/41

## Изменения, уже внесённые в исходники
- `mcp-host-source/workspace_mcp/http_server.py`: поддержка современного `server/discover`, объявления версий, capabilities, private no-cache, метаданных сервера, modern `resultType=complete`, stateless `tools/list`/`tools/call`; строгая проверка обязательной метаинформации, версии и заголовков, fail-closed RPC ошибки `-32020`/`-32022`. Legacy initialize и tools остались доступными. Bearer authorization и фиксированный observer профиль не ослаблены.
- `mcp-host-source/tests/test_mcp_discovery_20261106.py`: новые HTTP регрессии. ПЕРЕД правкой: job `dc15b03732224883bc5969443d97bdcb`, rc1, modern discovery returned 400. ПОСЛЕ: job `0048adc79c734ab998bb5cd5d0eb312b`, rc0, 5/5 PASS.
- Legacy HTTP tests `test_http.py`: job `f936630ee62f4d64a5a16ab7df47d4e3`, rc0, 6/6 PASS.
- Full observer host test suite: job `59185bf93b374cdeb67e564802496ae1`, rc0, 240 tests / 6 skipped / 0 failures.

## Для текущего (28-tool) живого сервера
- `host_patches/http_server_2026_discovery_legacy28_candidate_v3.py`: отдельная *не установленная* кандидатная реализация, собранная из неизменённого baseline `host_snapshot/http_server.py` с SHA `00c663880d581a3aeb47d7028c443ef603f33b517b4ffdb4d84c4c51e1dd1491`; сохранены исходный registry, количество инструментов, существующие методы и исходное поведение авторизации. Кандидат SHA `8a81907ff4d0aaf25bdc061949f6c365ef5afeb406865c67086eef51a2d61585`.
- `host_patches/test_http_2026_legacy28_candidate.py`: job `dc1e4d8a517f497fbc554a21fdaf7b7a`, rc0, 6/6 PASS, *все 28 fake инструментов* остаются в `tools/list`, stateless discovery, method mismatch, legacy compatibility. Это mock тесты, не live-e2e.
- `apply_mcp_2026_compat_owner_only.py`: owner-only manual installer. Требует путь к активному `workspace_mcp/http_server.py`, точный baseline SHA, делает backup, проверяет кандидат и отсутствие слушателя 8765. Без флага `--apply` только план. Не может по ошибке заменить защищённую observer сборку, иной исходник или активный процесс.
- `test_apply_mcp_2026_compat_owner_only.py`: job `dbfc6e20b314461f874a6799df42d195`, rc0, 5/5 PASS (offline mocks, backup, idempotency, live-listener guard, wrong SHA and path).

## Безопасное применение владельцем (не выполнялось)
1. В собственном Windows Terminal остановить новые MCP-задачи, дождаться текущих jobs, остановить Tunnel Client и активный Local MCP Server.
2. Найти *фактический* путь активного модуля `workspace_mcp/http_server.py`. Не подставлять путь к `mcp-host-source` или `host_snapshot`, это не доказанные пути работающего сервера.
3. В корне `Local-Workspace-Extensions` выполнить read-only preflight:
   `python apply_mcp_2026_compat_owner_only.py --target "C:\\...\\workspace_mcp\\http_server.py"`
4. Только при `READY` и остановленном локальном слушателе выполнить тот же вызов с `--apply`. Скрипт сделает backup и атомарную замену с проверкой SHA. Если SHA отличается — **остановиться, не форсировать**.
5. Запустить Local MCP Server, затем Tunnel Client. Повторно проверить `server/discover` современным запросом: **HTTP 200**, `resultType=complete`, `supportedVersions` содержит `2026-07-28`. Затем `tools/list`, `tools/call` и подключение из ChatGPT Desktop.
6. Не перемещать bearer-токены, не обходить P085/trusted authorization и не перезапускать неизвестные/UNKNOWN очереди.

## Текущий статус
- **Доказанная причина / исходниковое исправление: ГОТОВО.**
- **Изолированные регрессии: PASS.**
- **Установка в фактический запущенный 28-tool хост и подтверждение через Tunnel ChatGPT: НЕ ВЫПОЛНЕНО.** Поскольку активный сервер отличается от patched observer source и перезапуск оборвёт MCP-сессии.
- Дополнительно: read-only legacy initialize в live endpoint ответил без Authorization. Укрепление конфигурации доступа требует отдельного согласованного cutover, не следует подменять им этот узкий compatibility fix.

## Перепроверка после перезапуска владельцем — 06.11.2026 (14:03 MSK)
Повторный Live RPC через реальный локальный `127.0.0.1:8765/mcp` (job `edb764725efa4c60a0f89ca5415e90b0`, rc0):
- Legacy `initialize` v2025: **HTTP 200**.
- Modern `server/discover` v2026-07-28: **HTTP 400**, `Unsupported MCP protocol version`.
- Modern `tools/list` v2026-07-28: **HTTP 400**, `Unsupported MCP protocol version`.
- `GET /healthz` (job `538e1c8c03144759ba6395418e4a96c1`, rc0) **HTTP 200, 28 tools, 1 workspace**.

**Итог: запущена старая копия 28-tool MCP HTTP handler, исправленная версия ещё не внедрена в фактический установленный сервер.** Новая стандартная версия подтверждена по официальной спецификации (https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/server/discover.mdx).

Новая диагностическая команда для установщика:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
py -3 .\apply_mcp_2026_compat_owner_only.py --check-live
```

Она осуществляет только read-only `server/discover` без пользовательских учётных данных и выводит `MODERN_DISCOVERY_READY` при HTTP 200 / современном корректном ответе, `LEGACY_OR_INCOMPATIBLE` при HTTP 400 или `AUTH_REQUIRED` при HTTP 401. Проверки: job `573cfa128b624243a3fa951d71e70243`, **7/7 PASS**; read-only live check job `05f956835b4f46798a711566a81ae945`, **HTTP 400 / LEGACY_OR_INCOMPATIBLE**.

Для применения из **собственного терминала Windows** (не через MCP) сначала определить реальный путь установки. В предыдущей конфигурации использовался `$HOME\Downloads\local-workspace-mcp`, но его актуальность не подтверждена; не считать его установленным без проверки. Пример предварительного шага:

```powershell
$target = Join-Path $HOME "Downloads\local-workspace-mcp\workspace_mcp\http_server.py"
Test-Path $target
py -3 .\apply_mcp_2026_compat_owner_only.py --target $target
```

Только если `plan` сообщает `READY`, остановить Tunnel Client и Local MCP Server, дождаться остановки слушателя 8765 и выполнить:

```powershell
py -3 .\apply_mcp_2026_compat_owner_only.py --target $target --apply
```

Скрипт проверяет SHA текущего файла, сохраняет резервную копию и не изменяет активный сервер. Затем владелец запускает Local MCP Server и Tunnel Client снова; проверка `--check-live` должна вернуть `MODERN_DISCOVERY_READY` (либо `AUTH_REQUIRED` при защищённой схеме, где для проверки нужен авторизованный клиент). Если `Test-Path` ложно или `SHA_MISMATCH`, **не применять исправление силой**: значит, фактическая копия хоста отличается от аудированного исходника, требуется отдельное сравнение.

Рабочий каталог MCP ограничен `projects`; у модели нет подтверждённого права заменять установленный хост за пределами этого workspace. Живой процесс не останавливался и не заменялся.

