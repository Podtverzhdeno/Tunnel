# P085 staged-code SID review, installer contract and diagnostic repin — 2026-11-04

## Scope
Through Local Workspace MCP `projects`; source review, hermetic unit QA, read-only diagnostics only. No elevated PowerShell, UAC, local account creation, Windows ACL or service mutation, broker grant, protected staging, live queue/browser change, external owner assertion, Chain2 ACK fabrication, Chain3 activation or Git operation.

## Security review
- Audited `p085_stage_audit.py` (13 pinned code files, staged code/private-state directory ACLs, role SIDs, stage receipt). The recent source change admits Windows Administrators **read-and-execute** on sealed code and its directories, matching the owner-only installer; it continues to reject administrator write and reviewer/worker read/write through allowlist ACL checks. Basic deny/unsupported ACEs and unknown SID data-read scopes remain blocked.
- During review, a broader P085 unit run initially FAILED **12** negative SID subcases. Root cause: distinct well-known/group/service SID values could satisfy the receipt's prior SID syntax/distinctness checks. Concurrent local work updated the staged receipt checker with a syntactic `LOCAL_USER_SID` shape constraint (S-1-5-21 machine/domain components plus RID) and the test fixtures. The result is fail-closed for built-in Administrator group, LocalService, NetworkService and service SID values, but the checker **cannot independently prove an account is actually local/non-admin**. A source-only regex can never provide that attestation.
- Inspected the updated owner-only `Install-P085ProtectedService.ps1` routine `Assert-LocalNonAdminPrincipal`: it uses Windows `Get-LocalUser` to match the SID, checks group membership against `S-1-5-32-544`, and is invoked for service/reviewer/worker principals. Still not executed via MCP; production trust needs actual owner-supervised independent OS E2E.
- The SHA-inventory matrix blocked correctly with `SOURCE_DEPENDENCY_SHA_DRIFT` until stage source review/tests. Updated only the pinned `p085_stage_audit.py` SHA after source and local test inspection; owner authorization remains false.
- Found a separate **diagnostic status contract** defect: `p085_stage_audit.inspect_staged_package()` emits `BLOCKED` for rejected stage, but the matrix's stage allowlist considered `BLOCKED` unrecognized while accepting obsolete values. Aligned `_ALLOWED_STAGE` to the four emitted values (`NOT_STAGED`, `STRUCTURE_AND_ACL_OBSERVED`, `UNTRUSTED_LOCATION`, `BLOCKED`) and added `P085_STAGE_AUDIT_BLOCKED` for known fail-closed stage failures. Unknown values still generate `UNRECOGNIZED_STAGE_STATUS`. Added two tests ensuring neither case grants permission or exposes untrusted details.

## Source SHA256 after review
- `Local-Workspace-Extensions/p085_stage_audit.py`: `4b6a3b75bd2d1cabc3c116716056382e243457e74899255d4a58009fe063ea84`
- `Local-Workspace-Extensions/test_p085_stage_audit.py`: `8bf3ce78857d6b6552009948f7ac014ea82fbf349b5a8ff0e459dc046332eb7e`
- `Local-Workspace-Extensions/Install-P085ProtectedService.ps1`: `b2bdac792998f4e083f9d1e6f262e2a18b96f53c2662a160c106dd8a4322e709`
- `Local-Workspace-Extensions/test_p085_installer_source.py`: `4e69d32319a8b732ddcdd1ed2c041405e1a68b3ccd7f14f8b637db3e137a4697`
- `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py`: `e042974b7f20d052a7c08801cac98285bba6e91bef51aeb62924b353f4acb537`
- `chat-launch-smoke-desktop-test/web-companion/test_p085_readiness_matrix.py`: `f72d87ef6abc5c95a7719a072dfd26bfd8b1fed6ecbb8355aafbcd5aa48980fc`

## Test and runtime evidence
- P085 broad pre-fix `44d83a74dd3e41428c53445441f13079`: completed returncode=1, 135 run, **12 failures**, 6 skipped; exposed missing role-SID syntax check. (A subsequent focused stage run with tightened source but stale test fixtures also failed and was corrected through concurrent file updates.)
- `a9075af5604b498fb7e215e19d0885ea`: completed rc=0, stage audit **26 run, 24 PASS, 2 SKIP**.
- `2c18383811714a938aaf30dab58e55f5`: completed rc=0, installer source QA **10 PASS**.
- `b6d7ff8a0c0f48c9a1b0a8353f1821d1`: completed rc=0, P085 wide **135 run, 129 PASS, 6 SKIP**.
- `5d6316ab303548ee91f54b2ecb1cb751`: completed rc=0, deploy preflight **13 PASS**.
- `5bcdfc5f54064653bc1c5924b7088b1c`: completed rc=0, matrix **25 PASS**, including new BLOCKED/unknown-state negative tests.
- `b1ca77ed84574de79b2b36b929759e51`: completed rc=0, full web-companion **246 run, 242 PASS, 4 SKIP**.
- Final read-only readiness matrix `6961d8adc1154993a6ef59e92f83e003`: completed rc=0, `ok=true`, `status=UNTRUSTED`, `stage_status=NOT_STAGED`, 0/5 OS principals configured, `can_activate_chain3=false`, `can_complete_chain2=false`, 7 pinned sources checked, and no account or service mutation.
- Chain3 preview `9744dbd71eca41f0b837384729a68118`: completed, `effective_mode=blocked`, `owner_armed=false`, `no_jobs_created=true`.
- Chain2 read-only dossier `c36862a57fa44bef8973d2efcdec582c`: completed, **9 ACTIVE**, split 4 closed-no-ACK / 4 pre-send-unconfirmed / 1 account-context-disputed. No automatic ACK, retry, send or queue mutation.

## Remaining release blockers
The current staged package is `NOT_STAGED`, the Python interpreter/source ACL trust is unverified, broker service is unprovisioned, 5 segregated local principal roles are missing, no independent 2-SID negative E2E or owner cutover occurred. A valid SHA of agent-editable code is not an OS-rooted trust anchor. Chain2's unresolved browser/account and original delivery receipts must be reconciled through authenticated original actors, not inferred from local JSON. Chain3 stays deliberately blocked.
