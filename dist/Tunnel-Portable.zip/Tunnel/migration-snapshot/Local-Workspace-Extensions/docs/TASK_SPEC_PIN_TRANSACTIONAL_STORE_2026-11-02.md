# Implementation checkpoint — transactional task-spec pin store (STAGED)

Date: 2026-11-02.
Project: C:\Users\user\IdeaProjects\Local-Workspace-Extensions.
Status: implemented and tested against an **isolated SQLite database using the real agent_team schema**. The active coordinator, its live SQLite database, registered scheduled agents, reviewer leases, task files, and P085 host permissions were NOT changed.

## Outcome

Two distinct, reusable components now exist.

- task_spec_pin_contract.py (unchanged): OpenSpec/SDD source receipt generation, read-only multi-task preview, pure check of source drift. Uses spec_traceability.audit_traceability rather than a second hash parser.
- task_spec_pin_store.py (new): SQLite **transaction adapter** for explicit, owner-controlled migration and future seed/acquire/review integration. It is not wired into agent_team.py and cannot be treated as an active host authorization boundary.

### Functions delivered

1. initialize_pin_store(db): creates a dedicated task_spec_pins table ONLY within the caller's existing SQLite transaction. Never calls COMMIT. Validates schema including exact columns, PK, NOT NULL and FK declaration. Rejects a same-name incompatible table.
2. stage_seed_pins(db, project, pins_by_task, expected_source_snapshot_sha256=...): requires the existing transaction and the task rows to be AVAILABLE, unclaimed, without sandbox or baseline. Re-reads and validates the full OpenSpec/SDD inventory **once** and compares with the earlier seed preview; verifies every per-task bound receipt and current task.spec_ref. Uses a unique nested SAVEPOINT to prevent partial receipts on a failed INSERT; never commits on behalf of the caller.
3. inspect_stored_pin(db, project, task_id, require_pin=False): read-only prospective gate for acquire/reviewer. Differentiates SPEC_PIN_CURRENT, SPEC_PIN_STALE, STORED_PIN_INVALID, PIN_SCHEMA_CONFLICT, LEGACY_UNPINNED and PIN_REQUIRED. Never grants a lease, acceptance or merger; host_authenticated=false; may_accept_or_lease=false.
4. Receipt JSON reads are bounded (8 KiB); unexpected malformed, oversized or shadow-view payloads fail closed. No exception or untrusted receipt contents are printed to the report.

**Important limitation:** stage_seed_pins cannot independently prove that an AVAILABLE unpinned row was created in the current transaction. The owner-approved coordinator seed call MUST provide only exact IDs whose own INSERT returned rowcount=1, while holding the same BEGIN IMMEDIATE lock. Passing legacy IDs is forbidden; this helper cannot authenticate who called it. The adapter does not acquire leases, insert jobs, revise task contracts or modify approval workflows.

## Integration sequence — code ownership and approval required

A. At seed admission, inside the coordinator's authoritative BEGIN IMMEDIATE transaction:

- Read the preexisting task IDs from the same SQLite connection.
- Invoke preview_seed_pins(project, incoming_tasks, existing_ids=...) once and verify its source scope.
- Validate existing seed policy / responsibility contracts, and perform ordinary INSERT OR IGNORE.
- Record the exact IDs whose INSERT cursor.rowcount is 1 (never infer newly inserted from AVAILABLE status).
- Call initialize_pin_store(db) for the owner-approved migration.
- Call stage_seed_pins(db, project, pins_for_exactly_those_inserted_ids, expected_source_snapshot_sha256=...) before COMMIT. A mismatch must trigger ROLLBACK of the WHOLE seed transaction, including new task rows.
- Do not backfill legacy tasks; the contract requires an explicit migration/review policy.

B. At developer acquire:

- Check the per-task durable receipt under the same coordinator lock before _snapshot, lease assignment or acquisition idempotency recording.
- A pinned task with SPEC_PIN_STALE/STORED_PIN_INVALID must not receive a lease. Continue scanning other eligible tasks, rather than blocking the entire team.
- Legacy tasks follow the separately approved compatibility policy, not implicit success of a missing receipt.
- Do not silently re-pin an already admitted job after source changes.

C. At reviewer preview and **direct review accept**:

- Include durable spec_snapshot_sha256 only after verifying source pin integrity and task binding.
- Freshly recheck the pin in the reviewer acceptance path independently of any advisory UI preview and in addition to existing __spec_sha__, responsibility and code-reuse checks.
- An unreadable/mismatching pin never becomes QA PASS. No escalation of reviewer or host permissions.

D. Explicit prerequisites for actual deployment:

- Owner-approved OpenSpec/SDD migration, separate artifact owner and code review of agent_team.py.
- Atomic introduction of the table and task receipt writer with backwards compatibility.
- Migration dry-run on a copied SQLite database, foreign key enforcement, crash/replay recovery, measured latency and mixed legacy/new-task behavior.
- Independent QA (including real Windows coordinator integration) and P085 host-authenticated authorization. These are NOT accomplished by this isolated adapter.

## Executed tests (all exit 0)

- python test_task_spec_pin_store.py: 22 tests passed, zero skipped.
- python -m unittest discover -p test_task*.py: 58 run, 2 skipped, zero failures (includes the 22 focused tests and the 17 original receipt tests).
- python -m unittest discover -p test_spec*.py: 113 run, 4 skipped.
- python -m unittest discover -p test_review*.py: 96 run, 2 skipped.
- python test_agent_team.py: 54 run, 1 skipped.
- python spec_check.py: 11 capabilities, 99 requirements, 128 scenarios, 43 FR mappings, zero structural errors.
- python sdd_roadmap_check.py: 58 tasks, zero structural errors.
- python ops.py spec_report Local-Workspace-Extensions local-pc-agent-tooling --strict: upstream validation reports valid, but separately reports 56 requirements missing FR mappings and 1 quality error. No release acceptance.
- python code_duplication_baseline.py (before final narrow hardening): 104 canonical modules, 460 substantial functions, zero structural clone groups; this is a heuristic not semantic proof.

Total nonoverlapping suites: 58 + 113 + 96 + 54 = **321 tests**, 9 skipped, zero failures. The focused tests overlap the 58.

## Source evidence (SHA-256)

- task_spec_pin_store.py: eace9a50b64b258ef153880682acc7d99e4717b32c9b5e828d45cd11801c126c
- test_task_spec_pin_store.py: 5630abc71c29b8d0906fe395b52d0d0d0a2a1a0ffe72bcc2429db1ba60918a7e
- task_spec_pin_contract.py (unchanged): 3858c76fbaa6d7e8f85f871b22745dfc061fe5cb7a06e89d33aca3ae9ff6f439
- agent_team.py (unchanged): cc4f91dbeb4a8bd9c7e766bcb9dc8fc6c66e55109ba2786fd2db86040291c866

## Threats and limitations (unresolved)

- SHA-256 payload is self-consistent but NOT host- or actor-authenticated, tamper-evident against unrestricted local admin, or authorized by reviewer.
- Filesystem snapshot/SQLite transaction are NOT atomic together; a specification can change after the final read. The future trusted acceptance gate must revalidate.
- The current coordinator defaults to PRAGMA journal_mode=WAL; the adapter records an FK declaration but does NOT enable SQLite PRAGMA foreign_keys=ON for arbitrary callers. Actual integration must enforce database integrity under trusted migration.
- Temporary tests do not prove Windows ACL/P085, signed agent identity, live queue recovery, E2E production results or acceptance receipts.
- This is an owner-reviewable implementation, not a command to run against .agent-team/team.sqlite3. Do NOT enable by bypassing the coordinator's formal owner approval.
