# Anti-idle execution policy — OpenSpec + SDD agent team

**State:** operational guidance 2026-11-01. This is NOT a new normative OpenSpec capability or host security grant; canonical specs, live SQLite queue and existing leases prevail.

## Implemented coordinator fix — 2026-11-02

**This supersedes historical P104–P107-specific examples below**, which remain as prior incident records only. It is now a working mechanism, not just a prompt policy. `agent_team.py acquire` skips a stale owned task when its main source/specification SHA no longer matches the saved sandbox baseline. `python agent_team.py plan-work developer-3` identifies ready independent tasks without mutating live tasks. At the time of implementation it recommends **P110** while obsolete **P096** remains separately owned/blocked. In an authorized developer-3 scheduled invocation, issue a **fresh** idempotency request and `python agent_team.py acquire developer-3 <fresh-request-id> --task P110`. The coordinator atomically rechecks eligibility, returns an independent task lease and leaves P096 untouched. No legitimate host actor grant is created by the tool's caller-supplied role string. Read `docs/AGENT_NONBLOCKING_SCHEDULER.md` and current OpenSpec before changing files. Lost active lease tokens cannot be force-recovered without trusted host identity; unrelated tasks can nevertheless proceed.

## Purpose and invariants

A task-level blocker must not become a role-wide blocker when the same role has a separately authorized, independent task. Never turn productive work into repeatedly describing the same blocker. Never turn this policy into a bypass of lease fencing, owner consent, review, file permissions, source SHA, task dependencies or security restrictions.

**Example (current):** `P096` has expired lease, stale canonical source and high-risk `agent_team.py` deliverables. It requires an independent reviewer/rebase/supersession decision; do NOT submit or merge it. `P106` is a distinct accepted-to-queue offline diagnostics task (`team_recovery_diagnostics.py`, `test_team_recovery_diagnostics.py`) with **no dependency edge** to P096 in the machine-readable SDD roadmap and separate sandbox. P096's conflict must NOT prevent P106 implementation under P106's own valid current lease.

## Every developer invocation — safe-work selection algorithm

1. Read `AGENTS.md`, `docs/FIVE_AGENT_TEAM.md`, exact canonical OpenSpec and SDD, `agent_team.py overview`, `status --role ROLE`, and `history TASK_ID` for previous work. Do not rely on stale chat text.
2. Identify all tasks currently owned by the role and their independent output sets. Classify each:
   - `EXECUTABLE`: current spec, authorized role and paths, no blocking dependencies/merge intent, valid lease actually available.
   - `BLOCKED_LOCAL`: one task has stale source, missing dependency, reviewer approval, failure, unsuitable environment or a revoked/expired lease. Write precise reason; do not modify the blocked task without valid authorization.
   - `BLOCKED_GLOBAL`: real host permissions absent for privileged effects, or shared resources cannot be safely isolated. Continue only permitted read-only or independently isolated task work.
   - `REVIEW_WAIT`: submitted to reviewer; do not self-review.
3. **Prefer task-specific corrective work** if it can be completed lawfully inside the task's allowed outputs and active lease. Otherwise choose another `EXECUTABLE` task with no overlapping deliverables and no dependency edge to the blocked item. Existing reviewer-approved queue assignment beats freeform initiative.
4. For a task that is `working` with a live lease **but the current run has no lease token**, never guess/reuse a token or bypass it. Perform bounded read-only preparation: inspect exact spec and own candidate for defects, outline test cases, record a local plan only where permitted. Resume mutation after legitimate fenced reacquisition/renewal. Do not claim that read-only work is completed code.
5. For `available` tasks, use one new stable request ID and `acquire ROLE REQUEST_ID`; for tasks previously owned and recoverable, follow existing queue's legitimate expiration/reacquire semantics. If `acquire` returns null, explicitly diagnose *why* before reporting idle; do not invent tasks or manipulate SQLite.
6. On every completed implementation step, run nominal and adversarial tests, persist only factual `agent_progress.json` via `checkpoint-file` while lease active, and submit with actual evidence. Other tasks' checkpoints are not authorization to overwrite their files.
7. When no executable task exists, produce useful **read-only** work: compare current spec vs backlog, analyze rejection/incident, identify ready independent tasks with canonical spec mapping, prepare a scoped task recommendation, or run non-mutating diagnostic checks. Developer cannot seed unapproved tasks; only architect-reviewer coordinates queue changes under existing gates.
8. The reviewer independently resolves blocked-task decisions and environmental test-contract defects; never recommends bypassing negative tests or merging stale code. Return precise next action and owner. Disallow speculative auto-merges.
9. Report `task_id`, `status`, `blocker_scope` (`local|global|review`), `alternative_task`, changed files and hashes, executed tests, `lease_status`, `next_action`. `no_safe_work` is an acceptable result **only when** the queue truly has no independent authorized work.

## Specific instructions for current wave

- **Developer-3:** inspect P096 only to document/referral its stale-code danger. Work on P106 independently, if P106's **own** lease is valid and the run holds the matching token; do not change, submit or merge P096. Under P106 implement read-only recovery/lease incident diagnostics, negative tests, checkpoint and independent reviewer submission. If lease lost, keep preparation read-only and hand off exact next steps; do not wait for P096 merely because it is still `working`.
- **Developer-4:** continue P107 within own sandbox. The full-suite failure caused by missing `team_seed.json` is a shared snapshot/test fixture issue; seek an authorized fixture/snapshot correction without editing non-deliverables or suppressing tests. Independently fix only P107's own test/code defects and rerun all required gates.
- **Developers 1 and 2:** continue P104/P105 respectively and prefer local fixes; if blocked, same task-local vs role-global classification applies.
- **Architect Reviewer:** never claim P096 and P106 are sequential unless an actual DAG edge exists. Resolve P096 source drift and P107 sandbox fixture independently. Keep P104–P107 in their assigned ownership, review submitted candidates, and propose the next safe wave after canonical requirement/dependency checks.

## Anti-idle acceptance cases

A. Given an expired/stale P096 and an independently authorized P106 with its own current lease, when Developer-3 starts a run, then it works on P106 without waiting for P096, while leaving P096 unmerged.

B. Given P106 working but the run lacks its active lease token, when Developer-3 restarts, then it does not call submit/checkpoint under an invented token; it performs only bounded read-only preflight or waits for legitimate reacquisition.

C. Given P107 test fixture failure outside assigned deliverables, when Developer-4 encounters it, then it flags an infrastructure blocker and continues focused allowed tests or independently executable work; it does not patch the core fixture behind the review gate or label full-suite PASS.

D. Given no valid role-appropriate tasks, then agent reports `no_safe_work` with queue blockers and proposes a reviewer action; it does not create fake implementation progress.

E. Given a source/version/hash conflict or real MCP host authorization failure, then no alternative task is admitted with overlapping outputs, unauthorized effects, or missing security grants.

## Future implementation (not yet shipped)

- Versioned DAG-aware queue admission/park-unpark state and task-local `blocked_reason` stored transactionally; separate `blocked` from `available` and `working` without corrupting existing leases.
- Bounded fallback selection with fairness, priority, output conflict detection and a permanent audit trail for each switch.
- Tests for duplicate leases, starvation, role impersonation, cycle, stale SHA, crash while parking, multi-task same role and mock/live distinction.
- Independent host actor grants and OS-level isolation (P085) required before enforcing any privileged action.

**No claim:** This policy changes agents' runbook and scheduled instructions. It does not by itself implement a transactional queue parking API, independent Windows sandbox, or production permissions.
