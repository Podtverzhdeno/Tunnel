# Owner handoff: revive four idle coding agents (2026-11-02)

Read-only evidence verified through Local Workspace MCP. This file is not an owner authorization receipt and does not change the canonical queue.

## Exact QA-backed reserve task proposal

- **P150 / developer-1:** `mcp_trace_coverage_audit.py` and tests; observability-recovery / Local trace correlation; depends on independently accepted P104.
- **P151 / developer-2:** `usage_calibration_evidence.py` and tests; agent-orchestration / Per-agent provider-reported LLM token accounting; depends on P105.
- **P152 / developer-3:** `mcp_trace_failure_cases.py` and tests; observability-recovery / Failure-injection tests; depends on P106.
- **P153 / developer-4:** `mcp_trace_retention_plan.py` and tests; observability-recovery / Metrics and retention; depends on P107.

Live preview: `ready_ids=["P150","P151","P152","P153"]`, `blocked=[]`. No tasks admitted yet. `owner_action_packet.py` verifies plan/hash consistency without writes, and unit tests include tamper detection, malformed or duplicate IDs, safe command construction and no synthetic owner grant.

Canonical seed currently SHA256: `705343afee3f9a159a1f490e3d115620b8b541265d74b2bf5a255b581430fd15`.
Proposed seed SHA256: `985c4e122246429574031621e51d20d5443e052b68aa63065c779258ea2d2f87`.
Candidate pool SHA256: `5be852edbb8bdcef74e0414dda3d460098276bb141aebd3afc77ca12be3da601`.
Current expected plan ID: `985c4e1222464295` (must re-preview before action).

## Owner's ONLY foreground step — do not execute through MCP/ChatGPT scheduled jobs

Open an interactive user-owned PowerShell on the PC, not a ChatGPT MCP execution:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python .\experiments\chat_only_run\owner_action_packet.py
python .\experiments\chat_only_run\owner_queue_admit.py --apply --plan-id 985c4e1222464295
```

Confirm exact scope P150,P151,P152,P153, and only if the unchanged SHA and task scope remain correct, TYPE exactly `ADMIT 985c4e1222464295` at the program's prompt. If refreshed plan ID changed, STOP and re-preview; do not blindly retry an interrupted apply. A pending admission marker after failure requires manual reconciliation. The foreground action uses atomic backups, CAS preconditions and new-task seeding.

After the owner step:
```powershell
python agent_team.py overview
python agent_team.py plan-work developer-1
python agent_team.py plan-work developer-2
python agent_team.py plan-work developer-3
python agent_team.py plan-work developer-4
```
Then the four already-enabled scheduled chat developer automations will obtain their own fresh legal task leases, do full QA and guarded `quality_submit.py`. They must NEVER infer authorization from this markdown file or use an old token.

## Important independent blocker

P085 (trusted host identity / reviewer grants) remains UNRESOLVED. Admitting safe new coding tasks does **not** authorize formal `review accept/reject`, merge or deployment for the nine existing review candidates. The Architect Reviewer should separately resolve the trusted host-side authorization and decide lawful rework transitions. This is deliberately distinct from owner approval of new reserve tasks.

## Additional reproducible quality work

P111 untrusted-text Git global options defect has a proposed read-only test laboratory at `experiments/chat_only_run/P111_git_options_lab.py`. It now passes 58 tests in a disposable copy, including five new scenarios involving `git -C`, `git -c`, benign `status` and negated documentation. Original P111 sandbox and main SQLite are untouched. The candidate owner must obtain a fresh authorized rework lease before incorporating this proposal, run all QA, and submit through guarded entrypoint.
