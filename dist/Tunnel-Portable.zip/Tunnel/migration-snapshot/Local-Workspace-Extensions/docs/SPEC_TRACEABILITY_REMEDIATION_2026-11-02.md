# Spec audit — false-positive task links and real OpenSpec/SDD gaps

**Date:** 2026-11-02. **Status:** read-only inspection + NON-NORMATIVE remediation proposal; no canonical file edits and no automatic acceptance.

## Executive findings

The existing source analyzer `spec_analyzer.py` returned **27 error entries** for the canonical `local-pc-agent-tooling` change, while `openspec validate --strict` still returned valid. These are *different checks*: OpenSpec checks syntactic/structural validity, whereas the analyzer tries to establish complete OpenSpec ↔ SDD ↔ task coverage.

**Important: 26 of the 27 reported errors are currently false positives.** The implementation at `spec_analyzer.py:142-144` searches for the exact substring `[FR-001]` and therefore misses legitimate multi-reference task syntax such as `T004 [FR-001,FR-002]`. An independent read-only scan of all 43 FR IDs from `specs/001-local-pc-agent-tooling/spec.md` against `specs/001-local-pc-agent-tooling/tasks.md` found **0 FR IDs absent as whole tokens**; 26 were incorrectly flagged by the exact substring check. This is a reproducible parser defect, *not* permission to mark 26 tasks complete.

**The remaining reported error identifies a genuine specification coverage gap:** 99 OpenSpec requirements, but only 43 unique existing SDD FR mappings. All 43 mappings refer to known OpenSpec capability/requirement pairs (no unknown-reference error in the report), so **56 OpenSpec requirements lack explicit SDD FR rows**. The tool currently truncates this single aggregated `REQUIREMENT_WITHOUT_FR.references` list to 30 names without a coverage/count field; it is not correct to interpret the list as exactly 30 gaps.

Additional structural findings:
- `add-agent-code-reuse-governance`: 6 SHALL requirements / 12 scenarios / 6 FR mappings, OpenSpec strict valid, **three unresolved TBD decisions** in canonical `design.md`.
- `add-continuous-agent-work-loop`: 8 SHALL requirements / 13 scenarios / 8 FR mappings, OpenSpec strict valid, **three unresolved TBD decisions** in canonical `design.md`.
- `add-agent-foundation-hardening`: 12 requirements / 36 scenarios / 12 FR mappings, strict valid and 0 design placeholders; no unchecked implementation task is automatically satisfied.
- Keyword-based `NO_NEGATIVE_SCENARIO` messages are **advisories** and should be manually adjudicated; absence of a matching keyword is not proof that failure testing is absent.

## Prioritized remediation (proposed, not live tickets)

### SR-01 / P0 — Repair the FR task reference parser without changing task files

**Existing implementation owner:** `spec_analyzer.py` and `test_spec_analyzer.py`. Refactor its own parser; do **not** replace the entire SDD checker or create a parallel implementation.

**Required behavior:**
1. Parse checklist entries as typed task records, extract *all* `FR-\d{3}` tokens only from a well-formed task reference bracket, including `[FR-001,FR-002]`, `[FR-001, FR-002]` and tags like `[P] [FR-005,FR-006,FR-018]`.
2. Do not count FR mentions in unrelated explanations, test output, comments, future work or example code as implementation task linkage. Anchor to actual checklist `- [ ] Tnnn ...` or `- [x] Tnnn ...`.
3. Reject malformed task IDs, ambiguous multiple FR reference groups, duplicate task identifiers and references to undefined FRs with **distinct diagnostic codes**.
4. Distinguish `TASK_REFERENCE_PRESENT` from `TASK_ACCEPTED_WITH_EVIDENCE`; a checked Markdown box cannot imply implementation verification or owner acceptance.
5. Repro tests: all 43 known FRs map to a checklist task; an intentionally absent FR is reported; spurious FR mention in task body not accepted; grouped and singleton syntax both pass; boundary `FR-001` does not match `FR-0010`; Unicode/CRLF/Windows paths pass.
6. Preserve existing public API/response fields where possible, version any new fields, and verify no regression in established test fixtures.

**Exit:** False positives 26 -> 0 with no cheating via textual insertion of `[FR-xxx]` into unrelated descriptions. If previously unknown true missing references appear after strict parsing, report them individually.

### SR-02 / P0 — Complete the missing requirement ↔ FR mapping without spec inflation

**Current evidence:** 99 OpenSpec requirements, 43 SDD FR mappings, 56 gap entries. Do not add fake requirements purely to increase coverage.

**Required sequence:**
1. Produce a *full* deterministic mapping report for all missing `capability/name` pairs with `total_missing`, `reported`, `truncated`, and exact source SHA; do not silently cap to 30.
2. Classify each of 56 gaps by independently reviewing canonical source:
   - `ADD_FR` — substantive independent behavior lacking an FR (new approval needed);
   - `LINK_EQUIVALENT` — provably same normative behavior already covered by an FR; explicit reviewed mapping, not string similarity;
   - `RETIRED_OR_MOVED` — genuine superseded behavior with owner-approved spec change;
   - `SPLIT_OR_MERGE_REQUIRED` — composite requirement needing reviewed restructuring;
   - `BLOCKED_UNKNOWN` — insufficient evidence or authority.
3. Protect FR identity and downstream references: do not renumber existing FR-001..FR-043. Allocate new IDs only by the canonical approved SDD workflow with collision detection and source revision pinning.
4. For each new/relinked FR, specify at least one corresponding implementation task and *negative* acceptance scenario, plus source, tests and reviewer evidence if available.
5. Compare against `openspec/changes/add-agent-foundation-hardening`, code reuse governance, continuous-work-loop change and the 72-idea portfolio to avoid duplicate policy requirements.
6. A mapped requirement is **not** an implemented requirement: coverage, executed-test evidence, reviewer acceptance and host enforcement stay separate fields.
7. Run both structural crosswalk and independent negative QA under a stable revision; if any canonical source changed, reopen impact analysis and rebase.

**Exit:** All OpenSpec requirements have an explicit approved SDD relationship (or an explicit documented exception which is not falsely counted as mapped); no duplicate FR IDs; no unapproved production scope.

### SR-03 / P1 — Resolve the three design placeholders for code reuse governance

The existing owner-approved change has code/review evidence, but `design.md` still states:
- Architecture TBD;
- Decisions & alternatives TBD;
- Rollback TBD.

**Proposed content for owner-reviewed canonical design update:**
- Architecture: `task_reuse_preflight.py` inspects already-held responsibilities and accepted source inventory; `agent_responsibility_guard.py` identifies canonical owner conflicts and API/import boundaries; `code_reuse_guard.py` supplies conservative static clone signals; `agent_team.py` atomically enforces new-task-only ownership and independent review. Host identity remains P085. No semantic inference of equivalence and no migration of already active tasks without authority.
- Alternatives: (A) pure advisory prompt — weak, fail-open; (B) hard global file ownership by string — fast but conflates responsibility and path and breaks future refactor; (C) current hybrid of transactional ownership contract + static reuse/clone checks + independent review — preferred under negative fixtures.
- Rollback: disable/revert only new admissions rule via a separately approved, versioned policy change; preserve SQLite accepted history, grandfathered tasks and sealed reviewer receipts. Never delete or rewrite accepted state or overwrite another sandbox. Rollback requires one-way compatible schema and a migration fixture test.
- Resolution evidence: architecture boundary graph, two-agent same-module race, semantically different but AST-similar false-positive adjudication, API import cycle, dynamic import UNKNOWN, live lease preservation.

### SR-04 / P1 — Resolve the three design placeholders for continuous agent work loop

**Proposed content for owner-reviewed canonical design update:**
- Architecture: supervised *finite* work cycle driven by existing scheduled invocations and canonical lease/checkpoints: `load current spec -> list ready scoped tasks -> acquire legally -> execute bounded steps -> run independent QA -> submit with evidence -> re-check ready work -> peer-review/architect-support advisory -> stop on budget/platform boundary`. Each tool-effect has explicit approval/idempotency handling. No claim that a single chat can run for hours or that a prompt can bypass platform time limits.
- Alternatives: (A) long single invocation — unreliable and platform-limited; (B) recurring scheduled invocations with durable checkpoints and legal leases — preferred; (C) separate owner-operated always-on worker — possible future architecture requiring its own actual runtime, budget and host permissions, not another ChatGPT automation by assumption.
- Rollback: stop scheduled *new admissions* safely, let in-flight operations reach a checkpoint, preserve open leases/SQLite and unresolved intents for explicit recovery. Never auto-expire another worker's valid lease to unblock throughput.
- Resolution evidence: crash between intent/receipt, no work available, stale task isolated while independent work continues, expensive queue spin throttled, unknown provider limit, failure to reconnect, dropped tool result, stop when budget exhausted.

### SR-05 / P1 — Make spec quality reports truth-preserving

Extend **existing** `spec_analyzer.py` and `spec_check.py`, not another linter:
- `missing_fr_total`, `missing_fr_reported`, `missing_fr_truncated`, `fr_without_task_total` and `parse_errors_total` must be separate, with stable machine-readable error codes.
- Keep `strict_validation.valid`, `spec_structural_ready`, `implementation_verified`, `release_approved` independent; never conflate OpenSpec syntax passing with tested implementation.
- Add source SHAs, analyzer version, policy digest and exact SDD revision in the report; a stale report must not be actionable for release.
- Require a contradictory-evidence check: a negative QA witness for the exact current source hash overrides an advisory ready hint. This is a consumer of the existing QA registry, not a second one.
- Distinguish `missing`, `unknown`, `not-applicable` and `verified zero` for counts/coverage.

## Data source references inspected

- `spec_analyzer.py:115–144`: mismatch computation; `tasks` uses literal `f"[{fid}]" in tasks` and missing list caps at 30.
- `specs/001-local-pc-agent-tooling/spec.md`: 43 table FR rows.
- `specs/001-local-pc-agent-tooling/tasks.md`: multiple legitimate task refs like `T003 [FR-001,FR-021]`, `T004 [FR-001,FR-002]`, `T005 [FR-003,FR-004]`.
- `openspec/changes/add-agent-code-reuse-governance/design.md`: three unresolved TBD statements.
- `openspec/changes/add-continuous-agent-work-loop/design.md`: three unresolved TBD statements.
- `ops.py spec_report ... --strict`: observed 2026-11-02 results recorded above.

## Required gates before any canonical update

No silent direct edit of existing owner-approved OpenSpec/SDD. Prepare an exact diff, independently review mapping and source SHAs, obtain foreground owner approval of the normative change, then run strict OpenSpec, corrected crosswalk, actual test execution and independent review. Do not change the live SQLite queue, P085 host policy, accepted states or lease ownership from this design report.

**Current QA classification:** structural defects and report-parser defect identified; **not fixed in executable code** by this document. Changes listed here are a proposed implementation plan only.
