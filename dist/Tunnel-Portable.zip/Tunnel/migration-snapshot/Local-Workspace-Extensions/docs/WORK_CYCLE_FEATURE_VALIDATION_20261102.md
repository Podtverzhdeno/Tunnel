# Валидация четырёх приоритетных идей для возобновляемого рабочего цикла

Дата: 2026-11-02. **Статус:** независимая техническая оценка для owner-ready backlog; НЕ создание новой OpenSpec/SDD задачи, НЕ решение об одобрении, НЕ производственное внедрение.

## Ground truth

- Существующий `feature_idea_gate.py catalog`: все 4 × 10 = **40 портфелей-кандидатов валидированы по формальным полям** (волна `41c08590a4cb550b`); это НЕ означает, что гипотезы доказаны экспериментально.
- `feature_idea_gate.py architect`: проверены 40; выделены ровно 4 `PROMOTE_FOR_OWNER_SPEC_APPROVAL`. Это *проектные рекомендации*, без изменения live SQLite.
- Соблюдается уже существующая `openspec/changes/add-continuous-agent-work-loop`. Не строить второй параллельный supervisor и не пытаться увеличивать лимит платформы.
- Четыре идеи ниже основаны на фактических исходных предложениях и утверждённых **только архитектором к представлению владельцу** weighted_score. Не выдавать scores за измеренный ROI.

## Строгий порядок внедрения

| Порядок | ID | Идея | Architect score | Why / gate |
|---:|---|---|---:|---|
| 1 | developer-1:F07 | Контракт ошибок и безопасного повтора | **89/100** | Непроверенный `retryable` и потерянный результат опаснее простоя. Сначала offline classifier, затем только owner-approved policy изменения. |
| 2 | developer-2:F02 | Реестр критических `SKIP` по ОС и host-grants | **85/100** | Зелёный unittest с пропущенной Windows ACL/MCP host проверкой даёт ложный сигнал готовности. Только чтение QA receipts. |
| 3 | developer-2:F08 | Негативные доказательства отсутствия побочных эффектов | **85/100** | `0 events` нельзя объявлять `no writes` при неполном наблюдении. Нужна модель границ наблюдения. |
| 4 | developer-1:F03 | Канарейка совместимости MCP/CLI контрактов | **81/100** | Схемы ответов `job_status`, `job_output` и lease-событий изменяются независимо. Нужен строгий versioned fixture gate. |

## Что именно проверить прежде, чем писать продуктивный код

**F07 — Error taxonomy:** deterministic offline table of (operation_policy, dispatch_proof, provider_result, idempotency). Safety-critical default `OUTCOME_UNKNOWN/RECONCILE`; только подтверждённый pre-dispatch идемпотентный read-only 429 допустим в bounded-retry path. Минимум 100 фикстур ambiguous partial-commit с **нулём unsafe retries**; tests: duplicated replies, invalid UTF-8, timeout after execution, lost receipt, untrusted `retryable=true`. Не пытаться доказывать, что операция не выполнена, по одному сетевому exception.

**F02 — Critical SKIP ledger:** модель `test_id, os, source_sha256, critical_policy, skip_reason, job_exit`. Прогнать не менее 40 отрицательных фикстур: отсутствующие Windows junction/ACL и trusted-host-actor проверки должны давать `INCOMPLETE`, а не `PASS`; некритичные добровольные skip остаются видимыми. Цель: 0 false PASS, без внедрения в формальную приёмку до независимой QA.

**F08 — Negative-effect envelope:** `observer_id, coverage_scope, coverage_complete, source_sha, event_count`. `ABSENCE_PROVEN` допустимо только для заранее строго ограниченного scope с независимым полным наблюдением; все missing observers => `UNVERIFIED`; реальные видимые эффекты => `CONTRADICTED`. Не выдавать host-level аттестацию из локального Python.

**F03 — MCP/CLI schema canary:** матрица producer/consumer, проверка типов и отсутствующих safety-critical полей по явно версионированным JSON-фикстурам; 3 пары версий × 12 критических полей. Unknown major / missing `returncode` / unknown `DENIED` => fail closed, benign optional field => allowed. Не создавать новую сеть/registry-сервис без доказанной нужды.

## Почему это лучше для рабочего цикла

Продолжительность модельного запуска **не** KPI качества. Считаем: реально устранённые красные тесты, QA coverage для требований, найденные false-safe, throughput допущенных задач, owner-gate lag, процент повторно выполненных одинаковых исследований. Проверяем только фактические сохранённые SHA/exit codes, а не самооценку агента. Если код заблокирован, приоритет — независимое воспроизведение наиболее критического дефекта; идея F07 — лучший следующий owner-ready research track, но не новая самовольно созданная live coding задача.

## Проведённый offline-прототип F07 (не производство)

Созданы `experiments/chat_only_run/retry_safety_advisor.py` и
`test_retry_safety_advisor.py` — только аналитические функции, **без
вызовов инструментов, автоматических повторов, lease или сетевых действий**.
Двенадцать тестов прошли; негативный набор перебирает 160 комбинаций
`effect × status × receipt provenance × dispatch` и не выдаёт
`READ_RETRY_CANDIDATE` после возможного dispatch. Поддельные `retryable=true`
и `receipt_verified=true` в недоверенном JSON **не** становятся авторитетной
аттестацией. Даже проверенный read-only pre-dispatch возвращает лишь
`REQUIRE_HOST_BUDGET_AND_FRESH_ATTESTATION`, а не разрешение на выполнение.

Ограничение: 160 синтетических fixtures — не E2E проверки реального
MCP-хоста и не доказательство отсутствия сайд-эффектов при отказах сети.
Для производства понадобится отдельное host-присвоение `pre_dispatch_verified`,
защищённый контракт операций, реальные idempotency и retry budgets, а также
P085 trusted actor boundary. Ничего не внедрено в исполнительную цепочку.

## Предварительное решение

`RECOMMEND_F07_OFFLINE_PROTOTYPE_AFTER_OWNER_GATE`, остальные F02/F08 как дополняющие проверки, F03 — после фиксации API-контрактов. Никакой скрытой попытки вызвать ChatGPT Web в новом потоке, превышения автоматизаций (5/5), обхода P085 или имитации часового рабочего интервала.
