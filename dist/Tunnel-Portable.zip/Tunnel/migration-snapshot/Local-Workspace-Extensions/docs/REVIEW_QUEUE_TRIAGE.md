# Review backlog triage — 2026-11-02

Goal: expose review queue debt without taking over a developer lease, modifying
SQLite or granting reviewer identity. Four coding agents have submitted their
work, but host-enforced reviewer role proof (P085) is still outstanding.

## Quick verification

From `Local-Workspace-Extensions`:

```powershell
python review_queue_triage.py --pretty
python -m unittest -q test_review_queue_triage
python agent_team.py gate-check
```

The triage script connects to the coordinator's exact project-local
`.agent-team/team.sqlite3` in SQLite `mode=ro` with `query_only=ON`.
It never creates/updates task rows, reads lease tokens, copies code or calls
`review accept/reject`. It prints only Pxxx task IDs, author roles, verified
review age, stale reviewer lease state and bounded metadata anomaly codes.
Unavailable or implausible dates are reported as UNKNOWN (not zero minutes).

Prioritize: (a) independent reproduction of P152/P153 safety defects, 
(b) P125/P131 negative QA, (c) all review tasks older than 60 minutes,
(d) owner recovery of any *expired* reviewer lease, only after separate
authorization. Do not infer that the oldest task is technically safe or
that an advisory peer verdict grants formal approval.

As of the initial read-only snapshot on November 2, there were 20 tasks
in `review`, 1 in `reviewing`, 8 waiting more than four hours.
This is a momentary observation, not a current lease claim.

## Hard boundaries

- **P085 is not solved by this tool.** The Local Workspace connected account
  exposes owner-level file access, not cryptographically attested per-role
  reviewer permission. `host_review_authorized=null` is intentional.
- A code author's own review, a shared Developer 3+4 self-review, and automatic
  acceptance based solely on passing unittests are forbidden.
- `review` is not `done`; advisory `CHANGES_REQUESTED` is not an official
  `reject`. Do not mutate another role's task sandbox.
- Keep provider input/output tokens UNKNOWN unless an independently verified
  same-run receipt exists; no synthetic spend in the official ledger.
- Always recheck the live queue and test evidence before taking a new action.

The code and tests are `review_queue_triage.py` and
`test_review_queue_triage.py`. Architect Reviewer automation has been
directed to use the read-only view at the beginning of future reviews.

## Do not interpret negative reproduction as positive QA

`python review_negative_gate.py` executes ONLY the fixed independent
P152/P153 witness under a bounded subprocess. That witness historically
returned `exit=0` when ALL FOUR **defects were reproduced**. An
independent regression gate now emits `ok=false`,
`reason=BLOCKED_CONFIRMED_DEFECTS`, and exits 3 on those findings,
even when the underlying witness runs successfully. It also
fails closed when evidence is missing or unverified, and does not
create formal reviewer authority or alter another task's sandbox.
`python -m unittest -q test_review_negative_gate` covers this semantic
inversion and negative cases.

Before any `READY_FOR_OWNER_REVIEW` recommendation for P152/P153,
the architect must reconcile this independent negative evidence and
re-run exact candidate SHA negative/positive tests. Old advisory
`READY_FOR_ARCHITECT` packets and a green full suite cannot override
a verified failing regression.
