# Проверка пятиагентной OpenSpec + SDD команды — 2026-11-01 16:15 UTC

## Живое состояние SQLite

| Задача | Исполнитель | Состояние |
| --- | --- | --- |
| P009 | developer-1 | done |
| P010 | developer-2 | done — rework принят 15:58:17 UTC |
| P015 | developer-3 | done |
| P016 | developer-4 | done |
| P018 | developer-1 | done — принят 16:05:17 UTC |
| P021 | developer-2 | available |
| P033 | developer-3 | available |
| P034 | developer-4 | available |
| P092 | developer-2 | available, priority=100 |

Итого: **5 done, 4 available**. P092 назначена на security assurance и должна быть выбрана раньше P021. Её код ещё не написан. Четыре hourly карточки расписания для пяти ролей сохранены; developer-3 и developer-4 продолжают исполняться последовательно в одной карточке (лимит пяти активных автоматизаций).

## Реально выполнено

1. Добавлен независимый `test_accepted_capabilities_e2e.py`, проверяющий четыре принятых read-only Python-модуля на одной временной Unicode-структуре проекта: `workspace_discovery`, `workspace_search`, `diagnostics_parser`, `git_repo_map`. Контролируются относительные пути, Git-маркеры, строки кириллицы, редактирование файлов, секретные строки, пагинация и обход через символьную ссылку, где ОС допускает создание links.
2. Аудит regex: исходно новая проверка ошибочно назвала `a*a*b\\s+\\w+` уязвимым исключением whitelist. Фактическая проверка подтвердила, что `_safe_regex` **уже отвергает** этот шаблон. Неверная пометка expectedFailure удалена и заменена обычным положительным тестом на `SearchError("UNSAFE_REGEX")`. **Подтверждённого bypass для этого примера нет.** Ограничение stdlib re: отсутствие строгого timeout во время отдельного re.search остаётся; любая гарантия hard timeout требует отдельного продуманного enforcement.
3. Добавлена SQLite-migration поля `priority INTEGER NOT NULL DEFAULT 0` и приоритетная сортировка задач. Роль всегда возвращается к собственной rework, затем выбирает более приоритетную свободную задачу.
4. Разрешены последовательные ревизии уже принятых файлов через новую задачу и новую sandbox/lease, но overlap с любой незавершённой задачей остаётся запрещённым.
5. `team_seed.json` теперь содержит девять независимых задач, включая P092 (priority 100), использующую файлы ранее принятой P010 как следующую ревизию. Повторный `init` идемпотентен.
6. Добавлена возможность ревизии текста/приоритета **исключительно свободной и ещё никем не взятой** задачи через `agent_team.py init` с событием `seed_revision` в SQLite; уже выполняемая задача не переписывается.
7. Developer-2 и Architect Reviewer automations актуализированы; исправлены ранее необоснованные утверждения о конкретном regex bypass и прописан приоритет честного P092 security assurance.
8. OpenSpec workspace-files, SDD tasks и общий tracker дополнены критериями проверки regex, интеграционными тестами и задачами P092–P094.

## Фактическая регрессия

| Проверка | Результат |
| --- | --- |
| `python -m unittest discover` | 280 тестов, **264 PASS, 16 SKIP, 0 expected failures, 0 failures**, exit code 0 |
| `python agent_team.py gate-check` | Три успешных проверки: unittest / spec_check / OpenSpec CLI strict |
| `python spec_check.py` | 10 capabilities, 92 requirements, 105 scenarios, 38 SDD FR mappings, 42 tasks, 95 OpenSpec task IDs; errors=[] |
| `python validate_upstream.py` | OpenSpec 1.14.3: local-pc-agent-tooling valid, rc=0 |
| `python run_mcp_wire.py` | stdio MCP: **16/16 checks** passed |
| `python agent_team.py init` | added=0, revised=0, seed_total=9 |

## Ограничения и дальнейшие шаги

- P092 подготовлена в очереди, **но реализация и independent review ещё не выполнялись**. Не заявлять исправление таймаута или новой regex-уязвимости.
- P021/P033/P034 ожидают запланированных разработчиков. P034 — задача по состоянию независимых сцен монтажа, без запуска рендера.
- P085 host-verified role authorization остаётся блокером: текстовая CLI-роль не является аутентификацией, а общий Local Workspace MCP имеет инструменты с полномочиями OS-пользователя. Серверный исходник находится за пределами разрешённого workspace; ни tool grants, ни OS sandbox в этой итерации не внедрены.
- Merge journal обеспечивает консервативное выявление и восстановление частичного переноса, но SQLite/filesystem не становятся одной атомарной транзакцией.

Все операции выполнены только в доступном локальном проекте. Старые Scheduled-Agent-Harness данные, туннель, Git remote и посторонние автоматизации не изменялись.
