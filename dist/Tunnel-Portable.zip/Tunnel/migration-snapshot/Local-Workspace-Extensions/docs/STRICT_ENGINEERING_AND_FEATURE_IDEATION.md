# Strict Engineering Quality + 10+ Ideas per Backlog Wave

Date: 2026-11-02. Applies to scheduled ChatGPT developer-1..4 and independent Architect Reviewer in Local-Workspace-Extensions. No Codex/Work/API, no privilege promotion, no automatic spec or live queue writes.

## Priority and finite behavior

1. Perform an already authorized coding task under a legitimate scoped developer lease.
2. BEFORE developer `submit`: execute and inspect **focused + complete sandbox tests + SDD spec_check + canonical OpenSpec strict** (actual tool exit codes). Perform a security/reliability/architecture/scalability audit of exact candidate files with `experiments/chat_only_run/agent_quality_gate.py audit TASK_ID ROLE`. Use relevant negative/adversarial tests and independent reviewer. Do NOT submit with nonzero tests, outstanding critical defects or the audit reporting `can_submit_according_to_quality_policy=false`.
3. If no available coding task or after successful submit: pick independent **peer-review** via `docs/PEER_ROLE_SWITCH.md`. Prove that the reviewed code is not yours and not from the shared Developer-3+4 conversation. Record advice to separate peer SQLite; no formal merge.
4. After every peer-review, re-run coding selection. Alternate while meaningful work exists. If both coding and independent peer are empty, do NOT report idle immediately: use `architect_support.py plan ROLE` from `docs/ARCHITECT_SUPPORT_LOOP.md` for new actionable independent QA/architecture/feature-evidence tasks. Recheck coding after every support completion and never re-review unchanged input.
5. **Only after BOTH** coding and eligible independent peer-review are exhausted, create a substantial **10–20-feature** portfolio, once per canonical `team_seed.json` version and per developer role. Existing previous wave portfolios are historical, do not regenerate hourly. If incomplete, persist an explicitly DRAFT document and resume next scheduled run; don't mislabel unfinished as validated. Don't spend time inventing placeholders to meet quotas.
6. Architect Reviewer separately audits proposed features and produces an exhaustive independent decision for *every* candidate. After the 40-feature wave is validated, developers continue by independently validating/promoting evidence for the 8 selected features through `architect_support.py` instead of inventing repeat hourly 10-feature lists. No program or model may silently authorize normative OpenSpec, SDD or new live SQLite tasks without actual owner approval.

## The coding quality gate: measurable checks, not checkboxes

Script: `experiments/chat_only_run/agent_quality_gate.py`, read-only against actual live tasks, their isolated deliverables and the bounded report.

- **Security:** OWASP-style trust boundaries, allowlists, path traversal/symlinks/Windows junctions, untrusted JSON/YAML, secrets, subprocess/shell, unsafe deserialization, provenance, authn/authz, privilege escalation and prompt injection at agent/tool boundary. AST checks detect a subset, not proof of secure code.
- **Reliability:** malformed/empty/huge UTF-8, timeouts, crash/retry/idempotency, partial output, errors mapped to bounded statuses, transactional state, lease expiry, restart, cleanup, race/reentrancy, SHA/CAS conflicts. Add actual negative tests for specific failure modes.
- **Correctness:** OpenSpec/SDD requirement-to-test traceability, invariants, edge cases, Unicode, deterministic results, failure handling and focused property/metamorphic cases where applicable.
- **Architecture:** narrow cohesive modules, explicit interfaces/injected dependencies, no circular hidden state, sensible separation between parsing, validation, persistence and side effects. Refactor excessive complexity instead of suppressing the metric.
- **Scalability:** explicit algorithmic time/memory cost, bounded batch sizes/queues/read volume, pagination, backpressure, N agent contention, lock hot spots and cold restart costs. Benchmark representative sizes when relevant.
- **Maintainability:** readable names/types, small functions, meaningful errors, no silent broad catches, no single giant validator, no duplicative logic, tests that specify contracts instead of implementation details.
- **Performance:** justified O(N)/O(N log N) behavior, memory streaming, no uncontrolled full repository scans, no speculative heavy dependencies.
- **Observability:** structured event IDs, no leakage of secrets, transparent provenance, reliable and separately marked UNKNOWN telemetry, error classifications.
- **Tests and delivery:** exact source SHA-256 and actual job IDs; focused, full, `spec_check.py` and OpenSpec strict with real returncodes, zero regressions, static audit with `can_submit_according_to_quality_policy=true`, checkpoint and then submit.

AST audit currently rejects obvious dangerous calls, shell=True, unsafe YAML, racy tempfile, broad except + pass, Python assertions in production, constant secrets, parsing errors, oversized modules, functions longer than 110 lines or >18 heuristic branch structures. These limits may require explicit refactoring of existing modules; they're policy defaults, not statistically calibrated universal thresholds. Complex tasks must be restructured rather than merely documented as PASS.

Before submit use `run_script`:
```
path=Local-Workspace-Extensions/experiments/chat_only_run/agent_quality_gate.py
cwd=Local-Workspace-Extensions/experiments/chat_only_run
args=["audit","Pxxx","developer-N"]
```
The agent creates **only** `SANDBOX/agent_quality_report.json` (non-Python metadata, not another deliverable) with:
```json
{
  "task_id": "Pxxx", "role": "developer-1",
  "file_hashes": {"actual_source.py": "real sha256", "test_actual_source.py": "real sha256"},
  "dimensions": {
    "security": {"status":"PASS", "evidence":["actual threat or negative test reviewed"], "risks":[]},
    "reliability": {"status":"PASS", "evidence":["actual failure test and cleanup evidence"], "risks":[]},
    "architecture": {"status":"PASS", "evidence":["specific interfaces and cohesion checked"], "risks":[]},
    "scalability": {"status":"PASS", "evidence":["measured or bounded asymptotic cost"], "risks":[]},
    "correctness": {"status":"PASS", "evidence":["trace to exact requirement and test"], "risks":[]},
    "maintainability": {"status":"PASS", "evidence":["complexity and duplication audit"], "risks":[]},
    "performance": {"status":"PASS", "evidence":["observed timing/budget or honest boundary"], "risks":[]},
    "observability": {"status":"PASS", "evidence":["audited logs and secret-redaction"], "risks":[]},
    "spec_traceability": {"status":"PASS", "evidence":["requirement-to-test and scenario mapping"], "risks":[]}
  },
  "test_runs": [
    {"kind":"focused","command":"actual command","exit_code":0,"result_summary":"actual output summary with count","run_id":"actual job id"},
    {"kind":"full","command":"actual command","exit_code":0,"result_summary":"actual output summary with count","run_id":"actual job id"},
    {"kind":"spec_check","command":"actual command","exit_code":0,"result_summary":"actual output summary with count","run_id":"actual job id"},
    {"kind":"openspec_strict","command":"actual command","exit_code":0,"result_summary":"actual output summary with count","run_id":"actual job id"}
  ],
  "residual_risks":["specific remaining limitation"], 
  "architecture_decisions":["explicit design decision and alternative"]
}
```
The displayed evidence is a **schema example**: fill actual SHA, actual job IDs, evidence at least 15 chars each and meaningful residual risks; do not copy example pseudo-evidence as proof. The script verifies source SHA, dimensions, evidence completeness and AST; **it cannot attest self-reported test runs or actor identity from the MCP host**. Architect cross-checks job outputs, regressions and findings independently.

**Actual guarded submit entrypoint:** after a passing audit, invoke via Local Workspace `run_script`:
```
path=Local-Workspace-Extensions/experiments/chat_only_run/quality_submit.py
cwd=Local-Workspace-Extensions/experiments/chat_only_run
args=[ROLE,TASK_ID,ACTIVE_TASK_LEASE_TOKEN,"Detailed real QA evidence and changes"]
```
`quality_submit.py` repeats the source/evidence/static gate, refuses to invoke the coordinator at all when it is red, and only then calls normal `agent_team.submit` with the user's real active task-specific lease. Require `job_status completed`, `returncode=0`, `job_output.ok=true`, `submitted=true`, then `agent_team.py history TASK_ID`. Do not use raw `agent_team.py submit` in scheduled developer chats. A mock test proves the guarded entrypoint cannot reach submit when there are unresolved issues. **The old direct CLI still exists, and the host can execute arbitrary scripts; this is policy-entrypoint enforcement, NOT an OS/MCP host security boundary** (P085 remains required).

## Feature discovery: one comprehensive portfolio per developer per wave

Script: `experiments/chat_only_run/feature_idea_gate.py`.
- `wave` displays 16-character SHA prefix based only on canonical `team_seed.json` contents.
- `catalog` shows whether four role portfolios have been validated, without creating or overwriting files.
- `validate developer-N` strictly checks 10–20 proposals, unique IDs/titles, minimum description lengths, at least 3 failure scenarios, 4 concrete tests, 2 real alternatives, 13 deep design sections, six numerical scores (1..5) and comparison to 72-item existing portfolio. A passing validation means **completeness**, not guaranteed novelty or worth.
- Developer writes a JSON document `.agent-team/feature-proposals/WAVE/developer-N.json` with `schema=feature-candidates-v1`, `wave`, `role`, `cycle_reason` and `candidates`. Use `write_file` / CAS on existing file. 10+ means TEN DISTINCT thoughtfully elaborated concepts, not titles, versions of the same idea or artificial filler. If only 6 viable concepts exist, document blockers rather than inventing 4. Record incomplete work as DRAFT until 10 legitimate candidates exist.

Each candidate has **exact fields**:
- `id`: F01 ... F20, `title`: precise and unique, `summary`: >=95 chars.
- `related_existing_ids`: list of matching MF-xxx / Pxxx from existing portfolio and queue, or [] if demonstrably novel.
- `sections` EXACT keys: `problem`, `user_value`, `evidence`, `technical_design`, `interfaces`, `scaling_design`, `security_design`, `reliability_design`, `observability`, `acceptance_metric`, `migration_plan`, `rollback_plan`, `costs_and_tradeoffs`. All 13 sections require substantive text; lengths validated in code (70–200+ chars).
- `failure_scenarios`: >=3 detailed actual failure/negative cases. `test_strategy`: >=4 verifiable test/benchmark cases. `alternatives`: >=2 meaningful alternatives with constraints/tradeoffs. Each entry >=50 chars.
- `score`: 1..5 ints each for `impact`, `confidence`, `feasibility`, `strategic_fit`, `engineering_effort`, `security_risk`; evidence-backed `confidence_note` >=65 chars.

Check exact machine validation via `feature_idea_gate.py validate ROLE`; zero errors is only a prerequisite, not final selection. Make list diverse: reliability, security, observability, design, test quality, scalability, orchestration, cost, value, product integration; don't reinvent existing MF concepts. Inspect original 72-feature portfolio and current OpenSpec/SDD before inventing.

The two logical roles in the shared D3+D4 scheduled chat each owe their own **10+** proposal set; do not conflate 20+ in one file. If time is exhausted, checkpoint to role's DRAFT, next run resumes instead of regenerating. A new wave requires actual manifest changes, not a clock tick.

## Architect's very strict independent filter

`feature_idea_gate.py catalog` initially returns false until all four complete; `architect` reports what is missing, never silently marks approved.
After all **40+** validated entries exist:
1. Independently read the portfolio files, all original MF portfolio, current full OpenSpec/SDD, live technical blockers and user goals. Eliminate same-problem duplicates, reused capabilities, cosmetic features, unsafe bypasses and speculative complexity.
2. For **every** feature write one decision to `.agent-team/feature-proposals/WAVE/architect_decisions.json`, with `schema=architect-feature-decisions-v1`, `wave`, `owner_gate_acknowledged=true`, `architecture_summary` >=180 chars and `decisions` covering every `developer-N:FXX`.
3. Each decision: `feature_id`, `decision` (PROMOTE_FOR_OWNER_SPEC_APPROVAL/MERGE_EXISTING/DEFER/REJECT), `rationale` >=120 chars, `similar_to` (existing ID/group; [] when none), `risks` list concrete >=35 chars, `tests_required` list >=35 chars, `dimensions` same six score names, each 1..5, and `weighted_score` computed EXACTLY by `strict_arch_score` in code:
   `clamp[0,100](8*impact+5*feasibility+4*confidence+3*strategic_fit -3*engineering_effort -4*security_risk+15)`.
4. Independent architect rubric only promotes score **>=78**, no duplicates (`similar_to=[]`), no unsafe permission expansion, **max 8 promotions per wave**. Every promoted item needs concrete baseline, target, testable acceptance, threat model, rollback and budget before any owner spec proposal. Others are merged, deferred or rejected explicitly, with rationale and evidence. The tool checks declared scores and exhaustive decisions; it cannot itself prove the rationale is true.
5. Validate with `feature_idea_gate.py architect`. Only successful output indicates all decisions internally consistent; `formal_spec_approval=false`, `live_queue_mutated=false` always. New normative specs require independent owner-reviewed OpenSpec preview / approved terminal step and new queue tasks require valid owner approval.
6. If some developers' portfolios are still pending: architect performs useful independent architecture review of ready entries and existing backlog, but cannot pretend an aggregate final decision is ready.

## Boundaries

No autonomous tool/script in this workflow acquires trusted MCP host grants, closes P085, reviews its own code, or merges artifacts. Unsafe static findings and unverified test reports fail closed at policy level. The exact minimum 10 is subject to good-faith originality; never fabricate filler, benchmarks, hashes or test runs to reach the quota. No new scheduled Automations were created; existing four prompts are enhanced.
