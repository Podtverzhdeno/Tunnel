# P085 — автономный контроль безопасности и прогресса

Статус: **реализовано и подключено к существующему расписанию Architect Reviewer**, 2026-11-02. Автономный auditor **не является привилегированным брокером** и не закрывает P085.

## Контур без ручных операций

- В корне проекта: `p085_autonomous_guard.py`. Единственная команда Scheduled-архитектора через Local Workspace: `run_script(path="Local-Workspace-Extensions/p085_autonomous_guard.py",cwd="Local-Workspace-Extensions",args=["--write-report"])`; job_status и job_output обязательны.
- Роль: **observer + test orchestrator**; только read-only проверка live `127.0.0.1:8765/healthz`, live SQLite `mode=ro, PRAGMA query_only=ON`, SHA локальных исходников и bounded тесты.
- Исполняемые локально проверки: `test_capability_profiles.py`, `test_http.py`, полный `mcp-host-source/tests`, три канонических `foundation_kernel` suites (Windows isolation, named pipe, supervisor), `spec_check.py`, `ops.py spec_validate Local-Workspace-Extensions add-agent-foundation-hardening`.
- Каждая subprocess с таймаутом 75 сек, `shell=False`; BROKER test suites используют строго фиксированный `PYTHONPATH` (корень проекта и свой пакет). Ни одна проверка не меняет prod-host, TLS/tunnel, Windows accounts, live queue, grants, owner approvals или сливает исходники.
- Два раза проверяется source SHA: сканируется весь ограниченный набор `*.py` в `mcp-host-source/workspace_mcp`, `mcp-host-source/tests` и `experiments/foundation_kernel` плюс обязательные OpenSpec/host artifacts, отказывая при symlink/junction/переполнении и изменениях во время прогона. В таком случае результат `OFFLINE_REGRESSION_FAILED`, а не ложный PASS.
- Машинные отчёты атомарно сохраняются в `.agent-team/reports/P085_auto_YYYY...json` и `P085_auto_latest.json`. В них **только** счётчики, SHA, статусы и имена блокировок; stdout/stderr, bearer, lease token, промпты и закрытые документы не записываются. `delta` сравнивает риск с предыдущим отчётом, не шумит при изменении количества задач, если проверка не регрессировала.

## Встроенная ChatGPT Automation

Планировщик имеет лимит **5 активных задач**, отдельный шестой слот создать невозможно (получен `too_many_active_automations`). Вместо него **обновлён существующий** `OpenSpec — Architect Reviewer`, ID `6ae6ba8c7c1081919402e9d8bb58f0d7`, сохранив исходный hourly RRULE и все обязанности. В промпт добавлен фрагмент `P085 AUTONOMOUS READINESS HOOK 2026-11-02`: перед основной архитектурной работой он выполняет audit, анализирует действительную job output и использует свежие блокировки как входные данные для дальнейшего QA. Информация о новом heartbeat/Scheduled окне **не проверена**, только обновление конфигурации Automation подтверждено.

Проверки запускаются только тогда, когда platform Scheduled запустит соответствующий ChatGPT-turn и Local Workspace будет доступен. При остановке ChatGPT, туннеля или ПК **никакая локальная команда сама по себе не продолжит работать в фоне**. Это не вечный демон и не обход квот.

## Правила безопасной автоматизации

1. **Каждый green offline test не даёт права писать/accept/merge**. `p085_release_ready=false` до реального отдельного Windows SID, защищённого подписанта/grant issuer, ACL, независимых Windows multi-user E2E и удаления privileged tool bypass из агентского контра.
2. Действующий MCP сейчас объявляет 28 инструментов, поэтому `LIVE_MCP_PRIVILEGED_INTERFACE_EXPOSED` — ожидаемый открытый блокер, а не результат неисправности offline observer.
3. Если один из тестов красный, архитектор должен воспроизвести сбой с новым исходным SHA, проверить ownership и исправить только разрешённый модуль, не вмешиваясь в параллельную работу разработчика.
4. Архитектор сохраняет текущую работу по 20+ задачам QA и версионированным планам. Блокировки reviewer authorization нельзя обходить очередью рекомендаций, увеличением лимитов или самоподписанием.
5. Нет ручного шага для **рутинного аудита**. Для первоначального создания доверенного Windows service principal и защищённых приватных ключей может потребоваться отдельная санкционированная операция ОС с правами владельца; аудит не выдаёт её сам себе.
6. Если нет новых фактов, Scheduler не должен посылать уведомления ради подтверждения запуска. Новые нарушения безопасности, drift/FAIL, восстановление или инженерные исправления — существенные обновления.

## Проверяемые достижения и следующие задачи

Первый полный подтверждённый audit `p085_autonomous_guard.py --write-report` создал report; `observer-profile`, `observer-http`, `host-full-suite`, `broker-os-ipc-supervisor`, `normative-crosswalk`, `approved-openspec-strict` были PASS. Это подтверждает **офлайн-контроль**, а не право на production. В очередь живых задач не внесено ни одного изменения самим auditor.

Следующий автоматизируемый этап — **подготовить доверенный двухконтурный запуск**, переиспользовав `experiments/foundation_kernel/broker_named_pipe.py`, `broker_supervisor.py` и `windows_isolation.py`:
- Read-only observer endpoint, отдельный защищённый OS SID для broker, изолированные ACL ключей и executable, отдельный issuer и scoped one-use grants.
- Автоматические preflight и negative E2E; если any trust requirement UNKNOWN, **не переключать** текущий MCP и не рестартовать туннель.
- После фактической multi-SID validation и reviewer acceptance разработать ограниченный rollout под подтверждённым владельцем с резервной копией и rollback.

## Подтверждённый итоговый прогон (2026-11-02)

`p085_autonomous_guard.py --write-report`, job rc=0, `P085_auto_20261102T174848Z_eacde96cef3d.json`: **6 из 6 локальных проверок PASS**, 72 исходных файла прошли сравнение SHA до/после, структурная/strict OpenSpec в норме. Host suite **128 тестов, 3 skipped**; kernel OS/IPC/supervisor **51 тест, 1 skipped**; дополнительные targeted suites (часть проверок повторяется) 15+6 PASS. Live health: 28 инструментов, privileged gateway NOT isolated.

Интеграционная ошибка главного regression gate найдена и исправлена в `test_agent_team.py`: одноразовый sandbox fixture должен копировать `spec_analyzer.py` и `spec_tools.py` вместе с `spec_check.py`. Без них subprocess review QA ошибочно возвращала rc=1. Целевой тест подтверждён PASS. После исправления `python -m unittest discover -q` из корня проекта — **1613 тестов, OK (skipped=40)**.

Это evidence измеренного локального прогона. **Первая будущая Scheduled-попытка** обновлённого Architect Reviewer пока не подтверждена историей выполнения, поэтому нельзя утверждать, что ChatGPT будет непрерывно работать при выключенном ПК/туннеле.

## Zero-touch hardening v2 — защита от самоповреждения планировщика (02.11.2026)

- Контроллер `p085_autonomous_guard.py` теперь различает `PASS`, `FAIL` и `NOT_RUN`: `--quick` возвращает только наблюдение и никогда не подтверждает offline QA. Комбинация `--quick --write-report` отклоняется, чтобы не перезаписать доверенную полноту последнего полного аудита.
- Для канонического `--write-report` действует **один OS-exclusive lock на весь цикл** (проверка → сравнение → атомарная публикация). Второй конкурентный запуск получает `AUDIT_ALREADY_RUNNING` без перезаписи `P085_auto_latest.json`. После аварийного завершения lock автоматически освобождается ОС, без TTL-эвристик и кражи блокировки. Это операционный lock, не trusted ACL.
- `classify` принимает PASS только при точном наборе **всех шести** именованных suites; отсутствие, подмена, повтор имени или частичный набор — FAIL. Пустой набор — NOT_RUN. Ложный `Ran 0 tests ... OK` тоже FAIL, действуют пороги 10/5/30/30 для соответствующих unittest suites.
- Два замера SHA охватывают полный bounded Python-набор host/kernel, сам контроллер, его тесты, OpenSpec tasks, `spec_check.py`, `spec_analyzer.py` и `spec_tools.py`. Отчёты не содержат stdout, stderr, SID, lease tokens, ключи или секреты. Ошибки CLI выдаются только стабильными безопасными кодами, без Windows-путей.
- Новые негативные unit tests покрывают одновременный второй запуск, `NOT_RUN`, потерянные/дублирующие результаты suites, нулевое количество тестов, неизменяемость full-QA baseline и безопасные коды ошибок.
- **Фактическая проверка:** `python -m unittest test_p085_autonomous_guard -q`: 21 test OK, 2 skipped (Windows symlink permission). Полный `python -m unittest discover -q`: **1619 tests OK, 40 skipped**. OpenSpec strict и SDD ранее подтверждены; новый production broker deployment не проводился.
- Существующий Architect Reviewer уже имеет почасовой hook к тому же пути, поэтому улучшения подхватятся в его последующих запусках без новой Automation карточки. Подтверждать выполнение по фактическому `job_status/job_output`, не по одному наличию расписания.

## Следующий автономный этап — Windows bootstrap readiness (2026-11-02)

- Существующий почасовой `p085_autonomous_guard.py --write-report` теперь проверяет **7** отдельных suites, включая `windows-bootstrap-negative` (Windows ACL/runtime readiness, broker startup interpreter guard, keyless bundle tampering), и сохраняет отдельное `windows_deployment` с фактическими кодами блокировки. Отсутствие elevated OS token не превращается в вымышленный успех.
- Брокер `broker_named_pipe.py` включает **сам `python.exe`** в перечень защищаемых путей перед открытием pipe. Внешне защищённая программа с подменяемым агентом интерпретатором больше не проходит этот preflight.
- Автоматическая подготовка кандидата: **только после PASS + SHA-stability** брокерские production Python-модули без ключей, политики, журналов и тестов копируются в `.agent-team/p085-release-candidates/<content_sha256>/`. Результат помечен `STAGED_FOR_INDEPENDENT_REVIEW`, `release_approved=false`, `os_acl_verified=false`. Повторная сборка того же содержимого идемпотентна, добавленный невключённый в manifest файл даёт FAIL, история ограничена 40 кандидатами.
- Актуальные blockers Windows: `ELEVATED_INSTALLER_NOT_AVAILABLE`, `BROKER_PYTHON_RUNTIME_UNTRUSTED`, `BROKER_CODE_TREE_UNTRUSTED`, `BROKER_SERVICE_UNPROVISIONED`, `REAL_TWO_SID_E2E_UNVERIFIED`. Эти ограничения нельзя снять исполнением команд под текущим SID.
- Полная последовательность защищённого развёртывания, требования к отдельной OS principal / protected runtime и файл подтверждённых ограничений: `docs/P085_WINDOWS_ISOLATION_BOOTSTRAP.md`.
- Проверки после изменений: новые targeted 37 tests OK (3 skipped), полный проект `python -m unittest discover -q` — **1659 tests OK (41 skipped)**. Это подтверждает код и офлайн-тесты; production OS isolation **не установлена**.

**Эксплуатационная граница:** не пытаться «полностью автоматизировать» предоставление себе привилегий из того же незащищённого чат-процесса: это уничтожит смысл P085.
