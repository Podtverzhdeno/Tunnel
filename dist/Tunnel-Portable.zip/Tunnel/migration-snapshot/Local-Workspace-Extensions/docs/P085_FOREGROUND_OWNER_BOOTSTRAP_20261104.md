# P085 — owner-only Windows bootstrap, evidence current 2026-11-04
> **Актуализация 07.11.2026:** контрольный SHA для `Setup-P085WindowsPrincipals.ps1` изменился на `9e84499bfffbfc64263c9841983613400187e008fdb417953111e91469017b56` (исправлена длина и нечувствительная к регистру уникальность имён Windows). Таблица SHA ниже — **исторический снимок 04.11**, не использовать её для нового owner-вызова. Текущий полный handoff: `docs/P085_OWNER_UNBLOCK_EVIDENCE_20261107.md`. Source SHA не заменяет независимую проверку доверенной копии.


## Verified state

Connected Local Workspace was inspected without elevation. Latest read-only checks:
- `p085_accounts_readonly_check.py`: **0 of 5** service/reviewer/worker/QA accounts exist; no Windows account was created. Job `7fdd59252a874de7983d59cc786e189d`, rc=0.
- `p085_elevation_probe.py`: Windows session 2, `is_elevated_administrator=false`, no UAC confirmation. Job `0aa407494bda44aca13d47d2598280bd`, rc=0.
- `p085_release_handoff_check.py`: the SHA-addressed 25-file source candidate `8dba537314f9520cad3d299aaede2e173b3f0742dc742b723cddd379958b5940` is intact and matches current foundation-kernel source; `accounts_missing=5`; `release_authorized=false`. Job `bd86f23f56734df2bd143a38aff95507`, rc=0.
- No protected broker installed; trusted Windows broker principal, ACL and multi-SID E2E are NOT verified. The 25-file foundation-kernel package is **not** the `mcp-host-source` payload used by the protected installer.

## Reviewed script SHA256 (compare independently before any elevated use)

| Script | SHA256 |
|---|---|
| `Setup-P085WindowsPrincipals.ps1` | `a24c8ab163dec6782d4afc0335f633e8f426a1025d3f5e42c90993dd7589dbb9` |
| `Open-P085AdminTerminal.ps1` | `d606b299a2927f467cec180c3b97575f3ad2c77954d3804353ba7aca7fdfa67b` |
| `Install-P085ProtectedService.ps1` | `b2bdac792998f4e083f9d1e6f262e2a18b96f53c2662a160c106dd8a4322e709` |

A SHA hash proves byte identity only, not origin, authenticity or owner consent. **Never launch the above mutable local-workspace scripts elevated without independently reviewing and staging a trusted immutable copy.** The ChatGPT/MCP session must not enter passwords, run UAC, or assume a reviewer/owner token.

## Foreground owner workflow (NOT executed by this chat)

1. Independently obtain/review a trusted copy of the project and the three scripts, compare each SHA (e.g. `Get-FileHash -Algorithm SHA256`) to a trusted pinned source. Open Windows PowerShell as Administrator yourself using Windows UI, not an MCP-launched shell. A convenience `Open-P085AdminTerminal.ps1` opens a *blank* UAC console but does **not** execute setup or grant authority.
2. Run the **account setup plan**, without `-Apply`, in the trusted foreground console:
   ```powershell
   .\Setup-P085WindowsPrincipals.ps1
   ```
   Check the five proposed account names and that each is a distinct, non-admin role. Then, only upon your own explicit approval, the intended interactive provisioning command is:
   ```powershell
   .\Setup-P085WindowsPrincipals.ps1 -Apply
   ```
   It asks for account passwords via secure Windows prompts and creates **disabled** accounts. This is only the account phase; no service is installed/started. No credentials belong in ChatGPT or MCP.
3. Once distinct accounts are present and a **trusted, immutable copy of the whole installer input tree** is ready, run the **installer dry-run**, with existing local account names:
   ```powershell
   .\Install-P085ProtectedService.ps1 -ServiceAccount '.\p085svc' -ReviewerAccount '.\p085review' -WorkerAccount '.\p085worker'
   ```
   Review `files[]`, all source SHA, destination under `ProgramData`, distinct SIDs and the returned `plan_sha256`. Do not confuse it with the foundation-kernel bundle ID. An independently approved `-Apply -ExpectedPlanSha256 <reviewed-plan-sha>` invocation can **stage code only** and requires an interactive confirmation; it does **not** provision keys, register/start services, or grant runtime authorization.
4. Before activating anything, validate protected code and interpreter ACLs, independent broker/worker/reviewer Windows SIDs, local transport authorization, signed grant issuer and negative two-principal E2E in a trusted environment. Only authenticated owner/reviewer controls may advance P085 or integrate agent acceptance.

## Machine checks available safely in the current project

```powershell
python p085_accounts_readonly_check.py
python p085_elevation_probe.py
python p085_release_handoff_check.py
python p085_windows_deploy_preflight.py
python -m unittest -q test_p085_release_handoff_check test_p085_accounts_output_hardening_20261104
```

These checks are read-only, advisory and **cannot** satisfy the host-trust requirement. The MCP agent must not invoke `-Apply` or treat a simulated passing ACL as a real signed grant.

## Verified current final test and acceptance evidence

- Focused owner handoff and account/installer tests: job `e634b2baebf94bea8ef2e7088eaa8682`, rc=0, **26 tests OK**.
- Full canonical Python unittest discovery: job `15158a13c0d748ea9a04b17884961974`, rc=0, **2573 tests OK (43 skipped)**.
- Code reuse/architecture gate: job `8c150270b5f44ed59f83d09d7cb36ee9`, rc=0, PASS, 128 modules, 581 substantial functions; no structural clone groups.
- `team_acceptance_audit.py`, job `77c56ef89ed64ef39cddfff6eaba0e4d`, rc=0, 8 recorded_pass, 7 legacy_unverifiable, **1 invalid_evidence P104 (CURRENT_SOURCE_HASH_MISMATCH)**, 20 not_accepted. Nothing in this handoff modified historic acceptance records.
- OpenSpec structural `spec_check.py`, job `2708f6e4b0b54776b43617e25727d202`, rc=0.
- Read-only live P085 handoff, job `bd86f23f56734df2bd143a38aff95507`, rc=0: 25 source files match manifest, five accounts missing, release not authorized.

## 2026-11-04 staging race fix (source only)

The protected installer now constructs the temporary staging root with a non-inheriting explicit ACL **in the atomic Directory.CreateDirectory(path, security) call**, before any child directory or source-copy operation. During pre-publication staging, only SYSTEM and the elevated Administrators group have FullControl; the broker service, reviewer and worker receive no temporary-stage permissions. The installer immediately validates that the temporary root has a protected DACL, Administrators owner and only the two approved explicit ACEs. After moving it to the final destination, the original stricter SYSTEM-owned code ACL and private-state split are still applied. A failed check aborts before copy and never activates a service. This is a source-level contract; **Windows multi-principal E2E and actual protected staging were not executed**.

Previous (before SID hardening) `Install-P085ProtectedService.ps1` SHA256: `f07cb5a0147a0fde700ecab812c71dffb4af6b5f07bd793b8a058ec890ad49b1`. The *current* SHA256 is `b2bdac792998f4e083f9d1e6f262e2a18b96f53c2662a160c106dd8a4322e709`. Previous SHA in the owner handoff must not be used for the amended installer. Focused test `test_p085_installer_source.py` now checks atomic security at creation and ordering before copy/rename. Targeted 24-test job `980dc0b8445043a7bd7a5d23bc96581b`: rc=0, no errors.

## Final verification after installer hardening

- Focused security, installer and handoff suites: job `980dc0b8445043a7bd7a5d23bc96581b`, completed rc=0, **24 tests OK** (PowerShell parser is syntax-only, never runs the installer).
- Full canonical unit tests: job `da995b7934cf487bb317abe8da845575`, completed rc=0, **2584 tests OK, 43 skipped**.
- Architectural reuse CI: job `eea57593ca284b68a14a584bdabece60`, completed rc=0, 128 production modules, 582 eligible substantial functions, 0 structural clone groups.
- Current P085 handoff check: job `e249864f86214d08bc52dfafaaf63435`, completed rc=0, 25-file source candidate matches current source; **5 of 5 Windows principals missing**, service unprovisioned, release authorization false.
- Acceptance evidence audit: job `74c3b32b35cc46079e3082536ccd8abd`, completed rc=0; 8 recorded_pass, 7 legacy_unverifiable, 1 invalid_evidence (**P104 historical SHA mismatch**), 20 not_accepted. No historical receipt was altered.

## P085 sealed-stage auditor alignment (2026-11-04)

A deterministic negative test first reproduced a real cross-component mismatch:
`Install-P085ProtectedService.ps1` explicitly grants local Administrators
(`S-1-5-32-544`) `ReadAndExecute` on the final sealed code and private-state
directories, but `p085_stage_audit.py` previously rejected *any* admin
read ACE as `STAGE_ACL_READ_EXECUTE_SCOPE_VIOLATION`. This meant a correctly
staged package could be permanently classified `BLOCKED` after installation,
even when ACLs matched the reviewed installer.

**Applied fix (canonical):** `p085_stage_audit.py` SHA256
`46b4b96a8bad1729e74df207a4e147fa4f69037094993f57c578c2f867f2d17b`.
The stage auditor permits the Administrators SID in read-only/execute ACE
principal lists, but **not** in write-allowed lists, including private state;
reviewer/worker and arbitrary SID read access remain blocked.
`test_p085_stage_audit.py` SHA256
`99026cf46942e03ab570c7a04387e043c0fa9ac30f31bfcf081080a5f32ab861`
uses installer-realistic ACL fixtures, exercises admin-write attempts on the
root, a code module, the receipt and private state, and checks that the
PowerShell source still grants Administrators only RX in its *final sealed*
ACL, never FullControl.

**Evidence:** prior negative test job `25d9a2c6f08b4911ad81b6bc5d3695f8`
completed rc=1 with the expected misclassification;
post-fix targeted job `4eb6c7c9926f40ef8087b0dbd28ad1f7`
completed rc=0, **52 tests OK (2 skipped)**.
The canonical full-suite result before the last test-only reinforcement,
job `e2b632551cf64c10bdcf459d77738fc8`, was rc=0,
**2586 tests OK (43 skipped)**. The subsequent direct-source contract
test also passed in the targeted run. The code reuse gate
`5794d02c51b4403f835ea8008e73f44b` passed.

**Trust boundary remains unchanged:** no Windows user was created, no
admin/UAC action, service installation, code stage publish, protected grant
issuance, historical acceptance edit, SQLite write or release activation
was performed by this repair. Administrator effective access and the
separate broker/worker/reviewer SID isolation still require foreground
Windows testing. Passing an offline ACL model is never release permission.

## P085 local-user SID isolation hardening (2026-11-04)

A new independent negative test reproduced that distinct but *privileged* SIDs
could pass the staged receipt's former `SAFE_SID` validation (e.g.
`S-1-5-32-544` Administrators, `S-1-5-19` Local Service,
`S-1-5-20` Network Service and `S-1-5-80-...` service identities).
The source-only witness job `b710163f17d84b5d8506c185f8bc97e7`
returned rc=1 with 12 expected negative failures; it was **not** a passing QA.

**Implemented in canonical main:**
- `Install-P085ProtectedService.ps1` SHA256
  `b2bdac792998f4e083f9d1e6f262e2a18b96f53c2662a160c106dd8a4322e709`
  now calls `Assert-LocalNonAdminPrincipal` for each requested role
  *before* source planning, any staging mutation, or `-Apply`. This read-only
  guard requires Windows local-account SID structure, membership in
  `Get-LocalUser`, and exclusion from the built-in Administrators group via
  `Get-LocalGroupMember`. If the local accounts module is unavailable
  or cannot enumerate accounts, the installer fails closed.
- `p085_stage_audit.py` SHA256
  `4b6a3b75bd2d1cabc3c116716056382e243457e74899255d4a58009fe063ea84`
  rejects built-in, group, service and virtual SID formats in all three
  `STAGE_RECEIPT.json` role fields with
  `STAGE_ROLE_SID_NOT_LOCAL_USER`. Offline SID shape is *not* proof that
  an OS account exists; only an authentic Windows-host lookup can establish
  that property.
- `test_p085_installer_source.py` SHA256
  `4e69d32319a8b732ddcdd1ed2c041405e1a68b3ccd7f14f8b637db3e137a4697`
  pins local-user/admin checks before mutation; and
  `test_p085_stage_audit.py` SHA256
  `8bf3ce78857d6b6552009948f7ac014ea82fbf349b5a8ff0e459dc046332eb7e`
  contains negative fixtures for every role and forbidden SID class.

**Verified after changes:**
- Focused Windows installer + stage + preflight: job
  `f599986c7c3c441ca145e09bee854cd9` rc=0, **54 tests OK
  (2 skipped)**; the PowerShell script was only parsed, not executed elevated.
- Complete canonical `python -m unittest discover -q`: job
  `8623f2a8903e41f4b16dc6715188e0e4`, rc=0,
  **2588 tests OK (43 skipped)**.
- `agent_reuse_ci_gate.py`: job `7314ca6c24624603a6e0c9fd1849df7a`,
  rc=0, PASS; 131 scanned modules and zero structural clone groups.
- `spec_check.py`: job `57b532e4312c48d78bf0520f252c50b7`,
  rc=0, 99 requirements, 128 scenarios, structural errors=[].
- `team_acceptance_audit.py`: job `a4f1d1fb5d7845109a6b170b62c3f917`,
  rc=0; only historical P104 remains `CURRENT_SOURCE_HASH_MISMATCH`.
  No receipt or queue records were edited.

Still blocked: 5 Windows P085 accounts absent, no authenticated broker service,
and no real separate-principal E2E. **Do not run `-Apply` through MCP** or
promote advisory passing tests to protected-host authorization.

## Source repair performed in this run

- `p085_accounts_readonly_check.py` now fails closed on invalid JSON top-level types, excessive stdout/stderr size, and malformed dry-run output without uncaught `AttributeError`.
- `p085_release_handoff_check.py` now includes a non-secret five-account readiness summary and explicit `MISSING_P085_WINDOWS_PRINCIPALS` / `READONLY_ACCOUNT_INVENTORY_UNVERIFIED` blocker codes.
- Added negative regression suite `test_p085_accounts_output_hardening_20261104.py` and expanded `test_p085_release_handoff_check.py`. Existing source modules, live host, principal accounts, task SQLite, ACLs and acceptance records remain unchanged beyond the two stated source changes.
