# Multiagent execution — Architecture & SDD V3

Date: 2026-11-02  
Status: PROPOSED / non-normative extension; no automatic owner approval  
Project: Local-Workspace-Extensions  
Source anchors: specs/001-local-pc-agent-tooling/MASTER_SDD.md, ARCHITECTURE_V2.md, docs/SDD_MULTI_TEAM_EXECUTION_V2.md, docs/CHANGE_IMPACT_PLANNING_DESIGN_2026-11-02.md  
Existing feature proposals: add-durable-agent-memory, add-agent-reliability-qa, add-agent-foundation-hardening, add-continuous-agent-work-loop, add-agent-code-reuse-governance  
Scope: full autonomous developer lifecycle, NOT permission to change the live coordinator or MCP host

## 1. Product contract and precise objective

Create a multiagent engineering platform where four logical developer roles and one architect-reviewer can repeatedly consume legitimate OpenSpec/SDD tasks, write disjoint scoped code, collect reproducible evidence, independently review, and resume safely after a ChatGPT scheduled invocation ends. The current scheduler uses four automation cards for those five logical roles because Developer 3+4 share one card; this is not five independent platform invocations.

Primary outcome is **verified accepted useful work**, not maximum token consumption, elapsed session length, filled time, number of generated ideas or a green-looking dashboard. Never trade away trust or independent review for an anti-idle metric.

Key hard restrictions:
- A ChatGPT model message, title, project document, model-created signature or Python role string cannot become trusted MCP principal authorization.
- P085 is the single canonical host-level identity/policy implementation track. No duplicate broker, no capability escalation by scripts.
- Existing agent_team.py + its SQLite is the source of truth for task/lease/review state. No second mutable task ledger.
- Existing review_merge.py and MergeIntent own file publication; advisory components cannot perform it.
- Owner approval for canonical specs, live queue admission, production release and sensitive mutations remains separate.
- No claim that ChatGPT can execute for one hour in a single scheduled run or bypass product limits. If no valid work is available, record the reason and stop.

## 2. Normative proposal inventory (not yet approved SHALL)

S3-01 / Authenticated actor: privileged effect SHALL be authorized by the *actual host* for principal, exact tool, workspace, path/resource, grant, lease epoch, policy revision, expiry and revocation.

S3-02 / Admission as guarded transaction: task acquisition SHALL recheck canonical requirement SHA, accepted dependencies, ownership locks, risk scope, host capability and current state atomically where those values are coordinator-owned. External host policy is separately rechecked at effect time.

S3-03 / Exclusive responsibility: at most one active canonical responsibility owner SHALL modify a given API/module responsibility, even if physical output file paths are disjoint.

S3-04 / Durable intent: any non-idempotent effect SHALL have durable pre-effect intent and a host-verifiable completion receipt; on ambiguous result, transition to reconciliation instead of blind retry.

S3-05 / Fault-tolerant resumption: after crash or disconnected invocation, the next role SHALL reconstruct task/version/lease/checkpoint and either resume safe steps or return typed blocker without claiming prior execution.

S3-06 / Reproducible evidence: acceptance SHALL require exact code/test/spec/environment identity, actual execution receipts, negative tests and independent reviewer provenance rather than agent-authored PASS strings.

S3-07 / Safe publication: one review SHALL not publish a partially replaced multi-file change; MergeIntent and file CAS SHALL preserve ability to inspect uncertain state without automatic destructive recovery.

S3-08 / No self-review: same-authored or jointly-authored work SHALL not acquire formal independent review authority; shared Dev3+4 card counts as one independence domain.

S3-09 / Deterministic scheduling: read-only planning SHALL report a stable reason for rejection, unknown data, resource conflict and queue readiness; no simulated result can mint a lease.

S3-10 / Bounded execution: every operation SHALL have explicit time, memory, I/O, retry and context budgets, with typed incomplete outcomes rather than fabricated completion.

S3-11 / Reuse before new code: task intake SHALL evaluate canonical module/API responsibilities and existing implementation, favoring reuse or owner-approved refactor over redundant modules.

S3-12 / Spec impact: changing SHALL or public API SHALL invalidate only provably affected work and receipts, retaining UNKNOWN for unresolved dynamic edges.

S3-13 / Truthful observability: platform-observed run time, user-reported context, provider-reported tokens, estimates and modeled counterfactual savings SHALL remain separate typed evidence categories.

S3-14 / Least privilege by default: sandbox isolation SHALL be enforced by host OS or constrained worker boundary for privileged deployment; a directory named sandbox alone is insufficient.

S3-15 / Human checkpoints: approving risk, normative requirement changes, owner queue admissions and release SHALL require the specific independent authorized actor, with visible request, expiry and revocation.

S3-16 / Proof of non-regression: release SHALL require reproduction of prior known-negative security and concurrency failures against the final exact source SHA, not only unit pass counts.

All sixteen are **candidate normative statements**; they do not change owner-approved specifications or implementation authority until reviewed in the established spec flow.

## 3. Single-writer source-of-truth map

| Domain / object | Canonical owner | Advisory readers | Forbidden competing owner |
| --- | --- | --- | --- |
| Task state, leases, dependency satisfaction, reviewer states | agent_team.py SQLite coordinator | planner, readiness matrix, metrics | new scheduling database |
| OpenSpec/SDD normative requirements | owner-approved OpenSpec/SDD files | traceability, impact planner | unapproved markdown revisions |
| Runtime host grant/actor authorization | actual trusted MCP host, P085 | host policy offline probes | agent prompt, Python CLI role |
| Source acceptance/copy/rollback | review_merge.py and MergeIntent | reviewer previews, QA matrix | simulation, idea generator |
| Canonical module responsibility | existing responsibility contract registry | code reuse preflight and import graph | per-agent arbitrary module naming |
| QA evidence | existing verifier/acceptance receipt pathway | test matrix, risk planner | agent-submitted freeform PASS |
| Scheduled invocation observation | scheduler_run_history / actual observed receipts | productivity reports | inferred task lease duration |
| Token/cost evidence | provider receipt importer and explicitly scoped estimators | reports | guessed ChatGPT totals |
| Memory/checkpoint | existing task checkpoints; optional future durable extension | resume packets | parallel mutable memory-backed queue |

Boundary rule: each new component may be an adapter or materialized *read-only* view over canonical records. If it requires independent mutable truth, submit an ADR proving why existing transaction ownership cannot be extended safely; otherwise reject.

## 4. System context

Human owner -> canonical spec approval -> queue admission -> coordinator -> role-specific sandbox -> developer tool effects -> QA evidence -> independent reviewer -> MergeIntent -> canonical accepted artifacts -> optional owner-gated release.

Control plane: authoritative coordinator and host policy.
Execution plane: sandbox-scoped operations, bounded jobs and tools.
Evidence plane: source/test/spec/runner hashes, structured QA, actor provenance and immutable acceptance records.
Planning plane: read-only spec-impact graph, reason explanations and fixture-only scheduling simulations.
Observability plane: scheduler run evidence, queue age, blockers, accepted throughput, token *coverage*, not invented billing.

Do not merge these planes into an all-powerful monolithic agent. Specifically, plan-only tools must not import or invoke acceptance, owner approval or file publish functions.

## 5. Task state machine

Proposed --[owner-approved admission]--> Queued
Queued --[all dependency, ownership, source and security checks]--> Ready (derived, never permanent authority)
Ready --[atomic owner/lease CAS]--> Working
Working --[valid fenced checkpoint]--> Working
Working --[evidence-authenticated submit]--> Review
Review --[independent QA failure]--> Rework
Rework --[authorized new lease + revision]--> Working
Review --[authenticated reviewer acceptance + MergeIntent]--> Accepted
Accepted --[separate release gates]--> Released
Any nonterminal --[stale spec/dependency]--> Blocked (reasoned)
Any mutation with unknown effect --[crash/timeout]--> ReconciliationRequired
Any still-valid lease MUST NOT be stolen simply to increase utilization.

State is not proof: a task in Review or Accepted may contain older unverified host actor fields. Only actual receipt evidence can support claims that a production trust gate passed.

### 5.1 Allowed transitions and proof requirements

| Transition | Required verifiable inputs | Forbidden shortcuts |
| --- | --- | --- |
| Proposed → Queued | approved exact task & spec mapping, owner contract, safe deliverables, prerequisites | candidate portfolio score or planner suggestion |
| Queued → Working | current legal role lease, CAS revision, no same-owner collision | role text, stale copied token, non-atomic queue preview |
| Working → Review | final deliverable SHA, negative QA receipt, spec checker, owned lease | checkbox, screenshot, unverified PASS note |
| Review → Rework | independent reproducible failure, task-specific reason, reviewer ID | developer self-review |
| Review → Accepted | actual authorized reviewer, final source QA, MergeIntent + CAS, no known critical finding | peer advisory note, stale QA source hash |
| Accepted → Released | signed/host-verified release actor, real runtime E2E and rollback drill | merged source alone |
| Unknown effect → ReconciliationRequired | journal intent before effect and missing conclusive receipt | repeat a non-idempotent tool call |

### 5.2 Safety invariants

INV-01 Every writer uses a bounded, authorized workspace root; Windows reparse points, junctions, UNC, drive-relative and alternate data streams are checked at trusted execution boundary.

INV-02 A task's scope contains both paths *and* canonical responsibility identifiers. File disjointness alone does not prove safe parallel execution.

INV-03 A reviewer cannot accept authored/coauthored work; Developer 3+4 shared invocation is in the same independence domain.

INV-04 Only one active, current lease epoch can commit a task checkpoint or submit; stale sessions are fenced.

INV-05 An exact idempotency key may map to one stable request digest and one effect identity. Same key + different digest => conflict.

INV-06 Ambiguous external side effects remain UNKNOWN and block replay until independently reconciled.

INV-07 A published artifact's acceptance receipt pins its source/test/spec SHA and reviewer provenance.

INV-08 All required dependent task receipts are accepted *before* dependent admission. Static checklist status is not a dependency proof.

INV-09 Verified unaffected tasks do not inherit a false BLOCKED from one unrelated stale task; unsafely unknown tasks are still blocked.

INV-10 A newly changed canonical source file cannot be accepted using a receipt from an older hash.

INV-11 A missing observed platform run interval is NULL, not estimated as useful runtime or zero runtime.

INV-12 A reviewer cannot create owner grants, and an agent-authored tool result cannot override actual host ACL.

INV-13 All read-only plans/simulations are unable to alter the queue, filesystem or trust store.

INV-14 A complete-looking model answer cannot mark a requirement/test implemented without independent source evidence.

INV-15 All recovery operations are journaled, bounded and reversible where technically possible; irreversible work always needs separate authorization.

INV-16 A stopped scheduled ChatGPT invocation does not imply a crash in external jobs; those jobs need independently observable status.

## 6. Concurrency, consistency and recovery

### 6.1 Coordination model

For the current single Windows host, SQLite with WAL and short explicit write transactions is appropriate. Different SQLite processes share DB-level locking; a file CAS is not part of that DB transaction. Therefore exactly-once multi-resource atomicity must never be asserted. The existing MergeIntent journal bridges that gap. Do NOT assume SQLite WAL makes file renames and external APIs atomic.

Precheck can advise READY, but a real acquire must re-evaluate readiness in the authoritative coordinator and commit lease assignment atomically. A current lease is not an MCP host identity; a host grant is checked separately on each privileged effect.

### 6.2 Fencing

Logical task identity: (project_id, task_id, task_revision).
Attempt identity: (task_id, attempt_id, lease_epoch).
Every write includes lease_epoch and expected task revision; stale attempts cannot commit. Lease expiry uses server-observed time, not untrusted agent workstation clock. External tool jobs need effect identity, host grant and durable idempotency/reconciliation.

For read-only operations, a status snapshot may be stale and should be marked BEST_EFFORT_REVALIDATED. A task mutation cannot use that snapshot as an authorization token.

### 6.3 Fault taxonomy

- SAFE_RETRY: verified no-effect read failed transiently; bounded retries with backoff and latest source SHA.
- IDEMPOTENT_REPLAY: same effect ID and digest has host-recorded committed receipt; return receipt, do not rerun.
- NEEDS_RECONCILIATION: lost response after possible write or interrupted merge; inspect exact journal and file hashes before any action.
- FORBIDDEN_RETRY: destructive/irreversible operation without trusted idempotency and explicit authorization.
- HUMAN_DECISION: conflicting source edits, unexpected current owner, invalid approval, unknown host actor, failed rollback proof.

Unknown/ambiguous is never interpreted as success or no-effect.

### 6.4 Anti-idle without policy bypass

Priority order for a legal developer scheduled run:
A. Own valid active task; if inaccessible due to missing lease token, do not forge it.
B. Different already-approved non-overlapping task with legally acquired lease.
C. Independent peer review under separate peer-only lease (not a formal reviewer acceptance).
D. Architect support with verified foreign-owner scope.
E. Evidence-backed new feature hypothesis, once per canonical wave; evaluate against existing 72-idea portfolio.
F. Honest NO_SAFE_WORK with specific blocker IDs.

When rechecking after work, return to coding when a valid task is actually available. No guaranteed continuous runtime or no-idle pledge is possible if approval, QA or host grants are genuinely blocked.

### 6.5 Backpressure

Define WIP as Working + Review + Rework separately. Proposed dynamic gates: under heavy review backlog, pause *future owner-approved admissions* of additional noncritical tasks, but never prevent accepted task completion or safety-critical repairs. The current queue already exists; gate evaluation must be introduced through approved coordinator change, not advisory side writes.

A non-starving candidate selector uses priority + age + dependency critical path + observed QA risk, subject to ownership and hard constraints. Deterministic tie-break: (priority descending, age descending, task ID ascending). Quantities and weights require fixture benchmark calibration.

## 7. Evidence contract

Evidence is an assertion with a verifier, not a freeform statement. Each required proof item has: evidence_id, event type, task revision, spec SHA, source SHA, test inventory SHA, exact command identifier, execution environment fingerprint, start/end observation, authoritative actor provenance, result PASS/FAIL/UNKNOWN, and confidential-data redaction status.

A QA report saying PASS while independent negative witness for the same exact SHA reports a confirmed critical defect is BLOCKED_DEFECT, not ready.

A report with no actual executed tests is PLANNED_NOT_RUN. Runner exit code 0 needs a typed test result interpretation: some negative tests return 0 **when they successfully reproduced a bug**, not because the candidate passed.

The existing P085 trust gap remains: self-signed hash in user-editable Python files is evidence integrity metadata, not authoritative host attestation.

## 8. Quality evaluation lifecycle

Gate G0: original owner-approved SHALL and exact task mapping.
Gate G1: genuine tool/actor authorization for mutations where required.
Gate G2: responsibility ownership + reuse preflight.
Gate G3: deterministic source/spec hash pinning + static syntax.
Gate G4: focused unit and negative tests for changed area.
Gate G5: full applicable regression tests + spec checker and dependency graph.
Gate G6: independent reviewer and QA provenance.
Gate G7: content-addressed merge + fresh CAS.
Gate G8: Windows host integration + release/rollback proof for privileged changes.

A positive G3 or G4 result never substitutes G6, G7 or G8. Report every gate as PASS, FAIL, NOT_RUN, BLOCKED or NOT_APPLICABLE with a reason; unsupported evidence cannot be represented as PASS.

## 9. Security model / threats

Attacker inputs: prompt-injected README, poisoned task payload, fake reviewer strings, malicious tool output, path-junction substitution, dangerous shell wrapper, forged PASS receipt, replayed lease token, SQLite race, partial copy, malicious dependency and stale cached analyzer result.

Trust zones:
T0: external documents, agent text, proposed feature JSON, model outputs.
T1: authorized workspace source under human-controlled editing, not host-privileged.
T2: coordinator task data with authenticated local write semantics, still not sufficient host principal evidence.
T3: actual MCP host grant enforcement with independently attested caller identity and OS isolation.
T4: independent owner/release boundary with revocation and rollback.

Data should only promote from T0/T1 to a privileged action through T3 + appropriate T4 decision; a read-only planner cannot promote trust by formatting.

Deny-by-default rules apply to arbitrary script runners, Git push, service restarts, Docker socket, PostgreSQL write, approvals, release and desktop capture. Transport reconnect is not re-authentication by itself.

## 10. Architectural decisions (proposed ADRs)

ADR-V3-01 Extend agent_team.py; reject dual coordinator. Rationale: avoids split brain and conflicting leases. Tradeoff: coordinator change sensitivity; use versioned scoped adapters.

ADR-V3-02 Lease epoch plus task revision. Rationale: old invocations can resume read-only but cannot commit. Tradeoff: requires migration and fixtures before production.

ADR-V3-03 Existing MergeIntent for file+DB atomicity approximation. Rationale: durable intent/reconciliation over false exactly-once. Alternative: pretend atomic file and DB writes, rejected.

ADR-V3-04 Real host policy is the only trust authority. Alternative: role fields/Python tokens, rejected as spoofable.

ADR-V3-05 Independent review separated from peer advice. Alternative: allow developers to accept each other's shared-invocation outputs, rejected for independence.

ADR-V3-06 Critical source SHA pinned at validation and publication. Alternative: rely on timestamps/file names, rejected due to TOCTOU.

ADR-V3-07 Structured UNKNOWN states. Alternative: fail open on missing observations, rejected.

ADR-V3-08 Single responsibility owner per module/API. Alternative: ownership by output path alone, rejected due to duplicate code issue.

ADR-V3-09 Read-only, bounded impact and simulation adapters. Alternative: speculative planner writes to live queue, rejected.

ADR-V3-10 Optimize accepted work per reviewer-hour, not prompt volume. Alternative: generate unbounded ideas or tokens, rejected.

ADR-V3-11 Observed run ledger ≠ provider tokens ≠ API what-if dollars. Alternative: blend estimates into billed usage, rejected.

ADR-V3-12 Human-approved canary release with immutable rollback references. Alternative: agent self-upgrade and self-approve, rejected.

## 11. Implementation milestones and stop lines

M0 Baseline snapshots and gap register: read exact source SHA, spec warnings, current ownership and live queue (read-only).
M1 P085 trusted MCP host boundary: instrument real host, prove role forgery/generic runner bypass denied. HARD BLOCKER to production privileged actions.
M2 Validated source/requirement/evidence graph: fix false-positive FR parser; explicitly classify missing FR mappings; no fake checkboxes.
M3 Lease+intent recovery: versioned opt-in fixture schema first; crash and replay tests; no unapproved live DB migration.
M4 Deterministic planner/anti-idle preview: disjoint tasks, fairness and stale source hints, no direct admit.
M5 QA and reviewer throughput: receipt correctness, negative witness, source CAS and distinct independent reviewer.
M6 End-to-end Windows canary: staged owner approval, fault injection, safe rollback, measured key metrics.

Concurrent safe work while M1 pending: source inventory, spec gap analysis, read-only impact graph, synthetic schedule simulation, independent test design and nonprivileged diagnostics. Never call a speculative release production-ready.

## 12. Operational targets (all unmeasured hypotheses until benchmark)

- Zero unauthorized privileged operations in the defined red-team suite.
- Zero accepted tasks with a current confirmed critical defect for exact source hash.
- Zero duplicate external effects in all idempotent replay fixtures.
- Zero self-review acceptances for shared or independent developers.
- 100% of blocked tasks show typed reason and provenance.
- A 10k-node graph finishes under the declared local benchmark budget, otherwise PARTIAL with coverage.
- Reduced p95 review age, rework re-diagnosis and lost-progress-after-disconnect versus matched baseline; quantify only after controlled measured trials.
- No more than one platform scheduled execution counted for the shared Developer 3+4 card.

## 13. Decision log requiring human or measured input

OPEN-01 Host grant model, issuer and revocation authority at real MCP backend.
OPEN-02 Evidence provenance that remains trustworthy if user-editable workspace is compromised.
OPEN-03 Legacy responsibility mappings and scope of migration; no silent retroactive effects.
OPEN-04 Approved schema evolution and recovery operator for current SQLite.
OPEN-05 Negative QA witness classification and independently verified runner origin.
OPEN-06 Deterministic simulation fairness coefficient from representative queue fixtures.
OPEN-07 Actual scheduled runtime ceilings; platform may interrupt any invocation.
OPEN-08 Limit and ownership of source path scanning on Windows junctions.
OPEN-09 External irreversible operations permitted in first canary (default none).
OPEN-10 Owner approval/release path and separate rollback verification.

End-of-document invariant: This design is an *engineering proposal*. The existing owner-approved OpenSpec/SDD, actual host authorization and live queue remain authoritative.