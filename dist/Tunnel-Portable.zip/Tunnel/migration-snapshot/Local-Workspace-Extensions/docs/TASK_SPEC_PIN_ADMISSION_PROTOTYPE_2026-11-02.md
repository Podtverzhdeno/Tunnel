# Task spec pin admission contract — locally implemented prototype

Date: 2026-11-02.
Scope: Local-Workspace-Extensions; no live seed/acquire/review schema mutations.
Status: prototype code + isolated negative/unit tests executed, **not** owner-approved active coordinator deployment.

## Why

The durable five-agent coordinator creates task rows with `agent_team.seed()`; per-task baseline and the original `__spec_sha__` are currently generated only at `_snapshot()` during developer `acquire`. Therefore the system cannot currently detect a source change strictly between initial new-task admission and developer claim. A new aggregate OpenSpec/SDD seed-time pin contract is needed, but must not be silently added to live SQLite without a reviewed cutover.

## What is coded

- `task_spec_pin_contract.py`: `make_pin(project, spec_ref)` builds a deterministic `task-spec-pin-v1` receipt from the existing `spec_traceability.audit_traceability` (single canonical parser and double-read SHA source inventory).
- Each receipt has the exact `spec_ref`, canonical spec path, exact raw-byte spec-file SHA-256, all-specs aggregate SHA-256, source-file count and self-consistency `receipt_sha256`.
- `inspect_pin(pin, current_provenance)` and `recheck_pin(project, pin)` distinguish matching source from stale file or aggregate snapshots; they never claim host authentication, QA execution or approval.
- `preview_seed_pins(project, tasks, existing_ids=...)` constructs deterministic pins for only **new** task IDs from ONE spec audit, failing the batch for missing/duplicated/invalid IDs or source references. Existing ID information is supplied by the caller and is **not authenticated against live SQLite**.
- The module has a read-only CLI producing a pin for an explicit canonical spec reference; it writes no task rows, journals, tokens, leases or files.
- `test_task_spec_pin_contract.py` includes 17 tests (source and aggregate drift, BOM/CRLF, forged receipts, malformed paths, missing source, batch duplicates, one-scan batch, legacy nonbackfill, fail-whole-batch, no database creation).

## Real read-only smoke test

Command:
    python task_spec_pin_contract.py "openspec/changes/local-pc-agent-tooling/specs/agent-orchestration/spec.md / Lease and heartbeat"

Result:
- exit code 0; matching existing requirement
- 12 included source files
- source_snapshot_sha256: 51b5df759bfaa4689eee65ba861fa77fc8021f50d5a58cb5c582c63a348c8825
- receipt_sha256: e30f6f9a4e6a26cd4211eb6be83774b73010c5123a41b2a8c1a23e543e72b4cf
- No task admission, database write or host permission was requested/performed.

## Executed verification

| Command | Result |
| --- | --- |
| python test_task_spec_pin_contract.py | 17 tests, 0 skipped, 0 failed |
| python -m unittest discover -p test_spec*.py | 113 tests, 4 skipped, 0 failed |
| python -m unittest discover -p test_review*.py | 96 tests, 2 skipped, 0 failed |
| python test_agent_team.py | 54 tests, 1 skipped, 0 failed |
| python sdd_roadmap_check.py | exit 0; 58 SDD tasks, structural checks pass |
| python spec_check.py | exit 0; 11 OpenSpec capabilities, 99 requirements, 128 scenarios, 43 FR maps |

Unique nonoverlapping test suites: 17+113+96+54 = 280 test invocations, 7 skipped, 0 failed. The tests establish local code behavior, not independence of the reviewer or actual Windows broker authorization.

## Current SHA-256

- task_spec_pin_contract.py: 3858c76fbaa6d7e8f85f871b22745dfc061fe5cb7a06e89d33aca3ae9ff6f439
- test_task_spec_pin_contract.py: 2d3f8238b5f367d2d38c9a10e9b0728f1420f5e56810e156acd2c4d70b41771f
- agent_team.py remains unchanged: cc4f91dbeb4a8bd9c7e766bcb9dc8fc6c66e55109ba2786fd2db86040291c866

## Proposed owner-reviewed, unimplemented admission integration

1. Add a **dedicated durable task pin contract field** via reviewed, backwards-compatible SQLite migration, rather than repurposing `baseline` (which is currently written at `acquire`).
2. In `seed`, execute one `preview_seed_pins` against the canonical OpenSpec/SDD for new task rows, within the same bounded queue-admission workflow. Verify source snapshot consistency immediately before task admission commit. Insert new tasks and their pin atomically under `BEGIN IMMEDIATE`. On any inconsistency roll back without partial insert. Existing tasks are intentionally `LEGACY_UNPINNED`, not backfilled.
3. At `acquire`, independently capture/recheck current spec snapshot vs stored pin before leasing a newly pinned task; do not silently bypass on file read failure.
4. In `review-preview`, expose `spec_snapshot_sha256` from durable receipt plus exact file snapshot, so existing `review_readiness_matrix` opt-in strict mode can validate it.
5. In direct `review accept`, independently recheck pin and source hashes immediately before privileged accept/merge; a clean advisory preview alone must not authorize acceptance.
6. A changed pin requires separately authorized rebase/review, not retroactive replacement by an arbitrary developer.
7. Independently test concurrent seed vs spec modification, rollback under lease contention, invalid JSON, CLI denial and Windows host actor boundary. Legacy tasks must remain available under the compatibility policy.
8. Perform formal OpenSpec/SDD owner approval for the new coordinator contract and code ownership before activating the migration. The 56 unmapped requirements and P085 trusted broker security remain independent blockers.

## Security and truthfulness

The receipt SHA only proves payload self-consistency. It is not a MAC, digital signature, trusted host attestation or authorization token. Storing a digest in an SQLite row cannot prevent malicious changes by a process with unrestricted host file permissions. The source filesystem can change immediately after a double-read and a later accept requires its own fresh gate. The current prototype cannot claim end-to-end seed-to-review enforcement or production readiness.
