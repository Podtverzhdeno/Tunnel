# P085: Windows isolation — verified preparation and remaining release gates
Date: 2026-11-02. **No production deployment or OS permissions changes.**

## What is implemented
- `p085_windows_deploy_preflight.py` probes *actual* Windows process SID/elevation and conservatively inspects the Python interpreter, broker source and containing directories through the existing Win32 ACL reader. It does not enumerate user accounts, change ACLs or issue credentials. A positive ACL result is never a production authorization.
- `broker_named_pipe.py` now includes `sys.executable` in the protected startup path set; before this, an agent-writable interpreter could run arbitrary code before broker policy validation even if the broker source tree was protected.
- `p085_broker_release_candidate.py` creates an atomic, keyless, content-addressed broker **review candidate**, reusing the current foundation kernel. Exactly Python modules are included, never `.env`, policy files, signing keys, SQLite, tests or local state. SHA-256 binds every module and **all** files in the bundle; extra files or altered bytes make verification fail. Duplicate builds are idempotent; history capped at 40 candidates.
- `p085_autonomous_guard.py --write-report` invokes the new Windows negative-test suite and OS readiness probe and automatically stages a candidate **only after all offline suites and source-stability checks pass**. A staged bundle is not trusted, owner-approved or installable by merely setting a flag.
- The existing Architect Reviewer hourly automation invokes the same controller and receives the new checks automatically. Live queue and host are not modified.

## Observed environment
- Real Windows process SID query: **successful**.
- Current MCP process elevated: **NO**. Cannot install a Windows service/task under a separate built-in account from this process.
- Broker's current Python executable: **not proven OS protected** (conservative ACL gate fails).
- Broker source in project workspace: **not OS protected** (expected; agents have write rights).
- Separate broker OS process / OS principal: **not provisioned**.
- Real two-SID negative E2E / protected signed grant issuer: **not verified**.
- Connected live MCP still advertises **28 privileged tools**. Do not replace the running endpoint with the six-tool observer profile until a separate trusted developer/reviewer broker is in place.

## Candidate and evidence
- Staged candidate SHA identity:
  `73d17d5fcdf8f96c3e29d96b797ccf40d3359b717f92366fac9ae57082f850e6`
- Staging location: `.agent-team/p085-release-candidates/<candidate_id>/` (private, ignored by Git; *not* a protected Windows deployment directory).
- Contains **25 Python modules**, verifiable via `p085_broker_release_candidate.verify_candidate`.
- `.agent-team/reports/P085_auto_latest.json`: last full audit 7/7 suites PASS (including 14 Windows/bundle tests before the final extra-file check). All runtime values are measured and source SHA-bound.
- Финальный повтор после проверки дополнительных файлов: `python -m unittest discover -q` в корне проекта — **1676 tests OK (41 skipped)**. Автономный P085 audit: 7/7 suites PASS, 95 source files SHA-stable, `changed_source_paths=[]`, candidate повторно проверен без дубликата. Это **не** снимает OS-привилегий и reviewer acceptance.

## Intended zero-touch deployment sequence once trusted OS prerequisites exist
1. Independent reviewer freezes and reviews the exact candidate digest. Trusted issuer signs a release / policy **outside the agent-writable workspace**; agent text, SHA-only manifests and project files cannot act as issuer authority.
2. A genuinely elevated, owner-controlled Windows installer creates a separate service principal (for example `NT AUTHORITY\\LocalService`, SID S-1-5-19), and a protected installation area. The installer must use a **trusted OS-protected interpreter or reviewed standalone executable**, never the agent-writable user Python runtime. <https://learn.microsoft.com/en-us/windows/win32/services/localservice-account>
3. Set restricted directory ACLs, verify the true broker token SID, source/runtime parent DACLs and sealed signed-policy revision. Any failure aborts before launching the broker.
4. Run **actual distinct-Windows-SID** Named Pipe negative E2E (wrong client SID, replay, grant expiry, direct file/SQLite write denial). Existing same-SID fixtures do *not* satisfy this gate.
5. Publish separately authenticated developer/reviewer entrypoints and **remove universal `run_script` / `run_command` / arbitrary file writes from their effective agent scope**. Maintain a protected owner/admin repair plane. Never stop the current 28-tool MCP/tunnel before a reviewed, reversible cutover.
6. Only then can release acceptance and trusted auto-merge be considered. The continuous auditor must check all gates; it cannot self-issue grants or override an OS permission failure.



## Periodic installed-stage integrity monitor (2026-11-02)

The stage installer now creates `STAGE_RECEIPT.json` **before**
publishing the protected copy. It contains only schema, pinned
`plan_sha256`, three distinct Windows SID strings, 13 approved code
relative paths and SHA-256 digests, plus constant
`release_approved=false` and `live_mcp_modified=false`. It never
contains private key material or service credentials. The receipt itself
receives explicit SYSTEM-writable-only ACL and is checked after sealing.

`p085_stage_audit.py` is an independent, **read-only** verifier. It
checks the regular root and receipt, exact code inventory (no extra
`.py`, bytecode, DLL, or symlink), all source SHA hashes, and read-only
ACL evidence: SYSTEM ownership and only SYSTEM write permissions on
code, receipt and their subdirectories; the service SID has write rights
only on `private_state/`. It intentionally does **not** open or enumerate
private key/ledger contents. Its return is always
`trusted_deployment_verified=false` and
`auto_merge_authorized=false`, even when structure and ACLs appear
correct.

The periodic `p085_windows_deploy_preflight.py` now includes a
`stage_health` field. `NOT_STAGED` is the current factual status;
a later `BLOCKED`/bad-location state adds
`P085_STAGED_CODE_INTEGRITY_UNVERIFIED` to the autonomous P085
risk report. The existing Architect Reviewer hourly schedule runs this
through `p085_autonomous_guard.py --write-report`; no new slot or
manual monitoring is needed.

**Security limits:** the stage receipt is generated by source code still
in the agent-editable workspace; it is **not signed owner attestation**
and cannot establish trusted provenance, actual service-account token,
child dependency integrity, deny-read rights, or separate-SID negative
E2E. The verifier can optionally compare the plan hash to an
independently retained expected hash, but the standard agent audit
doesn't possess such a protected owner pin. Consequently it remains an
advisory fail-closed monitor and can never itself authorize service
start, grants, owner cutover or merge. A partially staged directory
must never be activated even if it has a plausible receipt.

**Current hard blocker:** the connected agent process is **not elevated** and cannot create a protected Windows principal/interpreter. This requires an owner-controlled elevated installation context (at least one OS elevation approval). There is no valid software-only workaround under the same Windows user SID. No manual action is needed to continue *routine QA and candidate staging*.

## Added host-hardening: immutable code vs. mutable state (2026-11-02)

A writeable broker journal and an immutable broker executable are **different
trust domains**. Earlier `preflight_isolation` allowed the broker account to
write any protected path, including its own interpreter/source. Now
`immutable_code_paths` performs a *separate strict DACL test*:
- **SYSTEM** must own the broker Python executable and every immutable source
  module and their parent directories (under the conservative supported ACL
  subset). Only **SYSTEM** may have a write/owner/delete ACE on those paths;
  the broker SID, reviewer SID, worker SID, `Everyone` and Administrators
  write ACEs are all rejected. A different trusted Windows packaging strategy
  would need an independently reviewed exception, not relaxation by agent.
- Broker's private journal, outbox and policy runtime roots remain protected
  under the existing broker/SYSTEM write policy. Neither identity may be
  conflated with the agent account.
- At production startup, `broker_named_pipe.py` enumerates every non-test
  `*.py` module in its adjacent kernel directory and the actual `python.exe`,
  requiring all to be included in the protected-path preflight. Bounded
  limits: <=60 immutable module paths and <=64 total protected paths.
- Direct production broker startup without Python's `-E -s` flags now
  fails. `broker_supervisor._command` supplies these flags to the *child*
  so attacker-controlled `PYTHONPATH` and user site packages are not loaded
  by that child. These flags are only minimum hardening: the **supervisor**
  also needs a protected, sanitized OS launcher and the global Python/site
  package runtime must be protected and independently reviewed.
- The dedicated negative suite `test_p085_immutable_code_acl.py` covers
  agent/service writable code, untrusted owner, missing protected path, and
  module count limits. `test_p085_broker_runtime_boundary.py` ensures the
  actual broker inventories its `host_gate`, `journal`, `signed_policy`
  and other sibling modules, and denies unsafe Python startup.
- `p085_autonomous_guard.py` includes the immutable-code ACL tests in the
  recurring `windows-bootstrap-negative` suite; no new scheduler slot or
  owner action is necessary for this QA work.

### Interaction with separately developed reviewer staging installer

`Install-P085ProtectedService.ps1` remains an **owner-only source-copy
staging script**, **not** a service installer, trusted issuer, or production
authorization. Its updated `p085-code-stage-plan-v2` has two disjoint
protected directories: `code/` is SYSTEM-owned and writeable only by SYSTEM;
`private_state/` is SYSTEM-owned, writable by the named service SID and
SYSTEM, and initially empty. Reviewer and worker identities are pipe peers
and receive no file write grants. Administrators are given read/execute,
not explicit code write permissions. Neither a code-only stage nor an
offline ACL test verifies a real isolated Windows service.

The default mode prints the source/destination/SID-bound
`plan_sha256` and changes nothing. Elevated `-Apply` requires the
**same externally reviewed plan hash**, an interactive owner foreground
confirmation, a new destination below ProgramData, and post-copy hash and
DACL checks. It refuses an existing directory and never creates keys,
signing credentials, service registrations, auto-merge, or an MCP cutover.
It copies to a random staging directory and moves it to a new final
destination *before* sealing ACLs (an elevated administrator could not
rename it after SYSTEM-only sealing without bypass privileges). A crash
between publication and sealing can leave an **incomplete, untrusted**
directory. That directory must NEVER be used by a service. The script
fails closed, warns for manual cleanup and refuses to overwrite it; it does
not pretend this sequence is an atomic security transaction.

`mcp-host-source/p085_reviewer_service.py` and the canonical
`owner_cutover_gate.py` now resolve `private_state/` as a sibling of
the staged `code/` folder; legacy disposable-test layouts still use
`p085_private/`. Tests check both layouts and refuse silent fallback to
the old private path in a v2 installation.

**Important:** the source tree and installer script are still editable by
the untrusted agent account. A malicious modification to the installer
itself is not prevented by its own hash calculation. Before ANY elevated
execution, the owner must independently review a pinned script and
source digest in an OS-protected launch location (outside IdeaProjects).
An owner approval of a past OpenSpec request is **not** this authorization.
The installed runtime, dependency directories and real Windows service
token must independently pass ACL/SID checks, negative two-principal E2E,
signed grant issuer checks, and live MCP reduction before deployment.

Even a green code/ACL preflight is **not proof** of two-SID E2E, protected
issuer keys, safe import of third-party compiled extensions, trusted
reviewer acceptance or removal of the legacy privileged MCP gateway.
All those gates remain OPEN.

## Stage ACL read/execute and deny-ACE checks (2026-11-02)

The read-only Win32 `inspect_acl` now exposes
`read_execute_allowed_sids` (explicit basic allow ACEs for BOTH
read/list and execute/traverse) and `has_deny_aces`. The periodic
`p085_stage_audit.py` requires a service SID read/execute allow ACE
on staged code, receipt, parent directories and private-state root.
A missing allow ACE, missing/unknown ACL evidence, any deny ACE, or a
reparse-point staging path is `BLOCKED`, not successful stage
inspection. Tests include empty/missing read grants, deny ACEs, unknown
interpretations and dangling symlinks.

This is intentionally **not an effective-access proof**: membership in
nested Windows groups, dynamic privileges, deny interactions outside the
audited ACLs, Python dependencies, process token identity and real
read/traverse/write operations require separate cross-principal E2E.
No production setup, owner grant, service or MCP cutover occurs as a
result of a green stage-audit report.


