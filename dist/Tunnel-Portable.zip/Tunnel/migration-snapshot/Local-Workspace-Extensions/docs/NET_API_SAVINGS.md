# Economics: avoided API charges vs one fixed ChatGPT Plus subscription

This is a **management what-if**. ChatGPT scheduler provider usage is unobservable. The forecast model gpt-6-sol is a pricing assumption, not verified execution identity.

## Three quantities that must never be confused

1. **Gross avoided API spend for OBSERVED runs:** hypothetical API cost from uncalibrated token estimates, if the identical scheduled work had otherwise used billable API. This is an **opportunity-cost counterfactual**, not refunded cash or a provider invoice.
2. **Cash subscription:** fixed $20 per month in the owner's model. Paying for more eligible runs within ChatGPT Plus does **not** add $0.05 per minute to the bill. $0.05/minute and $1/session are ALTERNATIVE budgeting allocations, not incremental spending.
3. **Net vs API for an ENTIRE billing cycle:** API equivalent for that same complete cycle minus $20. **Unknown when the source history is partial.** An observed subset cannot establish net monthly savings; do not extrapolate without warning. If Plus was bought anyway for other use, it is reasonable to describe the subset's avoided API charges and zero marginal extra cash, rather than charging it again $20.

Formula at zero assumed cache:

```text
hypothetical_api_usd = input_tokens_estimated*2/1e6 + output_tokens_estimated*10/1e6
gross_avoided_api_usd = hypothetical_api_usd for observed eligible runs
full_cycle_net_vs_api_usd = hypothetical_api_usd_full_cycle - 20
```

For the currently observed **11 unique runs** (not full billing history), estimated input ≈266252 and output ≈51519 => GPT-6 Sol API equivalent **$1.047694** (displayed ~$1.05); incremental Plus charge if already paid **$0**, while monthly fixed cash price remains **$20**. The *hypothetical* result of using only those runs for the entire paid month would be **−$18.95** vs API; **this is not a measured monthly profit or loss**. If all runs were similar, crude break-even ≈210 runs/month; that extrapolation ignores subscription access limits, workload mix, missing model usage and quality.

## CLI

```powershell
python economic_savings_kpi.py --api-report .agent-team/reports/api_token_cost_latest.json

python team_run_metrics.py --observations .agent-team/reports/scheduler_run_history.json --month 2026-11 --estimate --api-pricing --subscription-cost --savings
```

Only if the **owner independently established complete coverage of the actual subscription billing period** and comparable runs may `--complete-billing-cycle` be supplied. `--month` groups UTC calendar time and is **not** an attestation of a billing cycle. `monthly_net_savings_usd=null` is correct until evidence exists.

Caveats: actual ChatGPT requests are not necessarily billed as GPT-6 Sol API; hidden reasoning, tool context, cache, retries and internal routing are unknown. The current API estimate may be wrong by more than ×2. The analytics module does not perform money transfers, purchase an API key or change scheduled model effort.

**Product priority:** this KPI must never block the agents from writing spec-approved software, and is subordinate to the OpenSpec/SDD dependency DAG, leases and independent QA.
