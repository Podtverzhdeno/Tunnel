# Responsibility gate rollout (OpenSpec 004, 2026-11-02)

**Status:** approved OpenSpec/SDD and implemented gates for **newly seeded** coding
tasks in `agent_team.py` and `agent_responsibility_guard.py`.
Existing task rows P009–P161 and any other task IDs first seeded before this
cutover are explicitly **grandfathered**: their SQLite leases, workspaces and
acceptance history were not rewritten. Do not represent legacy tasks as mapped.

## New owner-ready task contract

A new `team_seed.json` entry requires a `responsibility` object. It is supplied
by the architect/owner-reviewed task brief, **not guessed from the filename**.
Example (illustrative only; not an approved queue ticket):

```json
{
  "id": "example-parser",
  "module": "example_parser",
  "public_api": "parse_records",
  "role": "owner",
  "reuse_decision": "PROPOSE_NEW_RESPONSIBILITY",
  "inputs": "Validated bounded record list",
  "outputs": "Immutable normalized records",
  "errors": "Typed errors with no partial writes",
  "scaling": "Linear number of bounded records",
  "depends_on": [],
  "allowed_extensions": ["example_parser.py"]
}
```

The task's `deliverables` must include `example_parser.py` and a separate
test file. The owner module must be inside `allowed_extensions`; a `consumer`
must instead use `REUSE_EXISTING` and may **not** modify the canonical owner
module. If there is a known accepted previous owner for the same responsibility
ID, the new owner must provide `handoff_from` pointing to that task ID, and
that predecessor must have an independent architect acceptance receipt.

Before implementing: run `task_reuse_preflight.py Pxxx`, inspect the actual
canonical source and approved task contract. The developer's `acquire` output
now includes `task.responsibility`, if mapped. In `quality_submit.py`
evidence notes cite the **exact** `reuse_decision` and `module`, plus tests
and rationale; otherwise `agent_team.submit` returns
`REUSE_EVIDENCE_REQUIRED`. Preflight and contract metadata are not proof of
semantic uniqueness or a trusted actor.

## Enforcement points

1. `seed`: new task without metadata fails after cutover, before any SQLite
   insert. Contract validation and owner uniqueness execute in one SQLite
   `BEGIN IMMEDIATE` transaction. A failed batch rolls back completely.
2. `plan-work` and `acquire`: recheck stored contract owner collisions. A
   disjoint task remains eligible when another task is blocked; no stolen lease.
3. `submit`: recorded contract's precise reuse disposition and module must be
   included in developer evidence. This is only review evidence, not acceptance.
4. `review-preview` and **direct** `review accept`: compare candidate source
   imports with the live root-level Python graph and registered dependencies,
   check declared canonical API and veto introduced import cycles. Exact clone
   veto remains independent and runs before merging.
5. `owner_queue_admit.candidate_preview`: uncontracted new candidates become
   blocked entries instead of requesting foreground approval and failing after
   the owner already typed ADMIT. Owner approval is still required for queue
   admission. The current P162+ reserve is not silently migrated or assigned
   invented responsibility contracts.

## Proposed reserve wave P162–P169 (not admitted)

The candidate pool now contains **eight explicit proposed responsibility contracts**
in `experiments/chat_only_run/queue_supply_candidates_backlog.json`.
These are proposals only, not owner-approved SDD rows. The read-only review
plan `requests/p162-p169-responsibility-migration-review.json` is SHA-256
bound to the exact pool bytes; the architecture regression
`experiments/chat_only_run/test_candidate_responsibility_review.py`
checks the eight contracts, disjoint deliverables and canonical source APIs.

- P162 consumes `spec_traceability.audit_traceability`; P163 consumes
  `token_usage_export.export_reports`; P167 consumes
  `team_acceptance_audit.audit_acceptances`. They must **import** their existing
  canonical module in the submitted production candidate. The direct review
  now blocks `CONSUMER_MUST_IMPORT_CANONICAL_OWNER` if they do not.
- P164 (synthetic redaction regression), P165 (read-only ledger chain),
  P166 (queue-capacity advisory), P168 (approval denial test vectors) and
  P169 (trace saturation counter alarms) declare distinct proposed owners.
  Their reviewer must check real semantics against related accepted modules;
  a new filename or responsibility ID alone does not prove novelty.
- P169 has a new dependency on accepted P153 trace retention work; P153's
  independent acceptance must be verified, not inferred from its name.
- **No new P162–P169 queue task was admitted.** These IDs are absent from the
  authoritative `specs/001-local-pc-agent-tooling/roadmap_tasks.json`.
  `owner_queue_admit` now reports each as
  `SDD_AUTHORITY:SDD_ROADMAP_UNMAPPED_Pxxx` in read-only preview, rather
  than raising an opaque error or soliciting premature owner approval.
  Independent review of exact SDD requirement mappings and the distinct
  task scopes must precede a separately permitted roadmap update.
  Foreground owner admission remains a separate final gate.

## Risk boundary and future hardening

The source graph is static and root-level, bounded to 350 modules and
2 MiB/source. Dynamic imports, plugins, cross-language imports and semantic
equivalence require architecture review; a PASS is not a universal uniqueness
guarantee. Existing uncontracted accepted modules remain a blind spot for
responsibility-ID collisions until reviewed mapping is authorized. P085 MCP
actor authentication remains unresolved, so typed role strings do not
authenticate a human. SQLite acceptance receipts are coordinator-local
evidence, not external cryptographic attestation.

Rollback without touching live SQLite: a separately approved change can
disable new task admissions or restore the previous coordinator files using
known source SHA fences; existing `task_responsibilities` rows must be preserved
and reconciled, **not truncated or silently removed**. Do not auto-restore,
reseed, revoke leases or create a fresh reviewer approval to silence a blocker.

## Reproduction

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python -m unittest test_agent_responsibility_integration -v
python -m unittest test_agent_reuse_integration test_code_reuse_guard -q
python -m unittest discover -q
python spec_check.py
```

`openspec validate add-agent-code-reuse-governance --strict` and
`ops.py spec_validate Local-Workspace-Extensions add-agent-code-reuse-governance`
verify the canonical new change. Source integration into production
review/accept still requires independent architect QA and real live task
evidence; synthetic unittest mocks are not release approval.
