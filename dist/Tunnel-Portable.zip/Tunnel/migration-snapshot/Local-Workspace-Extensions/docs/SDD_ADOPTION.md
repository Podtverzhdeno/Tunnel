# OpenSpec + GitHub SDD adoption

## Canonical source of truth

- `openspec/config.yaml` selects the official `spec-driven` OpenSpec workflow.
- `openspec/changes/local-pc-agent-tooling/proposal.md`: motivation, scope and capability list.
- `openspec/changes/local-pc-agent-tooling/specs/*/spec.md`: **only normative behavior**.
- `openspec/changes/local-pc-agent-tooling/design.md`: trust boundaries and ADRs.
- `openspec/changes/local-pc-agent-tooling/tasks.md`: implementation source of truth for P001–P032.
- `specs/001-local-pc-agent-tooling/spec.md`: Spec Kit-style user stories, FR crosswalk and success criteria.
- `specs/001-local-pc-agent-tooling/plan.md`: engineering plan.
- `specs/001-local-pc-agent-tooling/tasks.md`: phase gate tasks, each traceable to FR IDs.
- `.specify/memory/constitution.md`: policy, quality requirements and project governance.
- `spec_check.py`: offline structure, crosswalk and task-reference validator.

## How to use

1. Describe change → OpenSpec proposal and delta scenario requirements.
2. Review the exact scenarios and risk model before implementation.
3. Map change to SDD user story and requirement ID.
4. Plan in OpenSpec design and SDD plan; update task status only after evidence.
5. Implement in isolated working directory; run focused unit tests and live E2E.
6. Run `python spec_check.py` and `python -m unittest discover`.
7. Have a reviewer verify tests and the real MCP server.
8. Archive the OpenSpec change only after acceptance and appropriate CLI verification.

The two systems should not create two complete independent sets of normative requirements; the SDD side only indexes and evaluates OpenSpec requirements.

## External CLI status

Neither `openspec init` nor `specify init` has been executed in this project. OpenSpec CLI **1.14.3** was already installed on the Windows host; on 2026-11-01 the live command `openspec validate local-pc-agent-tooling --strict` completed with exit code 0 and output `Change 'local-pc-agent-tooling' is valid`. This confirms OpenSpec schema validity for that installed version; it does **not** install agent slash commands or validate implementation. `specify` (GitHub Spec Kit CLI) is not present on PATH; its own CLI/skills are not yet tested.

References:
- https://github.com/Fission-AI/OpenSpec
- https://openspec.dev/docs/schemas/spec-driven
- https://github.com/github/spec-kit
- https://github.github.com/spec-kit/quickstart
