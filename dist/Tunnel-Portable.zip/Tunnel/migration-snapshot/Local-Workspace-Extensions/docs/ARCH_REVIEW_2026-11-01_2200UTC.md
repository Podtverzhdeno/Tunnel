# Architect Reviewer — second-wave QA and safe remediation (2026-11-01 ~22:00 UTC)

## Verified live state
Local Workspace alias `projects` available. Reviewer `acquire` returned task=null; no review lease, no accept/reject or reviewer checkpoint. SQLite overview at 21:54:39 UTC: P108 developer-1 working (lease until 22:04:52); P125 developer-2 working (22:17:48); P111 developer-4 working (22:15:34); P110 available and unowned; P096 developer-3 working (22:15:23). Do not reuse these historical deadlines as current authority: reread overview and task history.

P104/P105/P106/P107 are done with recorded_pass QA acceptance evidence; acceptance audit reported recorded_pass=7, legacy_unverifiable=7, invalid_evidence=0. No host actor authentication, OS sandbox, or production grant is established.

## Reproduced sandbox QA blocker and precise cause
Main `team_seed.json` SHA cba7176a28669d7f781d9bcb2e192c84217422c2b8925cbfd754ace8fc66dc42 and `roadmap_tasks.json` SHA 7fd01584435df84e7adda5479c16d2e9cb43b989373a11cbcd1a7a349d60512d are BYTE-IDENTICAL to the P108/P125/P111 sandboxes. The mismatch is instead `test_sdd_roadmap_check.py`: main SHA abaa8d70cc77c2bd4bc68f8d05e792282e9835c0a463ef450aae22b01b0da022, all three sandbox SHA 5222f152e987df920633a0c48f8925f5f8778e845141fd6d345b3be27e4f355e.

The older sandbox test incorrectly demands the *main-only* SQLite `acceptance_records` in isolated developer snapshots, where that DB intentionally does not exist. Independently reproduced P111 `python -m unittest test_sdd_roadmap_check -v`: 16 tests, 1 FAIL, exit=1, with DEPENDENCY_NOT_ACCEPTED_P108_P104, P110_P106, P111_P104, P125_P105. A full sandbox discover also reproduced 838 tests, 23 skipped, 1 FAIL, exit=1. This is NOT evidence that accepted predecessors are missing from canonical SQLite.

Main test was corrected after sandbox creation: `test_real_project_roadmap_matches_seed_and_requirements` skips when main SQLite evidence is absent, while main project still executes a real-DB integration check. The skip is explicit and must not be called live QA.

## Authorized remediation — do not modify developer deliverables
Only the **current task owner holding its own valid lease token** may invoke:
`agent_team.py sync-sandbox ROLE TASK_ID ACTIVE_LEASE_TOKEN`
for P108/P125/P111, using Local Workspace run_script with project cwd, then poll completed/returncode=0 and parse job_output. This existing command CAS-checks unchanged non-deliverable Python snapshots, preserves the assigned two Python deliverables and canonical OpenSpec, and refuses unexpected sandbox edits or pending merge intent. Do not copy SQLite or forge QA receipts. Do not run the command with an expired, other-task or reviewer token; after lease expiry use only legitimate reacquisition. If sync reports conflict, preserve files and escalate exact error instead of overwriting. Re-run focused negative tests, FULL sandbox unittest, spec_check and OpenSpec strict; only then checkpoint-file and submit. Reviewer must still perform independent source inspection, review-preview, merge-status, sandbox QA and post-accept evidence audit.

Verified current candidate focused suites: P108 57 PASS (exit 0), P125 59 PASS (exit 0), P111 49 PASS (exit 0). These are preliminary and NOT accepted. Main `agent_team.py gate-check`: 790 unittest with 23 skipped (exit 0), spec_check 99 requirements/128 scenarios (exit 0), OpenSpec strict (exit 0). Main `sdd_roadmap_check.py`: 44 roadmap tasks, 8 seeded-ready, 4 seeded after recorded QA, 36 blocked, 0 errors.

## P096 and P110: independent work, coordinator starvation
P096 working under developer-3 lease but candidate deliverables diverge from canonical main: `agent_team.py` main c6dd768ffa068b44d5212c679fab38e434f971e551d45384e3f3c8bcc6b2cdb9 vs candidate ef09564998b2904525612a3310a84176f48cb2057b8c71b45037c1195d9d9a4d; `test_agent_team.py` main 7904f80e712ea2da2b10d8ae3141296bebfee206ade25f458ff0e54059e7ed6e vs candidate 4f0117ff27f40374afee0cae7356252611b40972cc31a97a82393bcda68b2337. Main has working sync-sandbox and acceptance_records; do NOT merge stale P096. `rebase-spec` already happened on 20:56:28 UTC and only updates reference docs, not Python baselines.

P110 is independently admitted and available, with unique `crash_reconcile_plan.py` and `test_crash_reconcile_plan.py`, predecessor P106 recorded_pass. But current `acquire` prefers the owned P096 rework to new P110, and CLI has no park/supersede/select-task action. Do not steal leases, mutate SQLite, submit P096 just to clear queue or claim P110 work. Reviewer/owner must separately approve a fail-closed, auditable parking/supersession/explicit-task acquisition contract against the latest main baseline before implementing it; this document is not such approval. Meanwhile developer-3 may perform read-only P110 test-plan preparation.

## Independent review risks and DoD
P108 is an offline caller-supplied host actor/grant shape validator, not host-attested authorization. P111 is advisory DENY/REVIEW text classification, not a security enforcement point; obfuscation and false negatives remain. P125 uses owner-supplied unverified tariff and caller-reported usage, not actual billing. All require independently reviewed negative cases, source SHA preconditions and complete QA after snapshot sync. P085 host role identity, true sandboxing, native MCP integration and production S1/S5 remain OPEN. No new tasks seeded, no specs altered, no source merged during this review.
