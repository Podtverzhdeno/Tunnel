# Контроль пятиагентной OpenSpec + SDD команды — 2026-11-01, ~14:57 UTC

## Изменения текущего этапа

1. В `agent_team.py` появилась команда `checkpoint ROLE TASK_ID LEASE_TOKEN REQUEST_ID JSON` — сохраняет в SQLite ограниченные структурированные записи `done`, `next`, `tests`, `blockers`. Проверяет активную роль и lease, использует идемпотентный request ID, отслеживает автора и UTC-время. В `status` появляется `latest_checkpoint`, в `history` — последние 20 чекпоинтов.
2. Добавлена `agent_team.py overview`: задача/владелец, последние timestamps UTC, минуты после последней активности, lease deadline, checkpoint next steps и alerts для истёкших lease, review старше часа и rework.
3. Спецификации OpenSpec/SDD обновлены требованием `FR-037 / Idempotent task progress checkpoint`, а в backlogs добавлены P079, P080 и P083.
4. Промпты всех четырёх ежечасных автоматизаций дополнены обязательным чтением предыдущих чекпоинтов и `overview`, сохранением промежуточного состояния при незавершённой задаче, и явной фиксацией фактических тестов.
5. Проверена запись и запуск Local Workspace `unittest` внутри скрытого каталога `.agent-team`: один тест прошёл; временный probe помещён в обратимую корзину.
6. Тест `test_real_acceptance_gate_in_disposable_project` прошёл с настоящими subprocess `unittest discover`, `spec_check.py`, `openspec validate --strict`. Файлы были перенесены из изолированной копии только в disposable temporary project, не в основной проект.

## Конкурентная работа

В 14:47–14:52 UTC реально выполнялся Architect Reviewer через расписание, проверил очередь, обнаружил два HIGH-риска и добавил архитектурную задачу P081 и связанный документальный контракт. Наше дополнение к task tracker ошибочно переиспользовало P081; структурный checker обнаружил коллизию `DUPLICATE_OPENSPEC_TASK: P081`. Конфликт исправлен без удаления чужой задачи: документальная задача по dashboard перенумерована в **P083**. Повторные quality gates стали зелёными.

**Открытый риск P081:** действующий CLI доверяет строке `architect-reviewer`, а multi-file merge может оказаться частичным при crash между заменами файлов и SQLite commit. Это НЕ исправлено в текущем этапе и требует server-side authenticated actor и crash-consistent merge journal. Не считать текущую SQLite ролевую проверку OS-level security enforcement.

## Фактические результаты после устранения конфликта

| Команда | Наблюдение |
| --- | --- |
| `python -m unittest discover` | 140 tests total; **137 PASS, 3 SKIP**, exit code 0 |
| `python spec_check.py` | 10 capabilities, 91 normative requirements, 98 scenarios, 37 SDD FR mappings, 37 SDD tasks, 84 OpenSpec P tasks, 0 errors |
| `openspec validate local-pc-agent-tooling --strict` | PASS, версия OpenSpec 1.14.3 |
| `python agent_team.py gate-check` | PASS: unittest + spec_check + actual OpenSpec strict |
| `python run_mcp_wire.py` | PASS: 16 real MCP stdio checks, no errors |
| `agent_team.py overview` | PASS: четыре задачи `available`; Architect Reviewer `sessions=1`, last activity `2026-11-01T14:48:39+00:00`; developers `sessions=0` |

## Расписания

4 hourly cards / 5 roles, как и ранее: developer-1 :10, developers-3+4 :20 (последовательно), developer-2 :30, reviewer :50 UTC. Ещё одна активная карточка — пользовательский мониторинг IT/AI-сертификатов; из-за лимита 5 активных автоматизаций не отключалась. Запланированные developer-карточки включены, но их **реальное выполнение и выдача кода пока не подтверждены**.

## Следующая проверка по живым результатам

При следующем запуске разработчиков проверять `agent_team.py overview` и `history TASK_ID` на возникновение задач со статусом working/review, реальных чекпоинтов, файлов в Sandbox и реальных тестов. Для ревью — не выполнять merge до устранения HIGH P081 либо явно признать, что ролевое разделение логическое, а операция с несколькими файлами не crash-atomic. Не выдавать unit tests за защиту привилегий Windows.
