# Доступ к исходникам работающего Local Workspace MCP-host

**Историческое состояние до импорта:** в проекте была частичная копия `host_snapshot/` из четырёх файлов.
Это **не** проверенная текущая копия всего работающего сервера. Реальный
сервер расположен (по ранее использовавшемуся пути) в
`%USERPROFILE%\\Downloads\\local-workspace-mcp`, вне единственного
разрешённого для чат-плагина workspace `projects`.

**Состояние после импорта (2026-11-02):** владелец перенёс 12 Python-файлов в `mcp-host-source/` с SHA-манифестом. В копии подготовлен `observer`-профиль (6 инструментов чтения), негативные HTTP-тесты и сохранён ревью-патч `host_patches/P085_observer_profile_review.patch`. Исходники запущенного сервера и туннель не изменены; P085 остаётся открытой до OS/host identity + grants. Отчёт: `docs/P085_MCP_HOST_ACCESS_IMPLEMENTATION.md`.

## Однократный доступ без расширения прав плагина (уже выполнено)

В **собственном PowerShell владельца**, из
`C:\Users\user\IdeaProjects\Local-Workspace-Extensions`:

```powershell
python .\mcp_host_source_import.py
```

Этот шаг выполняет пользователь, **не** агент через Local Workspace MCP.
Код скрипта лежит в проекте и протестирован на локальных fixture (6 тестов;
проверка Windows symlink может быть пропущена при отсутствии привилегии).
Импорт **только** исходников `manage.py` и файлов `*.py` под
`workspace_mcp/` и, если есть, `tests/`. Никаких `.env`, JSON с
настройками, приватных ключей, журналов, SQLite, токенов или сохранённых
пользовательских данных не переносится.

Результат: `Local-Workspace-Extensions/mcp-host-source/`, с
`SOURCE_MANIFEST.json`, исходными SHA-256 и отметкой
`live_host_integrated=false`. Путь добавлен в локальный `.gitignore`,
поэтому не должен попадать в массовые Git-коммиты.

- Никакого рестарта сервера, изменений конфигурации, ACL, учётных записей
  или туннеля.
- Если каталог `mcp-host-source/` уже существует, импорт откажет вместо
  перезаписи изменённых пользователем исходников.
- Если истинный исходный каталог расположен иначе:
  `python .\mcp_host_source_import.py --source "ПОЛНЫЙ_ПУТЬ_К_КАТАЛОГУ"`.
- Любая ошибка import означает, что **полный** доступ ещё не получен.

## После копирования

1. Агент читает `mcp-host-source/manage.py`,
   `mcp-host-source/workspace_mcp/http_server.py`,
   `mcp-host-source/workspace_mcp/tools.py` и зависимые модули
   `config.py`, `files.py`, `jobs.py`, `audit.py`.
2. Сверяет SHA копии с четырьмя файлами `host_snapshot/`, выделяет
   существенные различия и составляет **read-only** угрозы P085.
3. Вносит исправления только в **проектную копию**, с автономными тестами,
   запретом self-grants и negative cases, избегая нарушения активных leases.
4. Перед заменой *реального* сервера необходим отдельный точный
   user-reviewed foreground rollout с резервной копией и откатом; нельзя
   заменять запущенные файлы из чат-инструмента или отключать защиту.
5. Для достоверной проверки host-level actor authorization придётся
   независимо проверить OS process identity, ACL, runtime tool registry и
   запрет универсальных privileged command tools. Статический исходник
   и тестовая копия не являются такой проверкой.

**Проверенный в snapshot пробел:** `dispatch(registry, ...)` принимает
`tools/call` и вызывает `registry.call(name, arguments)`. Реестр
`ToolRegistry.call` проверяет типы аргументов и логирует мутации, но
не устанавливает доверенный authenticated actor или scoped grant перед
вызовом `run_script`, `run_command` и записью файлов. P085 остаётся
открытой до реальной проверки и установки host-side permissions.
