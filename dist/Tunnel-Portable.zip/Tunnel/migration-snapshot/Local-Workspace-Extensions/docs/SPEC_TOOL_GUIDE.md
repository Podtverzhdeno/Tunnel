# Создание OpenSpec + SDD из ChatGPT через Local Workspace MCP

## Что реализовано

Локальный инструмент `spec_tools.py` подключён к `ops.py`. Он превращает **структурированный бриф с уже сформулированными агентом требованиями** в полный набор OpenSpec change и GitHub Spec Kit-style SDD Markdown. Генератор не вызывает LLM внутри Python: качество самих требований зависит от работы агента и последующей проверки пользователя.

В текущем Local Workspace доступны команды предпросмотра, проверки и отдельной очереди согласования через `run_script`:

| Action | Параметры | Результат |
| --- | --- | --- |
| `spec_preview` | путь к JSON-брифу | Предпросмотр путей, FR/сценариев, SHA-256 плана; без записей |
| `spec_request_prepare` | JSON-бриф, `--expected-plan-sha256 <hash>` | Создаёт ожидающий запрос на подтверждение, без записи файлов проекта |
| `spec_request_status` | `request_id` | Состояние подтверждения и выполнения |
| `spec_report` | проект, change, необязательный `--strict` | Анализ качества ТЗ: SDD-связи, недостающие проверки, незавершённый дизайн, факты vs. допущения |
| `spec_request_execute` | `request_id` | Создание после одобрения в локальном терминале, OpenSpec strict + SDD проверка |
| `spec_validate` | проект, change | Повторная строгая проверка OpenSpec в выбранном проекте |
| `spec_status` | проект | Список изменений и SDD feature-пакетов |

Точными аргументами MCP `run_script` являются `workspace="projects"`, `path="Local-Workspace-Extensions/ops.py"`, `cwd="Local-Workspace-Extensions"`, `args=[...]`; затем нужно получить результат через `job_status` и `job_output`.

В `mcp_adapter.py` также подготовлены три **только читающие** нативные FastMCP-tools: `spec_change_preview`, `spec_project_status`, `spec_change_validate`. Регистрация в работающем MCP-сервере НЕ выполнена, так как исходный код сервера сейчас вне доступного workspace. `spec_change_create` намеренно не регистрируется без доверенного серверного механизма подтверждения — одного `--apply` недостаточно, чтобы защитить ПК от несанкционированных операций.

## Полный цикл для агента

1. Уточнить исходную задачу: цели, границы, затронутый проект, возможные ошибки, негативные сценарии, тесты. Не придумывать факты о существующем коде.
2. Сформировать валидный JSON-бриф: `project`, `change`, `title`, `problem`, `outcome`, `capabilities`, необязательные `constraints`.
3. Сохранить бриф в разрешённый workspace, например `Local-Workspace-Extensions/requests/<change>.json`.
4. Вызвать `spec_preview` и показать пользователю предполагаемые файлы и ключевые требования.
5. Вызвать `spec_request_prepare <manifest> --expected-plan-sha256 <hash>`; получить `request_id`. Владелец подтверждает в настоящем локальном Windows Terminal командой `python owner_approve.py <request_id>`.
6. Вызвать `spec_request_status <request_id>` и затем `spec_request_execute <request_id>`. Прямой `spec_create --apply` больше не выполняет запись. Дополнительные проверки прав в исходном MCP-сервере всё ещё необходимы.
7. Убедиться, что ответ содержит `created=true` и `validated=true`, а `openspec validate --strict` действительно завершился кодом 0.
8. Открыть созданные `proposal.md`, delta specs, `design.md`, `tasks.md` и SDD пакет. Отдельно доработать оставшиеся `TBD`, особенно технический дизайн, риски и план тестирования.
9. При готовности к реализации отработать задачи по чек-листам и прикрепить фактические тестовые результаты. Не ставить выполнено на основании одного создания файлов.

## Пример корректного JSON-брифа

```json
{
  "project": "my-project",
  "change": "add-webhook-retries",
  "title": "Повторы отправки вебхуков при временных ошибках",
  "problem": "Неуспешные сетевые вызовы теряются и не имеют явного повторного выполнения.",
  "outcome": "Система повторяет только временные ошибки и сохраняет проверяемые результаты каждой попытки.",
  "constraints": ["Не повторять необратимые операции без идемпотентности"],
  "capabilities": [
    {
      "name": "webhook-retry",
      "summary": "Контролируемые повторы webhook-операций с бюджетом попыток.",
      "requirements": [
        {
          "name": "Bounded retry",
          "shall": "The system SHALL retry temporary failures with a configured maximum attempt count.",
          "scenarios": [
            {
              "name": "Temporary failure",
              "given": "An authorized webhook operation fails with a temporary network error",
              "when": "the retry budget has not been exhausted",
              "then": "a bounded retry is scheduled and its outcome is recorded"
            }
          ]
        }
      ]
    }
  ]
}
```

## Какие файлы создаются

```text
<project>/
  openspec/
    config.yaml                         # только если ещё нет
    changes/<change>/
      proposal.md
      design.md
      tasks.md
      specs/<capability>/spec.md        # по одному на capability
  specs/<NNN>-<change>/
    spec.md                             # пользовательские истории и FR-index
    plan.md
    tasks.md
    checklists/requirements.md
  .specify/memory/constitution.md       # только если ещё нет, статус DRAFT
```

Существующие конфигурации, спецификации, конституция и другие файлы не перезаписываются. Номер `NNN` выбирается по доступному индексу, а SHA-256 плана фиксирует результаты выбора. Запись происходит через эксклюзивное создание файлов; если strict validation завершилась неуспешно, инструмент удаляет только созданные им **неизменённые** файлы.

## Прототип trusted-approval для будущего нативного MCP

`approval_broker.py` хранит только хеши одноразовых токенов в SQLite, проверяет срок, владельца, точный workspace, имя операции и SHA-256 плана. `approved_spec_tools.register_approved_spec_tool(mcp, approval_store, authenticated_actor)` регистрирует mutating MCP tool **только если** реальный MCP host передаёт проверенный actor и доступ к trusted UI issuer. Модуль по умолчанию НЕ регистрируется в `mcp_adapter.register_tools()`. Существующие свободные `run_script`/`run_command` обходят этот класс защиты: пока real MCP policy broker не ограничит их, запрещено считать нативный инструмент безопасно развернутым.

## Ограничения

- Максимум 8 capabilities, 15 SHALL-требований на capability, 5 сценариев на требование (не более 60 требований в брифе).
- Имя change и capability должно быть `kebab-case`; проект — существующий подкаталог авторизованного workspace.
- Нет произвольного запуска скриптов, установки пакетов и изменения рабочего кода.
- Не разрешается перезаписывать или автоматически архивировать OpenSpec changes.
- Markdown с `TBD` — реальный черновик дизайна, а не выдуманная техническая реализация.
- SDD Markdown совместим по структуре, но установленный GitHub Spec Kit CLI (`specify`) на этом ПК не обнаружен; нативная проверка его CLI не выполнялась.
- OpenSpec CLI 1.14.3 доступен, реальный strict validation выполнен успешно на тестовом change.
- Прямой `spec_create --apply` через `run_script` теперь отклоняется. Вызывайте очередь `spec_request_prepare/status/execute` после согласования через `owner_approve.py`. Это промежуточный контроль, не полноценная OS security boundary из-за существующих универсальных инструментов.

## Проверенная демонстрация

На текущем ПК генератор создал без перезаписи 10 файлов для `Local-Workspace-Extensions/openspec/changes/add-spec-creator/` и `Local-Workspace-Extensions/specs/002-add-spec-creator/`. Ответ реального CLI: `Change 'add-spec-creator' is valid`.

Источники:
- https://github.com/Fission-AI/OpenSpec
- https://github.com/Fission-AI/OpenSpec/blob/main/schemas/spec-driven/schema.yaml
- https://github.com/github/spec-kit
- https://github.com/github/spec-kit/blob/main/docs/quickstart.md

## Опциональный автоаппрув одного проекта (2026-11-11)

Новые запросы `spec_request_prepare` могут автоматически получать `approved`,
если владелец заранее включил политику для точного проекта. Изначально режим
выключен. В настоящем локальном терминале из `Local-Workspace-Extensions`:

```powershell
python owner_project_approval.py enable Hermes-WebGPT --permanent
```

Подтвердить строкой `ENABLE Hermes-WebGPT`. Без `--permanent` срок составляет
24 часа; `--hours 8` задаёт свой срок. Проверка и отзыв:

```powershell
python owner_project_approval.py status Hermes-WebGPT
python owner_project_approval.py disable Hermes-WebGPT
```

Отзыв подтверждается строкой `DISABLE Hermes-WebGPT`. Политика относится только
к созданию OpenSpec/SDD в этом точном проекте, не наследуется дочерними/соседними
проектами и не разрешает произвольные команды, установку инструментов или
приёмку задач. Старые pending/expired/denied/failed запросы не повышаются:
нужны новый preview и prepare. Отзыв блокирует ещё не начатое выполнение,
а уже начатую операцию не отменяет. Изменение манифеста, SHA плана, срок 15 минут,
запрет перезаписи, strict validation и crash reconciliation остаются в силе.

Для выключенного режима прежний `owner_approve.py REQUEST_ID` сохранён.
Автоматические запросы физически хранятся как pending с отдельной привязкой
к действующей политике: откат к старому коду не превратит их в ручные approvals.
Не включать политику через MCP, подставные interactive streams или правки БД.
Инструкция и SDD: `Hermes-WebGPT/planning/project-auto-approval-20261111/`.
