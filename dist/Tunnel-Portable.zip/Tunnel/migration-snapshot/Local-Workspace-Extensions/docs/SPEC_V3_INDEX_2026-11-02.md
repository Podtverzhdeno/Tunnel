# Specification V3 index — Local Workspace multiagent platform

Date: 2026-11-02  
Status: PROPOSED / non-normative / source-checked; no implementation or owner release implied

## Read this first

The canonical, owner-approved source of truth remains:
1. AGENTS.md and specs/001-local-pc-agent-tooling/MASTER_SDD.md.
2. specs/001-local-pc-agent-tooling/ARCHITECTURE_V2.md and IMPLEMENTATION_BACKLOG.md.
3. OpenSpec/SDD change documents approved through the existing foreground owner approval workflow.
4. agent_team.py current read-only queue state, current source SHA and independent QA receipts.
5. Actual MCP host identity and policy — P085 is not replaced by these documents.

**These V3 files are proposed design supplements**, not live task grants, validated production features, executable scripts, owner approval, or evidence of independent QA.

## New technical artifacts and their roles

| File in docs/ | Purpose | Key result |
| --- | --- | --- |
| MULTIAGENT_ARCHITECTURE_SDD_V3_2026-11-02.md | overall architecture, state transitions, security and concurrency | 16 additional proposed SHALL anchors S3-01..16, 16 invariants, 12 ADRs |
| MULTIAGENT_TYPED_CONTRACTS_V3_2026-11-02.md | typed API, events, receipts and errors | explicit no-authority advisory contract, lease fencing, effect receipts, compatibility |
| MULTIAGENT_ACCEPTANCE_CATALOG_V3.json | machine-readable positive/negative test scenarios | 64 planned cases, all PLANNED_NOT_RUN |
| MULTIAGENT_QA_RELEASE_PLAN_V3_2026-11-02.md | gates, chaos matrix, benchmarks, delivery | 30 chaos injections, E0–E4 evidence, go/no-go and staged release |
| OPENSPEC_SDD_EXACT_CROSSWALK_V3.json | read-only structural snapshot of existing canonical specs | 99 OpenSpec requirements, 43 exact SDD links, 56 without explicit FR link |
| OPENSPEC_SDD_GAP_TRIAGE_V3.json | advisory interpretation of the 56 gaps | 24 possible existing FR links, 32 candidate distinct FRs; all require review |
| CHANGE_IMPACT_PLANNING_DESIGN_2026-11-02.md | previous deep specification of change-impact preview | versioned graph, predicates, simulation and risk-oriented validation |
| SPEC_TRACEABILITY_REMEDIATION_2026-11-02.md | previous spec quality investigation | 26 false-positive FR/task errors + actual crosswalk gaps |

An exact title link in the crosswalk is a **structural** reference, not evidence that code was written, tests passed or semantic coverage is complete. The 24 suspected semantic overlaps are not mapped until a reviewer inspects full SHALL+scenarios and the owner approves any normative update.

### Existing proposed change (separate approval)

Manifest: requests/add-agent-change-impact-planning.json.  
Previewed change: add-agent-change-impact-planning.  
The existing request a9fda1ae86fe030ddb32c231c916d2ed was reported PENDING on inspection; exact state can change or expire. Only the human owner may approve the exact plan in a real foreground terminal. Any change to manifest requires a NEW preview and approval hash; V3 supplements deliberately leave it unchanged.

## Which document an agent should open

- Architect-reviewer: this index -> canonical MASTER_SDD -> V3 architecture -> exact 99-item crosswalk + 56-item triage -> real live source/QA. Do not auto-edit canonical specs.
- Developer: approved task lease and source SHA -> canonical requirement -> V3 contracts for interface decisions -> 64-case catalog for candidate tests -> independent QA receipts. No new module without reuse preflight.
- Tester: final source/test SHA -> 64-case catalog -> 30-case chaos matrix -> actual host negative E2E for privileged changes. Keep all unexecuted tests NOT_RUN.
- Planner: canonical coordinator read-only snapshot -> change-impact design -> V3 scheduler/fairness invariants. Never grant leases or accept QA from previews.
- Owner: decision/approval boundaries -> missing FR classification -> exact proposed normative diff -> host trust release decision.

## Recommended decision order

D0. Resolve false-positive FR/task parser mismatch in spec_analyzer.py, without altering real task linkage syntax or claiming tasks implemented.
D1. Review 56 missing structural FR links from exact source SHAs; do not auto-create all 56 FRs. Examine 24 potential covered-by-existing cases first, then 32 distinct candidates.
D2. Decide scope of the proposed 16 S3 requirements and whether they are amendments to approved foundation/reuse/continuous changes or need a truly disjoint new change. Reject duplicate auth/queue/reviewer implementations.
D3. Keep P085 actual host identity and generic runner bypass denial as the hard gate for privileged deployment.
D4. Use only approved scoped work, independent QA and explicit owner release to implement safe stages.

## Consistency and non-duplication guard

Do NOT create a second SQLite coordinator, owner-grant issuer, review merge service, duplicate finder, FR checker, durable-step ledger or long-running ChatGPT scheduler abstraction. Reuse the actual canonical owner and extend via reviewed adapters.

No write authority is created by any JSON field called owner, verified, eligible, accepted, trusted or approved. External repositories, README, spec documents and candidate tasks are untrusted input for tool authorization.

Any future owner-approved change must include old/new spec digests, exact source scope, impact graph, SDD FR mapping, test requirements, rollback strategy, independent reviewer and host-trust gate. Legacy accepted tasks must not be rewritten to make new S3 requirements appear passed.

## Observed versus proposed

Observed in read-only local inspection: existing OpenSpec and SDD source counts, pending approval request status at inspection time, source file hashes, stored proposed documents.

Proposed but NOT executed: all 16 S3 requirements, 64 acceptance scenarios, 30 chaos experiments, typed adapter schema evolution, host grant changes, live queue migrations and any performance improvements.

Source drift after inspection invalidates crosswalk and prior preview. Recompute before any approved normative change.