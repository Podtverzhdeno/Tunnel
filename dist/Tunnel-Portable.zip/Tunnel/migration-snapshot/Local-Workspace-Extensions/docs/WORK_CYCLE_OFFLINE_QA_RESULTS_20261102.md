# Возобновляемый цикл фич — независимые офлайн-прототипы (2026-11-02)

**Режим:** non-normative evidence / proof of concept. Никаких API-вызовов моделей, привилегий MCP-хоста, изменений live SQLite, owner approval или production integration. Этот документ сам по себе не допускает код к слиянию.

## Цель и границы

Один ChatGPT scheduled run нельзя программно растянуть до ровно одного часа. Уже существуют 4 почасовые карточки, исполняющие 5 логических ролей; рабочая память между ними — проверяемые файлы, очередь SQLite, SHA и нормальные lease/review процедуры. Не создавать пятый чат разработчика, параллельный координационный источник истины или автоматические повторы привилегированных действий.

В OpenSpec уже есть `openspec/changes/add-continuous-agent-work-loop`; строгая проверка этого изменения и SDD crosswalk прошла (`spec_validate`: 8 requirements, 13 scenarios, 8 FR mappings). Но `tasks.md` этого изменения пока не содержит выполненных реализационных чекпоинтов, внешний API supervisor НЕ развернут.

## Отобранные и проверенные идеи

`feature_idea_gate.py catalog`: 4 × 10 = 40 формально валидированных предложений (волна `41c08590a4cb550b`). `feature_idea_gate.py architect`: все 40 оценены, 4 рекомендованы для owner-spec рассмотрения. Подробная независимая сортировка — `docs/WORK_CYCLE_FEATURE_VALIDATION_20261102.md`.

| ID | Суть | Путь эксперимента | Изолированные unittest |
|---|---|---|---|
| developer-1:F07 | Консервативное решение SAFE_RETRY vs OUTCOME_UNKNOWN | `experiments/continuous_loop_retry_poc_20261102/` | 12 PASS; 100 post-dispatch ambiguous фикстур не повторяются |
| developer-2:F02 | Критические SKIP по OS / MCP actor / SHA | `experiments/critical_skip_poc_20261102/` | 15 PASS; 40 негативных вариаций не превращаются в PASS |
| developer-2:F08 | Бounded envelope отсутствия побочных эффектов | `experiments/no_effect_envelope_poc_20261102/` | 11 PASS; 40 неполных envelope отвергаются |
| developer-1:F03 | MCP/CLI schema canary | `experiments/mcp_schema_canary_poc_20261102/` | 14 PASS; 3 версии × 12 обязательных полей проверены |

Дополнительная общепроектная проверка `python -m unittest discover -q`: **1476 тестов, 37 skipped, 0 failures**, Local Workspace job `205bc76c85c04239890a87a989b80565`, rc=0. Новые изолированные PoC-тесты проходят *отдельно*, и число 1476 не следует складывать с 52 как с одним уникальным набором без проверки discovery.

Суммарный read-only smoke: **52 теста, 4/4 PASS**, `returncode=0`, Local Workspace job `a1c66736ab7e44f08f9a4463ab8d0ed2`, наблюдение `2026-11-02T17:15:49Z`. Запускать из корня проекта:

```powershell
python experiments/work_cycle_offline_validate_20261102.py
```

Скрипт выполняет только локальные фиксированные тестовые файлы через Python, не записывает файлы и печатает machine-readable JSON с SHA каждого исходника и теста, кодами завершения и числом тестов. Ни одна проверка не подтверждает действительную host actor identity, полноценное покрытие продакшн-трасс или фактическую длительность рассуждения модели.

## Актуальный блокер непрерывного потока

Read-only снимок 2026-11-02 17:06 UTC: **20 review, 1 reviewing, 1 working, 14 done; live_ready=0**. Главный затор — доверенная авторизация reviewer в реальном MCP-хосте (P085), а не нехватка новых идей. P152/P153 показали четыре воспроизводимых дефекта в независимом negative gate; P159 показал синтетический budget false-negative (порог $5, известная нижняя граница $5.28 => UNKNOWN). Выводы advisory: никакого формального accept/reject или самоодобрения.

## Следующий цикл после QA

1. В порядке реальной очереди разработчики с законным scoped lease исправляют P152/P153/P159 и другие task-local регрессии, приоритет — independent negative evidence, а не косметика.
2. Непосредственно в живом MCP-хосте уполномоченный владелец реализует и проверяет P085 trusted actor/permission boundary. Декларация роли в Python и офлайн-класс `host_verified=True` не выдаёт прав.
3. Для каждого PoC: отдельная traceability карта к существующему OpenSpec/SDD, явное owner foreground approval, ответственное владение модулем, негативные тесты, sandbox suite и независимый reviewer. Не копировать PoC в production без проверки источника authority.
4. Только после разрешённого admit/lease/QA — модифицировать реальные инструменты, при этом F07 должен получать attestations от хоста, F02 — полный обязательный тестовый контракт, F08 — независимые observers, F03 — версионированные производственные контракты.
5. После каждой принятой задачи возврат к live `plan-work` → independent peer QA → architect-support → новая идея/валидация только при наличии действительно нового seed wave. При пустой разрешённой очереди сохранять честный stop reason и SHA, не симулировать часовую активность.

**Запрещено:** автоматически продлевать веб-чат, создавать API-платёж, обходить лимиты расписаний, выдумывать owner approval/lease, запускать tool effects из исследовательских PoC или объявлять `PASS` на основании synthetic fixtures.
