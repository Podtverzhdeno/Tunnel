# Review throughput and quality: prioritized architecture proposal

**Date:** 2026-11-02. **Status:** NON-NORMATIVE proposal only. This file does NOT authorize new queue rows, reviewer identity, OpenSpec/SDD edits, production merges, or schedule modifications. Design reuses the canonical `agent_team.py`, `review_readiness_matrix.py`, `review_queue_triage.py`, `review_negative_gate.py`, `review_budget_negative_gate.py`, `agent_logistics_dispatch.py`, `MergeIntent` and existing owner approval workflow.

## Reproduced symptoms and scope

- Live read-only queue: 20 `review`, one `reviewing` with expired reviewer lease, one stale `working`, zero ready coding tickets.
- Current matrix preflight: 20 candidates `READY_FOR_INDEPENDENT_QA` and P111 `EXPIRED_LEASE_REACQUISITION_REQUIRED`. This means *static preflight only*, not independent approval or passing negative QA.
- Architect automation's latest recorded report identifies negative QA defects in P152/P153 and P159; this is a reported finding to cross-check against the exact candidate source SHA and existing independent negative witnesses, not formal accept/reject.
- One full matrix run took 93.34 s for 21 entries (single observation; not a representative benchmark). `MAX_ITEMS=50` limits output but the v2 implementation scans every item from a pair of up-to-100-entry lists. Introduce a separate explicit scan budget and an accurate `uninspected` count when the project grows.
- The Architect Reviewer automation prompt was ~32k characters in a recent inspected run. A shorter stable system policy plus source-linked task packet may improve token budget and time, but must be benchmarked rather than assumed.

## Strict ranking

| Rank | Proposal | Benefit / 10 (engineering estimate) | Cost | Required proof |
| --- | --- | ---: | --- | --- |
| 1 | **P085 trusted reviewer actor authorization at MCP host**: host-bound identities, role capabilities, one-time scoped grants; coordinator rejects self-declared actor strings for privileged transitions | 10.0 | High | unauthorized caller cannot `review accept/reject`; authorized reviewer can; replay/role spoofing negative tests |
| 2 | **SHA-bound negative QA finding registry**: normalize findings from existing independent witness tools and peer reports with `task_id`, candidate SHA, test SHA, severity, reproducibility, disposition, reviewer provenance | 10.0 | Medium | P152/P153/P159 cannot appear as QA-clean when same SHA has confirmed critical findings; stale findings cannot block a changed SHA without re-evaluation |
| 3 | **WIP cap & review admission backpressure**: per-role ready/working/review cap, priority to clearing independently reviewable candidates; never bypass owner admission or lock scope | 9.8 | Medium | new tickets do not flood review backlog; critical independent work continues; no starvation/fake leases |
| 4 | **Trusted lease reconciliation**: host-authenticated, transactionally fenced recovery for genuinely expired review claims, after no-pending-MergeIntent and latest revision check; never automatic unsafe resets | 9.7 | High | P111-type expiration recoverable by legitimate reviewer; stale token cannot accept; crash/replay tests |
| 5 | **Content-addressed QA evidence cache**: key source/spec/dependency/test-runner/environment snapshot; reuse only read-only discovery evidence, retain required fresh acceptance checks & final SHA/CAS | 9.6 | Medium | repeated matrix scans substantially faster; source drift invalidates cache; hidden negative witness never skipped |
| 6 | **Consistent snapshot & CAS review plan**: manifest over queue revision, candidate SHA, contract/spec SHA, review/merge journal; stale plan refuses promotion and recomputes | 9.5 | Medium | concurrent submission and edits cannot yield false ready-to-accept state |
| 7 | **Resumable MCP execution**: durable per-job status/output offsets/checkpoints and idempotent restart; agent resumes safely after transport failure instead of repeating QA or orphaning leases | 9.4 | Medium-high | tunnel drop simulation preserves exact job state; no double side effects or token leakage |
| 8 | **Risk and dependency aware review selection**: prioritize accepted blockers, executable negative QA, critical-path dependencies, risk, age; fairness limits avoid starving old tasks | 9.2 | Medium | earlier release of true dependent tickets compared with FIFO, with no lower-risk task starvation |
| 9 | **QA attestation and artifact provenance**: independent host-issued receipt tied to code/test/spec SHA and exact command, never developer-submitted PASS string; retain existing durable merge journal | 9.1 | High | alteration/replay of receipt rejected; crash after copy remains recoverable; no pretending CI=host identity |
| 10 | **Operational control metrics**: actionable queue age percentiles, acceptance throughput, blocked cause, WIP, QA reruns, cache hit, reviewer load and time-to-verified-accept; avoid speculative token billing | 8.8 | Low-medium | baseline then controlled improvement, no fabricated usage |
| 11 | **Semantic responsibility map**: connect existing new-task ownership registry to approved historical module/API inventory; compare contracts/interfaces, not just matching AST | 8.6 | High | independently reviewed migration; known equivalent capabilities propose reuse, not silent code merge |
| 12 | **Lean automation prompts**: reduce huge repeated role instructions to a small stable task protocol and immutable, SHA-referenced local specs; retain all safety constraints | 8.5 | Medium | A/B test completion quality and useful QA reports, no regression in restrictions |

Ratings are prioritization estimates, NOT measured KPI improvement. Do not create duplicate host auth, review coordinator, clone guard, merge ledger or negative repro engines.

## Recommended dependency-ordered work

**Stage A — immediate, nonprivileged:** aggregate existing negative QA evidence into a read-only risk matrix, show `KNOWN_DEFECT_SHA_MATCH` separately from `READY_FOR_INDEPENDENT_QA`; add current-source hash checks, explicit scan budget, priority rationale and benchmark 21-task scan. Existing statuses/leases are unchanged.

**Stage B — approved coordinator changes:** owner-reviewed OpenSpec/SDD covering queue WIP/backpressure, low-cost read-only cache, safe dependency ranking and tested stale-plan rejection. Never auto-seed P162+ or retroactively rewrite accepted legacy tasks.

**Stage C — trusted host boundary:** implement P085 identity and review-grant enforcement in the MCP host, then lease reconciliation and genuine five-agent E2E with fault injection. A Python `role` arg, an automation title, a fake TTY or a locally generated signature is not trusted identity.

## Required release and safety criteria

1. No merged code based only on matrix `READY_FOR_INDEPENDENT_QA`, completed subprocess exit code or self-reported QA.
2. Negative witness convention must distinguish `exit=0 means a bug reproduced` from `exit=0 means candidate passes tests`; fixed cases require independent positive regression tests against new source hashes.
3. Untrusted candidate Python must not be imported into a privileged coordinator process for preflight. Keep sandboxed execution boundaries and avoid treating path checks alone as OS isolation.
4. Failed/partial source promotion is handled by existing `MergeIntent` and owner recovery; do not introduce a competing apply path.
5. Changes require canonical project focused/full tests, OpenSpec strict and explicit owner approval for normative specs and queue admission. Rollback uses known SHA and preserves SQLite event history.
6. Report metrics as `accepted tasks/hour`, `p95 review age`, `confirmed defect escape rate`, `CPU/test seconds per reviewed task`, and `lost progress after reconnect`; compare before/after under the same workload.

**Do not prioritize now:** another dashboard, heuristic autonomous self-accept, auto-approval of spec/queue changes, self-signed approval tokens by agents, duplicate Python scheduler, unbounded full-suite reruns, or large semantic similarity model without measured false positives.
