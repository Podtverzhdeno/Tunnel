# Implementation checkpoint — Pinned OpenSpec source snapshot and advisory diff

Date: 2026-11-02.
Status: locally implemented and regression-tested; not canonical owner approval, independent review acceptance or host production certification.

## Code delivered

- spec_traceability.py: exact SHA-256 of raw bytes for each OpenSpec capability spec and the SDD feature spec, including BOM and CRLF.
- Deterministic source_files records (path, sha256, bytes) and versioned snapshot_sha256 over sorted-key JSON.
- Bounded second source read AFTER analysis; rejects detected concurrent edits as FILE_CHANGED.
- Re-checks capability-directory names to detect sources added or removed during scanning.
- Truthful consistency status: BEST_EFFORT_DOUBLE_READ_NON_ATOMIC. No claim of filesystem+SQLite atomicity.
- compare_source_snapshots(before, after): pure, bounded, structural validation of snapshot manifests; deterministic added_paths, removed_paths, modified_paths.
- When source differences are observed, report REVALIDATE_DEPENDENT_WORK, never assume transitive impact is known or that QA/release is authorized.
- test_spec_traceability.py: exact byte hashing, deterministic manifest hash, Unicode/BOM/CRLF, concurrent writes during source read/analysis, changed directory listing, forged hash, duplicate and unsafe path, new/removed spec cases.

## Source identities

- spec_traceability.py SHA-256: 0f68abb3b6a3603a401ac4669ba9c0f5d4fc8533960e2a484711ef2fc37dc739
- test_spec_traceability.py SHA-256: 40567a715f41756b25db7cd2fa6271f96fbfba136bfb75d22e3d2e9fd9cd89b5

## Usage in authorized Python code

    from pathlib import Path
    from spec_traceability import audit_traceability, compare_source_snapshots

    project = Path("C:/Users/user/IdeaProjects/Local-Workspace-Extensions")
    before = audit_traceability(project)
    # Re-read after a separately authorized spec update:
    after = audit_traceability(project)
    report = compare_source_snapshots(before["provenance"], after["provenance"])
    print(report)

These functions read source files only. Comparing two self-consistent manifests is not host attestation; an unchanged OpenSpec source manifest does not prove runtime environment, code, tests or all dependencies unchanged.

## Executed verification

| Command | Result |
| --- | --- |
| python test_spec_traceability.py | 26 tests, 2 skipped, zero failed |
| python -m unittest discover -p test_spec*.py | 113 tests, 4 skipped, zero failed |
| python test_agent_team.py | 54 tests, 1 skipped, zero failed |
| python test_review_readiness_matrix.py | 15 tests, none skipped or failed |
| python test_p085_autonomous_guard.py | 21 tests, 2 skipped, zero failed |
| python spec_check.py | exit 0; 11 capabilities, 99 requirements, 128 scenarios, 43 FR mappings |
| python sdd_roadmap_check.py | exit 0; 58 roadmap tasks and zero structural errors |

113+54+15+21 = 203 test invocations across the four separate suites, seven skipped, zero failures; the focused 26-case run is already within the 113 and should not be added twice.

## Open blockers

1. 56 OpenSpec requirements remain without an explicit SDD FR; current strict structure checks do not mean feature completion.
2. P085 host-enforced actor identity and generic runner bypass denial remain an independent production blocker; the local Python P085 suite is not an actual production-host authorization E2E.
3. The prior change-impact spec request expired. This is a read-only local component-level prototype, not an owner-approved canonical OpenSpec change, queue admission or release.
4. Actual formal independent reviewer QA/merge/acceptance has not occurred; no production readiness is claimed.
5. No SQLite queue state, live leases, user approval records, MCP host privileges or unrelated projects were intentionally modified.

Next: integrate snapshot digests as advisory stale-source predicates in existing review/report paths after the appropriate owner task scope is admitted; do not create a second coordinator or security broker.
