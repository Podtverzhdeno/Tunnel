# P010 post-acceptance independent architecture audit — 2026-11-01

## Scope and state
Task P010 was accepted at 2026-11-01 15:58:17 UTC by another architect-reviewer session while this independent audit was in progress. This document does not reopen, re-accept or modify that completed task. The accepted main source SHA-256 for `workspace_search.py` is `515398adb7efa87ba987b214334547836b7642ecf271b6eed3e4690a246fdec2`, matching the reviewed sandbox. `merge-status P010` returned `intent: null`.

## Finding A — HIGH: incomplete secret-line suppression
In `workspace_search.py:33-37`, `SENSITIVE_LINE` detects only a finite set of assignment names and Bearer tokens. The line `AWS_SECRET_ACCESS_KEY = EXAMPLE_PLACEHOLDER` and `Authorization: Basic EXAMPLE_PLACEHOLDER` do not match the filter, so an otherwise permitted search in a normal source file can return the complete matching line (`workspace_search.py:341-354`). This is a synthetic pattern inspection, not an actual credential exposure. The canonical `security-governance / Protected material` requirement calls for host-side redaction, which is not implemented in the live MCP backend. The source module must not be presented as a complete secrets policy.

Recommendation: return only a bounded, redacted match context; add explicit tests for common cloud credential names, Authorization Basic, embedded assignments, and false positives. Require a trusted host-side redaction/grant layer before claiming protection of secrets. Never use real credentials in test fixtures.

## Finding B — MEDIUM: max_seconds excludes directory traversal
`workspace_search.py:292-293` creates the deadline and then calls `_collect_files`, which enumerates and sorts up to `max_entries=50000` entries (`162-209`) without checking the deadline. A large/slow tree can therefore consume more than `max_seconds` before matching starts. When time is already exhausted before any progress, the returned `next_cursor` can be null despite `truncated=true` (`299,304-306,358-362`).

Recommendation: check a monotonic deadline during traversal, make partial traversal resumable or report explicitly non-resumable limits, and add a synthetic large-tree negative test. Stdlib `re.search` still cannot be forcibly interrupted mid-match; document this as a soft budget until a robust isolation strategy exists.

## Verified QA and limits
- Sandbox `unittest`: 183 tests, 6 skipped, rc=0, independently observed.
- Sandbox `spec_check.py`: 10 capabilities, 91 requirements, 100 scenarios, 0 errors, rc=0.
- Main `agent_team.py gate-check`: 255 tests, 13 skipped, rc=0; structural checker 92 requirements/103 scenarios; strict OpenSpec validation passed.
- P010 `review-preview` after acceptance: `already_accepted=true`; source hashes match main; no merge intent.
- The two findings above are code-review gaps not covered by the passing tests. No new regression test was executed on the Windows host. No native MCP registration or host-side role authorization is proven.

## Follow-up without disturbing active tasks
Do not edit P010's accepted source through a second `review accept`. Create a separately authorized maintenance change with a clear owner and negative regression tests; it must not overlap an active sandbox or silently rebase a `done` task. P085 host identity, unrestricted MCP script execution and absence of OS-level sandbox remain independent release blockers. Current P018 developer lease must be respected before any canonical spec rebase.
