# Verification report — 2026-11-01

## What was changed

- The personal Local Workspace ChatGPT plugin was upgraded to version **1.0.2** with the `local-openspec-sdd` skill. Its original App binding and UI metadata were retained; the new release was read back using Plugin Creator.
- `spec_approval_queue.py` adds a persistent SQLite queue for specification requests, scoped to manifest SHA-256, target project, change and preview plan. Requests expire after 15 minutes.
- `owner_approve.py` provides a local interactive terminal review. A real noninteractive `run_script` invocation returned `INTERACTIVE_REQUIRED`.
- `native_spec_mcp.py` exposes nine standalone MCP tools: five preview/status/validation/quality-audit tools and four request/approval/diagnosis/create tools.
- `docs/APPROVAL_WORKFLOW.md` documents the workflow and its current security limitations.
- `mcp_wire_check.py` tests creating a real OpenSpec + SDD change on a disposable project with simulated approval, then replays the completed request.

## Evidence

| Test | Observed result |
| --- | --- |
| `python -m unittest discover` | 118 tests, 115 passed, 3 skipped (Windows symbolic-link creation unavailable) |
| `python run_mcp_wire.py` | Real MCP client/stdio server, 9 tools discovered, 16/16 checks succeeded |
| `python spec_check.py` | 10 capabilities, 83 requirements, 85 WHEN/THEN scenarios, 29 SDD FR mappings, 30 SDD tasks, 69 OpenSpec task IDs; 0 structural errors |
| `python validate_upstream.py` | OpenSpec 1.14.3, strict validation accepted `local-pc-agent-tooling` |
| Background terminal authorization attempt | Denied with `INTERACTIVE_REQUIRED` as expected |
| App-backed personal plugin | Version 1.0.2, `skills/local-openspec-sdd/SKILL.md` read back successfully |

## Not yet verified

- Direct registration of the standalone tools in the currently connected Local Workspace backend on port 8765; only its App-backed plugin package and skill have been updated.
- Genuine human authorization in the user's interactive Windows Terminal: tests simulate an interactive terminal.
- Full server-side sandbox/permission policy on the existing broad `run_script`/`run_command` tools; the current queue is workflow control, **not OS privilege isolation**.
- Native GitHub Spec Kit CLI execution (`specify` was not detected on the host); generated SDD Markdown is checked locally and uses Spec Kit-style layout.

## Next gated actions

1. Expose the actual Local Workspace server source as a separately authorized workspace or connect the standalone stdio server through a supported local MCP host.
2. Verify real foreground approval on a throwaway feature; compare the exact planned target paths.
3. Enforce per-tool workspace restrictions and server-verified approval on the existing broad execution tools before using mutating MCP capabilities with untrusted agents.
4. Repeat the same E2E test from the actual ChatGPT plugin after integration; treat success in a local stdio test as separate evidence.
