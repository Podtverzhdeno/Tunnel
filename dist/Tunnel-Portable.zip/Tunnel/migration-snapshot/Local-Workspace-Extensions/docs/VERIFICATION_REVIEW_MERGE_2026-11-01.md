# Five-agent team — reviewer merge hardening and live progress
Date: 2026-11-01. Project: Local-Workspace-Extensions.

## New code and security controls

- `review_merge.py` — durable per-task merge intent, fsynced original/new artifact bytes, pre/post SHA-256 and revision; validated allowlist of root Python files.
- `agent_team.py review` — on accept, creates the intent before source file replacement, runs existing QA and source hash checks, commits state to SQLite before removing the journal. If a crash occurs before commit, a pending intent blocks all future accept/reject and reviewer acquisition of that task. A pending intent also prevents `rebase-spec`.
- `agent_team.py merge-status Pxxx` — read-only original/applied/unchanged/diverged status per target; `overview` reports `merge_intent_requires_owner_review`.
- `owner_review_recover.py Pxxx` — only manual recovery through an interactive terminal, only after old reviewer lease expires: RESTORE Pxxx if task not committed and file hashes still match, ACK Pxxx when the SQLite task is done and all outputs match. Divergent targets, corrupt backups, invalid TTY and active lease refuse operation.
- `test_review_merge.py` and additions to `test_agent_team.py` — hard subprocess crash with `os._exit(71)` after one file replacement, simulated SQLite error after file writes, interruption after DB commit, new reviewer refusal, partial restore, rejection of divergent user edits, symlink and hash negative cases.

**Security boundary not established:** the real MCP host does not authenticate a reviewer using an actor grant; a caller able to invoke arbitrary Local Workspace scripts can spoof a CLI role or mimic a terminal. This is a workflow integrity improvement, not a fix to host authorization. P081/P085 remain OPEN for host-level enforcement. Multi-file disk changes are recoverable but are not intrinsically atomic across the filesystem and SQLite; power loss and TOCTOU remain residual risks. No real owner recovery on their Windows Terminal has been performed.

## Validation (actual Local Workspace jobs, 2026-11-01, 15:23 UTC)

| Check | Observed |
| --- | --- |
| Main `python -m unittest discover` | 156 total; **152 passed, 4 skipped**; rc=0 |
| `agent_team.py gate-check` | unittest, structural spec, strict OpenSpec — all rc=0 |
| `spec_check.py` | 10 capabilities, 91 requirements, 100 scenarios, 37 SDD FR mappings, 37 SDD tasks, 88 OpenSpec P task IDs; zero errors |
| `validate_upstream.py` | OpenSpec CLI 1.14.3; `local-pc-agent-tooling` valid |
| MCP wire test | 9 standalone tools; 16/16 checks succeeded |
| Background `owner_review_recover.py P009` | refused with `INTERACTIVE_REQUIRED` (rc=3), as designed |
| P009 sandbox | 164 unit tests; 157 passed, 7 skipped; `spec_check` + `openspec --strict` PASS |
| P015 sandbox | 175 unit tests; 171 passed, 4 skipped; `spec_check` + `openspec --strict` PASS |

## Live scheduler team observations

At 15:23:16 UTC:
- **P009** Developer 1 — `review`, submitted 15:19:52 UTC, independent sandbox tests passed, not yet accepted.
- **P010** Developer 2 — `available` (no logged acquire).
- **P015** Developer 3 — `review`, submitted 15:22:21 UTC, independent sandbox tests passed, not yet accepted.
- **P016** Developer 4 — `working`, last activity 15:22:44 UTC, lease to 16:12:44 UTC.
- Architect Reviewer completed one prior auditing session; no acceptance of P009/P015 recorded at this observation.

Current scheduled model remains four hourly automation cards for five roles (Dev3 and Dev4 sequentially share one), preserving the unrelated daily IT/AI certificates automation due to the plan's five-active-task limit.

## Next steps

1. Reviewer independently examine P009/P015 code and tests. Execute `merge-status` first; any non-null intent requires owner recovery rather than a retry.
2. Check Developer 4's progress and Developer 2's upcoming scheduled acquire, using actual SQLite events and checkpoints.
3. Integrate actual local MCP host source (not present in authorized workspace) for reviewer identity/grants, per-role command restrictions and negative spoofing tests — the critical remaining P081/P085 portion.
4. Verify owner confirmation and real power-loss/Windows junction race scenarios separately; no claim of full OS sandbox until proven.
