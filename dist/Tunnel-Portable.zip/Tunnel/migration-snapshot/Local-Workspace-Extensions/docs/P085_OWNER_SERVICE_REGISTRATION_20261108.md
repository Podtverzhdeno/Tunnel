# P085 — Owner-controlled Windows service registration and inspection

Date: 2026-11-08. Status: SOURCE ONLY — NOT DEPLOYED; P085 OPEN.

## Components

- P085-OwnerReadOnlyServiceAudit.ps1: read-only local SCM inspection. Checks service state, actual process owner token SID via Win32_Process.GetOwnerSid, strict protected Python entrypoint invocation, optional owner SHA-256 pins and stage/receipt existence. Never authorizes release or auto-merge.
- Register-P085ProtectedReviewerService.ps1: separate owner-foreground service registration. Dry-run by default. Its only mutation is one New-Service call with StartupType Manual, using an already existing local non-admin service account. It never starts the service, provisions accounts/keys, changes ACLs, modifies the working MCP or grants review acceptance.
- test_p085_owner_scm_readonly_audit.py and test_p085_owner_service_registration_source.py: source-level negative test contracts only.

Important: this project checkout is agent-writable. SHA matches and self-tests in this checkout do not establish ownership, protected Windows runtime, or a root of trust. Before UAC, owner must independently inspect and copy approved scripts to an OS-protected folder, validate their hash from an owner-controlled source, and not run privileged code directly from agent-writable project storage.

## Owner-controlled sequence (manual, not through ChatGPT MCP)

1. Review the P085 canonical OpenSpec/SDD, protected code tree and service account plan. Choose a protected Python interpreter; the current user-writable uv/AppData Python is not a trusted P085 runtime.
2. Run Setup-P085WindowsPrincipals.ps1 as dry-run after independent review. There must be five distinct local non-admin identities: service, reviewer, untrusted worker, QA supervisor, QA test child. Separate foreground owner action can create only missing DISABLED accounts; no web agent creates or enables them.
3. Run Install-P085ProtectedService.ps1 without Apply for the actual distinct service/reviewer/worker accounts, inspect the complete plan SHA-256 and every file hash, then elect a distinct foreground Apply to stage code and empty private_state under ProgramData. It DOES NOT install a Windows service.
4. Verify protected Python file and directory ACLs and the immutable stage: SYSTEM-only code writes; service account read/execute; reviewer and worker cannot read private_state. Validate all 14 staged source SHA digests and independently pin STAGE_RECEIPT.json. The owner-approved digest of a writable checkout is not an OS identity proof.
5. Use the registration script **without -Apply** and supply real ExpectedServiceSid, TrustedPythonPath, ExpectedPythonSha256, ExpectedEntrypointSha256, ExpectedOverlappedSha256 and ExpectedStageReceiptSha256. The source rejects missing stage, unsafe reparse paths, non-SYSTEM code writes, receipt mismatches, missing account or an existing service. Default execution performs no machine mutation.
6. For real registration only, owner separately enables and credentials the approved service account, runs the independently reviewed script from a protected location in a genuine interactive elevated Windows terminal with -Apply, approves exact phrase REGISTER-P085-MANUAL-SERVICE, and enters the password at the SecureString prompt. The account password is not placed in arguments/files/logs. A successful New-Service still produces only Manual/Stopped, never Start-Service.
7. Use P085-OwnerReadOnlyServiceAudit.ps1 with independent SHA pins. Independently confirm the true service process SID and protected executable; perform negative ACL and E2E signed-review tests from real separate worker/reviewer/QA Windows SID principals; verify the broad legacy MCP privileged surface is disabled or guarded. Final owner authorization remains an independent step after real E2E.

Sample dry-run parameters (placeholders are NOT valid or owner-approved pins):

    .\Register-P085ProtectedReviewerService.ps1 -ExpectedServiceSid ACTUAL_LOCAL_SERVICE_SID -TrustedPythonPath PROTECTED_PYTHON_EXE -ExpectedPythonSha256 REVIEWED_HEX64 -ExpectedEntrypointSha256 REVIEWED_HEX64 -ExpectedOverlappedSha256 REVIEWED_HEX64 -ExpectedStageReceiptSha256 REVIEWED_HEX64 -ExpectedInstallerSha256 REVIEWED_OWNER_SCRIPT_HEX64

Do not run Apply, UAC, service registration or service start through the current writable Local Workspace MCP.

## Verified source and negative QA evidence (2026-11-08)

Live Local Workspace alias projects was reachable. No owner UAC or
PowerShell execution was possible: the MCP command allowlist explicitly
returned Executable not allowlisted: powershell. This is a SOURCE-ONLY
implementation and is NOT a native Windows install/parse test.

Exact local source checksums:
- P085-OwnerReadOnlyServiceAudit.ps1: 2f4df7b9d8c4c616d87cb0cfac855494d0142346140bdfd892d90c618b4f8155
- Register-P085ProtectedReviewerService.ps1: 9523952b38a71d114f1cd733f45bdadb62bcf6b30874408e8150e9ff4fa32826
- test_p085_owner_scm_readonly_audit.py: 3202e52af0ffe6007e1bd5c759db948d81657f32348e483c0184a13f1d696369
- test_p085_owner_service_registration_source.py: 628ab3e1a8317a761b3771ead316073f39531bd6ddab20c1b692c493acc53ffd
- p085_autonomous_guard.py: c7b21f2987e3c779cf531befad086787569efece7ba31103c553f4a82fee41dd
- test_p085_autonomous_guard.py: 32e603ad54069c1abdcf2b1eaf76aa3401ecf27508fc06cd7bd2bf08b29c085f

Checks:
- Focused P085 bootstrap suite job c4401e7d20d046c4852f225b303bd9cd:
  72 tests, 70 PASS, 2 SKIP, rc=0.
- Focused audit supervisor + owner script job 44a73148416244aabe1af0ddd8901a7b:
  41 tests, 39 PASS, 2 SKIP, rc=0.
- Full main Python suite job f56997ff80174406b3f84394602757e7:
  2664 tests, 2618 PASS, 46 SKIP, rc=0.
- Full P085 autonomous guard job 61b6a71af03b4c23a08fc4f395a7234d:
  7 of 7 suites PASS, source_stable=true, 107 source files SHA-tracked
  including the new owner PowerShell scripts and static tests; bootstrap
  negative suite increased to 90 tests (87 PASS/3 SKIP). Report at
  .agent-team/reports/P085_auto_20261107T232218Z_1cdd1412e9d9.json.
  This reports p085_release_ready=false, auto_merge_authorized=false and
  verified_host_identity=false, as required.
- Read-only Windows OS observations job 49bc719d1d584c558bb8fb402e3c3e92:
  SCM=ABSENT, stage=NOT_STAGED, safe_to_activate=false, runtime untrusted.
  Accounts job d4ab503afc594b0394d6ec22f9546cdf: 0/5 configured.

No Windows service creation/start, account mutation, signing-key read or
issuance, ACL/UAC change, queue merge or privileged MCP access occurred.
Any future owner action requires separate trust bootstrap and real multi-SID
E2E before P085 can be marked complete.

## 2026-11-08 — independent source-hardening checkpoint

Concrete fail-closed fixes:

1. The owner-only registration script validates ProgramData against the
   Windows CommonApplicationData known folder, rejecting a spoofed environment.
   It requires an absolute local drive-qualified .exe: UNC, device namespace,
   drive-relative path, ADS, environment substitution, control characters and
   quotes are rejected. Every parent directory of the Python executable is
   checked for junction/reparse-point redirection.
2. A sealed stage receipt must contain three *distinct* local user SIDs
   (service, reviewer and worker), each resolving to a real nonadministrator
   local Windows account. Service SID alone is insufficient.
3. After foreground New-Service, the script independently queries SCM to
   confirm Manual, Stopped, Own Process, PID=0, exact ImagePath, and an
   OS-resolved recorded account SID matching the owner-supplied service SID.
   A mismatch does not auto-delete/reconfigure/start the registered service.
4. Read-only service inspection correlates the stored account SID, actual
   process token SID, live executable, live command line and a repeated
   SCM query confirming stable PID/state. Mismatches/unknowns block claims.
   This remains observational, never release authorization.

Native PowerShell parser/runtime checks are STILL UNVERIFIED: the Local
Workspace MCP command allowlist explicitly rejects powershell. Do not work
around that restriction by spawning PowerShell through Python or another
allowlisted executable. A trusted owner can perform the following read-only
syntax inspection in a non-elevated local PowerShell console, on independently
reviewed source files:

    $files = @(
      'P085-OwnerReadOnlyServiceAudit.ps1',
      'Register-P085ProtectedReviewerService.ps1'
    )
    foreach ($file in $files) {
      $tokens = $null
      $parseErrors = $null
      [System.Management.Automation.Language.Parser]::ParseFile(
        (Resolve-Path -LiteralPath $file).Path,
        [ref]$tokens,
        [ref]$parseErrors
      ) | Out-Null
      if ($parseErrors.Count -ne 0) {
        $parseErrors | Format-List
        throw 'P085_OWNER_POWERSHELL_PARSE_FAILED'
      }
    }
    'P085_OWNER_POWERSHELL_PARSE_OK'

The source inspection above does not execute either script and is not a
Windows ACL, SCM, QA issuer, UAC or independent two-SID E2E check.

Service credential semantics: the owner enters the service password via
Read-Host -AsSecureString. The script does not write it to plaintext args,
files or logs, but the Windows SCM/LSA necessarily persists the configured
service logon credential for later service starts. Do not describe this as
ephemeral credential handling.
Microsoft New-Service (Windows PowerShell 5.1):
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/new-service?view=powershell-5.1
Microsoft service account lifecycle:
https://learn.microsoft.com/en-us/windows/win32/services/service-user-accounts

Source SHA-256:
- Register-P085ProtectedReviewerService.ps1: 93cc3ae2d1648682c4532f9ba22d89faa50471ad2e6737a32523cdeea21cb291
- P085-OwnerReadOnlyServiceAudit.ps1: 2c2bcc8ac171ec1f6ec9639b095813d74ae3198981ab637eab00b666328eee31
- test_p085_owner_service_registration_source.py: c002a6ff1b45cd8ea1d3ed7572ef3d69b2a1f0a41346ca62c5bca0ae76ccefb9
- test_p085_owner_scm_readonly_audit.py: 3f21bd252f88806539ce0acdd639cdd55cfe55b8b1dd0a6dbbc43bf0c6ad608e

Verifiable results:
- Registration source tests: 13 PASS (job c0547090036c493a81cd35440c1ce033).
- Combined owner inspection and registration: 22 PASS
  (job 1a8b811c24af4044906d7321144e341e).
- Target P085 regression: 101 tests, 97 PASS / 4 SKIP,
  job 152d2a5869c343e98e5f04047fa83e92.
- Main suite: 2669 tests, 2623 PASS / 46 SKIP,
  job 89ae2bf292154287be46f93f38f6b5e8.
- Full P085 guard: 7/7 suites PASS, 107 source files SHA tracked and
  unchanged during test execution, host-full-suite 270 tests/6 SKIP,
  windows-bootstrap-negative 95 tests/3 SKIP,
  job 43a538e7d1e04f629c74cc3e12c08a4c.
  Evidence file:
  .agent-team/reports/P085_auto_20261107T233401Z_76deebc9fc7a.json
- Windows read-only check c6484935f0424a4e811bd594095baf7d:
  SCM=ABSENT, protected stage=NOT_STAGED, safe_to_activate=false.

Status remains SOURCE FIXES TESTED, OS P085 OPEN. Need five real Windows
role principals, independently protected interpreter and staged code,
owner UAC approval, actual Manual/Stopped service registration and real
two-SID + QA issuer negative E2E. The live MCP still exposes 28 tools
without a verified protected host actor. No auto-merge or host privileges
were granted by this work.

## 2026-11-08 — ancestor ACL and privileged non-admin group hardening

Scope: owner-only registration source and independent static tests; NO
Windows service installation, UAC, file ACL mutation, secrets, grants or
main-queue changes. Live preflight for P085 returned UNKNOWN_TASK:
this is isolated non-queue, source-only defensive work.

Two additional fail-closed checks:

1. Assert-InterpreterAncestorAcl inspects the DACL and owner of every
   Python parent directory through the volume root, not merely the
   executable and immediate parent. SYSTEM, built-in Administrators
   or Windows TrustedInstaller are the only trusted owners/writers.
   Untrusted ownership or WRITE/DELETE_CHILD/DELETE/WRITE_DAC/
   TAKE_OWNERSHIP ACE on any parent blocks registration. Inherited
   non-writing read permissions are allowed. Unknown deny ACEs and
   failed reads are blocked instead of counted as proof of safety.
2. All service/reviewer/worker principals are denied membership in
   BUILTIN Backup Operators (S-1-5-32-551) in addition to the
   BUILTIN Administrators. Backup Operators can receive backup/restore
   privileges despite not being administrators. Unavailable privileged-
   group inventory blocks registration.

Owner caveat: this conservative ancestry check may reject a legitimate
Windows install if any directory, including volume root, has an
untrusted WRITE ACE. Remediate by independently provisioning and
verifying a protected Python runtime, NOT by an agent-driven ACL
relaxation. These are STATIC SOURCE tests only; no PowerShell 5.1
parser/runtime was executed through MCP, and no UAC/SCM/token E2E
identity validation was performed.

Current SHA-256 (supersedes prior dated SHA in this document):
- Register-P085ProtectedReviewerService.ps1:
  ffe3af286d46e65a979e45b246615be684a2fb5eba0527861a0b946d03eed899
- test_p085_owner_service_registration_source.py:
  e9171c5a669820c7b70c6c65facf0193f453f726731845197941e6ecc1c1a42e

Verified jobs:
- Focused registration source QA:
  ddee7e50cb8545feadd03ee37b9d3ddf — 15 PASS, rc=0.
- P085 targeted negative tests:
  9119421a76324acabf6d7f60a88efd25 —
  103 tests, 99 PASS / 4 SKIP, rc=0.
- Full main Python project:
  72f4562fe8e74077a642870e3045aa1e —
  2671 tests, 2625 PASS / 46 SKIP, rc=0.
- P085 autonomous guard:
  36bed805d1f243f8808935b63eae7062 — 7/7 suites PASS,
  107 files SHA-tracked with stable source,
  host tests 270/6 SKIP, Windows bootstrap 97/3 SKIP.
  .agent-team/reports/P085_auto_20261107T234439Z_e64e2228c769.json

OS blockers unchanged: service SCM=ABSENT, protected stage=NOT_STAGED,
last confirmed Windows accounts=0/5, 28-tool privileged MCP surface
still observable, verified host identity=false, independent
two-SID and QA issuer E2E absent, p085_release_ready=false and
auto_merge_authorized=false. This source work does not confer owner
approval or release permission.

## 2026-11-08 — sealed source inventory and owner-only UAC script pin

**New fail-closed source hardening (no privileged deployment):**

1. Owner-only registration now verifies the exact root and source-code directory
   entries of the sealed stage. A matching count of 14 files is insufficient:
   an extra empty directory (including hidden __pycache__) or a reparse-point
   child must be rejected before New-Service. The script enumerates *direct*
   children without recursively following potential junctions. This mirrors
   the canonical, independently tested Python stage-audit structure.
2. The registration dry-run output distinguishes an owner-checked
   interpreter executable SHA from the *unverified* Python DLL, extension,
   standard library and dependent runtime code. The plan now states
   python_runtime_dependency_manifest_verified=false,
   python_runtime_os_attested=false, and service_runtime_ready=false.
   A valid python.exe SHA is not proof of a trusted Python runtime.
3. **Apply-only local execution origin guard:** before a password prompt or
   New-Service, the script requires an absolute local PSCommandPath, no
   reparse point, SYSTEM-owned/immutable script ACL, protected ancestor
   directories and owner-provided ExpectedInstallerSha256 matching the
   *exact script copy that will execute*. This value is mandatory also
   for the non-mutating dry-run CLI. The owner must independently review
   and pin the protected copy outside the writable project, not treat
   its SHA generated inside a chat or repository as trusted evidence.
   Runtime self-validation is defense in depth; it **cannot prove the
   integrity of the already executing code** if the file was compromised
   before Windows PowerShell parsed it. Do not elevate source from an
   agent-writable checkout.

**Scope and limitations:** The PowerShell scripts were NOT run from MCP;
the command allowlist denies powershell, and no alternative executable
was used to bypass that restriction. Native Windows PowerShell parsing,
SCM registration, ACL effective-access checks, independent Windows SID
and QA key E2E remain separate owner-controlled requirements.
New-Service -Credential and Manual startup are documented by Microsoft
PowerShell 5.1; Manual does not mean unstartable by another authorized
Windows principal:
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/new-service?view=powershell-5.1

**Source SHA (latest, superseding prior blocks):**
- Register-P085ProtectedReviewerService.ps1:
  79eebf90189a843901e66b763c5208599f95d96871b09f9f4646914b93cc3cba
- test_p085_owner_service_registration_source.py:
  05c41bdc0eebc55058ad08b2c51b7c9e937916e122c81b93d394f4462b309fc7
- test_p085_stage_audit.py:
  2c6d7e67738329bcc1b94b648b5bfcd81cde78131dc737dbf586205365a246ed

A negative source-contract check originally FAILED for the old
count-only stage check (job e957bb22c8d348ee9cbfb0188b153d0a).
After the exact-tree change, 16 registration tests PASS
(job e0f1a51d5de84e4f8176b3494ba58467).
Actual staged-package fixtures with extra empty directories now fail
closed in test_p085_stage_audit.py, and 46 combined tests pass
(44 PASS/2 SKIP; job bcc97cc2354b491b862aeb1861a9b83c).

**Windows state:** last read-only preflight job
22d9726f737b4434aab52f0166388c75:
SCM=ABSENT, stage=NOT_STAGED, safe_to_activate=false,
runtime code and interpreter OS-protected=false.
Source-only change is not a release, lease or owner cutover.

## Final verification for this source-only cycle — 2026-11-08

After the exact-stage-tree guard, added owner-script SHA requirement and
new adversarial stage fixtures, the final in-process results are:

- Focused owner and stage tests: 46 tests (44 PASS / 2 SKIP),
  job bcc97cc2354b491b862aeb1861a9b83c.
- P085 bootstrap-focused regression: 107 tests
  (103 PASS / 4 SKIP), job 1d215cbd5e4e4967ac82e4d7a9c01daf.
- Full Local-Workspace-Extensions Python suite: 2675 tests
  (2629 PASS / 46 SKIP), job de41c39ec8114876921b21e0a8feb51f.
- Full autonomous P085 guard: 7 of 7 suites PASS,
  source_stable=true, 107 source files SHA tracked,
  Windows negative bootstrap suite 101 tests (98 PASS/3 SKIP),
  host-full-suite 270 tests (264 PASS/6 SKIP),
  job b77ca35ff33249f79f2b2238d34bbc0c.
  Stored report:
  .agent-team/reports/P085_auto_20261107T235509Z_5842cde45586.json.
- Windows read-only preflight: SCM service ABSENT, protected stage NOT_STAGED,
  verified OS host identity false, safe_to_activate=false,
  job 22d9726f737b4434aab52f0166388c75.

No privileged Windows PowerShell script was executed, no accounts or
ACLs were modified and no SCM service was registered or started.
The previous source candidate remains the same pending independent owner
review, and owner_approval_verified=false, p085_release_ready=false,
auto_merge_authorized=false and release_authorized=false remain mandatory.

Before any future privileged step: an independent owner must verify the
SCRIPT **and** Python runtime (not merely python.exe SHA) from a trusted
source, parse PowerShell 5.1 locally, stage the approved protected runtime,
provision separate principals and a protected QA issuer, then execute
actual two-SID positive/negative E2E. The mutable project-side installer
cannot attest its own source integrity.

## 2026-11-08 — effective OS-access probe widened and integrity guard closed

**Risk reproduced:** previous p085_windows_isolation_probe.py attempted a
single CreateFileW access check: FILE_WRITE_DATA for files and FILE_ADD_FILE
for directories. If write-data access was denied while DELETE, WRITE_DAC,
WRITE_OWNER or FILE_DELETE_CHILD was available, the worker might still
replace a supposedly protected file or tamper with its ACL. The previous
assessment also ignored the directories ABOVE the project. This could
produce an overly optimistic effective-write-denied witness.

**Code now fixed (read-only):**

- Query individual requested access masks, not one combined mask, through
  CreateFileW(... OPEN_EXISTING) for files and directories: data/append,
  write EA/attributes, add file/subdirectory, delete child, DELETE,
  WRITE_DAC, WRITE_OWNER. Each successful handle is CLOSED, with no
  WriteFile/DeleteFile/SetSecurityInfo/SetFileInformationByHandle calls.
- A single granted dangerous right yields UNTRUSTED_WRITE_ALLOWED.
  Only all individually denied rights yield
  EFFECTIVE_WRITE_ACCESS_DENIED; ERROR_SHARING_VIOLATION,
  ERROR_LOCK_VIOLATION, DOS read-only flags, unknown errors,
  symlink/junction ancestors or oversized paths remain inconclusive.
- The project assessment checks its WHOLE parent directory chain, with
  anonymous ancestor_1, ancestor_2, ... keys, so a worker cannot replace
  a sealed project through a writable parent. The report does not
  emit absolute source paths or treat one OS token as production release.
- P085 autonomous guard now includes both effective-access and
  cross-principal modules, their tests, and Windows-account read-only QA
  files in the required SHA-tracked source inventory. The mandatory
  windows-bootstrap-negative suite runs both test groups. This closed
  a real observability blind spot: earlier source fingerprints did not
  include these root-level Python files.

**Windows evidence on the EXISTING untrusted MCP user session:**

- Direct non-mutating p085_windows_isolation_probe.py run, job
  6a4f0aff64b54a4bbbd3d6be694aea56, returned rc=3 (expected
  non-isolated verdict), not an execution failure. Existing project
  coordinator DB, source, directory and multiple ancestors granted
  write/child-creation rights. This confirms NO trusted separation
  of the current MCP principal.
- RED witness: job a5d20ecb89174741b5565dec4e339526,
  6 failures for missing independent access checks.
  Job 71fbb9fb06c742bc87e8541ea62ab536
  reproduced the false positive when parent DELETE_CHILD was granted.
- Focused post-fix probe tests including temporary Windows file fixtures,
  fake CreateFileW individual-right requests and cross-principal contracts:
  job f0405c1258d04ac8b96bf0a37dbe4960,
  24 tests / 21 PASS / 3 SKIP, rc=0.
  Related guard + probe QA job 0ab137f510e54df7bba0f67ecbaf036c,
  49 tests / 44 PASS / 5 SKIP, rc=0.
- Main project suite job cc1fd08251644d1c9b6b3b6d51cac38d:
  2686 tests / 2639 PASS / 47 SKIP, rc=0.
- Final autonomous P085 job 3cab766e54594a98b47d1af3b254d179:
  7/7 suites PASS, 114 SHA-tracked files and source_stable=true
  (stable DURING this audit, NOT a claim that no edits occurred before).
  Mandatory Windows bootstrap suite now executes 125 tests, 6 SKIP,
  and source_changed=true vs previous narrow 107-file inventory.
  Evidence file:
  .agent-team/reports/P085_auto_20261108T001128Z_f7d1f7b618b6.json.

**Source SHA-256 for independently reproducible review:**
- p085_windows_isolation_probe.py:
  6fe3b6565142ce18863a9fe3c7f0112e39f32ad43c7d298905cb2f3782267fcf
- test_p085_windows_isolation_probe.py:
  6c9b753d53cf9ac2a6cf9446a390e576e854ba55345a2dfd5432335f5ae9a933
- p085_autonomous_guard.py:
  118c7381bffa0738bf203541bd1e3c6e71697ee7635c79945c3609d4f4d907a6
- test_p085_autonomous_guard.py:
  89eba70d58dc6d086de81d11b29f1867acf8187cd961e77fc82d3376cda3b75e

Windows API semantics verified from Microsoft Learn:
https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew
https://learn.microsoft.com/en-us/windows/win32/fileio/file-access-rights-constants

**Release blockers NOT resolved:** real service SCM=ABSENT,
protected installation NOT_STAGED, host identity not OS-verified,
independent real worker/reviewer/QA issuer login tests missing.
The 28-tool untrusted MCP is still writable, auto_merge_authorized=false
and p085_release_ready=false. An effective-access probe is only a
negative witness under the actual tested token, never an
owner-signed grant or authority to accept/merge work.

## 2026-11-08 — cross-principal stage write denial now mandatory

**Critical negative witness bug reproduced and fixed.** Earlier
p085_cross_principal_probe.py checked coordinator source/SQLite write
denial and file READ_DATA denial for two private-state key names,
but did NOT check whether the UNTRUSTED WORKER could MODIFY the
separately staged P085 broker itself. It could emit
worker_negative_access_witness=true even when:

- p085_reviewer_service.py in the protected stage was writable;
- the protected code stage was MISSING, although project source and
  private key READ_DATA were reported denied; or
- a parent of the protected stage had DELETE_CHILD and could enable
  replacement of the stage tree.

New canonical probe_protected_install() reuses the same Windows
CreateFileW requested-access probe (not a second WinAPI implementation)
and the single EXPECTED_FILES inventory from p085_stage_audit.py.
The worker-negative witness now requires every result to deny
write/replace/ACL takeover capabilities for 14 expected staged
source files, the stage root, code/workspace_mcp/p085_trusted
directories, receipt, private_state directory, and all ancestors.
Results are labeled (no absolute file paths or key contents).
Missing, linked or unknown access produces INCONCLUSIVE, never
an accepted negative witness. A matched self-reported worker SID
is NEVER independent Windows multi-principal attestation.

Also hardened probe_key_read() so symlinks/junctions in ANY
parent path and errors during link inspection fail closed,
instead of silently continuing to try a key-read test.

**Measured RED -> GREEN evidence:**
- job 711e0ac0bc1f4e3e870b1000a07df750 — three negative
  tests FAIL on the old implementation, reproducing false-positive
  worker_negative_access_witness.
- job c3fd8873a00a4100a7a0d2c2ce433b29 — failed key-path
  inspection returned KEY_READ_ALLOWED instead of inconclusive.
- job 69b57fb196744a1c9c3f33beb5f75c72 — 29 scoped
  tests, 26 PASS / 3 SKIP.
- job 3ea0029fd488461ea8d695656ecf65bf — after final link
  hardening, 31 tests, 27 PASS / 4 SKIP.
- job 6b654fde396b44d5a1d583969bdaa88f — complete
  Local-Workspace-Extensions Python suite: 2693 tests,
  2645 PASS / 48 SKIP, returncode 0.
- job 7b966791e32b47bbb44ad8632c50c950 — full
  autonomous P085 guard: 7/7 PASS, source fingerprint stable
  during audit, 114 source files SHA-tracked; mandatory
  Windows bootstrap 132 tests / 7 SKIP; protected host 270
  tests / 6 SKIP; report:
  .agent-team/reports/P085_auto_20261108T003534Z_ed935d512904.json.
- job 4bc0435b3193468384bdd5c60491350b — Windows
  read-only preflight SCM=ABSENT, stage=NOT_STAGED,
  python_runtime_os_protected=false, safe_to_activate=false.

**Current exact SHA-256:**
- p085_cross_principal_probe.py:
  6f4d5ea4d807c658ddef8663eb956c460fa47f19b10199e8c7acc58898571b62
- test_p085_cross_principal_probe.py:
  ea2dee43b86bc216ba459f9dbd9e47f26160fbf00ab0fc7686e39f49047d7528
- p085_windows_isolation_probe.py:
  6fe3b6565142ce18863a9fe3c7f0112e39f32ad43c7d298905cb2f3782267fcf

**Safety boundary unchanged:** task_reuse_preflight.py P085
still reports UNKNOWN_TASK; no lease, approval or ownership
was invented. No Windows service/accounts/ACL, key reads,
signed grants, running MCP permissions, coordinator DB or
agent queue were changed by this work. This diagnostic
is strictly read-only and cannot enable cutover; P085
release_authorized=false, auto_merge_authorized=false and
p085_release_ready=false until independent owner UAC and
real two-SID/QA E2E are completed.

## 2026-11-08 — independent signing-key write rights

**Confirmed critical false-positive:** previous cross-principal probe verified
FILE_READ_DATA denial for review-key.bin and qa-verify-key.bin but did not
check dangerous WRITE_DATA, DELETE, WRITE_DAC or WRITE_OWNER rights on
these files. Under a simulated worker with key READ denied but WRITE allowed,
the old worker_negative_access_witness returned true.

Now p085_cross_principal_probe.py reuses the canonical non-mutating
p085_windows_isolation_probe.probe() for each of the two key paths.
The worker witness requires BOTH key read denial and key write/delete/ACL
denial, in addition to the worker SID match, coordinator access denial,
staged-code/parent directory write denial. private_key_write_access
contains path-free state labels; no key bytes are read or modified.
Metadata unavailable under a protected SID remains INCONCLUSIVE,
not a positive witness. Key existence and independent QA issuer identity
must still be attested separately by an owner-controlled actor.

**Repro and proof:**
- RED job defd5f5c79ad452599fc118ca813395d: two failing negative
  tests with WRITE_DATA allowed while READ_DATA denied.
- GREEN job bd10ad2c648d465c94e9e949ea8c9fee:
  33 tests / 29 PASS / 4 SKIP.
- Actual disposable Windows files job 9bdd429eddba4b849be0c9b1b5fe1915:
  34 tests / 30 PASS / 4 SKIP. Source and fake key bytes unchanged
  after WinAPI access queries.
- Main project full suite e6aacecbebb84c8d813dfd9f33cc4ea9:
  2696 tests / 2648 PASS / 48 SKIP, rc=0.
- P085 autonomous guard 252c18c326e74d88939e4eb34e7ac76d:
  7/7 suites PASS, 114 SHA-inventoried source files,
  windows-bootstrap-negative 135 tests / 7 SKIP.
  Report: .agent-team/reports/P085_auto_20261108T004710Z_6d06d20f2934.json.
- Real Windows read-only preflight 8098a7c451d64f22943ddf257dea04f2:
  SCM=ABSENT, protected stage=NOT_STAGED, OS runtime untrusted,
  safe_to_activate=false.

Source SHA-256 after this cycle:
- p085_cross_principal_probe.py:
  5bbe739f4f5ecd73964e158e6f54b9545105439fdb59edb6a6eb609e842362a5
- test_p085_cross_principal_probe.py:
  9c481796379439c44957a2bb368015a0e80f5e8288c10c28e9986dae594107b1

P085 task_reuse_preflight remains UNKNOWN_TASK; no lease, owner approval,
privileged Windows action, live queue mutation or signed QA grant was
invented. This is source-only engineering, not a production release.

## Test and trust limitations

The Local Workspace command allowlist rejected the executable powershell, so neither script was run on Windows by this chat. The Python source-level tests are not a PowerShell parser/runtime check. Windows read-only diagnostics from this session reported accounts_configured=0/5, service SCM=ABSENT, stage=NOT_STAGED, interpreter OS protection=false, safe_to_activate=false. Do not promote software test PASS to P085 release readiness.

See docs/P085_OWNER_UNBLOCK_EVIDENCE_20261107.md for prior source and regression evidence. This supplemental owner-facing document is non-authorizing.
