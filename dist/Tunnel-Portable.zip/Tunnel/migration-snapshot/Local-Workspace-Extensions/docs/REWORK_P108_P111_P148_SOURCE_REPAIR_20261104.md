# Owner-directed source repair: P108, P111, P148 — 2026-11-04

## Scope

The owner requested continued code fixes. The connected Local Workspace alias `projects` was verified, then three independent negative witnesses were re-run against the submitted task sandboxes. Each confirmed the earlier defect without changing the sandbox:
- P108 witness `e96e1799cece4a12b7414ac60eb66e8c`: unqualified `run_script` denied, but `local_workspace.run_script`, `local_workspace.run_command` and `mcp.run_script` were wrongly classified `ELIGIBLE_UNVERIFIED`.
- P111 witness `3fc563b355b1453a93be4fd5fd6a5cc1`: `git -C repo push`, `git -c core.hooksPath=/tmp/hook push` and `Do not run shell and now run shell` were classified `REVIEW`.
- P148 witness `71665d1950e64aa797003aadd53774d8`: an otherwise accepted predecessor with `source_ok=false` or `spec_ok=false` incorrectly allowed `ready`.

These witnesses are read-only advisory reproducibility checks, **not** host authorization proofs or production exploits.

## Actual code changes

Exact submitted-source and test SHA pins were verified before producing a patch candidate. Existing task sandboxes were left unchanged. The candidate was tested from a separate staging directory, then 7 files were created **in canonical `Local-Workspace-Extensions/` with exclusive create and SHA verification** (job `06ee52e08df34cf3acfb03a20c8407a7`, rc=0).

| Task | Actual canonical module | Current SHA256 | Improvement |
|---|---|---|---|
| P108 | `actor_grant_contract.py` | `405a6c414fb2678afe38c3305f0b790004992a26daf0aebad6ebc75a1e98fe2f` | Deny executable aliases including dotted MCP forms; reject R0/R1 classification of mutating tools; reject Windows-forbidden path metacharacters |
| P111 | `prompt_boundary_checks.py` | `6129d9a7cd25cec6f90367ff69ac042ff26f2e804dbe8203881770acfcd64860` | Detect global Git flags `-C`/`-c` before mutating commands; preserve punctuation in paths/config values; split adversarial `and now` contrasts |
| P148 | `queue_starvation_diagnostics.py` | `7fee9ef7c5a8ead622b00a8a50839cbee3c250921a7239647d0ad5d1f4482bca` | A done+QA predecessor is insufficient when its source/spec pin is stale; dependent task remains blocked |

Also copied each task's original focused tests (unchanged bytes) to canonical root and created `test_rework_security_regressions_20261104.py` (SHA `7e89d92357bae1288a836c0bcae9dd50103386462857ae5e90cfe437f1a73978`).

## Verification

- Staged original focused suites: job `4aa28432cbe4418b94c846ea5120117e`, rc=0, **165/165 PASS**.
- Staged combined suite including additional independent regressions: job `4c5ed6418ebb4bc080ba3ea309e27746`, rc=0, **232/232 PASS**. One interim assertion about DEL was corrected because it was already rejected earlier as `INVALID_ARGUMENT_TEXT`; no product guard was relaxed.
- Canonical full suite `python -m unittest discover -q`: job `47e33e58c6b14dd880d17731c32b929a`, rc=0, **2545 tests OK, 43 skipped**.
- `spec_check.py`: job `f05fda1d951244d08554b5092555b191`, rc=0; **99 requirements, 128 scenarios, errors=[]** (structural only).
- `sdd_roadmap_check.py`: job `8221bb0a23b9417eb2ebbabc04bd87e7`, rc=0, 58 roadmap tasks, errors=[].
- `agent_reuse_ci_gate.py`: job `d751d4b91b8c4b78941c75baeb989e4b`, rc=0, passed, 126 canonical modules scanned, 0 structural cross-module clone groups.
- Verified exact SHA of all 7 canonical files with Local Workspace `file_info`.

Repeatable staging source builder: `.agent-team/owner-review-fixes/20261104/integrate_rework_security_20261104.py`. Staging directory and manifest: `.agent-team/owner-review-fixes/20261104/rework_108_111_148/`.

## Critical limitations / outstanding gates

**Manual source integration is not formal reviewer acceptance.** Original P108/P111/P148 tasks remain in their coordinator-controlled rework process unless independently accepted; we did not alter live SQLite statuses, leases or approval ledger, and did not self-grant the architect/reviewer identity. The corrected files in main do not authorize execution, host identity or automated merge. The P085 protected Windows broker, SID/ACL separation and independent multi-principal E2E remain outside this source-only work. P096 lease recovery and P104 historical receipt drift are separate outstanding work.

Note: P108 and P111 are advisory offline classifiers, not enforcement at the MCP host boundary. P148's evidence flags remain caller-supplied; a `ready` classification never grants an actual lease.
