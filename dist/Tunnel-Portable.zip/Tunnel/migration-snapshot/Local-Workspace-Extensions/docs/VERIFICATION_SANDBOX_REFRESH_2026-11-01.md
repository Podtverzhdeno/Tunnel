# Пятиагентная OpenSpec/SDD команда — безопасное обновление тестовой песочницы

Дата проверки: 2026-11-01, около 17:41 UTC.
Проект: C:\Users\user\IdeaProjects\Local-Workspace-Extensions.

## Проблема, наблюдавшаяся в реальном запуске

Developer 2 выполнял P021: offline dependency review. В SQLite checkpoint 2026-11-01 17:25:19 UTC записано:
- `dependency_review.py` + `test_dependency_review.py` реализованы;
- focused unittest: 21 тест, 1 skip, exit code 0;
- полный sandbox unittest: 359 тестов, 20 skip, но **3 KeyError** в старых coordinator test mocks, полученных с прежней версией `agent_team.py` / `test_agent_team.py`;
- существующий `rebase-spec` обновляет только OpenSpec/SDD, а ручная правка служебных Python запрещена `UNSCOPED_CHANGE`.

Корневая причина: `_snapshot` копировал все root Python-файлы в момент acquire, затем `_candidate_files` требовал точных baseline SHA для каждого недекларированного файла. У параллельных агентов основной Python тестовый runtime изменялся быстрее, чем отдельная песочница.

## Изменения в коде

**`agent_team.py sync-sandbox ROLE TASK_ID ACTIVE_LEASE_TOKEN`**:
1. Только developer-1..4, только текущий действующий task lease. Запрещена чужая роль, истёкший токен и pending reviewer merge.
2. Обновляет исключительно root Python-файлы, **которые НЕ входят в список deliverables данного задания**: добавленные, изменённые или удалённые служебные исходники/тесты. Все source/sandbox хеши проверяются по SHA-256 до первого изменения.
3. Не трогает собственные `dependency_review.py` / `test_dependency_review.py`, `agent_progress.json`, задачи соседних агентов, OpenSpec canonical reference и связанный `__spec_sha__`. Изменение spec по-прежнему требует отдельного `rebase-spec`, с активным lease оно блокируется.
4. Любая нестандартная правка невыходного файла (SHA не соответствует ни old baseline, ни актуальной main) отклоняется без перезаписи. Проверяет symlinks/junction и MAX_BYTES; bounded 250 Python names.
5. Отслеживает изменения после staging и обновляет `__snapshot_py__` в SQLite только после всех source hash сверок.
6. Повтор без изменений возвращает пустой `refreshed`. Если процесс был прерван после одного-двух файлов и перед SQLite commit, при стабильном main можно повторить refresh только для исходных/ожидаемых хешей. При обычной ошибке в середине `os.replace` выполняется best-effort rollback. Это **не транзакционная атомарность ОС**.
7. Записывает UTC activity/event `sync_sandbox`, число обновлённых файло́в. Ревьюер по-прежнему обязан проверять итоговые deliverables и независимый тестовый gate.

Временная спецификация: FR-041 / P099 и тест T047 отмечены реализованными; P100 и T048 ожидают реального scheduled подтверждения, не ставятся как done.

## Регрессионные тесты

Добавлены отдельные случаи:
- refresh изменённых и новых non-deliverable файлов при неизменных собственных deliverables и checkpoint;
- идемпотентный повтор;
- чужая роль и expired lease;
- запрет перезаписи изменённого служебного файла;
- безопасное повторное продолжение после частичного refresh;
- удаление ранее отслеживаемого файла, убранного из main;
- необходи́мое сохранение main-source conflict для own deliverables;
- mid-copy failure с возвратом уже обновлённого файла и успешной последующей попыткой;
- stale canonical OpenSpec не обновляется и `submit` по-прежнему возвращает `SPEC_CHANGED`.

## Фактические результаты

| Проверка | Наблюдение |
| --- | --- |
| `python -m unittest discover` | **388 тестов: 369 PASS, 19 SKIP, 0 FAIL**, exit 0 |
| `python spec_check.py` | **11 capabilities, 97 requirements, 121 scenarios, 41 FR mappings, 48 SDD tasks, 101 OpenSpec tasks**, 0 errors |
| `validate_upstream.py` | Реальный OpenSpec CLI 1.14.3, local-pc-agent-tooling strict PASS |
| `agent_team.py gate-check` | unittest/SDD/OpenSpec strict PASS, **388 тестов, 19 SKIP**, подтверждено повторно 17:43 UTC |
| `run_mcp_wire.py` | 9 standalone stdio MCP tools, **16/16 E2E PASS** |
| `team_acceptance_audit.py` | recorded_pass=2, legacy_unverifiable=7, invalid_evidence=0, not_accepted=2 |

Живой `overview` на 17:40:56 UTC: 9 done, 2 working (P021 developer-2 и P096 developer-3). У P021 lease до 18:05:21 UTC. С учётом ownership **не запускали `sync-sandbox` с чужим активным token**. Промпт Developer 2 дополнен инструкцией использовать **фактически выданный** активный lease и выполнить sync при следующем запуске, а Reviewer — проверить фактическое качество P021, а не отменять проверку изменений.

## Остающиеся ограничения

- Реальный запуск `sync-sandbox` именно внутри live P021 и его полный цикл до `accept` ещё **не подтверждены** — тестирование прошло в disposable fixtures с действительными независимыми lease из тестовой SQLite.
- P096 выполняется developer-3; не изменяли её deliverables.
- MCP host-side authenticated actor grants (P085) **не реализованы**. CLI role + lease — логические проверки, а не OS sandbox; мощный Local Workspace run_script остаётся системным обходом этой границы.
- Исторические 7 acceptance событий не получили выдуманных QA records.
- Принудительная остановка в момент обновления snapshot и power-loss не может гарантировать общую атомарность Windows ФС и SQLite; при unexpected hash — fail closed, ручная диагностика.

Все файлы редактировались только в авторизованном проекте. Не менялись другие пользовательские репозитории, Git remote, локальный MCP bridge, система Windows и посторонние автоматизации.
