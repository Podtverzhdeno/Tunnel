# Scheduler activity health — проверенный checkpoint (7 ноября 2026)

## Что реализовано

- `scheduler_activity_journal.py`: зафиксированный lifecycle start/finish, idempotent finish, короткие самоотчёты о тестах/файлах/причинах остановки. Упрощённые суточные и недельные отчёты: `report-recent --days 1|7`.
- Новый `health`: возраст последнего подтверждённого запуска, enabled-состояние только из свежего снимка (`scheduled-card-observation-v1`, срок доверия 15 минут), оценка незакрытых receipt, подозрение на отсутствие receipt после начала инструментирования. Никакое локальное наблюдение не доказывает пропуск платформенного запуска.
- Существующие четыре ChatGPT Automation сохранены и включены. У всех в заданиях инструкции start/finish; у Architect дополнительно health + отчёты 1/7 дня и условный свежий peek снапшот. Порядок проверки: start -> полезная работа -> health/reports -> finish.
- Никаких изменений live SQLite, P085 grants, Windows broker, Git, частоты планировщика, API ключей или платных операций.

## Проверено

Тестовое задание `9dca1d1b7b7b48b9ab8f10bee642d0aa` завершено: `python -m unittest discover -q`, **rc=0; 2632 tests, skipped=45**. Фокусное задание `8959698fd2d34525ab1d94c1d3a8a3d5`: `62 tests, skipped=1, rc=0`.

Актуальные SHA256:
- `scheduler_activity_journal.py`: `1565962e58d1b5719bbc6e72c037be55678d9e67544bfa2cde9f7799fb39110c`
- `test_scheduler_activity_journal.py`: `43954c9afe7ca637acccf0bc04cceb944d6ebb668efa8f794dc48908a4f7073a`
- `test_scheduler_activity_monitor.py`: `759f6d3e313d53dcd9358318c38e543a0eedee922de8f00ea3e99c5963afd403`

Срез `scheduler_card_status_latest.json` получен непосредственно из четырёх Automations.peek на `2026-11-07T00:01:32.525Z`. Все четыре enabled, последние запуски completed. `health` на `2026-11-07T00:01:41Z`: 4 × RECENT_SCHEDULER_OBSERVATION, `rc=0`, `ok=true`. Срез автоматически устаревает после 15 минут.

Сохранённый частичный scheduler-run-history: 16 наблюдений, 4 роли. Сводка за семь локальных календарных дней на момент проверки: 5259 секунд, 16 записей (НЕ полная история платформы). Нет настоящих self-report после rollout; `.agent-team/reports/scheduler_activity_journal.json` пока отсутствует, что нормально до новых scheduled-turn.

## Следующий подтверждаемый этап

1. После ближайших реальных запланированных запусков проверить, создался ли `.agent-team/reports/scheduler_activity_journal.json`, содержит ли ровно один begin/finish на карточку и были ли реальные тесты/job IDs.
2. Если карточка обновилась, получить её свежий `Automations.peek`, сохранить новый снапшот через SHA-CAS и выполнить `scheduler_run_history.py --snapshot ... --save`; нельзя имитировать прошлые run IDs.
3. Запустить `scheduler_activity_journal.py health --threshold-minutes 120 --card-snapshot ...` и `report-recent --days 1`, `--days 7`. При отсутствии API для peek использовать локальный health без enabled-сигнала.
4. Для P085 нужны отдельное защищённое подтверждение host identity, broker и реальные grant/lease. В `P085_auto_latest.json` до этой разработки `verified_host_identity=false`; фраза об одобрении не равна удостоверенному OS-гранту.

Нет оснований обещать 60 минут работы модели за запуск, считать self-report подлинной аттестацией или утверждать завершённый production E2E до следующего scheduled-run.
