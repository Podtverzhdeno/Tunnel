# Основной тариф: GPT-6 Sol — оценка стоимости scheduled-задач

Дата проверки официального прайса: 2026-11-01. Источник: https://developers.openai.com/api/docs/models/gpt-6-sol

- **Выбранная для расчёта модель:** `gpt-6-sol`, не `gpt-6.1-sol`.
- **Standard / short context / USD за 1 млн токенов:** input $2, cached input $0.20, output $10.
- Расчёт применяется **к каждому наблюдаемому запуску задачи**, затем суммируется по scheduled-задаче и по всей команде. Нет минимального порога покупки «миллиона токенов».
- Это **условная стоимость через API**, а не фактические списания. Исходное количество токенов — некалиброванная эвристика. По умолчанию кеширование неизвестно и принято равным 0.
- **Thinking High планировщика: не подтверждено.** У всех четырёх активных Automation есть расписание, инструкции и результаты, но нет открытого параметра `thinking_effort`, `model` или `reasoning_effort`. Настройка High этого чата не доказывает её перенос в scheduled-запуски. В report: `scheduler_model_verified=false`, `scheduler_thinking_effort_verified=false`.

## Срез доступной истории

11 уникальных завершённых scheduler-запусков, найденных в сохранённых числовых наблюдениях на 2026-11-01. Это **не все** запуски аккаунта за месяц.

| Scheduled-задача | Наблюдаемых запусков | Сценарий input tokens | Сценарий output tokens | Условная API-стоимость Sol |
|---|---:|---:|---:|---:|
| OpenSpec — Developer 1 | 3 | 67 120 | 13 216 | **$0.266400** |
| OpenSpec — Developer 2 | 3 | 69 254 | 12 966 | **$0.268168** |
| OpenSpec — Developers 3+4 (совместный run) | 3 | 74 350 | 15 217 | **$0.300870** |
| OpenSpec — Architect Reviewer | 2 | 55 528 | 10 120 | **$0.212256** |
| **Итого** | **11** | **266 252** | **51 519** | **$1.047694** |

**Нельзя** разбивать совместную automated-задачу Developer-3+4 на два фактических API-счёта. Также нельзя присваивать стоимость конкретным coding ticket `P104`/`P105` без достоверного сопоставления `scheduler run_id → ticket_id`; этот отчёт агрегирует **именно запланированные задачи и их запуски**.

## Запуск

В каталоге `Local-Workspace-Extensions`:

```powershell
# Обновить грубую оценку токенов по накопленной истории
python token_spend_estimator.py --observations .agent-team/reports/scheduler_run_history.json --save-report

# Получить и сохранить стоимость API по умолчанию по GPT-6 Sol
python api_token_pricing.py --token-scenarios .agent-team/reports/token_spend_scenarios_latest.json --save-report

# Общий отчёт за UTC месяц: токены, API GPT-6 Sol, фиксированная подписка
python team_run_metrics.py --observations .agent-team/reports/scheduler_run_history.json --month 2026-11 --estimate --api-pricing --subscription-cost

# Если нужны альтернативы для сравнения
python api_token_pricing.py --token-scenarios .agent-team/reports/token_spend_scenarios_latest.json --model all
```

Файлы `.agent-team/reports/api_token_cost_latest.json` и `.agent-team/reports/token_spend_scenarios_latest.json` — **раздельные** числовые прогнозы. `subscription_cost_allocation_latest.json` — самостоятельная метрика распределения фиксированной подписки $20 по времени, её нельзя складывать с API-сценарием.

Тариф API следует перепроверять на официальном сайте при изменении прайс-листа. При другом API SKU или контексте больше 272K входных токенов действуют другие ставки.
