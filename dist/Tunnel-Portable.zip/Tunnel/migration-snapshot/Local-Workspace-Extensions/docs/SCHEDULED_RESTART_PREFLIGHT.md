# Scheduled chat restart preflight (read-only)

**Scope:** `scheduled_restart_preflight.py` is a standalone advisory tool in `Local-Workspace-Extensions`. It is **not** host authentication, an MCP server change, an automation trigger, permission to take a lease, nor an agent's proof of successful work.

## Per-turn usage

After re-reading canonical OpenSpec/SDD and before choosing a task to acquire, call with the actually selected task ID:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python scheduled_restart_preflight.py --task P110
```

Via existing Local Workspace MCP, call `run_script` with `workspace="projects"`, `path="Local-Workspace-Extensions/scheduled_restart_preflight.py"`, `cwd="Local-Workspace-Extensions"`, and `args=["--task","P110"]`. Then check `job_status` and `job_output` to verify the actual response.

The command uses `task_resume_packet.build_packet` and a separate SQLite `mode=ro` read with `PRAGMA query_only=ON`. It reads only public task status, owner, role hint, deadline, revision, last activity and *timestamp only* of the last checkpoint. It never queries or returns a lease token, checkpoint body, private chat or secret.

## Decision contract

| Decision | Meaning | Allowed subsequent step |
| --- | --- | --- |
| `WAIT_LEASE` | Previous exclusive lease is active and inaccessible to this new turn | Do not steal/revoke; do read-only checks or another separately eligible task |
| `REQUEST_FRESH_ACQUIRE` | Old task lease expired or unowned ready task has verified recorded dependencies | **Only advisory:** normal host-authorized `plan-work/new-request/acquire` is still required; race must be rechecked atomically |
| `WAIT_REVIEWER` | Independent review or review-in-progress | Do not self-accept or mutate |
| `STOP` | Already done, missing prerequisites, contradictory/missing metadata | Stop, investigate or route to reviewer |

All responses carry `may_mutate=false`, `may_recover_lease=false`, `may_trigger_chat=false`, `host_actor_authenticated=false`. Even a green preflight cannot authorize writes.

## Defenses / limitations

1. Unknown or spoofed receipt provenance, missing accepted predecessor, inconsistent owner, malformed timestamp, incorrect/changed task status and unsafe DB path fail closed.
2. Active lease holders with a real token must still use their own coordinator fencing; a new scheduled turn does not inherit that token.
3. A missing/ambiguous read is a diagnostic error, not evidence of an expired or recoverable lease.
4. Checkpoint timestamps establish only presence of a saved record, never that it is correct or host-verified.
5. The local `run_script` MCP executor is still an unrestricted privileged path; host-side enforcement and actor identity (HOST-001..005, P085) remain unimplemented and must be validated outside this repo.
6. This script is not a general crash reconciler for reviewer merge intents. Use `team_recovery_diagnostics.py` / owner recovery procedure for those incidents.
7. This does not initiate ChatGPT web turns. Existing Automations are the supported trigger; no unsupported browser UI automation or API call is made.

## Verification

`python -m unittest test_scheduled_restart_preflight test_task_resume_packet test_team_recovery_diagnostics` (72 tests, 2 platform-specific skips, PASS on Windows). `python spec_check.py` and existing strict `openspec validate --strict` pass.

New feature is not an accepted/released agent task until the normal owner/independent reviewer process validates it. The script does not modify canonical specs, production queue or privileges.
