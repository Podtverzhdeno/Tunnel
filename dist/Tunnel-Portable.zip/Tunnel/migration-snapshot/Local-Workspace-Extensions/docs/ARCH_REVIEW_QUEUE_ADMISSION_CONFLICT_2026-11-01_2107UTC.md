# Architect Reviewer — queue admission conflict (2026-11-01 21:04–21:07 UTC)

## Finding: HIGH / release-blocking SDD gate regression

During this reviewer run, a separate concurrent coordinator invocation inserted P108, P125, P110 and P111 into team_seed.json and live SQLite at 2026-11-01T21:04:20Z, recording the role string architect-reviewer. This run DID NOT seed these tasks. The role string in the CLI is not host-authenticated (P085); do not infer which physical actor performed the operation.

At 21:00:53Z SQLite overview showed 14 done / 1 rework (P096), no available tasks. After concurrent changes, live status showed 14 done / 1 rework / 4 available, task_count=19.

Before insertion, team_seed.json SHA256=2ceac35e831249527c31a1cff47f78f3b387a6612032c45f939d9507d5e6cbc3. After insertion SHA256=cba7176a28669d7f781d9bcb2e192c84217422c2b8925cbfd754ace8fc66dc42. roadmap_tasks.json SHA256=175143c1bd938540e865d603b25a8cc27f848caf5045e482093bbb612c43892b remained unchanged.

The roadmap explicitly has admission=blocked_pending_dependencies_and_spec_review, spec_status=proposed_requires_canonical_mapping, spec_ref=null for all four new tasks. The accepted dependencies are present, but the canonical mapping/admission gate was NOT cleared. The newly seeded entries instead reuse broad existing headings:
- P108 (developer-1, depends P104): security-governance / Tool-by-tool authorization; actor_grant_contract.py + test_actor_grant_contract.py.
- P125 (developer-2, depends P105): agent-orchestration / Per-agent provider-reported LLM token accounting; model_price_contract.py + test_model_price_contract.py. The cited requirement governs usage receipts, NOT model-price contract acceptance.
- P110 (developer-3, depends P106): observability-recovery / Restore and rollback; crash_reconcile_plan.py + test_crash_reconcile_plan.py.
- P111 (developer-4, depends P104): security-governance / Tool-by-tool authorization; prompt_boundary_checks.py + test_prompt_boundary_checks.py. The cited requirement does not define the proposed untrusted-text classifier.

The four output pairs are distinct and no task IDs were duplicated. However, disjoint files and accepted predecessors are necessary, not sufficient, for SDD admission.

## Reproduced QA regression

Before concurrent seeding:
- sdd_roadmap_check.py: exit 0, 44 roadmap tasks, 4 ready seeded, 40 future blocked, errors=[].
- spec_check.py: exit 0, 11 capabilities, 99 requirements, 128 scenarios, 43 FR mappings.
- validate_upstream.py: exit 0, OpenSpec 1.14.3 strict valid.
- python -m unittest discover: exit 0, 787 tests, 23 skipped.

After concurrent seeding:
- sdd_roadmap_check.py: exit 1; errors DEPENDENT_TASK_SEEDED_EARLY_P108, _P110, _P111, _P125.
- agent_team.py gate-check: exit 1, TEST_FAILED.
- python -m unittest discover: exit 1, 787 tests, 23 skipped, one failure in test_sdd_roadmap_check.RoadmapChecks.test_real_project_roadmap_matches_seed_and_requirements.
- Acceptance audit prior to seeding: 7 recorded_pass, 7 legacy_unverifiable, 0 invalid_evidence. Recorded_pass is local evidence, not host actor authentication.

## Required safe resolution (owner/reviewer coordination)

1. Treat P108/P125/P110/P111 as NOT ADMITTED despite available SQLite status. Do not acquire, implement, submit or accept them until admission is repaired. Inform all four developer roles.
2. Obtain actual owner-approved canonical OpenSpec requirements and SDD mapping for each specific behavior (especially price contracts and untrusted prompt classification), including negative acceptance tests, security scope and host/owner limitations. A markdown report or model role string is NOT owner approval.
3. Use a supported transactional coordinator mechanism to reconcile/withdraw incorrectly seeded available tasks, or introduce such a tested mechanism in an independently authorized change. No manual SQLite edits, no lease resets, no bypass of sdd_roadmap_check. If a task was already acquired, preserve its lease and outputs and escalate rather than forcibly changing its state.
4. Only after approval update the roadmap's spec_ref/spec_status/admission consistently, verify dependency ACCEPT and disjoint outputs, and run sdd_roadmap_check, full unittest, spec_check and strict OpenSpec. Verify the queue's actual state after any permitted mutation.
5. P096 remains rework with stale source baseline: main agent_team.py SHA256=c6dd768ffa068b44d5212c679fab38e434f971e551d45384e3f3c8bcc6b2cdb9 versus P096 candidate ef09564998b2904525612a3310a84176f48cb2057b8c71b45037c1195d9d9a4d. Main test_agent_team.py SHA256=7904f80e712ea2da2b10d8ae3141296bebfee206ade25f458ff0e54059e7ed6e versus candidate 4f0117ff27f40374afee0cae7356252611b40972cc31a97a82393bcda68b2337. Never merge the stale pair. P106 is independently DONE.

## Evidence and limits

All commands above ran via Local Workspace projects with job_status/job_output checked. This run made no Python, canonical OpenSpec, roadmap, team_seed or SQLite edits. No review lease was available (acquire returned task=null). No acceptance or checkpoint was simulated. P085 host-authenticated actor grants and OS-level sandbox are still unverified. No real LLM provider usage was observed: input/output tokens UNKNOWN, not zero.
