# Multiagent SDD V3 — Formal interface, state and evidence contracts

Date: 2026-11-02  
Status: DRAFT contracts, non-normative; NOT the live agent_team.py API or schema  
Companion: docs/MULTIAGENT_ARCHITECTURE_SDD_V3_2026-11-02.md  
Source of truth: current owner-approved OpenSpec + existing coordinator and acceptance ledger

## 1. Contract design rules

C-001 Data schemas are versioned; unknown required major versions fail closed. Unknown optional fields may be preserved for forward compatibility only if the owning parser explicitly defines how to ignore them safely.

C-002 A preview/plan result has no mutation authority and never contains a reviewer acceptance credential, live lease secret or an owner approval.

C-003 State-changing calls require current coordinator revision, valid fenced lease and authenticated host principal when a privileged effect is involved. A request may return UNKNOWN even if a side effect happened. No blind retry.

C-004 All content-addressed identifiers use stable canonical serialization, not platform-native str(dict), local time or filename. Canonicalization must be explicitly versioned.

C-005 Every field must be marked REQUIRED, OPTIONAL, NULLABLE or UNKNOWN_ALLOWED. The difference between absent data and a measured zero is material.

C-006 Source changes must not silently make earlier evidence valid; test and spec references are pinned to the examined revision.

C-007 Freeform model response is always untrusted data; schemas do not give text security authority.

C-008 The existing coordinator and its CLI are canonical. These contracts are target adapters and future changes only. No migration or new write API is authorized from this document.

## 2. Artifact and revision identifiers

- project_id: stable owner-reviewed project identifier, not arbitrary directory traversal.
- task_id: registered task identifier, not a substitute for a source hash.
- task_revision: integer increase for any task contract/scope/spec change; coordinator-owned.
- attempt_id: opaque unique ID for one role's work attempt, not a platform scheduled job ID.
- lease_epoch: monotonically increasing per task; opaque tokens remain host secrets and never go into reports.
- invocation_id: actual observed scheduler run identifier if available, else NULL with source=UNOBSERVED; shared D3+4 card is one invocation even with two logical roles.
- effect_id: host-scoped operation identity; request_id and effect digest protect idempotency.
- evidence_id: digest/address of a verified assertion; existence does not imply trust.
- source_sha256: digest of canonical bytes or a versioned Merkle manifest over all relevant files, never SHA of a file list alone.
- spec_sha256: digest of verified normative spec snapshot.
- test_inventory_sha256: digest of versioned manifest of all required test sources and their identities.
- environment_digest: digest of bounded verified runner metadata without credentials or private host names.

### 2.1 Canonical serialization rules

JSON UTF-8, sorted keys, separators comma/colon with no whitespace, NFC normalization for logical identifiers but NEVER silently alter source file bytes before hashing; UTC timestamps use explicit RFC 3339 with timezone; non-finite floating values forbidden. Strings representing Windows project paths are normalized only after host-verified root check; absolute paths and secrets never enter exported reports. Include schema_version and algorithm_version in the digest input. Exclude volatile captured_at, elapsed_ms and trace IDs only when the contract explicitly declares them non-semantic.

Use a stable digest over all files plus relative file path, byte length, content hash and mode/type. A file rename must alter the manifest digest even if content is identical.

## 3. Target typed API surface (adapters only)

| Name | Input | Output | Mutates? | Owner |
| --- | --- | --- | --- | --- |
| plan_readonly | canonical task snapshot ref, optional budgets | ReasonedPlanV1 | NO | existing plan-work/readiness composition |
| impact_readonly | pinned base/source spec digests, proposed diff | ChangeImpactV1 | NO | spec_traceability + dependency graph adapter |
| quality_readonly | source/test/spec/evidence refs | EvidenceDecisionV1 | NO | existing quality/review evidence tools |
| simulate_readonly | immutable fixture ref, seed, policy digest | ScenarioReportV1 | NO | new fixture-only adapter |
| acquire_authoritative | task ID, role, unique request ID, current fences | existing coordinator task/lease receipt | YES | agent_team.py only |
| checkpoint_authoritative | task ID, current lease, idempotency key, bounded progress | existing coordinator checkpoint receipt | YES | agent_team.py only |
| submit_authoritative | current task + exact QA evidence | current coordinator submission path | YES | quality_submit + agent_team.py |
| review_authoritative | actual host-bound reviewer + QA evidence | MergeIntent / acceptance receipt | YES | host P085 + existing review path |
| spec_approval_authoritative | exact plan digest + human interaction | owner-approved spec request status | YES | established foreground owner process |
| release_authoritative | approved artifact + trusted host policy + rollback | verified release receipt | YES | separate owner-gated release path |

Do not implement authoritative methods in a new planning service. Their presence in this table is a boundary reference only.

## 4. Read-only ReasonedPlanV1

```json
{
  "schema_version": 1,
  "plan_id": "sha256:<digest>",
  "authority": "ADVISORY_ONLY",
  "project_id": "Local-Workspace-Extensions",
  "task_id": "P110",
  "snapshot": {
    "task_revision": 2,
    "source_sha256": "<digest>",
    "spec_sha256": "<digest>",
    "coordinator_revision": "<opaque>",
    "host_policy_version": "<known-or-null>"
  },
  "decision": "BLOCKED_SECURITY",
  "predicates": [
    {"id":"host.principal_verified","result":"UNKNOWN","source":"host-observation-unavailable","required":true},
    {"id":"task.dependencies_accepted","result":"TRUE","source":"verified-coordinator-snapshot","required":true}
  ],
  "eligible_roles": ["developer-3"],
  "safe_next_action": "WAIT_FOR_TRUSTED_HOST",
  "limits": {"read_nodes": 200, "truncated": false},
  "issued_grants": 0
}
```

This object is explicitly non-executable. An authenticated, owner-approved host grant must never be derived by any parser from plan_id or safe_next_action. An existing coordinator may classify a task as READY even if host trust is unknown for preview; the advisory contract MUST distinguish code readiness from effect authorization.

Predicate result type: TRUE / FALSE / UNKNOWN / NOT_APPLICABLE, each with provenance and policy_digest. A required UNKNOWN yields UNKNOWN_EVIDENCE or BLOCKED_SECURITY, never READY_ADVISORY when an effect is privileged.

## 5. Target StepIntentV1 and StepReceiptV1

### 5.1 Intent before external mutation

```json
{
  "schema_version": 1,
  "operation_id": "op-opaque-unique",
  "project_id": "Local-Workspace-Extensions",
  "task_id": "P110",
  "task_revision": 2,
  "attempt_id": "opaque",
  "lease_epoch": 17,
  "effect_kind": "LOCAL_OWNED_FILE_REPLACE",
  "effect_scope": {"resource_type": "file", "relative_path": "src/owned.py"},
  "input_sha256": "<source>",
  "expected_before_sha256": "<before>",
  "expected_after_sha256": "<after>",
  "idempotency_key": "host-nonce",
  "grant_reference": "host-stored-only",
  "journal_state": "PREPARED"
}
```

Durable journal states: PREPARED, IN_FLIGHT, CONFIRMED, REJECTED, RECONCILIATION_REQUIRED. A crash at PREPARED may be safe to abort only if no effect invocation was possible. IN_FLIGHT without trusted host receipt is *ambiguous*. CONFIRMED requires independently observed committed effect. Reusing same key + different digest must return IDEMPOTENCY_CONFLICT and leave prior receipt unchanged.

A legitimate current lease alone never authorizes an arbitrary filesystem write; the host must validate effect permissions and root scope.

### 5.2 Completion receipt

```json
{
  "schema_version": 1,
  "operation_id": "op-opaque-unique",
  "status": "CONFIRMED",
  "effect_id": "host-effect-reference",
  "observed_after_sha256": "<actual>",
  "verified_host_principal": "<host-opaque-id>",
  "policy_digest": "<host-policy>",
  "grant_scope_digest": "<host-verified-scope>",
  "runner_evidence_id": "<receipt>",
  "verified_at_utc": "2026-11-02T18:00:00Z",
  "retry_count": 0
}
```

Future target contract, not an assertion that today the connected host issues such receipts.

### 5.3 Tool result ambiguity table

| Observed fact | Typed outcome | Allowed continuation |
| --- | --- | --- |
| Read-only call failed before any effect | SAFE_RETRY | bounded retry under current source hashes |
| Host reports same effect committed with exact digest | IDEMPOTENT_REPLAY | reuse verified receipt |
| Host reports different effect digest for same key | IDEMPOTENCY_CONFLICT | stop + investigate |
| Call timed out after entering IN_FLIGHT | RECONCILIATION_REQUIRED | read-only status/intent inspection |
| Operation touched unapproved resource | POLICY_DENIED | no retry with broader path |
| Lease expired during candidate write | LEASE_STALE | reject write, do not steal lease |
| Spec changed during test run | SPEC_DRIFT | revalidate before submission |
| Reviewer accepted but journal cleanup failed | POSTCOMMIT_CLEANUP_PENDING | read-only acceptance and journal inspection; no second accept |

## 6. QA evidence schemas

### 6.1 ExecutionEvidenceV1

```json
{
  "schema_version": 1,
  "kind": "TEST_EXECUTION",
  "task_id": "P110",
  "task_revision": 2,
  "source_sha256": "<digest>",
  "spec_sha256": "<digest>",
  "test_inventory_sha256": "<digest>",
  "test_id": "T-NEG-001",
  "runner": {"kind":"unittest","version":"<verified>","environment_digest":"<digest>"},
  "result": "PASS",
  "exit_semantics": "TEST_PASS_ZERO",
  "observed_exit_code": 0,
  "start_time_utc": "2026-11-02T18:00:00Z",
  "end_time_utc": "2026-11-02T18:00:02Z",
  "evidence_origin": "LOCAL_VERIFIER_UNTRUSTED_UNTIL_HOST_ATTESTED",
  "stdout_digest": "<digest>",
  "stderr_digest": "<digest>",
  "source_recheck": "MATCHED"
}
```

exit_semantics vocabulary:
- TEST_PASS_ZERO: zero means test asserts candidate passed.
- BUG_REPRO_ZERO: zero means failure of candidate has been demonstrated.
- TOOL_SUCCESS_ZERO: zero means only that tool executed; no claim about target.
- CUSTOM: independent verifier must supply exact classifier reference.
- UNKNOWN: cannot be used for release.

A single model-written QA JSON is untrusted evidence until verified by independent runner and host trust boundary. Reproducibility requires test identity, command, source and environment; even that remains weaker than a genuine host-issued attestation.

### 6.2 EvidenceDecisionV1

```json
{
  "schema_version": 1,
  "decision": "BLOCKED_KNOWN_DEFECT",
  "authority": "ADVISORY_ONLY",
  "candidate_source_sha256": "<digest>",
  "required_gates": [
    {"gate":"open_spec_strict","state":"PASS","evidence_id":"sha256:..."},
    {"gate":"negative_qa","state":"FAIL","evidence_id":"sha256:..."},
    {"gate":"independent_reviewer","state":"NOT_RUN","evidence_id":null},
    {"gate":"host_actor_grant","state":"UNKNOWN","evidence_id":null}
  ],
  "critical_findings": [{"finding_id":"F-001","source_sha256":"<digest>","state":"CONFIRMED"}],
  "not_executed": ["windows_host_e2e"],
  "incomplete": true,
  "release_authority": false
}
```

Required gate states: PASS, FAIL, NOT_RUN, UNKNOWN, BLOCKED, NOT_APPLICABLE. NOT_APPLICABLE requires reviewer-approved rationale and policy version, never an untrusted developer flag. A fresh critical finding for exact source SHA dominates cached discovery evidence. Source SHA drift invalidates the old pass but does not automatically mean a previous defect has been fixed; it becomes NEEDS_REVALIDATION.

## 7. Task and reviewer ownership

### 7.1 ResponsibilityContractV1

```json
{
  "schema_version": 1,
  "responsibility_id": "module:canonical.module",
  "canonical_owner": "project-accepted-registry",
  "public_api_id": "api:canonical.module:interface-v1",
  "allowed_write_paths": ["src/canonical/module.py", "tests/test_canonical_module.py"],
  "task_id": "P110",
  "task_revision": 2,
  "handoff_from": null,
  "handoff_decision_ref": null,
  "confidence": "DECLARED_AND_VALIDATED",
  "unknown_imports": []
}
```

Ownership is by responsibility/API contract, not solely by path; a task with disjoint file path but identical responsibility is a conflict. Legacy tasks without contracts may be inventoried as LEGACY_UNMAPPED but must not be retroactively mutated while leased.

### 7.2 Independent reviewer eligibility

ReviewerEligibilityV1 fields: reviewer host principal reference, author logical roles, author invocation ID, shared-scheduled-card equivalence, reviewer ownership history, task revision, final source SHA, proof origin.

Rejection conditions:
- reviewer authored/coauthored candidate;
- reviewer shares execution independence domain with author;
- reviewer identity only string in Python CLI;
- review source differs from final source;
- incomplete required negative QA;
- unresolved merge intent;
- old lease reviewer accepted new revision.

Peer review is advisory and cannot grant ACCEPT, no matter how convincing the report.

## 8. Snapshot consistency and CAS

To build a planner view, read current file SHA + coordinator revision in read-only transaction, collect all graph inputs under bounds, re-read SHA + revision. Any mismatch => STALE_SNAPSHOT. This is best-effort cross-resource consistency, NOT atomic NTFS+SQLite snapshot isolation.

For a coordinator mutation:
1. trusted host verifies actor scope and effect policy;
2. coordinator transaction checks current task state, revision, lease epoch and owners;
3. transaction records intent before any irreversible external operation;
4. effect executes through bounded host-owned tool;
5. coordinator records confirmed receipt or leaves reconciliation marker;
6. reviewer acceptance separately uses existing durable merge journal and CAS.

Do not open a long database write transaction around slow subprocess/LLM calls. Crash while external effect is uncertain => reconciliation, not repeated write.

## 9. Typed failures / reason codes

Naming format DOMAIN_REASON, severity INFO/WARN/BLOCK/CRITICAL, retryability NEVER/AFTER_REFRESH/SAFE_READ_ONLY/HUMAN_DECISION.

| Code | Severity | Retryability | Explanation |
| --- | --- | --- | --- |
| HOST_ACTOR_UNVERIFIED | CRITICAL | HUMAN_DECISION | authenticated principal unavailable |
| HOST_GRANT_EXPIRED | BLOCK | AFTER_REFRESH | valid prior grant is no longer current |
| HOST_GENERIC_RUNNER_BYPASS | CRITICAL | NEVER | unrestricted privileged operation path exists |
| TASK_LEASE_STALE | BLOCK | AFTER_REFRESH | task lease epoch no longer current |
| TASK_OWNER_CONFLICT | BLOCK | HUMAN_DECISION | same canonical module responsibility claimed twice |
| TASK_DEPENDENCY_UNACCEPTED | BLOCK | AFTER_REFRESH | predecessor receipt not independently accepted |
| TASK_SPEC_SHA_DRIFT | BLOCK | AFTER_REFRESH | task specification changed |
| TASK_OUTPUT_SHA_CONFLICT | BLOCK | HUMAN_DECISION | concurrent canonical source edit |
| REVIEW_NOT_INDEPENDENT | BLOCK | HUMAN_DECISION | author/reviewer overlap |
| REVIEW_NEGATIVE_QA_FAIL | BLOCK | AFTER_REFRESH | exact source has confirmed failing witness |
| REVIEW_EVIDENCE_UNKNOWN | BLOCK | AFTER_REFRESH | executed-test or origin proof incomplete |
| REVIEW_MERGE_RECONCILIATION | CRITICAL | HUMAN_DECISION | file/DB merge intent uncertain |
| TOOL_EFFECT_UNKNOWN | CRITICAL | HUMAN_DECISION | external write may have occurred |
| TOOL_REPLAY_CONFLICT | BLOCK | NEVER | same idempotency key with different input |
| PLAN_POLICY_DRIFT | BLOCK | AFTER_REFRESH | advisory predicate mapping diverged |
| PLAN_SNAPSHOT_PARTIAL | WARN | AFTER_REFRESH | source/graph analysis incomplete |
| RUN_TELEMETRY_UNOBSERVED | WARN | SAFE_READ_ONLY | platform usage/time cannot be inferred |
| SPEC_FR_UNMAPPED | BLOCK | HUMAN_DECISION | OpenSpec requirement not explicitly linked |
| SPEC_TASK_REF_PARSE_ERROR | BLOCK | AFTER_REFRESH | malformed SDD task linkage |
| TRUST_INPUT_INJECTION | BLOCK | NEVER | untrusted content requested authority escalation |

Typed error envelope includes correlation ID, redacted public explanation, source refs/sha when safe, retryability, and observed/not-observed field; never secrets, lease tokens or raw credentials.

## 10. Read-only interface budgets and scaling

The following are **design maximums**, not measured performance claims. All require benchmark validation on authorized hardware:
- read-only graph scan: <=10,000 nodes, <=50,000 edges, <=10 s wall (return PARTIAL if exceeded);
- output report: <=2 MB JSON, no unbounded embedded traces;
- scenario simulation: <=1,000 tasks and <=100,000 simulated events per fixture, finite deterministic seed;
- retry budget: <=3 read-only transport retries with bounded exponential delays; zero automatic ambiguous write retry;
- QA witness collection: explicit size and privacy budgets; report truncation instead of hiding evidence;
- error envelope: bounded stack/no path disclosure and correlation IDs.

A reported node_count=10,000 but unknown uninspected_count is INVALID_COVERAGE. Time limit exhaustion is not PASS. Runtime metrics must include measured environment, warm/cold mode and input fixture class before any performance comparison.

## 11. Migration and versioning rules

Phase V0: pure read-only adapters; no schema changes to live database.
Phase V1: versioned opt-in fixture tables and deterministic migration tests, backward compatible, preserving old accepted records.
Phase V2: owner-approved limited canary with real host, actor grants and independent negative QA; use explicit migration ledger.
Phase V3: broader production only after rollback drill, host bypass negative tests, reviewer identity proof and accepted artifacts.

At every migration: dry-run preview, current schema hash, backup/restore proof if stateful, owner authorization, controlled update, post-write verification and explicit rollback strategy. Never apply a migration merely because a new SDD field exists.

## 12. Compatibility and data safety checks

Compatibility must be tested on:
- Python stdlib version supported in existing code; no assumed new runtime features until verified.
- Windows case-insensitive path collisions, junction/reparse points, UNC, device path, trailing period/space, drive-relative path, Unicode filenames, CRLF and UTF-8.
- SQLite busy/locked status, journal/WAL recovery, concurrent readers, task lease races, expired active leases and interrupted transactions.
- Offline mode and disconnected tunnel; absence of transport does not prove an external job stopped.
- Missing optional provider usage counts; NULL vs zero cannot be conflated.
- Legacy tasks without responsibility contracts; inventory only until approved migration.
- Existing review merge receipts and prior passed tests; do not rewrite history to make new requirements look satisfied.

## 13. Invariant-to-contract traceability

| Invariant | Contract object | Implementation source | Test family |
| --- | --- | --- | --- |
| INV-01 scoped filesystem | host grant / effect_scope | actual P085 MCP host | SEC-PATH |
| INV-02 exclusive module responsibility | ResponsibilityContractV1 | agent_team / agent_responsibility_guard | CON-OWN |
| INV-03 no self-review | ReviewerEligibilityV1 | reviewer / shared-card policy | REV-ID |
| INV-04 lease fences | attempt_id, lease_epoch | agent_team transaction | CON-LEASE |
| INV-05 idempotency | StepIntentV1 / StepReceiptV1 | approved durable-step journal | REC-REPLAY |
| INV-06 ambiguous effects | RECONCILIATION_REQUIRED | MergeIntent / host effect receipts | REC-CRASH |
| INV-07 evidence pinning | ExecutionEvidenceV1 | existing QA + acceptance records | QA-SHA |
| INV-08 accepted dependency | ReasonedPlanV1 | agent_team / readiness matrix | SCH-DAG |
| INV-09 unrelated blocked task | ReasonedPlanV1 | agent_logistics_dispatch | SCH-FAIR |
| INV-10 final CAS | EvidenceDecisionV1 | review_merge / agent_team | REV-CAS |
| INV-11 observed run intervals | invocation_id | scheduler_run_history | OBS-RUN |
| INV-12 trusted identity | grant_reference | P085 actual MCP host | SEC-ACTOR |
| INV-13 no mutations in preview | ScenarioReportV1 | planning adapters only | SIM-RO |
| INV-14 no fake acceptance | EvidenceDecisionV1 | quality gate / reviewer | QA-NEG |
| INV-15 recovery journal | StepIntentV1, MergeIntent | existing journal + approved extension | REC-CRASH |
| INV-16 external job status | effect_id | actual host job state | OPS-JOB |

## 14. Open decisions requiring evidence

D-CON-01 Can the existing coordinator safely expose read-only state revision and predicate provenance without refactoring privileged transitions?
D-CON-02 Which real host integration will bind tool calls to a verified principal, including universal command/script tools?
D-CON-03 Which acceptance records contain source/test/spec/environment digests with sufficient verifiable provenance?
D-CON-04 Is a monotonic per-task lease epoch already present, or does it need a new owner-approved migration?
D-CON-05 What non-idempotent external writes are genuinely needed in the first authorized canary?
D-CON-06 Which current modules already define idempotency and error enums, to reuse rather than duplicate?
D-CON-07 Which source SHA format is stable across sandbox and main file promotions?
D-CON-08 Can an independent QA runner be isolated from candidate Python imports and evaluator modifications?
D-CON-09 Which legacy accepted records are provable and which must remain LEGACY_UNVERIFIED?
D-CON-10 How will a downstream schema reader distinguish a new minor version from unsupported major version?

Non-goal: This contract does not implement host auth, trust a writable local README, create a sixth scheduled card, modify live SQLite or assert platform token totals.