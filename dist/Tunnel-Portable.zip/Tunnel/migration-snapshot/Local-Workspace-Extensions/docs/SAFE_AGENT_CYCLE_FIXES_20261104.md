# Safe agent cycle fixes — 2026-11-04

## Verified changes

1. `experiments/chat_only_run/queue_supply_watch.py` now applies the actual read-only `owner_queue_admit.candidate_preview()` to its supply proposals before displaying role readiness. Fail-closed on malformed/stale preview, duplicates or unapproved IDs. Operator command corrected to invoke `owner_queue_admit.py` without a positional `preview` argument. SHA256: `b82182498028996a470c1591ee704952d63852a3328089cddb99a9b22a73b429`.
2. `experiments/chat_only_run/test_queue_supply_watch.py` includes new SDD-unmapped, subset, untrusted/duplicate preview negative tests. SHA256: `66986e5a700215fc2eb3168691332c1a7c6238f1b7ecc6d896d596fbfa99e5d0`.
3. `chat-launch-smoke-desktop-test/web-companion/chain2_blocker_dossier.py` now refuses symlink/junction segments in advisory role-workspace path diagnostics and does not report them as safe repair hints. No ACK, request, queue or browser mutations. SHA256: `c645eb3b735b48eee92ccc46a1f255b5c4d000342342bb3531acf4505c561210`.
4. `chat-launch-smoke-desktop-test/web-companion/test_chain2_blocker_dossier.py` adds symlinked-parent and unsafe-path regression cases. SHA256: `4c1b10fefd05f1b746a4cd7a9f89d090ab53b21af3303b2344c93e9181d10d21`.

## Actual test evidence (Local Workspace jobs)

- Watcher focused: job `a91a99e96cfa462d9d2956e2165d0b3d`, rc=0, 12/12 PASS.
- Owner gate regression: job `ce8bfa5323304e23996734162cf11d21`, rc=0, 10/10 PASS.
- Supply plan regression: job `304d7c39a245400093cdc510319de785`, rc=0, 11/11 PASS.
- Chain2 focused: job `ccf64ac7ca924d948432b381337caad7`, rc=0, 16 tests OK (1 SKIP because local Windows directory symlink creation unavailable; mock negative test passed).
- Chain2 full suite: job `328056e2920143ec9950558da7c2a6c9`, rc=0, 181 tests OK (1 SKIP).
- SDD roadmap check: job `7d5342631f4d4831abf9b2a274d5236f`, rc=0, 58 roadmap entries, no validation errors in existing mapped tasks.
- Post-fix live supply monitor: job `4b230fa65f7c44afbf43169c4bf723f9`, rc=0, four roles exhausted/blocked, no falsely owner-ready task; P163/P164/P165/P167/P168 correctly blocked by missing SDD mapping.

## Open blockers — NOT repaired by these code changes

- Chain2: 19/50 DONE, 9 durable ACTIVE, 0 QUEUED; four closed without a verified ACK, four presend unconfirmed, one disputed account context. `l02-redaction` has physically present files with wrong project prefix in handoff; correcting it requires legitimate original actor/owner evidence and safe reconciliation. Do not treat this diagnostic hint as an authority grant.
- Chain3: not armed; 0 jobs run. Do not force arm or send duplicate ChatGPT requests. No automatic replay of UNKNOWN outcome.
- P085: host trusted Windows SID/ACL/issuer separation and real two-SID E2E are not verified, so no trusted review acceptance, merge, live queue admission or privileged OS changes from MCP.
- Candidate P163/P164/P165/P167/P168 have no sanctioned SDD roadmap mapping; updating the live authoritative roadmap and admitting tasks require the existing owner-reviewed OpenSpec/SDD and interactive foreground owner gate. Don't edit the seed or SQLite directly.
- `P153` dependency remains a separate blocker of `P169`; `P104` QA gate blocks developer-1 reserve.

## Next safe operation

Use read-only `chain2_blocker_dossier.py` and trusted original browser/report evidence to reconcile each of the nine unresolved jobs. For candidate queue, first obtain sanctioned SDD mapping and independent QA, then `owner_queue_admit.py` read-only preview; the owner may separately authorize interactive `--apply --plan-id` after provenance checks. P085 needs a protected Windows account and elevated OS installation with owner participation. Never self-grant trust or fabricate ACK.
