# Second ChatGPT chat as a separate human-started Local Workspace agent — smoke test

Date: 2026-11-02. Status: **manual cross-chat test prepared; NOT yet demonstrated in a second conversation**.

## Observed in original chat
- Connected Local Workspace `list_workspaces` returned alias `projects` with root `C:\Users\user\IdeaProjects`.
- Executed `run_script(path="Local-Workspace-Extensions/verified_work_cycle.py", cwd="Local-Workspace-Extensions", args=["developer-1"])`.
- `job_status`: completed, exit=0, job_id=`70d1b8f354c94f88a47dcebb8edb423f`.
- `job_output`: `ok=true`, `schema=verified-work-cycle-v1`, `new_scheduled_tasks_created=0`, phase=`AUTHORIZED_CODE_PREFLIGHT`. This is a READ-ONLY plan, not a task lease.
- No verified tool to programmatically create and send a message to an independent ChatGPT conversation from this chat. New conversation must be started by the user via the normal ChatGPT UI.
- Creating a chat does not change the account's model limits, Scheduled Tasks quota, or per-turn lifetime. Browser scripting or account-farming to circumvent rate limits is not in scope.

## Paste into a fresh ChatGPT conversation (after selecting @Local Workspace)
Ты — отдельный тестовый агент Observer-2 в моём проекте Local-Workspace-Extensions. Проверь реальный доступ к одному общему MCP, но НИЧЕГО НЕ МЕНЯЙ.

1. Вызови Local Workspace list_workspaces и убедись, что есть alias projects. Если доступа нет, сообщи точную ошибку и остановись.
2. Прочитай `Local-Workspace-Extensions/AGENTS.md` и `docs/VERIFIED_WORK_CYCLE.md`, не извлекай секреты. Если read_file вернёт пустой результат, используй документированный `ops.py read_text`.
3. Вызови через Local Workspace run_script: workspace=projects, path=`Local-Workspace-Extensions/verified_work_cycle.py`, cwd=`Local-Workspace-Extensions`, args=[`developer-1`]. Это ТОЛЬКО read-only диагностический снимок роли, не доказательство, что тебе доверена identity developer-1.
4. Через job_status и job_output получи окончательный код возврата и JSON ok. Приведи фактические job_id, returncode, phase, candidate, planner_snapshot_sha256.
5. Сравни результат с живым состоянием проекта, не предполагай, что он совпадёт со старым снимком.
6. Не выполняй acquire/submit, review accept/reject, Git, owner_approve, spec_request_execute, не пиши файлы и не меняй расписания/очередь. P085 trusted host identity пока не подтверждена.
7. Заверши коротким отчётом: доступ к MCP ДА/НЕТ; чтение ДА/НЕТ; выполнение read-only команды ДА/НЕТ; можно ли взаимодействовать с очередью из второго чата; ограничение автономного перезапуска.

## Success criteria
- New independent conversation actually calls its own Local Workspace tools, returns its OWN verified job ID with rc=0 and ok=true.
- This proves shared backend access through two manually started chat sessions (NOT concurrent execution and NOT auto-wake).
- Any missing permission or tool requires correction via normal connection flow; do not claim an unobserved connection.
- For true parallelism, start the two chats manually with separate independent read-only commands and compare overlap by job timestamps. Do not use the same developer role to claim the same lease.

## Next safe experiment
Use two manually started observer conversations, each with a different read-only diagnostic; compare verified start/end timestamps and identical repository metadata. Then design separate legitimate task-specific roles and host-issued grants before code writes.
