# P085 read-only ACE visibility — checkpoint, 2026-11-04

## Verified scope
Implemented an advisory, fail-closed security hardening of the existing Windows P085 staged-code audit. No privileged host change, UAC prompt, Windows account/ACL modification, broker installation, owner approval, queue mutation, Git operation or Chain2/Chain3 state transition.

## Defect and fix
Previously `experiments/foundation_kernel/windows_isolation.inspect_acl` exposed only `read_execute_allowed_sids`: an unrelated SID with a basic allow ACE granting only `FILE_READ_DATA` / `FILE_LIST_DIRECTORY` or `GENERIC_READ`, but not `EXECUTE`, was omitted. Consequently `p085_stage_audit._acl_sane` could classify the staged code or `private_state` as structurally protected despite an explicit read-only ACE.

Applied:
- `windows_isolation.py`: emits `read_allowed_sids` for basic allow ACEs granting `FILE_READ_DATA/LIST_DIRECTORY` (0x1), `GENERIC_READ` (0x80000000) or `GENERIC_ALL` (0x10000000). A pure `_data_read_allowed` helper centralizes the bit classification. The original `read_execute_allowed_sids` evidence remains unchanged.
- `p085_stage_audit.py`: makes `read_allowed_sids` mandatory; rejects any explicitly enumerated data-reader SID except the broker service and SYSTEM with `STAGE_ACL_DATA_READ_SCOPE_VIOLATION`. Missing evidence fails closed.
- `test_p085_stage_audit.py`: updated ACL fixtures; adds read-only leak negative tests for untrusted worker and reviewer, both code and private-state paths, plus missing-field negative test.
- `experiments/foundation_kernel/test_windows_isolation.py`: adds a mask-level test proving read/list-data and generic read/all detection without execute, and that execute-only, read-control and write-only do not count as data read.
- `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py`: updated two exact dependency digests after local source tests. The monitor's drift rejection was independently confirmed before updating the pins. These pinned hashes are writable diagnostic metadata, NOT signed owner approval or trusted deployment authorization.

## SHA256 of verified source
- `experiments/foundation_kernel/windows_isolation.py`: `50709f8ed93506c6714e94df634c9c05fb2931d69811a812f4339a03deb3f888`
- `experiments/foundation_kernel/test_windows_isolation.py`: `035bbfa679813b80d1a9a2e472a078a0232e8ed56c177911baff36f20c7d72d1`
- `p085_stage_audit.py`: `c1e75326fae14b39c8b1e911bc19c73327546a327cce1a23ac7875f971fb32ac`
- `test_p085_stage_audit.py`: `398a18b79c73c39ba86274ccc285cdebbe9e71ea32d64ad4ff8193f82aab43d1`
- `../chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py`: `a5dc21d53311195f1fa671a70431d376e80415810cd6f8d39fb49e4149ae4352`

## Confirmed MCP job receipts
- Stage auditor focused tests `7f5daa8536a442a4989c1c502b6a47cb`: completed rc=0, **23 run, 21 PASS / 2 SKIP**.
- WinAPI mask classification focused tests `65c37106e6bd42bfb519d7d71fc407d1`: completed rc=0, **19 PASS**.
- P085 suite `b4cd093e9afc4a6199e546c4d08317be`: completed rc=0, **100 run, 94 PASS / 6 SKIP**.
- Pre-pin readonly monitor `c9578a9fcbbb4de79cc237ff90a76f17`: completed rc=0, `status=UNKNOWN`, `SOURCE_DEPENDENCY_SHA_DRIFT`, no privileges granted.
- Post-pin monitor tests `f096245d89e84e9b94e8126f5d230bd8`: completed rc=0, **15 PASS**.
- Post-pin live readonly monitor `46c1691ee4e945068089433d50909f2b`: completed rc=0, `ok=true`, `status=UNTRUSTED`, `accounts_configured=0`, `accounts_missing=5`, `stage_status=NOT_STAGED`, `can_activate_chain3=false`, `can_complete_chain2=false`.
- Repeat Windows-isolation suite `4c57efece31e45ca9f9c0b4bb4bb0c92`: completed rc=0, **19 PASS**.
- Full web-companion regression `6ffdef806f9c44488eeab1cb31c1c99c`: completed rc=0, **204 run, 203 PASS / 1 SKIP**.
- SDD structural checker `9e1e7f9257db49039f581a96029a8704`: completed rc=0, **0 structural errors** (NOT upstream OpenSpec CLI or real broker E2E).

## Remaining trust limitations
This remains an advisory source-level ACL inspection in an agent-writable repository. It cannot prove effective access through SID group membership, UAC/Windows inheritance context, inaccessible deny ACEs, a race-proof filesystem, cryptographic source provenance, independent QA signer custody or protected broker identity. The current installation is NOT staged and none of the five principals have been configured.

## Safe next activity
Only an owner-mediated, genuinely privileged Windows installation *outside* `IdeaProjects` and verified separate-principal negative E2E can close P085; do not grant authority based on these SHA-pinned diagnostics. Chain2's nine ambiguous in-flight tasks require reconciliation from the original browser/ACK evidence rather than blind retries.
