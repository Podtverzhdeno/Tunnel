# Scheduled agent runtime — five-run repeatability / workload test

**Status:** observation, not established platform policy.

## Source of truth
`.agent-team/reports/automation_timeout_repro_20261102.json` stores
*three historical failed runs* and separately at least *five new,
independent terminal scheduler run IDs*. An in-progress run is **not**
a finished sample. The shared Developer 3+4 card counts as **one**
invocation, not two. Do not estimate start/end from Local Workspace job
times: only the Automation scheduler's own `started_at` and
`completed_at` support scheduler wall-clock duration.

## Experiment arms

- Long upfront substantive workload (intended treatment):
  Developer 1 and shared Developer 3+4. At run start plan at least
  four real, distinct, safe QA/development checkpoints which may
  require 40–50 minutes if permitted; NEVER idle or fabricate activity.
- Unmodified repeatability-control workload:
  Developer 2 and Architect Reviewer. Normal authorized engineering QA
  continues.
- All roles: no previous 17–18-minute proactive cutoff or
  20-minute terminal deadline. No automatic privileged accept/reject,
  rework, host permission changes or owner-grant impersonation.
- Actual prompt snapshots for an individual run are **not exposed**.
  An intended treatment arm is not proven treatment exposure.
  Different task content and the shared D3+4 configuration confound
  causal claims.

## Reproduce and validate

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python automation_duration_analysis.py --pretty
python -m unittest -q test_automation_duration_analysis
python agent_team.py gate-check
```

The script is read-only. It recalculates duration using offset-aware
timestamps, rejects duplicate run IDs, mismatched role/automation IDs,
unfinished runs and forged durations, and reports counter discrepancy.
`near_25m` means 1485–1515 seconds, an exploratory band rather
than an SLA or proof of a service limit.

**Interpretation:**

- Fewer than five additional terminal runs:
  `INSUFFICIENT_ADDITIONAL_RUNS`.
- At least five and every additional run fails in the exploratory band:
  `ALL_ADDITIONAL_RUNS_FAILED_NEAR_25_MINUTES`.
  This is evidence of a repeated observable pattern, not a documented
  provider hard timeout or a known failure code.
- Mixed statuses/durations: `MIXED_TERMINAL_DURATIONS_OR_OUTCOMES`.
  A naturally completed 13-minute run is informative but does not
  test whether 40+ minutes were available.
- A verified completion past 40 minutes would refute a universal
  25-minute cap, but **not** prove that a large prompt caused it.
- A failed run with no matching final report can still have delivered
  verified queue events to SQLite. Attribute causal conclusions to
  exact run IDs and timestamp evidence only.

The Architect Reviewer scheduled card has been asked to gather and
record matching observations on subsequent recurring checks, keeping
SHA-safe updates and preserving role/grant rules. Local file scripts
cannot themselves query ChatGPT's scheduler without the connected
Automation tools; they do not run a hidden continuous polling service.
