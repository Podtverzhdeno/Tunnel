# P085 — release gate and independent reviewer finalizer (2026-11-02)

**Implementation status: SOURCE COMPLETE FOR STAGING; LIVE PRODUCTION CUTOVER BLOCKED.**
This file documents actual code and observed tests; it is NOT permission to modify live Windows ACLs, approve a spec or change the five-agent schedule.

## Delivered implementation

1. `mcp-host-source/workspace_mcp/review_grants.py`: short-lived, SHA+review-lease-bound owner grant and durable one-use nonce/revision ledger.
2. `review_qa_attestation.py`: separate independent QA supervisor HMAC receipt, bound to the same task/spec/source+test/lease revision and a pinned runner environment. It requires all six positive checks: unit tests, spec check, strict OpenSpec, reuse, architecture and negative QA. No signed receipt means NO acceptance.
3. `review_grant_broker.py.reserve_with_independent_qa`: Windows OS peer SID, trusted current task snapshot, owner grant and independent QA before consuming the one-shot nonce.
4. `review_finalizer.py`: after a successful broker reservation, fresh SQLite BEGIN IMMEDIATE/CAS state check, fresh grant and QA proof, canonical MergeIntent.prepare, comparison of exact **staged bytes** with the signed bundle SHA, then MergeIntent.apply and status=done + acceptance record + event in the SAME SQLite transaction. It never imports/executes candidate Python.
5. `trusted_journal_loader.py`: canonical `review_merge.py` must be copied by an owner to a protected installation and PINNED by SHA in protected config. The privileged service NEVER imports the editable main project module.
6. `review_pipe_server.py`: local Windows named-pipe transport; `--serve-one` is reservation-only. With an explicitly provisioned `trusted_finalizer`, it runs privileged finalization, returning generic `OWNER_RECONCILIATION_REQUIRED` on any unexpected post-staging failure. It never retries an already reserved nonce.
7. `owner_cutover_gate.py`: short-lived (24 h) manually installed owner acknowledgement scoped to service/reviewer/worker SID, project root, immutable journal hash and QA environment. Acknowledgement is an **operator assertion, not OS-authenticated proof**. Missing or stale acknowledgement fails closed.
8. `mcp-host-source/p085_reviewer_service.py`:
   - `--doctor`: read-only startup configuration check.
   - `--serve-one`: independent QA + owner grant + Windows peer authentication; reserves only.
   - `--accept-one`: additionally requires a current protected owner-cutover acknowledgement, a pinned journal and the privileged finalizer. No path here changes the running MCP host.
9. `p085_windows_isolation_probe.py`: read-only WinAPI effective file write check from the untrusted MCP process; tests never write to production files.

## Confirmed test results

- Mirrored host: **226 tests (6 skipped), PASS** including QA signature/replay, grant, real Windows peer SID retrieval, pipe framing and SDDL, protected startup/pinning, trusted pinned journal loader, actual disposable SQLite+file finalizer, injected partial merge failure and transport-to-finalizer integration (Windows pipe kernel mocked for these full E2Es).
- Canonical project `agent_team.py gate-check`: **1658 tests (41 skipped), PASS**, `spec_check.py` PASS, `openspec validate local-pc-agent-tooling --strict` PASS.
- `agent_reuse_ci_gate.py`: PASS; 0 hard duplicate code groups in scanned root modules.
- Live Windows write probe: **NOT READY**. Current MCP execution account has `UNTRUSTED_WRITE_ALLOWED` for `.agent-team/team.sqlite3`, `.agent-team/`, `agent_team.py`, and project root.
- Live `p085_reviewer_service.py --doctor`: exit 2 `PROTECTED_BROKER_NOT_READY` because no separate protected service config exists. This failure is expected; no installation or Windows ACL change took place.

## Explicit cutover prerequisites — require real owner OS access

**Do not write secrets, actual SIDs, privileged config or grants under `IdeaProjects`.**

1. Create or select THREE distinct Windows security principals: untrusted MCP agent worker, reviewer client, protected owner service (each gets its own actual SID). Run real cross-principal access probes. For the untrusted worker SID: cannot write main source, canonical state/SQLite, read service key/ledger, or open protected reviewer pipe. For reviewer SID: may use protected pipe, but cannot modify service files/ledger/keys or masquerade as the service. QA child executing candidate Python cannot read the QA supervisor key.
2. Move a vetted, pinned release copy to a service-owned directory **outside the entire `C:\Users\user\IdeaProjects` MCP root**, with OS ACLs (SYSTEM/Administrators recovery, protected service account allowed, worker denied). Copy the audited canonical `review_merge.py` into `p085_trusted/review_merge.py` there; put its exact SHA in the private `trusted_journal_sha256` config field. A copy in a sibling directory of `IdeaProjects` is not protected.
3. In service-owned `p085_private/`, provision config `config.json` (sample schema in `docs/P085_PROTECTED_BROKER_ROLLOUT_2026-11-02.md`), unique 32+ byte random `review-key.bin`, separately generated `qa-verify-key.bin` and `ledger.sqlite3` (created by service after authorization). Secrets must never be given to a scheduled agent, developer sandbox or low-privilege QA child. The QA proof issuer must be an *independently protected supervisor* which signs only truly executed, scoped QA results. The code here contains no untrusted-client signer.
4. Run `p085_reviewer_service.py --doctor` as the actual service Windows account. The service must read only its protected config and no current unprivileged host state outside its explicitly configured project.
5. Perform supervised negative E2E using DISTINCT real principals: wrong/forged OS SID and role, worker direct OS writes, owner grant replay/revocation, QA signature forgery/source drift, candidate Python unable to read signer keys, reviewer pipe allow/deny, crash after one file, and recovery from durable MergeIntent with owner, before approving cutover.
6. Only after physically observing all negative results, the owner may store the short-lived `p085_private/owner-cutover.json` acknowledgement, exact shape:
```json
{
  "schema": "p085-owner-verified-isolation-cutover-v1",
  "service_sid": "REPLACE_REAL_SERVICE_SID",
  "reviewer_client_sid": "REPLACE_REAL_REVIEWER_SID",
  "untrusted_mcp_sid": "REPLACE_REAL_WORKER_SID",
  "project_root": "C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions",
  "trusted_journal_sha256": "REPLACE_EXACT_64_HEX",
  "qa_runner_environment_sha256": "REPLACE_EXACT_64_HEX",
  "recorded_at_utc": "REPLACE_REAL_UTC_TIMESTAMP",
  "operator_checks": {
    "worker_cannot_write_coordinator_db": true,
    "worker_cannot_write_canonical_source": true,
    "worker_cannot_read_protected_keys": true,
    "worker_cannot_connect_reviewer_pipe": true,
    "reviewer_can_connect_reviewer_pipe": true,
    "qa_test_child_cannot_read_signing_key": true,
    "recovery_owner_has_tested_partial_merge": true
  }
}
```
   These booleans alone do NOT prove tests occurred. Creating this acknowledgement without real cross-principal evidence would defeat its purpose. The protected code does not generate it automatically.
7. Enable `--accept-one` only on the protected Windows service, not from chat's unrestricted Local Workspace MCP. For the agent orchestration, roll out a restricted bridge that cannot use legacy `run_script` or raw `agent_team.py review accept` as a bypass; verify actual developer+architect E2E before replacing the current host. Preserve a reversible rollback and independent owner recovery process.

## Reproducible protected-code staging (additional implementation)

- `Install-P085ProtectedService.ps1` at repository root provides **owner-admin-only, copy-only** protected code staging. It enumerates fixed audited Python modules, computes SHA-256, rejects symlinks, verifies distinct service/reviewer/worker SIDs, refuses a target within `IdeaProjects`, and refuses overwriting an existing installation. Default invocation only prints a JSON plan. `-Apply` requires an elevated, non-redirected Windows console and a manually typed confirmation, then applies a protected ACL (SYSTEM, Administrators, dedicated service SID) and copies only code and canonical `review_merge.py`. It does **NOT** create accounts, keys, QA signers, owner approval, or enable a live review service.
- `mcp-host-source/workspace_mcp/review_pipe_client.py` implements bounded reviewer-client transport. Before sending any owner grant or QA receipt, it verifies the Windows PID/token/SID of the pipe server against an independently trusted expected service SID, preventing pipe preemption from harvesting signed credentials.
- `p085_cross_principal_probe.py` is a no-modification, no-key-content WinAPI access probe. The operator must run it independently as the real worker, reviewer and QA-child identities and compare actual Windows identity separately.
- `test_review_pipe_client.py`, `test_p085_installer_source.py`, and `test_p085_cross_principal_probe.py` add targeted negative tests; installer PowerShell syntax is parsed without executing installation.

From an OWNER foreground Windows PowerShell console after provisioning three separate Windows accounts (replace example account names with the actual names), first inspect a read-only staging plan:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
.\Install-P085ProtectedService.ps1 -ServiceAccount '.\p085_service' -ReviewerAccount '.\p085_reviewer' -WorkerAccount '.\p085_worker'
```

Only after reviewing the planned source hashes, repeat with `-Apply` in an elevated interactive owner console. This stages code and stops. The canonical coordinator ACL migration and actual isolated QA signer must still be independently set up and verified before enabling `--accept-one`.

## Windows account preparation and actual SID-bound canary (2026-11-02)

- Added `Setup-P085WindowsPrincipals.ps1`: **dry-run by default**, separately stages five *OS principals* (service, reviewer, MCP worker, QA supervisor, QA child). These are NOT the five logical ChatGPT agents. `-Apply` only operates in an elevated owner foreground Windows terminal, requires exact typed confirmation, and creates only missing **disabled non-admin** local accounts with securely prompted passwords. It does not migrate ACLs, enable logons, start services, or change existing users.
- Added `p085_accounts_readonly_check.py`: safely parses dry-run data and returns only counts. On this PC it returned **0/5 configured, 5 missing**, no changes made.
- Extended `p085_cross_principal_probe.py --expected-worker-sid S-1-...`: reads actual process SID from Windows kernel, compares it against separately owner-verified expected SID, then verifies effective Windows write deny and protected key access deny. Unknown or inaccessible paths fail closed; it never reads secret bytes, never changes ACLs and is not sufficient by itself for production authorization.
- Test coverage: `test_p085_principals_source.py` (PowerShell AST parsed only), `test_p085_cross_principal_probe.py` (actual SID plus denial/allow tests). No local account creation was attempted through MCP.

Owner instructions in **genuine local Windows PowerShell terminal**:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
.\Setup-P085WindowsPrincipals.ps1
# Inspect five missing accounts, then only in an owner-controlled
# elevated interactive terminal, if you approve OS account creation:
.\Setup-P085WindowsPrincipals.ps1 -Apply
```

Accounts created by `-Apply` are deliberately **disabled** until the owner independently provisions password/login rights, access-denied ACLs and protected service/QA supervisor. Never enable them or use `--accept-one` merely because they exist. Protected code staging remains a separate `Install-P085ProtectedService.ps1` action. All five genuine OS principals and the installed service must pass independent access-denial tests and owner cutover gates.

## Avoiding duplicate broker implementations

A separate, simultaneously developed `experiments/foundation_kernel/` already contains an isolated **command/outbox execution broker** (`broker_named_pipe.py`, `win_pipe_ipc.py`, `signed_policy.py`, `journal.py`). It is for signed tool-command staging/reconciliation, NOT independent reviewer acceptance. The `mcp-host-source/workspace_mcp/review_grant_broker.py` and `review_finalizer.py` implement the latter. Do not treat them as two independent, competing authorities for acceptance.

The foundation kernel has a more advanced overlapped-I/O Win32 pipe layer. Before any production deployment, the owner/architect should approve a single **canonical IPC/identity adapter** and replace duplicated low-level named-pipe code; preserve distinct command-execution vs. formal-review capabilities and separate task/QA proof contracts. This design choice requires proper OpenSpec/SDD approval, not silent cross-owner imports. Neither experimental broker is live.

## Verified additional results

- `Setup-P085WindowsPrincipals.ps1`: safe Windows PowerShell AST parse PASS; three source-contract tests PASS; `p085_accounts_readonly_check.py` observed **0 configured / 5 missing**, with no account changes.
- `p085_cross_principal_probe.py`: five Windows tests PASS including process token SID match and key ACL failure modes; a service key unavailable due access denied is no longer misclassified as simply missing.
- `mcp-host-source` tests: 233 total, 6 skip, PASS.
- `agent_reuse_ci_gate.py`: PASS, zero hard clone groups. A first concurrent main gate had one failure in a separately edited experimental foundation-kernel broker test; its focused rerun passed. The **second complete** `agent_team.py gate-check` passed 1711 tests (41 skip), `spec_check.py` PASS and strict OpenSpec PASS. Treat the first failure as possible concurrent source/test drift; do not assert its underlying cause without a controlled reproduction.
- The connected production Local Workspace remains with script/file write privileges, so P085 is still **NOT DEPLOYED / NOT AUTHORIZED**.

## November 2 owner elevation inspection — verified account state

The connected Local Workspace MCP process was probed using read-only Windows WinAPI. Actual result: `is_elevated_administrator=false`, process `windows_session_id=1`, `can_create_local_accounts_without_uac=false`. Separate account inventory returned `accounts_configured=0`, `accounts_missing=5`. No account/user right/security descriptor was changed. Starting a Windows UAC prompt or supplying privileged passwords cannot be treated as granted merely because the chat user requested automation.

**Critical additional boundary:** Any `.ps1` file under the `IdeaProjects` MCP root can be modified by currently privileged agents. The owner must NOT execute the repository copy of `Setup-P085WindowsPrincipals.ps1` or `Install-P085ProtectedService.ps1` elevated without first independently reviewing and staging its exact bytes in an owner-controlled, write-protected location outside the MCP root, and validating its trusted SHA. A hash embedded in another writable repo file is not a trust anchor.

`Open-P085AdminTerminal.ps1` was added to request standard Windows UAC **only for a clean PowerShell terminal**; it does not invoke any editable repo setup code. Its two syntax/static safety tests PASS. No UAC has been triggered by MCP. To provision accounts, the owner must approve the genuine Windows UAC and operate from a trusted, owner-controlled source; never use a forged ChatGPT identity or scheduled task as consent.

## Remaining blockers

**P085 cannot be truthfully closed in the connected production environment** without the three actual OS identities, production ACL rollout and a genuinely isolated QA supervisor capable of signing witnessed execution. A signed PASS fabricated in a chat and a model-generated reviewer role are not proof of authority. The current observer source is not proof that the live tunnel uses it.

No privileged MCP host was restarted, no scheduled agent was stopped, no live queue task was accepted, no OS account/ACL was modified, no Git commit/push and no owner approval were fabricated.

Official API references: Microsoft Learn `Named Pipe Security and Access Rights`, `ImpersonateNamedPipeClient`, `Named Pipe Type, Read, and Wait Modes` (nonblocking compatibility mode is not a replacement for true overlapped I/O).
