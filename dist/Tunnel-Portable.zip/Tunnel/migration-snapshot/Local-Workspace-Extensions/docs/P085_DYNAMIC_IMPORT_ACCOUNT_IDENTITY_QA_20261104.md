# P085 — dynamic-import closure + five-principal evidence contract (2026-11-04)

## Scope
Real offline source/test work through Local Workspace MCP alias `projects`. Strictly diagnostic/non-authorizing. No UAC, new Windows principals, password handling, service creation, ACL change, browser launch/send, Chain2 ACK or queue transition, Chain3 activation, Git or unauthorized merge.

## Findings and fixes

### 1. Dynamic loader bypass in static Python import inventory
`chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py` already SHA-pins seven source/dependency files and checks their static `Import`/`ImportFrom` graph. Calls to `__import__()`, `importlib.import_module()`, `runpy.run_path()`, `exec()`, and `eval()` could select a new unpinned local source without creating a static import edge.

The inventory now fails closed with `SOURCE_DYNAMIC_CODE_LOADING_UNVERIFIED` on:
- Direct calls to `__import__`, `exec`, `eval`, or built-in `compile`.
- Calls to attributes `__import__`, `import_module`, `spec_from_file_location`, `run_path`, `run_module`.
- Imports of dynamic module resolution/loader packages `importlib`, `runpy`, `pkgutil`, or `builtins` (including aliases).

The test `test_dynamic_python_loader_and_evaluation_are_nonreviewable` exercises 11 variants without running any dynamic code. `test_non_dynamic_stdlib_imports_are_not_false_positives` confirms benign static imports still pass. This **does not prove** a complete dynamic dependency graph: module aliases, reflective Python tricks, embedded native code, imported subprocesses, unsafe interpreter/loader state and transient source mutation still require independent OS-protected review.

### 2. Ambiguous JSON from the diagnostic programs
`p085_readiness_matrix.py` now uses `_strict_diagnostic_json` for subdiagnostic stdout. Duplicate JSON keys and non-finite `NaN/Infinity` are rejected at any nesting level with `DIAGNOSTIC_JSON_UNTRUSTED`. The new regression test uses a mocked subprocess and confirms both negative rejection and positive ordinary JSON decoding. The no-privilege evaluation rule stays in place.

### 3. Read-only PowerShell account evidence lacked distinct identity contract
Concurrent workspace agent first added bounded stdout/stderr and root-schema checks to `p085_accounts_readonly_check.py` (SHA at that point: `6f25c2a3aafac539e91944f7a2484a57a544ae05ad8e8e7c307e3030abf0214c`; seven initial tests PASS). The matrix correctly returned `SOURCE_DEPENDENCY_SHA_DRIFT` until the code was inspected and tested.

Follow-up hardening of that existing read-only Python checker:
- Rejects duplicate JSON keys and non-finite values.
- Requires the exact five distinct PowerShell role labels: `service`, `reviewer`, `untrusted_worker`, `qa_supervisor`, `qa_test_child`.
- Rejects duplicate Windows account names (case insensitive), duplicate existing SIDs, malformed local-account names, existing entries without a local SID/boolean `disabled`, and missing entries with non-null SID or disabled status.
- Requires dry-run declarations `dry_run=true`, `creates_only_missing_accounts=true`, `all_new_accounts_disabled_until_owner_cutover=true`, `does_not_start_services_or_change_project_acls=true`, and `effective_os_token_isolation_verified=false`. Contradictory or missing flags fail closed.
- Output still consists only of aggregate counts; does not claim genuine OS identity or service trust.
- Added `test_p085_accounts_identity_contract_20261104.py` with 10 isolated tests and adapted the existing `test_p085_accounts_output_hardening_20261104.py` positive fixture to actual PowerShell output fields.
- Re-pinned the validated accounts module SHA in the read-only matrix using optimistic concurrency control and reran integration.

## Exact verified source SHA256
- `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py`: `70b697df2e39efd866c641e17ae8ee0e9886d06e4e076b3c6587ad4cc57b706a`
- `chat-launch-smoke-desktop-test/web-companion/test_p085_readiness_matrix.py`: `f31ee3b0c8ecbe7a70e76ccb7465182211c9314849ff0991bf68abdadf554c36`
- `Local-Workspace-Extensions/p085_accounts_readonly_check.py`: `2d5d56f6c390bfd76f6fe47a822e5b2c70e1beb7f6391422197278cd36ebdf84`
- `Local-Workspace-Extensions/test_p085_accounts_identity_contract_20261104.py`: `ae74666bd9df3fb8390d9c8fed3cba19994f559f81c37090298812c189de9d0a`
- `Local-Workspace-Extensions/test_p085_accounts_output_hardening_20261104.py`: `d6efffc7a1134ee64adac2d0bb31dc811745738a405da781f647d67035d59516`

## Verified job results
- First dynamic-loader-focused matrix test `bdff2971ae144692b12c4e99ccd939ff`: completed rc=0, 22 PASS.
- Account pre-change seven negative tests `e2f05b035939489f8ee8e474e378e060`: completed rc=0, 7 PASS.
- Pre-repin diagnostic `f3835dc152cc401489989345be4d1510`: completed rc=0, `status=UNKNOWN`, `SOURCE_DEPENDENCY_SHA_DRIFT`, no action authorized.
- Added identity tests `e4b71d0ccbc44a51913352df31827e7d`: completed rc=0, 9 PASS; first broad `d2051ae4cd9a40aab7d79ee787c58095`: 130 run, 124 PASS / 6 SKIP.
- Final account identity suite `2c3e0d4860e240448a01c95a407b04a8`: completed rc=0, 10 PASS.
- Final legacy account suite `b6dac0d2c1e04409a73cccd13978077d`: completed rc=0, 7 PASS.
- Final P085 broad suite `71fa7df21f344ef8aa11ee727f949591`: completed rc=0, **131 run, 125 PASS / 6 SKIP**.
- Final matrix suite `82182ae58f704392b0c63209d8164b55`: completed rc=0, **23 PASS**.
- Final full web-companion `2df34cbd507a455dbd68faf692bdc4ec`: completed rc=0, **223 run, 222 PASS / 1 SKIP**.
- Final read-only matrix `f9154f0d963e491190954d7a1b8769af`: completed rc=0, `ok=true`, `status=UNTRUSTED`, `accounts_configured=0`, `accounts_missing=5`, `stage_status=NOT_STAGED`, `can_activate_chain3=false`, `can_complete_chain2=false`, `source_inventory_checked=7`, `dependency_sources_checked=5`.
- Chain2 independent readonly dossier `fa96ea774804424ca65d6cd9e9d7843d`: completed rc=0, 9 ACTIVE (4 CLOSED_WITHOUT_VERIFIED_ACK, 4 PRE_SEND_UNCONFIRMED, 1 ACCOUNT_CONTEXT_DISPUTED), 0 matching ACKs, no queue mutations.
- Chain3 read-only preview `34b0a0fc7cee413a931f5894f840ac11`: completed rc=0, `effective_mode=blocked`, `owner_armed=false`, `trusted_host_verified=false`, zero new jobs.

## Unresolved release blockers
No OS-protected broker or code source, no privileged owner approval, no genuine isolated Windows service/reviewer/worker accounts, no independently attested two-principal E2E, and unresolved original delivery ACKs for nine Chain2 tasks. The new role/SID inventory remains **diagnostic evidence only** and cannot close those blockers. Any real staging/ACL provisioning/cutover must be owner-controlled and inspected outside the agent-writable project tree.
