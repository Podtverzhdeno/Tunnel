# Foundation hardening — приоритеты и зависимости (2026-11-02)

**Статус:** owner-approved **создание OpenSpec/SDD** завершено через foreground `owner_approve.py` request `25b92cf977b0a0ad2617aa4752e2e9cc`; `spec_request_execute` успешно создал 13 файлов. Это **не** разрешение на privileged host deployment, reviewer accept/merge или live-очередь.
Канонический бриф: `requests/add-agent-foundation-hardening.json`.
Созданы `openspec/changes/add-agent-foundation-hardening` и `specs/005-add-agent-foundation-hardening`.
OpenSpec strict + SDD crosswalk: 12 FR / 36 scenarios / 12 mappings. Не считать чекбоксы выполненными без QA.

## Строгий порядок реализации

| Order | P | FR / будущие задачи | Фундамент | Зависимости и порядок |
|---:|---|---|---|---|
| 1 | P0 | FR-001–002 / T001–T002 | Доверенная личность MCP и единое применение прав на host | P085 — существующий канонический владелец. Перед любым доверенным merge, privileged queue/spec/release. |
| 2 | P0 | FR-003–004 / T003–T004 | Очередь независимого ревью и восстановление принятия | Read-only triage можно параллельно с T001; доверенное accept/merge строго после T001–T002. |
| 3 | P1 | FR-005–006 / T005–T006 | Полный журнал измеренных запусков | Независимый поток, можно начинать параллельно с P0. Нужны проверенные наблюдения scheduler; неизвестное не интерполировать. |
| 4 | P1 | FR-007–008 / T007–T008 | Матрица OpenSpec ↔ SDD ↔ тесты ↔ review receipts | Строгая нормативная проверка перед выпуском; можно проектировать параллельно с P0. |
| 5 | P1 | FR-009–010 / T009–T010 | Реестр ответственности старых задач | Только read-only mapping до T007; live migration — после T001, T002, T007, T008 и отдельного разрешения. |
| 6 | P2 | FR-011–012 / T011–T012 | Package/import DAG, публичный API, совместимость | После инвентаризации канонических модулей; дополнять текущие AST guards без второго движка. |

## Реализация по этапам, с проверяемыми рубежами

**M0 — P0 host trust, блокирующее условие безопасности.**
- Проверить реальный MCP host, а не только библиотеку из sandbox: actor credentials, grant expiry, scope, tool name, filesystem limits, lease, revocation, idempotency.
- Негативные E2E: подмена роли reviewer в аргументах, прямой `run_script`/file write, истёкший/повторный grant, reconnect без идентичности.
- Pass: все mutation entrypoints используют единый policy gate и отказывают без гранта. Публичные read-only health/triage не требуют эскалации.
- Fail: остаётся хотя бы один privileged обход через универсальный runner. Это блокирует доверенный merge.

**M1 — P0 review flow, сначала read-only, затем доверенное принятие.**
- Использовать существующие `review_queue_triage.py`, `review_merge.py`, `peer_review_switch.py`, `acceptance_records`.
- Воспроизвести queue head-of-line blocking, две параллельные попытки accept, hash drift, падение после merge intent и неверный reviewer.
- Pass: eligible review проходит независимо от другого заблокированного, peer не может accept, повтор операции не удваивает receipt, неопределённое состояние попадает в reconciliation.

**M2 — P1 scheduler history без фиктивных часов и токенов.**
- Развивать `experiments/chat_only_run/all_session_runtime_audit.py` + `team_run_metrics.py`, не создавать ещё одну независимую систему учёта.
- Персистентный run_id, host source, status, started_at, completed_at (nullable), observation completeness, timestamp drift, duplicate conflict.
- Pass: совпадающий run_id считается один раз, Dev3+4 — один scheduled run, failed completed counted with status, in_progress duration NULL, acquisition count не превращается в runtime.

**M3 — P1 нормативная трассировка результата.**
- Развивать `spec_check.py`, `spec_traceability.py`, `sdd_roadmap_check.py`, проверять SHA и независимые QA receipts, не доверять чекбоксам в плане.
- Негативные тесты: требование без executed test, сменился source SHA, изменился SHALL, два владельца одной FR.
- Pass: для каждой принятой FR есть воспроизводимая цепочка evidence; incomplete, conflict, stale отделены от accepted.

**M4 — P1 поэтапная миграция legacy, только после M0+M3.**
- Read-only inventory для старых unmapped задач и API; отдельно фиксировать REVIEW_REQUIRED.
- Каждая реальная migration batch должна иметь owner approval, независимое review, SHA CAS, transactional journal.
- Pass: active leases не перезаписываются, чужая ответственность не захватывается, rollback и retry идемпотентны.

**M5 — P2 расширение архитектурных границ.**
- Повторно использовать `agent_responsibility_guard.py`, существующий `import_graph_guard.py`.
- Покрыть packages/relative import, dynamic import UNKNOWN, циклы, baseline API и error contracts.
- Pass: новый package-cycle блокируется, опасное изменение ABI/API требует план миграции, семантическая эквивалентность никогда не угадывается.

## Критическая цепочка

`M0 trusted host grants` → `M1 privileged review accept` → `M3 verified release evidence` → `M4 legacy live migration` → `M5 architecture compatibility`.

Возможная параллельная работа **без привилегированных изменений**:
`M1 read-only triage` + `M2 observed run ledger` + `M3 read-only crosswalk` + `M4 source inventory`.

## Антидублирование

- P085 / host access — один канонический владелец, новая спецификация задаёт его критерии E2E, а не новый authentication broker.
- `review_merge`, `peer_review_switch`, `review_queue_triage` — дополнять, не дублировать.
- `team_run_metrics`, `all_session_runtime_audit` — одно хранилище наблюдений с provenance.
- `spec_traceability` / `sdd_roadmap_check` — один нормативный crosswalk.
- `agent_responsibility_guard` / `import_graph_guard` — один канонический dependency graph.
- Резерв P162–P169 нельзя считать одобренным вследствие появления этого документа.

## Подтверждённое внедрение hardening, 2026-11-02 (не formal release)

**T001–T002 / P085 (частично):** в `host_role_policy.py` offline-guard
теперь распознаёт namespace-qualified aliases универсальных команд
(`local_workspace.run_script`, `mcp.run_command`, `run-script`),
а не только короткие имена. Добавлены негативные тесты
`test_host_role_policy.py`; возможное offline `ELIGIBLE_UNVERIFIED`
**не** является разрешением. Реальный Windows MCP host с доступным
универсальным `run_script` ещё не обеспечивает доверенное разграничение.
Для закрытия P085 необходим реальный host-side denial/ACL E2E с отдельным
Windows principal и защищённым владельцем grant, как указано выше.

**T003 (частично):** `review_readiness_matrix.py` рассматривает всю
ограниченную `review_queue_triage`-выборку (не только первые N элементов),
отдельно ограничивает вывод, сортирует структурно доступный независимый QA
выше blocked head-of-line и сохраняет полный счёт ошибок/просроченных аренд.
`agent_team.review_preview` переведён на `connect_readonly(mode=ro,
query_only=ON)`: больше не вызывает `connect()` с DDL/WAL и
инициализацией схемы только для инспекции. Тесты проверяют скрытую
`PREFLIGHT_ERROR`, 60 старых blocked перед ready и отсутствие записывающего
`connect()`. Это **не** выдаёт новый reviewer lease и не делает QA PASS.

**Live диагностическая выборка:** 21 задача review/reviewing; 20
`READY_FOR_INDEPENDENT_QA` означают только отсутствие статических
блокеров (не принятие кода), 1 `EXPIRED_LEASE_REACQUISITION_REQUIRED`
(P111). Имеющиеся отрицательные QA для P152/P153/P159 и других
кандидатов требуют отдельного исправления в owned task sandboxes;
их нельзя считать ACCEPT по положительной статической матрице.

**Проверки:** 132 targeted tests прошли (1 skipped), полный
`python -m unittest discover -q` прошёл: **1422 tests, 35 skipped**,
`spec_check.py` errors=[], OpenSpec strict + SDD validate=true.
Ни одна из T001–T004 не отмечена выполненной; окончательное принятие
и host security validation остаются открытыми. Ожидаемая цена полного
static readiness scan зависит от размера очереди; на 21 задаче
наблюдалось около 29 секунд. Не использовать этот scan под
долгоживущей SQLite write transaction и не смешивать с реальной QA.

## Правила Definition of Done

- Одобренный неизменённый OpenSpec/SDD; отдельное owner approval для любой расширяющей права операции.
- Обязательные negative tests и real Windows UTF-8/links/timeouts, независимое QA и digest; ни один mock не заменяет trusted host E2E.
- Статус тестов, исходников, решений, blockers и rollback подтверждён фактическими наблюдениями; без ручного объявления PASS.
- После завершения M0–M5 обновить задачи, FR evidence и canonical ownership, не смешивая proposed и accepted.

