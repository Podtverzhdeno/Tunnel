# Chat-only continuity protocol (W0): five scheduled roles, no external LLM clients

**Scope:** Existing OpenSpec + SDD scheduled ChatGPT chats and connected Local Workspace MCP only. This is a **non-normative runbook** for currently implemented `agent_team.py` commands; canonical OpenSpec and SDD govern permissions and acceptance. No Codex, ChatGPT Work, browser automation, GitHub triggers, OpenAI API or creation of fresh chats from the PC.

## The actual system boundary

A ChatGPT scheduled execution is one bounded platform-controlled turn. Python cannot keep its model reasoning alive, force a new ChatGPT message, or auto-extend model inference. The local SQLite coordinator persists *task state* between separate scheduled turns, not the model process or hidden thoughts. Prompts do not override platform limits.

The user has five logical roles in four hourly ChatGPT scheduled cards: D1 at :10 UTC, D3 followed by D4 at :20 UTC, D2 at :30 UTC, independent architect-reviewer at :50 UTC. The fifth active automation is unrelated and must not be disabled. Hourly launch timing is a scheduler property; we neither promise continuous 24/7 reasoning nor induce no-op calls to lengthen a turn.

## W0: one short authoritative start packet

On each scheduled chat execution:
1. Connect Local Workspace `list_workspaces` and verify alias `projects`.
2. Invoke `run_script` on
   `Local-Workspace-Extensions/experiments/chat_only_run/chat_run_packet.py`
   with `cwd=Local-Workspace-Extensions/experiments/chat_only_run` and
   `args=["--role","developer-N"]` (or `architect-reviewer`).
3. Poll `job_status(job_id)` to **completed, returncode=0** and parse `job_output` JSON `ok=true`. A running job is not success. The first status snapshot is now obtained through `experiments/chat_only_run/read_only_queue_snapshot.py`: SQLite `mode=ro`, `PRAGMA query_only=ON`, one snapshot transaction, and a bounded set of non-secret fields. `plan-work` invokes the existing separate, read-only coordinator command; its recommendation may race with changes and is never a lease. The startup packet deliberately omits checkpoint text and does not inspect merge intents: review agents MUST call `merge-status` before any review; developers MUST use transactional `acquire` with a legitimate host permission.
4. Read current `AGENTS.md`, this file, `docs/FIVE_AGENT_TEAM.md` and the exact task's canonical OpenSpec + SDD/QA. For `ops.py read_text`, use existing `read_text` fallback if Local Workspace `read_file` returns empty.
5. For a proposed task, `python task_resume_packet.py --task Pxxx` is read-only and advisory; inspect actual source SHA, QA and dependency evidence. `plan-work` and packets are not assignments, leases, actor identity or approval.

**Read only documents relevant to the real task.** Do not repeatedly reread every portfolio or restate years of obsolete status. Before acting on any historical ID, consult live SQLite and current spec.

## Developer turn: deliver real verified code

- If there is a legitimate scoped active lease token for the current invocation, continue its actual task and sandbox. An **old** working status does not prove a new ChatGPT invocation possesses the lease token; never guess or steal it.
- If the previous task is blocked by stale spec/source or inaccessible lease, use `plan-work ROLE` and the packet to find a distinct **available** spec-backed safe task. Use a **fresh** `new-request ROLE`, then `acquire ROLE REQUEST_ID --task Pxxx`; repeat the **same** ID only for recovery of the *same* uncertain acquire. Coordinator rechecks readiness atomically. Never use P096 lease for P110. If no eligible task, meaningful read-only preflight / specific blocker; no invention or placeholder work.
- Read own sandbox's requirements, artifacts, previous review notes/checkpoint; edit **only allowlisted deliverables** under the valid task sandbox. The script or LLM prompt is NOT a trusted MCP actor grant and cannot bypass host permissions.
- Write implementation and negative tests. Run focused tests, **full** sandbox `unittest discover`, `spec_check.py`, and strict OpenSpec validation with observed exit codes. Avoid repeating long tests when unchanged and unnecessary; full gate required before submit.
- Heartbeat within lease TTL and before long tests. Record short accurate `agent_progress.json` in own sandbox via Local Workspace `write_file` with SHA CAS; call `new-request`, then `checkpoint-file ROLE TASK_ID TOKEN REQUEST_ID`. Verify history. No raw JSON in MCP script args; no secrets/keys/tokens in telemetry.
- `submit ROLE TASK_ID TOKEN NOTES` only when implementation and actual tests are ready. Review stays independent; only reviewer accepts. If partial, save checkpoint before ending.
- **If a task has been submitted and safe available work remains**, refresh the read-only packet/plan and legally acquire the next distinct task during **the same ChatGPT execution**. Repeat this while a meaningful safe task and sufficient time/context remain. No arbitrary required session duration, no simulated work. One turn may naturally end at any point.

## Architect reviewer turn: keep queue flow healthy

- On start, query the read-only packet with `architect-reviewer`; inspect `review` vs `reviewing`, current lease ownership and `agent_team.py status`.
- When legitimately granted review lease, use `review-preview` and `merge-status` first; independently inspect scoped deliverables, tests, current spec SHA, source CAS, prohibited edits and three QA gates. Only then `review accept/reject` with evidence, then check `team_acceptance_audit.py` and task history. No auto-accept because tests, model statements, or local data say PASS.
- An unresolved merge intent requires **owner manual recovery**, not an automatic retry. P096 stale source must not overwrite newer coordinator.
- Avoid re-reviewing a blocked task while other submitted work is ready. After a legal decision, refresh packet and handle the next independent submitted task within the same invocation.
- If no reviewable tasks, triage blocked tasks and optionally prepare independently scoped spec-backed backlog. New canonical normative spec requires owner approval; do not grant host rights or invent tasks just to fill runtime. Do not mutate SQLite directly.

## Developer 3+4 shared scheduled card

Execute the full workflow for **D3 then D4 sequentially**, separate request IDs, leases, sandboxes, test receipts and checkpoints. This is one ChatGPT scheduled run, not two independent concurrent LLM sessions. If D3 is blocked, proceed with safe D4 work instead of spending entire joint invocation on D3. Never transfer D3's lease or role to D4.

## Stop-reason and measurement

Each finished turn reports tasks actually changed/submitted/accepted, test exit codes, checkpoint, blockers, and why it ended: `done_and_next_ready`, `blocked_missing_lease`, `no_safe_work`, `QA_failed`, `review_waiting`, `MCP_unavailable` or `platform_turn_ended_unknown` when stop reason is unknowable. Never fabricate ChatGPT token use, exact reasoning time, or scheduled run count from visible text. A full run is valuable when it produces accepted, independently verified changes, **not when its wall-clock duration is long**.

### Remaining fundamental limitations

- No trusted role-to-MCP authorization enforced in actual privileged host until P085.
- New scheduled invocations cannot retrieve a previous, still-active lease token by asserting a role. Wait for legal reacquisition or do disjoint safe work. Do not bypass leases.
- Actual autonomous 24/7 ChatGPT web turns or user chat sending from local Python are not supported.
- Proposed deeper durable step memory/effect reconciliation remains a separate owner-approved OpenSpec change, not implemented here. This W0 solution is immediate workflow optimization, not an indefinitely running model.

## Main-project vs agent-sandbox QA (2026-11-02)

The default main-project `python -m unittest discover` now includes the `experiments/chat_only_run/test_*.py` suite via root `test_chat_only_run_suite.py`, with compatibility tests in `test_chat_only_suite_contract.py`. This catches regressions in queue supply, owner foreground gates, role packets and read-only SQLite snapshots which were previously omitted from main discovery.

**The per-task developer sandbox intentionally contains only root-level Python and allowlisted OpenSpec/SDD snapshots, not `experiments/`.** Root test discovery therefore recognizes only the coordinator-created `.agent-team/workspaces/developer-N/Pxxx` folder with `team_checkpoint.json` and omits the absent experimental suite there. It does not silently suppress a missing experimental suite in the real main project. Sandbox PASS is not evidence that experimental tests ran; independently run the main project suite when evaluating project-wide regressions.

Verification on Windows: `python -m unittest discover` => 896 tests, 26 skipped, 0 failed; `python -m unittest test_chat_only_suite_contract` => 4 PASS; `python ops.py spec_validate Local-Workspace-Extensions local-pc-agent-tooling` => OpenSpec strict valid. These observations are bounded to the test run, not a perpetual release status or a host-grant attestation.

The unrelated owner queue admission plan is **preview-only** until actual foreground confirmation; no chat agent should call `owner_queue_admit.py --apply` via MCP, alter live SQLite, or interpret preview-ready tasks as active developer leases.

## Reversibility

The single read-only packet helper is `experiments/chat_only_run/chat_run_packet.py`. To roll back workflow changes, restore the previous four scheduled prompt texts; never delete or alter existing `.agent-team/team.sqlite3` or reschedule/delete unrelated cards. The helper has no mutating CLI calls and is safe to remove independently after prompts are restored.
