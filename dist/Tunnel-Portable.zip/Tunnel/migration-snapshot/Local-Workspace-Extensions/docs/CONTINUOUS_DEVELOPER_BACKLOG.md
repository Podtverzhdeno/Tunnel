# Непрерывный резерв задач для 4 разработчиков — 2026-11-02

## Цель и гарантии
Проверять запас доступных **разрешённых** coding-задач, чтобы не терять почасовые запуски из-за пустой очереди. Цель — 2–3 live ready на каждую роль. Резерв — не гарантия бесконечной работы: исчерпание, reviewer gates, владелец, технические блокировки и ограничения подписки остаются реальными.

## Что готово
- Четыре предыдущих P150–P153 **допущены владельцем** ранее, но перед новой арендой статус всегда проверяется заново.
- 16 новых уникальных кандидатов P154–P169 в `experiments/chat_only_run/queue_supply_candidates_backlog.json`: по 4 на каждую роль. Каждая задача имеет отдельные deliverables, минимум один тестовый файл и ссылку на существующее OpenSpec SHALL.
- `queue_supply_plan.py` использует новый резерв, строго проверяет отсутствие конфликтов, готовые зависимости/QA, лимит и не меняет SQLite.
- `owner_queue_admit.py` проверяет не более **3 доступных задач на роль**, включая уже зачисленные, и требует foreground typed approval с SHA-планом; никакое согласование через MCP не имитируется.
- `queue_supply_watch.py` анализирует реальные статусы SQLite + будущую волну, рекомендует пополнение при `live_ready < 2` и честно различает `OWNER_ADMISSION_REQUIRED`, `BACKLOG_EXHAUSTED_OR_BLOCKED`, `LIVE_QUEUE_READY`.
- Почасовой Architect Reviewer обязан вызывать watchdog при каждом запуске, сверять независимые QA receipts и заранее готовить новую непересекающуюся волну, если активный резерв иссякает. Нельзя заполнять очередь фиктивными задачами, обходить P085 или устраивать self-review.

## Текущий статус допусков — 2026-11-02

P150–P153 и P154–P161 **уже допущены владельцем**, что подтверждено записями
`.agent-team/reports/queue_admission_985c4e1222464295.applied` и
`queue_admission_41c08590a4cb550b.applied`. Повторять историческую команду
`ADMIT 41c08590a4cb550b` **не нужно**. В частности, P152/P153 прошли
guarded submit и находятся на независимом review; P156/P157/P160/P161
доступны для отдельных штатных аренд, а оставшиеся P150/P151/P154/P155/P158/P159
проходят восстановление sandbox QA. Истина — живой `agent_team.py overview`,
а не эта моментальная сводка.

P162–P169 **ещё не допущены**. До явного утверждения нормативного SDD
`owner_queue_admit.py` обязан блокировать их с
`SDD_ROADMAP_UNMAPPED_P162`. Не менять seed/SQLite для обхода.

## Двухфазный механизм допуска новой волны

Новый статус SDD `qa_validated_owner_gate` означает «зависимости имеют
зафиксированную независимую QA-приёмку и точную каноническую SHALL-ссылку;
**ожидается интерактивное решение владельца**». Сам статус **не** создаёт
задачу в SQLite и не выдаёт developer lease. `sdd_roadmap_check.py`
разрешает этот статус как до, так и после реального owner admission и
проверяет фактическое наличие seed, совпадение role/spec/priority/deliverables
и persisted predecessor QA. Существующие статусы
`seeded_after_dependencies_accepted` по-прежнему требуют уже существующей
seed-записи — это исключает фантомное подтверждение.

После отдельного канонического согласования reviewer/owner может подготовить
точные P162–P169 как `qa_validated_owner_gate`. Только потом владелец
в **своём локальном интерактивном терминале** делает:
```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\chat_only_run
python queue_supply_watch.py
python owner_queue_admit.py
```
Только для актуального **нового** `plan_id` (если есть `ready_ids`)
выполняется `python owner_queue_admit.py --apply --plan-id YOUR_NEW_PLAN_ID`.
Файл roadmap и candidate pool дополнительно фиксируются SHA и повторно
проверяются после typed confirmation: CAS drift запрещает зачисление.
Если есть `.pending` receipt, не повторять операцию слепо — ручная сверка.

После зачисления повторить `queue_supply_watch.py` и
`python ..\..\agent_team.py plan-work developer-1` для каждой роли.
Свежие task lease и строгое QA обязательны, P085 не обходится.

## Автоматический безопасный цикл
Каждый Architect Reviewer hourly run: 1) проверить `queue_supply_watch.py`; 2) если <2 ready, получить read-only preview и сообщить владельцу новый plan ID; 3) проверить review-состояния и разрешённые coding задачи, приоритизировать исправление блокеров; 4) если будущих кандидатов менее 8, изучить текущий OpenSpec и подготовить новую separate JSON волну с уникальными ID, полностью новыми файлами и independent QA-зависимостями; 5) локально проверить `queue_supply_plan`, `unittest`, `openspec validate --strict`; 6) **не** записывать задачи в team_seed/SQLite без foreground owner approval. Агенты при отсутствии coding следуют уже установленным peer-review/architect-support схемам, не симулируя прогресс.

## Проверки
- `python test_queue_supply_watch.py`: 7 PASS.
- `python -m unittest discover -q`: 1155 tests, 31 skipped, 0 failures на момент изменения.
- `python ops.py spec_validate Local-Workspace-Extensions local-pc-agent-tooling`: OpenSpec strict valid.
- Живой read-only preview: 8 candidate-ready, 8 buffer-full; ни один из них ещё не зачислен этим чатом.
