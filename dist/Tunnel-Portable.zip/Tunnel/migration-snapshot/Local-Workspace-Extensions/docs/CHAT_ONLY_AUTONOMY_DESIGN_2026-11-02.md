# Chat-only autonomous agent operation — design note (2026-11-02)

Status: planning-only; NOT a production trigger, host grant, canonical OpenSpec change or owner approval.

## Hard platform boundary

A Windows process has no documented supported endpoint to send arbitrary new messages into an existing ChatGPT web chat. A local MCP server is an inbound tool surface, not a reverse RPC channel into a live ChatGPT conversation. Do not imply that a cron job, browser automation, relay or tunnel can reliably or permissibly turn a local event into a web-chat turn. No Codex, Work or OpenAI API is authorized for this design.

## Supported operating model

1. ChatGPT Automations invoke a scheduled role through its chat context; one invocation is a bounded turn, not a resident daemon.
2. Each invoked role opens the canonical OpenSpec/SDD, checks the durable SQLite coordinator and reads a task resume packet.
3. `plan-work ROLE` classifies candidates without altering leases. For a ready disjoint task, the genuine role invokes `acquire ROLE NEW_REQUEST_ID --task Pxxx`, obtains fresh task-specific fencing, performs scoped work and checkpoints.
4. If a task is blocked by source drift, unresolved owner approval, missing provenance or an active lost lease, do not forcibly release it. Route review evidence to the architect; switch to a separately authorized, independent ready task.
5. Reviewer independently runs spec traceability, negative and regression tests, applies source-hash checks and accepts/rejects artifacts. Developer never self-accepts.
6. When no eligible work exists, record the actual stop reason and terminate this invocation; the next scheduled turn reevaluates fresh state. Do not simulate model activity between scheduled turns.

## Persistence and reliable continuation

- Keep task identity, dependency edges, current baseline SHA, checkpoint, idempotency request ID, lease expiry, attempt number and actionable resume packet in durable storage.
- Distinguish host-attested actor identity from caller-supplied ROLE. Lost active leases cannot be transferred without host-side identity and fencing.
- Use atomic outbox/inbox for task events; dedupe by event ID; replay only idempotent operations. Preserve a terminal receipt: done, blocked, awaiting_review, no_work, provider_limit, or error.
- Calculate stale and unreachable statuses, but never treat a stale heartbeat alone as authorization to revoke another run's lease.
- Do not claim actual ChatGPT prompt/completion token usage unless sourced from trusted provider receipts.

## Acceptance tests before any production change

1. Four distinct developer tasks with non-overlapping write sets run on their respective scheduled turns.
2. Source SHA drift blocks only the affected task; another eligible task proceeds without lease theft.
3. Lost active token does not grant takeover, and no two roles acquire one task at once.
4. Repeated invocation with the same idempotency key does not double-apply a write.
5. Interrupted run resumes from durable checkpoint after normal lease handling.
6. Reviewer rejection returns actionable remediation without merging unauthorized code.
7. MCP/tunnel outage ends the turn with an accurate stop reason; subsequent scheduled turn recovers.
8. Unauthorized host role, unapproved spec write and unsafe replay all fail closed.
9. Reported success is tied to actual tests plus reviewer acceptance, never to a prompt response alone.
10. Measured tasks/hour and accepted code, not number of empty turns, define throughput.

## Non-goals

- Local script directly pushing messages into web ChatGPT; no supported primitive is established.
- Browser UI scripting as a replacement for an authorized trigger.
- Bypassing quota, subscription limits or task approval.
- Claiming five independent simultaneous models when roles are invoked sequentially.

## Rollout order

P0: Continue running existing scheduled chat roles and collect trustworthy receipts.
P1: Finish current P108/P110/P111/P125 work through isolated QA and independent reviewer.
P2: Implement missing host-attested identity/permission controls (P085) before any automatic lease recovery.
P3: Implement durable checkpoints/stop-reason observability in a separately owner-approved OpenSpec+SDD change; reuse existing add-continuous-agent-work-loop when feasible rather than duplicating it.
P4: Benchmark useful accepted tasks per day, failure recovery, and idle-turn percentage.

This document is intentionally non-normative and does not modify canonical requirements, live SQLite, permissions, existing automations or agent leases.
