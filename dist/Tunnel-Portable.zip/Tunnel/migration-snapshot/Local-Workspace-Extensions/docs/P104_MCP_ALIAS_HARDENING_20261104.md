# P104: Direct code repair — MCP namespace hardening (2026-11-04)

## Applied changes in canonical Local-Workspace-Extensions

The user explicitly requested to apply fixes. The project-owned `host_role_policy.py` was modified **in place with exact expected-SHA optimistic locking**, not merely staged in an agent report. Baseline SHA: `0932dd9ae237a100f7180fb2a5c68e87818483b1115c5e361baa0c2580c77883`. Current verified SHA: `933b96624f909c9b0cd4347466de30f975fa483ed0356c6fd38ccd2e739e1030`.

Changes:
1. General executor matching now recognizes real MCP `mcp__Local_Workspace__run_script` double-underscore namespaces (and other qualifying names) instead of only dotted aliases.
2. Canonical known Local Workspace 28 tool IDs are classified by offline diagnostics: 14 read-only tool names, 14 mutating/execution/Git names. An R0 claim does not make mutating tools safe.
3. Unknown, nested, changed-case or disguised `__` host identifiers are rejected with `UNRECOGNIZED_HOST_TOOL_ALIAS` before assessing hypothetical rules/grants.
4. `_validate_snapshot` runs the alias check on each listed tool.
5. Added canonical regression module `test_p104_mcp_host_registry_hardening_20261104.py`, SHA `5a586032da3162ece3f719172970231bd1c6bff4017de6b1d6fe9a3e67bbfd3a`, with negative, positive and fake-host risk tests.

## Verification facts

- Before patch: SHA-fenced isolated candidate test `9e57ce389b88435ba07bb73c6389b97b`: rc=0, 56 existing tests and 40 extra checks, all pass on candidate.
- After patch: `python -m unittest -q test_host_role_policy test_p104_mcp_host_registry_hardening_20261104`: job `1934cd538f5d4514a8a7070aa6bcdf89`, rc=0, **61 tests OK**.
- Full canonical `python -m unittest discover -q`: job `48fe3994a6a34fea8c0ddefec5d457ea`, rc=0, **2311 tests OK (43 skipped)**.
- `agent_reuse_ci_gate.py`: job `77f430089aaa4f0d8175457de57956fb`, rc=0, passed; 122 canonical modules scanned, 560 eligible functions, no structural clone groups.
- `spec_check.py`: job `44e8720d39fc48e58476bee5c7a1eb49`, rc=0, 99 requirements, 128 scenarios, structural errors=[].
- `team_acceptance_audit.py`: job `65aa2bfaeeef4cce80375ac4a4de5bb3`, rc=0. **P104 historical receipt still invalid**: `CURRENT_SOURCE_HASH_MISMATCH`. The source repair is not an acceptance-ledger repair.

## Security and lifecycle boundaries

This module is a deterministic, stdlib-only **offline policy classifier**. `ELIGIBLE_UNVERIFIED` always retains `execution_authorized=false` and `host_enforcement=false`, regardless of input. It does not deploy to the Local Workspace MCP dispatch boundary, authenticate Windows SID, issue grants, or satisfy P085.

No changes to task SQLite, source acceptance receipts, foreign agent sandboxes, leases, Windows ACLs, service configuration, browser or secrets; no Git commit, push, or manual merge. A protected owner/reviewer path must still create a fresh QA receipt for P104 and independently prove P085 host enforcement before declaring release readiness. P108/P111/P148 are separate rework responsibilities and have not been silently modified.

## Files

- `Local-Workspace-Extensions/host_role_policy.py` — actual main source fix
- `Local-Workspace-Extensions/test_p104_mcp_host_registry_hardening_20261104.py` — regression suite
- `Local-Workspace-Extensions/docs/P104_MCP_ALIAS_HARDENING_20261104.md` — this evidence
