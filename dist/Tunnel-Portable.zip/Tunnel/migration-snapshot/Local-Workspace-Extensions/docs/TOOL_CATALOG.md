# Tool Catalog — Local PC Agent MCP

**Status:** planned portfolio, not a claim of installed MCP tools. Existing CLI prototypes live in `ops.py`, `infra_tools.py`; `mcp_adapter.py` is not yet registered in the real server. Since 2026-11-02, `pc_toolbox.py` adds 12 *implemented and Local Workspace.run_script-callable* R0/R1 diagnostics (including safe terminal presets, AST, ffprobe, processes, CPU/RAM/disk and code search), with 12 matching **adapter declarations only**, not registered tools in the live MCP host. See `docs/PC_TOOLBOX.md` and `test_pc_toolbox.py`.

Scoring: usefulness (1–5, higher = more daily value); implementation complexity (1–5, higher = harder). These are engineering estimates, not benchmarks. Risk: R0 passive, R1 bounded/sensitive read, R2 changes state, R3 privileged/system-wide. The actual server may elevate a tool's risk based on arguments and data classification.

Core decision: enforce permissions in the real MCP host. Restricted agents must not retain unrestricted `run_command` / `run_script`, or these wrappers offer no security boundary.

## Ranked capability inventory (62 tools)

| Phase | Tool | Concrete result | Risk | Value | Effort | Status |
|---|---|---|---|---:|---:|---|
| P0 | workspace_discover | Projects, manifests, Git/Compose roots | R0 | 5 | 2 | new |
| P0 | code_search | Literal/regex search, globs, cursors | R1 | 5 | 2 | new |
| P0 | file_read_utf8 | Line-precise UTF-8 with hash | R1 | 5 | 1 | CLI implemented; MCP pending |
| P0 | file_patch_scoped | Atomic patch with expected hash | R2 | 5 | 3 | new |
| P0 | project_onboard | README + architecture + active specs + task checkpoints | R1 | 5 | 2 | new |
| P0 | project_test_run | Discover and execute bounded tests | R2 | 5 | 3 | new; existing run_tests |
| P0 | git_repo_map | Identify nested repo boundaries | R0 | 5 | 2 | new |
| P0 | git_scoped_diff | Safe review for one repo/worktree | R1 | 5 | 2 | new; existing git_diff |
| P0 | job_start_template | Approved lint/build/test command templates | R2 | 5 | 3 | new; existing run_command |
| P0 | job_cancel_owned | Cancel only jobs created by this broker | R2 | 5 | 2 | new; existing cancel_job |
| P0 | docker_compose_inspect | Ports, mounts, secrets, daemon access and network risks | R1 | 5 | 3 | new |
| P0 | docker_service_logs | Bounded logs for a Compose service | R1 | 5 | 1 | CLI implemented; MCP pending |
| P0 | docker_stats | Resource metrics for containers | R0 | 4 | 1 | CLI implemented; MCP pending |
| P0 | postgres_status | Ready check, auth status separated | R0 | 4 | 1 | CLI implemented; MCP pending |
| P0 | postgres_schema | Schema, indexes, table counts | R1 | 5 | 2 | CLI implemented; DB auth E2E pending |
| P0 | postgres_query_ro | Non-superuser bounded SELECT | R1 | 5 | 4 | CLI prototype; DB privilege E2E pending |
| P0 | http_healthcheck | Local API readiness | R0 | 4 | 1 | CLI implemented; MCP pending |
| P0 | port_owner | Listening PID and collision explanation | R0 | 4 | 1 | CLI implemented; MCP pending |
| P0 | diagnostics_parse | Normalized lint/compile/test errors with source line | R1 | 5 | 3 | new |
| P1 | git_worktree_create | Isolate agent edits from user changes | R2 | 5 | 3 | new |
| P1 | git_review_gate | Diff + tests + secret scan before approval | R1 | 5 | 3 | new |
| P1 | service_stack_up_approved | Compose + PostgreSQL + API readiness | R2 | 5 | 4 | CLI preview; approval broker missing |
| P1 | docker_compose_stop_approved | Stop selected service without volume deletion | R2 | 4 | 3 | CLI preview; approval broker missing |
| P1 | db_migration_plan | Inspect pending migrations without writes | R1 | 4 | 3 | new |
| P1 | db_migration_apply_approved | Run reviewed migration with backup verification | R2 | 4 | 5 | new |
| P1 | project_snapshot | Record owned file changes for restore | R2 | 5 | 3 | new |
| P1 | rollback_preview | Dry-run targeted file/service rollback | R1 | 5 | 3 | new |
| P1 | coverage_report | Coverage and changed-line quality summary | R1 | 4 | 2 | new |
| P1 | dependency_audit | Vulnerability/license metadata with sources | R1 | 4 | 3 | new |
| P1 | agent_task_acquire | Leases/fencing/idempotent job ownership | R2 | 5 | 4 | harness adjacent; not integrated |
| P1 | agent_checkpoint | Durable milestone + evidence reference | R2 | 5 | 3 | harness adjacent; not integrated |
| P1 | workspace_watch | Debounced edits scoped to project | R1 | 4 | 3 | new |
| P1 | hardware_metrics | CPU/RAM/GPU/disk health, no serials | R0 | 4 | 2 | new |
| P1 | windows_service_status | Read Windows services (scoped) | R0 | 4 | 2 | new |
| P2 | ide_workspace_diagnostics | IntelliJ/VS Code supported diagnostics only | R1 | 4 | 4 | new |
| P2 | ide_run_configuration | Bounded launch/test of named IDE config | R2 | 4 | 4 | new |
| P2 | local_notification | Opt-in completed task alert | R1 | 3 | 2 | new |
| P2 | windows_scheduled_task_preview | Inspect task definitions and upcoming runs | R1 | 3 | 3 | new |
| P2 | window_capture_approved | Selected window screenshot with visible consent | R2 | 3 | 5 | new |
| P2 | clipboard_read_approved | One-time clipboard read with opt-in consent | R2 | 2 | 4 | new |
| P2 | postgres_backup_approved | Encrypted dump + retention + restore probe | R3 | 4 | 5 | new |
| P2 | local_audit_dashboard | Viewer for approvals/jobs/metrics/errors | R1 | 4 | 4 | new |
| P2 | secrets_reference | Named credential handles without returning values | R2 | 5 | 5 | new |
| P0 | spec_preview | Preview OpenSpec + SDD file plan, stable hash | R1 | 5 | 2 | CLI implemented; MCP adapter ready |
| P0 | spec_request_prepare/status/execute | Queued, locally approved creation; OpenSpec strict verification | R2 | 5 | 3 | CLI + separate stdio MCP tested; host policy integration pending |
| P0 | spec_validate | Real OpenSpec strict check and generated SDD crosswalk | R1 | 5 | 2 | CLI implemented; MCP adapter ready |
| P0 | spec_status | List local OpenSpec changes and SDD features | R0 | 4 | 1 | CLI implemented; MCP adapter ready |
| P0 | media_asset_inventory | Project-scoped video/audio/subtitle inventory | R1 | 5 | 2 | new |
| P0 | media_probe_ffprobe | Duration, frame rate, codec, stream metadata | R1 | 5 | 2 | new |
| P0 | scene_manifest_read | Per-scene task, owner and checkpoints | R1 | 5 | 2 | new |
| P1 | media_preview_contact_sheet | Selected timestamp frames from footage | R2 | 5 | 3 | new |
| P1 | scene_checkpoint_write | Durable scene state and artifact fingerprints | R2 | 5 | 3 | new |
| P1 | render_plan | FFmpeg command preview and budget validation | R1 | 5 | 3 | new |
| P1 | render_job_approved | Tracked, isolated FFmpeg render job | R2 | 5 | 4 | new |
| P1 | media_quality_check | Validate duration, resolution, audio and integrity | R1 | 5 | 3 | new |
| P1 | mcp_endpoint_health | List local MCP server schemas and readiness | R1 | 5 | 3 | new |
| P1 | redis_inspect | Ready/keyspace metadata, no values | R1 | 4 | 3 | new |
| P1 | kafka_inspect | Topics, partitions, consumer lag with minimum grants | R1 | 4 | 4 | new |
| P1 | local_model_health | Ollama/llama.cpp local models and memory | R1 | 4 | 3 | new |
| P1 | wsl_status | Installed WSL distros and state | R0 | 4 | 2 | new |
| P2 | browser_smoke_local | Isolated headless localhost E2E with blocked redirects | R2 | 4 | 4 | new |
| P1 | service_topology | Map declared local service dependencies | R1 | 4 | 3 | new |

## Top 10 to implement *next* (not the easiest to demo)

1. **Central server policy broker** — required before enabling any new mutating tool; fixes direct shell bypass risk.
2. **`workspace_discover` / `project_onboard`** — a fresh agent can load exactly one project, specs and checkpoints.
3. **`code_search`** — high-leverage code navigation with bounded context.
4. **`file_patch_scoped`** — safe SHA precondition and conflict detection.
5. **`git_repo_map` + `git_worktree_create`** — protects existing dirty work in the crowded top-level `IdeaProjects`.
6. **`diagnostics_parse` + `project_test_run`** — makes fixes measurable rather than speculative.
7. **`docker_compose_inspect`** — prevents dangerous mounts or leaked ports before service operations.
8. **`postgres_schema`** with dedicated least-privileged role — useful for actual backend engineering; current SQL access is unverified.
9. **`project_snapshot` + `rollback_preview`** — controlled reversible agent edits.
10. **`agent_checkpoint` + reviewer gates** — durable multi-agent progress without duplicated or unapproved writes.

## Why some attractive tools rank lower

- Screenshots/clipboard: privacy-heavy, often unnecessary for backend tasks; require foreground consent.
- Full Docker shell and root PostgreSQL: disproportionately risky on an unrestricted host. Do **not** expose in default MCP tool list.
- Windows registry/service management: powerful system administration with weak connection to routine feature work.
- Native shell templating: less safe than typed parameters; keep arbitrary execution behind an operator-only boundary.

## Example user journeys

**A. Fix a service**: discover project -> open docs -> code search -> branch/worktree -> patch preview -> approval -> test run -> start selected Compose service -> healthcheck -> collect logs -> reviewer gate.

**B. Debug PostgreSQL**: readiness -> authenticated role check -> schema/index inventory -> bounded query -> explain evidence -> migration plan -> approval and backup checks -> apply migration -> service healthcheck.

**C. Resume a 6-scene project**: onboard project -> load per-scene task IDs and checkpoints -> acquire isolated scene lease -> execute permitted tools -> persist artifact/checks -> send reviewer evidence -> hand off.

## Release criteria

- All R2/R3 operations require a server-verified approval, not a CLI flag alone.
- Source-of-truth requirements + acceptance tests + reviewer decision.
- No unscoped writes/reads of unrelated OS paths, no hidden desktop activity.
- Explicit statuses: **implemented**, **stub/mock tested**, **E2E verified**, **registered in MCP** are four different things.
