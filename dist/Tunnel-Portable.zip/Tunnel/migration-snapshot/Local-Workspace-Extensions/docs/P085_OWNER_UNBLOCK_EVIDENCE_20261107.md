# P085 — устранение программных блокеров и проверенный Windows handoff

Дата аудита: 07.11.2026. Workspace: `projects/Local-Workspace-Extensions`.
**Статус: SOURCE FIXES TESTED; OS-TRUST BLOCKER STILL OPEN.** Ни один внешний механизм approval не подтверждает Windows UAC, SID, service grant или установку. Не выдавать релиз или auto-merge за готовый.

## Что реально исправлено

1. `p085_cross_principal_probe.py` раньше проверял `<install>/p085_private/{review-key.bin,qa-verify-key.bin}`, хотя `Install-P085ProtectedService.ps1` устанавливает layout `<install>/code` + `<install>/private_state`, и `owner_cutover_gate.service_private_root` использует `private_state` для staged `code`. Теперь probe использует **только** `<install>/private_state` и отвергает symlink/junction на корневом или приватном каталоге. Не возвращаться к legacy-path по fallback.
2. Обнаружено и воспроизведено отрицательным тестом, что единственный worker SID с denied-write и denied-read мог получить `untrusted_worker_ready_for_cutover=true`, хотя отдельные reviewer/service/QA SID, реальное существование ключей и owner approval не подтверждены. Теперь `worker_negative_access_witness` описывает лишь узкую проверку прав конкретного worker-токена, а `untrusted_worker_ready_for_cutover=false` остаётся до независимого trust gate. CLI rc=0 при подтверждённом одиночном negative witness **не означает готовность системы**.
3. Обновлены тесты `test_p085_cross_principal_probe.py`: отрицательный сценарий на legacy-path и несовпадение install layout, symlink path, смоделированный all-denied worker без двухстороннего trust attestation. До фикса последний тест ожидаемо FAIL (job `a130d63fd9944f38bbc36af901ed7e29`, rc=1), после фикса целевые 31 тест rc=0 (job `50e9c3f756d745a78adf0d1c8e2a5207`, 1 skip на Windows symlink privilege).
4. Никакие live permissions, OS accounts, credential store, signing keys, SQLite, lease, Git, работающие MCP/tunnel и OpenSpec accept не изменены.

## Непосредственные измерения среды

| Источник | Результат |
|---|---|
| `p085_accounts_readonly_check.py` | 0/5 локальных Windows-принципалов, отсутствуют все 5; rc=0 (job `429499d9257f44648b365fdb2fe6c014`) |
| `p085_elevation_probe.py` | Windows session ID 2, `is_elevated_administrator=false`; rc=0 (job `e96cf77652b2492e934bb0527b01e3bc`) |
| `p085_windows_deploy_preflight.py` | `stage_health=NOT_STAGED`, `service_installed=false`, `safe_to_activate=false`, source modules присутствуют; rc=0 (job `9c448434ac084185bc3ff87c5b15b8c8`) |
| `p085_release_handoff_check.py` | Кандидат из 25 файлов целый, source SHA совпадает, `release_authorized=false`; rc=0 (job `dbbf22e2085a4439b886b7e7692f2da1`) |
| `p085_windows_isolation_probe.py` | Windows **разрешает запись** в четыре защищаемые цели: SQLite, `.agent-team`, `agent_team.py`, проект; rc=3 expected RED witness (job `ea91a963c8344db5b6ee2fd9fb98f303`) |
| `p085_autonomous_guard.py --write-report` | 7/7 тестовых suites PASS, `verified_host_identity=false`, 28 live MCP tools, broker не установлен; rc=0 (job `29711b4bb9ea478ab9e4824942a57390`) |

## Граница полномочий и точный порядок unblock

**Невозможно снять P085 посредством роли в промпте, ChatGPT approval или скрипта, запущенного через тот же MCP с write/execute на всё IdeaProjects.** Доверенная OS-авторизация требует независимого foreground Windows владельца и настоящей разделённой учётной записи. Этот этап ещё не был выполнен; ниже только operator workflow.

1. На ПК **самостоятельно**, вне MCP/ChatGPT, открыть Windows Terminal/PowerShell от администратора через UAC. Независимо проверить доверенный, неизменяемый экземпляр bootstrap-скриптов и исходников. Нельзя исполнять elevated напрямую из агентом изменяемого `IdeaProjects` — сначала независимо review/pin и поместить экземпляр под администраторский ACL вне проектов.
2. В доверенной копии получить сухой план `Setup-P085WindowsPrincipals.ps1` (без `-Apply`). Проверить пять уникальных non-admin пользователей `p085svc,p085review,p085worker,p085qasup,p085qachild`. Затем **только в настоящем интерактивном повышенном терминале** запустить `Setup-P085WindowsPrincipals.ps1 -Apply`. Он запрашивает пароли через SecureString, создаёт отсутствующих пользователей **disabled** и не затрагивает работающий MCP. Не передавать пароли в ChatGPT, скриптовые аргументы или файлы проекта.
3. В доверенной копии запустить dry-run `Install-P085ProtectedService.ps1 -ServiceAccount '.\p085svc' -ReviewerAccount '.\p085review' -WorkerAccount '.\p085worker'`. Независимо проверить список исходников, SHA, путь под `ProgramData` и `plan_sha256`. `-Apply -ExpectedPlanSha256 <trusted-plan>` допустим лишь как отдельное foreground owner-confirmed **стейджирование кодовой копии**. Несмотря на имя, скрипт НЕ создаёт Windows Service, ключи или QA issuer. Не принимать `STAGED` за `READY`.
4. Отдельно владелец устанавливает проверенный OS-protected Python runtime и broker process под service SID, защищает code immutable + `private_state` и ключи, доверенно настраивает QA signer/runner под отдельным SID, worker и reviewer-сессии. Вывод `sys.executable` из текущего MCP пользователя для брокера **не подходит**: `BROKER_PYTHON_RUNTIME_UNTRUSTED`.
5. Перед cutover пройти **реальные** отрицательные Windows E2E под разными SID: worker не может писать canonical, SQLite, директорию очередей; не может читать protected keys или подключиться к reviewer pipe; reviewer может открыть только назначенный pipe; QA child не читает signing key; сервис по фактическому токену совпадает с service SID; nonce/replay/expired grant rejected. Документ `docs/P085_PROTECTED_BROKER_ROLLOUT_2026-11-02.md`. Один `p085_cross_principal_probe.py` подтверждает лишь часть worker negative E2E, не релизную готовность.
6. Переход на узкий agent MCP без `run_command`, `run_script` и широкого direct-write в защищённую область; после независимых acceptance/recovery тестов — owner-controlled cutover с rollback. **Не отключать текущий tunnel или агентские задачи заранее**. Только доверенный Windows issuer может подтвердить review grant.

### Достоверные SHA перед самостоятельным созданием доверенной копии

```text
Setup-P085WindowsPrincipals.ps1    9e84499bfffbfc64263c9841983613400187e008fdb417953111e91469017b56
Install-P085ProtectedService.ps1 b2bdac792998f4e083f9d1e6f262e2a18b96f53c2662a160c106dd8a4322e709
Open-P085AdminTerminal.ps1       d606b299a2927f467cec180c3b97575f3ad2c77954d3804353ba7aca7fdfa67b
```
Хеш подтверждает идентичность байтов с наблюдавшимся источником, **не криптографическое доверие к агенту или оригинальности источника**.

### Команды последующей проверки (обычные, без UAC; read-only)

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python p085_accounts_readonly_check.py
python p085_elevation_probe.py
python p085_windows_deploy_preflight.py
python p085_release_handoff_check.py
python p085_windows_isolation_probe.py
python -m unittest -q test_p085_cross_principal_probe test_p085_installer_source test_p085_windows_deploy_preflight
```
`p085_windows_isolation_probe.py` при отсутствии запрета записи ожидаемо вернёт **rc=3**, что является подтверждённым блокером, а не поломкой диагностики.

## Обновление 7 ноября — Windows имени и SHA

Из-за обнаруженной несовместимости с Windows `New-LocalUser` максимальная длина локального имени теперь **20 символов**, а не 24. В `Setup-P085WindowsPrincipals.ps1` также однозначно запрещены одинаковые имена с различным регистром. `p085_accounts_readonly_check.py` имеет согласованное ограничение. Обновлены SHA-пины в Web Companion `p085_readiness_matrix.py`. После обновления реальный read-only результат `status=UNTRUSTED`, `ok=true`, а не `SOURCE_DEPENDENCY_SHA_DRIFT`.

Текущие SHA: `Setup-P085WindowsPrincipals.ps1 = 9e84499bfffbfc64263c9841983613400187e008fdb417953111e91469017b56`; `p085_accounts_readonly_check.py = 50af23dc7caf740a80ddef50971f8968abe373944f4c1f449801e9c3ffcbfb73`; `p085_readiness_matrix.py = 23b66dae966beb5487b529636ef021c7207c7140860e65c4f083110909cfba79`.

Ни одна из этих source-правок не означает, что повышенные права/отдельные OS учётные записи/Windows broker выданы. `accounts_missing=5` по реальному запуску диагностического инвентаря.

## Финальный checkpoint — 07.11.2026 13:32 UTC

После source/CLI/QA правок полная `python -m unittest discover -q` основного проекта прошла в job `9d989f4ce90346d88942a37efea88767`: **2646 tests, 2600 PASS, 46 SKIP, rc=0**. Полный `mcp-host-source` после добавления нативного `CancelIoEx` smoke: job `ebcec7ee703840bd824ec389b854f42b`: **270 tests, 264 PASS, 6 SKIP, rc=0**.

Автономный аудит P085 после последних source-изменений: job `8d4e8865e66944ad8b3b3de21c1d5bdc`, **7/7 suites PASS**, `source_stable=true`, `verified_host_identity=false`, `p085_release_ready=false`, `auto_merge_authorized=false`. Отчёт `.agent-team/reports/P085_auto_20261107T133133Z_93f589a7993e.json`. `release_candidate_id=0d528de9acac5baa5bad890e9c896ae01a61bd5d0b03f01adf78483d7866a919`, candidate source intact (created=false); `release_approved=false`. Никакой elevated Windows SCM/ACL/account/grant/install не произведён.

**Следующий допустимый шаг:** отдельное owner-controlled UAC развёртывание настоящей защищённой SCM-службы после независимого review/pin исходника, проверка пяти локальных non-admin аккаунтов, protected Python/runtime и ACL, затем реальный two-SID/QA issuer E2E и сокращение широкого MCP surface. Пока реальная Windows-служба отсутствует (SCM=ABSENT), stage NOT_STAGED и 5 аккаунтов отсутствуют, P085 остаётся в OPEN. `p085_release_handoff_check.py --candidate-id SHA` умеет наблюдать новый кандидат, но не меняет pinned default и не выдаёт owner authorization.

## 07.11.2026 13:30 UTC — Native CancelIoEx, current candidate handoff и Web Companion

**Дополнительная нативная отрицательная проверка:** `mcp-host-source/tests/test_p085_real_overlapped_smoke.py` теперь включает `test_real_pending_accept_is_cancelled_on_stop` в ограниченном отдельном `python -E -s` процессе. На реальном Windows named pipe с `FILE_FLAG_OVERLAPPED` ожидание без клиента было начато; по STOP действительный `CancelIoEx` успешно прервал его, не отождествляя это с успешной заявкой. Job `6ca1dedf8ed346c7a8cbdc98775b09d0`, rc=0. Если бы незавершённая операция не закрылась, тестовый child прекратился бы с fail-closed кодом 124, не повреждая настоящий агентский host. Это **только one-SID OS smoke**, не подтверждает separate reviewer/worker SID.

**Текущая регрессия:** `mcp-host-source` job `ebcec7ee703840bd824ec389b854f42b` — **270 tests, 264 PASS, 6 SKIP, rc=0**. `Local-Workspace-Extensions` job `d27629b6cdd94152ae37258d42c22c84` — **2644 tests, 2598 PASS, 46 SKIP, rc=0**, запущен до двух финальных pure-Python CLI-тестов. Web Companion источниковый контроль `p085_readiness_matrix.py` был `UNKNOWN/SOURCE_DEPENDENCY_SHA_DRIFT` из-за обновлённого `p085_stage_audit.py` (job `0ff0999950444645a86d777f51d61e6a`); проверено и точечно перепинено на SHA `ca15b68bdfbd92c4278d9cc21b9fd3ce433c6516e8694a5930b243734371c081`. Job `c3dbee12f9f346eeac18d3d307c694f1` — 25 PASS; реальный job `03ba9f5602fa430c96bffd2b5a9009bf`: `ok=true,status=UNTRUSTED,accounts_missing=5,can_activate_chain3=false`.

**Content-addressed handoff:** после финального изменения canonical overlapped-модуля `p085_broker_release_candidate.py` вернул SHA кандидат `0d528de9acac5baa5bad890e9c896ae01a61bd5d0b03f01adf78483d7866a919`, 25 файлов, `release_approved=false`; повторный build `d158f5220f2f4041ab3ae02aec9101b1` — idempotent, `created=false`. Добавлен **только read-only** `p085_release_handoff_check.py --candidate-id SHA` для явной проверки нового пакета, не меняя исторически pinned default ID. Два теста CLI расширили `test_p085_release_handoff_check.py`: job `311b041903be4d70a3c2fea009c2d78f`, **10 PASS**. Реальный handoff job `49b4639dc924440a9eb5ccfd1f15cf74`: `manifest_matches_requested_id=true,candidate_matches_current_source=true,release_authorized=false`; оставшиеся блокеры — OS-учётные записи, SCM, ACL, Python runtime, real two-SID E2E. Ни source bundle, ни совпадение SHA не являются разрешением владельца.

**Актуальные SHA перед независимой owner проверкой:**
- `experiments/foundation_kernel/win_pipe_overlapped.py` — `ea39eda014c0a53b4a9a7e3a852f755da702923d1330c08a1f0195f16c6c8425`.
- `mcp-host-source/workspace_mcp/review_pipe_server.py` — `6cbea2e69cfbf2dc3b04b5a928408f1819f0385148d61637935eb452d87a2b56`.
- `mcp-host-source/p085_reviewer_service.py` — `387c51ce98132dcc7c82bc046942cafbbec819d96b256344ba2ba63c91b193b9`.
- `Install-P085ProtectedService.ps1` — `67948120549f74a9ef57dda648a1103915254e73bd38d5445f22d0b2965bb23e`.
- `p085_stage_audit.py` — `ca15b68bdfbd92c4278d9cc21b9fd3ce433c6516e8694a5930b243734371c081`.
- `p085_release_handoff_check.py` — `946ed6f8f3bb63d93523b62144b6e3dac07eff10d8054cfdf6fcf2f7f860e866`.
- `mcp-host-source/tests/test_p085_real_overlapped_smoke.py` — `47fe9a7bf474261609c55e575eb96101b36f3fe2f382f2a6fd3d61f7b31d5af9`.
- `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py` — `7e5c24251ff36bc9ad00fe91fd7c9e33aa8c44408e2c209089e1bee78dc2fa4d`.

**Hard stop remains unchanged:** Windows SCM observed `ABSENT`, staged private runtime `NOT_STAGED`, `accounts_missing=5`, `verified_host_identity=false`, `p085_release_ready=false`, `auto_merge_authorized=false`. None of the changes ran UAC, assigned Windows service logon, installed or started SCM, granted ACLs, accessed credentials, merged code or changed the live coordinator queue.

## 07.11.2026 13:25 UTC — интеграция Win32 overlapped I/O, staging и реальная IPC QA

**Итог кодовой работы, не trust cutover:** защищённый `p085_reviewer_service.py --serve-service` теперь передаёт `transport="overlapped"` в неизменный бизнес-контур `serve_one`. Он обрабатывает только `reserve_with_independent_qa`, без `merge`. Защищённый pipe создаётся с `FILE_FLAG_FIRST_PIPE_INSTANCE|FILE_FLAG_OVERLAPPED`; `ConnectNamedPipe`, `ReadFile`, `WriteFile` используют существующий `experiments/foundation_kernel/win_pipe_overlapped.py` (не новую конкурирующую реализацию). STOP и тайм-аут до выдачи grant не вызывают broker, отсутствие клиента возвращает `LISTEN_TIMEOUT` и не считается release. После записи durable reservation отправка ответа остаётся best-effort с ограниченным ожиданием, ACK может остаться неподтверждённым. Прежний `transport="legacy"` сохранён отдельно для обратной совместимости.

**Защита WinAPI:** до начала операции теперь валидируются timeout и STOP callback; ранее некорректный timeout мог привести к размонтированию OVERLAPPED/buffer при незавершённом WinAPI запросе. Pending операции отменяются `CancelIoEx` и ожиданием их завершения. У `read(...,exact_length=True)` нет лишнего байта чтения из следующей части length-prefixed фрейма. JSON-frame validation, запрет duplicate keys/NaN, SID, QA, ownership и signed grant остаются в прежнем строгом `review_pipe_server` и `ReviewGrantBroker`. При невозможности подтвердить завершение отменённой I/O текущий специализированный модуль прекращает child broker process fail-closed. Документация Microsoft: https://learn.microsoft.com/en-us/windows/win32/fileio/cancelioex-func .

**Установщик:** `Install-P085ProtectedService.ps1` больше не оставляет overlapped module за пределами пакета: отдельная pinned запись `code/workspace_mcp/win_pipe_overlapped.py` берёт точные bytes из canonical `experiments/foundation_kernel/win_pipe_overlapped.py` с SHA-256 в owner-reviewed stage plan и `STAGE_RECEIPT.json`. `p085_stage_audit.EXPECTED_FILES` требует именно этот файл, проверяет SHA и ACL; негативный тест доказывает fail-closed при подмене. Staged-`code/private_state` smoke проверил импорт под `python -E -s`. Это **только исходники**. Никакие Windows ACL, учётные записи, Windows-служба, главный MCP и его 28-инструментальная API-поверхность не изменены.

**Тесты и доказательства:**
- Новый `experiments/foundation_kernel/test_win_pipe_overlapped_stop_20261107.py`, 7 negative cases, PASS; первоначальные RED `1471fdb8e5154bed8ea18f8e597eab80` и `173b8bafc9a64fd88df44450ae5a9aee` воспроизвели дефекты.
- Защищённый wire-format `mcp-host-source/tests/test_review_pipe_server.py` — добавлены overlapped mode flag, fail-closed missing pinned module, idle timeout, STOP, exact byte-frame и successful reserve (с mock business outcome).
- Реальный Win32 E2E `mcp-host-source/tests/test_p085_real_overlapped_smoke.py` — отдельный ограниченный по времени subprocess; случайный disposable local named pipe; клиент передал length-prefix+JSON в одном write; сервер обработал через существующий P085 framed API + реальный `FILE_FLAG_OVERLAPPED`, ответил и подтвердил ACK. Job `8a3cb225ba0a4a17943813b7b5ff1e7f`, PASS. **Same-user I/O smoke**, не доказательство разных Windows SID и не production pipe.
- Stage/ACL QA `d95756ee0e1241d99574970af801905a`: 45 tests, 43 PASS/2 SKIP; high-level P085 protected pipe tests `fb5ece2bc7da412782bc692c34636ca5`: 48 PASS; real legacy Win32 IPC test `bd70c330a03e42a5b3ec55a1acd3dfb2`: 19 PASS.
- Полный host-suite до последнего документационного редактирования `91115e62b80f470f9eac429c99d97ae1`: 268 tests, 262 PASS, 6 SKIP, rc0; main-suite `418120f8e45a45abb425c57aa4e82ff7`: 2644 tests, 2598 PASS, 46 SKIP, rc0.
- `p085_autonomous_guard.py --write-report` `34837470167541829a26449a36bb3dc1`: 7/7 PASS, `verified_host_identity=false`, `p085_release_ready=false`, 28 privileged tools, SCM P085 service absent, stage NOT_STAGED; report `.agent-team/reports/P085_auto_20261107T132153Z_8412982710d6.json`.

**Release source integrity:** старый pinned candidate `8dba537314f9520cad3d299aaede2e173b3f0742dc742b723cddd379958b5940` теперь закономерно имеет `CURRENT_BROKER_SOURCE_DRIFT` (read-only job `1b0e311524e54e66851471fc8b946aab`). Новый небезопасный-для-доверенного-release source-only candidate формируется из 25 файлов и **не является approval**; `p085_release_handoff_check.CANDIDATE_ID` намеренно не изменён автоматически. После окончательного source SHA требуется независимый owner-review, а не silent re-pin.

**Remaining P085:** реальная регистрация Windows-службы под независимым service SID; защищённая копия Python и кода в ProgramData с ACL; отдельные worker/reviewer/QA/issuer роли; negative real two-SID E2E; узкий MCP без глобального `run_script` bypass; owner foreground approval. До этого `auto_merge_authorized=false`, `release_authorized=false`.

## Дополнительная доставка / Stop / durable reservation — 07.11.2026 13:03 UTC

Дополнен независимый сценарий `mcp-host-source/tests/test_review_pipe_finalizer_e2e.py`, тест `test_stop_during_response_ack_keeps_reservation_without_false_delivery`. Использованы настоящие disposable SQLite/ledger/grant/QA signatures, подмена только системного pipe-транспорта. Stop после отправки результата, но до client ACK: `result.state=RESERVED_REQUIRES_PRIVILEGED_QA`, `delivery_acknowledged=false`, одно отправленное сообщение, `reviewing` без merge. Ни повторной резервации, ни ложного подтверждения доставки. Исходный файл SHA `179bf8cee404e4c18cc3d37771c84d413e60062d4c937d644ccccb022d0b498b`.

Результат `python -m unittest discover -s tests -p test_review_pipe*.py -q`, job `78a3b2d56a2e41df9461712e6a1b53b4`: **43 PASS**, rc=0. Полный host `b52a66ebcffd4fa4a1a325e8575f25e5`: **263 tests, 257 PASS, 6 SKIP, rc=0**. Полный core main `99803771a7ad4b79a7036586511af526` после изменения production source: **2642 tests, 2596 PASS, 46 SKIP, rc=0**. Финальный p085 guard `e89870abbff447888502a9a03feef748`: **7/7 suites PASS, rc=0**, `p085_release_ready=false`, `verified_host_identity=false`. Отчёт `.agent-team/reports/P085_auto_20261107T130248Z_dca9164c281e.json`.

**Состояние владельца не изменилось:** нет установленной P085 Windows-службы, пяти Windows actors, полноценного защищённого overlapped transport, independently pinned runtime и 2-SID/QA E2E. Никаких ACL/UAC/сертификатов/аккаунтов/live-SQLite или reviewer approvals не изменено; новые PASS являются software/offline/same-user OS-tests, а не авторизацией.

## 07.11.2026 ~12:59 UTC — отрицательные проверки Stop и JSON на доверенной границе

**Новые дефекты, исправленные в `mcp-host-source/workspace_mcp/review_pipe_server.py`:**

1. После установления соединения `serve_one(..., stop_requested=...)` продолжал читать неполный фрейм до тайм-аута, несмотря на Stop. Реальный service STOP мог приходить **между** чтением и `broker.reserve_with_independent_qa`, но до этого не проверялся. `_read_exact` и `_read_message` теперь получают необязательный callback и завершаются с `PIPE_STOP_REQUESTED`. `serve_one` возвращает `{ok:false,status:STOP_REQUESTED,grant_processed:false}` и не пишет ответ, не резервирует grant. Stop во время ACK возвращает `delivery_acknowledged=false` без ложного подтверждения ответа. Важное ограничение: текущий `PIPE_NOWAIT` всё ещё должен быть заменён на полноценный overlapped I/O для production, callback не заменяет OS-level CancelIoEx.
2. `json.loads` раньше принимал **повторяющиеся JSON-ключи** в том числе вложенные, а также нестандартные `NaN`, `Infinity`, `-Infinity` и overflow чисел `1e10000`. Новый строгий parser отказывается от них до проверки подписанного запроса. Операция чтения payload вынесена из `try: json.loads`, чтобы остановка в середине JSON не выдавалась за `INVALID_JSON_FRAME`. `_read_message` по-прежнему ограничен `MAX_FRAME=8192`.
3. Дополнены `mcp-host-source/tests/test_review_pipe_server.py`: Stop на неполном заголовке/содержимом, Stop между полноценным read и broker, Stop на ACK, malformed/ambiguous JSON. Имеются существующие успешные локальные same-user Windows named-pipe connect/cancel smoke tests, но **нет** независимых двух-SID тестов.

**Проверенная регрессия после изменения:**
- Отрицательный RED для неоднозначного JSON `d79d76da58f1432eb1e0129722f58641`: 6 ожидаемых падений, rc=1; после исправления `2633c9ea9d204ac282becb5195c36398` — 21 тест, rc=0; после усиления тестов `769018148d9349299ca6b27feb90d291` — **23 теста PASS**, rc=0.
- `mcp-host-source/tests` полная регрессия `192e65569f05428783a59cc01071f37d` — **262 tests, 256 PASS, 6 SKIP, rc=0**.
- `Local-Workspace-Extensions` полная регрессия `99803771a7ad4b79a7036586511af526` — **2642 tests, 2596 PASS, 46 SKIP, rc=0**.
- `p085_autonomous_guard.py --write-report`, job `71b792fe6ebc4e759e494fb72a404dd9`: **7/7 suites PASS**, `source_stable=true`, `verified_host_identity=false`, `p085_release_ready=false`; отчёт `.agent-team/reports/P085_auto_20261107T125927Z_eab01117c309.json`.
- `p085_windows_deploy_preflight.py`, job `ee955ddcd48a479284432adfbfcc7a32`: `SCM=ABSENT`, `stage=NOT_STAGED`, `safe_to_activate=false`.

**Source SHA-256:** `review_pipe_server.py = 61910f75e2210a2a05cdaf82e1dc4d969d11bc3f2841e29b64c12ca2a8b1c79d`; `test_review_pipe_server.py = f8b6de1272ffa995337195a0fb72d1c7786324eb41b3ba4741123937e384df02`.

**Непреодолённые P085 блокеры:** 0/5 Windows actor identities, реальная защищённая установка/служба отсутствует, current MCP имеет 28 потенциально привилегированных инструментов и записи в live project, нет отдельно выданной QA подписывающей роли, protected credentials, two-SID негативного E2E, owner-approved cutover. `auto_merge_authorized=false`. *Не запускать тестовый или SCM entrypoint с elevated привилегиями в IdeaProjects.*

## 07.11.2026 12:22 UTC — SCM-reservation runtime (исходники, НЕ деплой)

Проверен настоящий источник `mcp-host-source/p085_reviewer_service.py`: добавлен `--serve-service` для `StartServiceCtrlDispatcherW`, `RegisterServiceCtrlHandlerExW`, `SetServiceStatus`, управления `START_PENDING → RUNNING → STOP_PENDING → STOPPED`. Вызов из обычного процесса **не** обходит SCM и не вызывает worker. Защищённый worker строго требует `load_configuration`, service-SID и `require_owner_cutover` ДО `RUNNING` и ДО создания pipe. Обслуживает последовательные **reservation-only** запросы с `trusted_finalizer=None`, не делает `review accept`, `merge`, выдачу сертификата/ключа или файловые операции от имени клиента. Никаких изменений в live tunnel/MCP/OS/service registration нет.

В `workspace_mcp/review_pipe_server.py` реализована отмена ожидания клиента по флагу STOP и исправлена ошибочная трактовка Win32: в `PIPE_NOWAIT` первый успешный `ConnectNamedPipe` означает только начало прослушивания; реальный peer подтверждается `ERROR_PIPE_CONNECTED`. `ERROR_NO_DATA` должен выдавать закрытый отказ, не считаться клиентом. Исходные non-cancellable `--serve-one` и QA/signature/replay gates сохранены.

**Реальные Windows-тесты (только для транспорта):** одноразовый случайный локальный named pipe без клиента прекращает ожидание, а другой случайный local pipe подтверждает открытие клиентом. Оба без production pipe name, service SID, ключей и grant. Это **same-user Windows IPC smoke**, **не** проверка разных Windows-аккаунтов и не разрешение на cutover. По Microsoft `PIPE_NOWAIT` предназначен для совместимости; промышленная версия потребует `FILE_FLAG_OVERLAPPED` с надлежащей отменой I/O, отдельной проверки read/write deadlines, защищённого worker/service E2E: https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-connectnamedpipe .

Код/тесты после финальной проверки:
- `mcp-host-source/p085_reviewer_service.py`: SHA256 `2b25ceffc86e2f104a1d6fb39f59d473fa66fbb2de6ae1207875a85ae630fd46`.
- `mcp-host-source/workspace_mcp/review_pipe_server.py`: SHA256 `ccc4ff17b41c47ce39ff6927fc3c06961b0d48895de840836b808b9546b20fe4`.
- `mcp-host-source/tests/test_p085_reviewer_service.py`: SHA256 `e7703772b7636d5388849ec55031be02087a3d45652f7f68bbffb0cedf826e10`.
- `mcp-host-source/tests/test_review_pipe_server.py`: SHA256 `24c5378edd93c3572fb7d42eb12ee0ab0c0f08a743a50a9a808fd672cf17b6df`.

Проверенные задания:
- Предварительный RED для неотменяемого transport / отсутствующего SCM API: `1f911a7d83a849d6b0e9a767349caeee`, rc=1; после фикса `434905b466cf417b850fd8b6561182cb`, 32 tests PASS, rc=0.
- Win32 initial-success mistaken for client + abandoned `NO_DATA`: RED `b592cd30391a4944a65b509033c68c5b`, rc=1; fix `d30eb28f7e6f4f04b076393396103881`, 37 tests, 1 SKIP, rc=0.
- SCM stopped-without-ready negative witness RED `eccdb09a797043fdb357042741e57ffc`, rc=1; fix `f21b7ab30dd74d1b9fc9f26d72c0402a`, 39 tests, 1 SKIP, rc=0.
- Настоящий одноразовый Windows named-pipe без клиента: `61df14a7a20644e88024f8d2602b97e4`, rc=0; peer connected `83dcd59e3b9743548187489b94aa6a62`, rc=0.
- Полная `mcp-host-source/tests` регрессия `9aa8c62f4b874f3381b68d5d7c0a28db`: **257 tests, 251 PASS, 6 SKIP, rc=0**. Главная `Local-Workspace-Extensions` `cbd65a1a5db04574b8c8fad3830ad4c5`: **2642 tests, 2596 PASS, 46 SKIP, rc=0**.
- `p085_autonomous_guard.py --write-report`, `f02c79ccfb654918b0bfd779b936f62f`: **7/7 suites PASS**, 28 live MCP tools, `verified_host_identity=false`, `p085_release_ready=false`; report `.agent-team/reports/P085_auto_20261107T122201Z_58dd7b00c7fe.json`.
- Read-only Windows preflight `954aad43194f4f139218c3ba6e740636`: `service_control_manager_observation.state=ABSENT`, `stage_health.status=NOT_STAGED`, `safe_to_activate=false`.

**Контроль после обновления source-docstring и staging-import closure:** `python -m unittest -q test_p085_installer_source test_p085_cross_principal_probe test_p085_windows_deploy_preflight`, job `3a0fba649a6340e0a84548e4143a0938`: **35 tests, 34 PASS/1 SKIP, rc=0**; полный host suite `b49bb44c761849df982a180f0b8008fb`: **257 tests, 251 PASS/6 SKIP, rc=0**. Проверен именно смонтированный `code/private_state` stage-import layout. Никакие повышенные/system действия не выполнялись.

**Остаётся ручная доверенная Windows-операция владельца:** 5 отдельных непривилегированных аккаунтов, проверенная защищённая копия кода и Python runtime, private_state/signing-keys с отдельными SID, регистрация `P085ProtectedReviewer` через настоящий SCM под service SID, реальное много-SID отрицательное E2E, узкая агентская MCP-поверхность и owner-authorized cutover. Текущий `Install-P085ProtectedService.ps1` по-прежнему создаёт только stage: не регистрирует службу. Не запускать `--serve-service` напрямую из `IdeaProjects` и не считать новый исполняемый код настоящим OS-сервисом без независимой установки.

## Наблюдение реального Windows SCM — 07.11.2026 (09:44 UTC)

Улучшен существующий `p085_windows_deploy_preflight.py`: добавлена **только read-only** Win32-проверка Service Control Manager `OpenSCManagerW(SC_MANAGER_CONNECT)` → `OpenServiceW(SERVICE_QUERY_STATUS)` → `QueryServiceStatusEx(SC_STATUS_PROCESS_INFO)`. Постоянное `service_installed=false` заменено наблюдаемыми `service_installed`, `service_running`, `service_control_manager_observation`. Служба, состояние которой проверяется, должна называться `P085ProtectedReviewer` (имя **службы SCM**, а не каталог или display name). Никаких Start/Stop/CreateService или прав на изменение конфигурации нет. Документация Microsoft: https://learn.microsoft.com/en-us/windows/win32/api/winsvc/nf-winsvc-queryservicestatusex .

Реальный Windows SCM-вызов в агентском контуре вернул `state=ABSENT, registration_observed=false, running_observed=false`; защищённая служба **отсутствует**, отдельные Windows principals по-прежнему 0/5. Дополнительный тест действительно запросил системную службу `EventLog` (наблюдаемую) и синтетическое отсутствующее имя (не наблюдаемое), подтвердив корректность интерфейса WinAPI. `RUNNING` лишь признак записи службы в SCM и её текущего статуса, не удостоверяет исполняемый код, SID Windows-процесса, owner approval, QA issuer, A2A/Named Pipe peer auth или право на merge. `separate_broker_process_verified=false` и `safe_to_activate=false` сохраняются всегда; при недоступности SCM возвращается `UNKNOWN`, а не фиктивное отсутствие службы.

Код: `Local-Workspace-Extensions/p085_windows_deploy_preflight.py` SHA256 `e4fb0be958d88ba69301a5c34a6f5517117ca48958ab2ef3d9e7d4c5296d9b4c`, тест `test_p085_windows_deploy_preflight.py` SHA256 `e11376116fd165ef311702bfac0518120fda91cc67e8ef7780d235ce7730eff0`. Зависимая read-only матрица Web Companion перепинена на текущий preflight SHA, `p085_readiness_matrix.py` SHA256 `0609eee73f29eb072c3921046ad55c01349e32c6b6e9e24689debc8145dbca35`.

Начальное негативное воспроизведение до фикса: `742cb1db4e09456abc2a65594b488fa6`, 3 ошибочных теста из 16, ожидаемый RED; после фикса `4f1f72a994604f8eb4b25e13d7cce001`, **17 тестов PASS**, rc=0. Матрица Web Companion `3679221633bd487099eaa04c0363eb24`: 25 PASS; реальный output `c65c1305dd1642e1a89ede66949e05a0`: `ok=true, status=UNTRUSTED`. Отдельный отчёт handoff `bc47f54da8db4af3baddb854db8f90fd`: 25-file candidate valid, `release_authorized=false`.

**Финальный регрессионный контроль после всех изменений:** `python -m unittest discover -q` в `Local-Workspace-Extensions`, job `6a69d908ed8a4704adf8d7aef84378b0`, **2642 tests, 2596 PASS, 46 SKIP, rc=0**. Полный автономный `p085_autonomous_guard.py --write-report`, job `94f8fefc6dfa45939f488a2f8d867d38`, **7/7 suites PASS, rc=0**, `source_stable=true`, `verified_host_identity=false`, `p085_release_ready=false`. Отчёт `.agent-team/reports/P085_auto_20261107T094628Z_420d86e1f73b.json`. Отдельная Web Companion P085 матрица `c65c1305dd1642e1a89ede66949e05a0` после SHA-repin вернула `status=UNTRUSTED`, а не `SOURCE_DEPENDENCY_SHA_DRIFT`. Никакой owner elevation, Windows service start/create или privileged merge не производились.

**Оставшийся реальный блокер:** защищённый источник и Windows runtime не установлены, OS account/SCM service нет, реальные независимые worker/reviewer/QA SID и ACL E2E не проведены. Текущий `Install-P085ProtectedService.ps1` — **только staging**, а `p085_reviewer_service.py --serve-one` не является Windows Service registration/SCM dispatcher. Даже создание учётных записей и stage само по себе не запустит постоянный брокер. Для полного снятия нужны отдельно независимо проверенные owner-controlled service runner, signer/QA child и multi-SID E2E; запуск агентом UAC/подмена SID через текущий 28-tool MCP запрещены.

## Дополнительный проверенный результат — 07.11.2026 (00:36 UTC)

**Сделано в этом запуске:**
- Исправлен предел имени для `New-LocalUser`: Windows допускает максимум 20 символов; ранее P085 позволял 24 и мог оставить частично созданные disabled accounts. Новый guard одинаков в `Setup-P085WindowsPrincipals.ps1` и read-only `p085_accounts_readonly_check.py`.
- Добавлена явная проверка уникальности Windows account names в нижнем регистре при provisioning: `$_.ToLowerInvariant()`, независимо от особенностей `Select-Object -Unique`.
- Обновлены точные SHA для двух источников в `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py`. До обновления её подтверждённый итог был `UNKNOWN/SOURCE_DEPENDENCY_SHA_DRIFT`; после — `ok=true/status=UNTRUSTED` с реальными оставшимися Windows-blockers. Роль не была повышена.

**Доказательства тестов:**
- `test_p085_principals_source`, `test_p085_accounts_identity_contract_20261104`, `test_p085_accounts_output_hardening_20261104`: job `935f8812a490440db35ca6e20fab3387`, **23 tests, rc=0**.
- `chat-launch-smoke-desktop-test/web-companion/test_p085_readiness_matrix.py`: job `ed20eddb68744b55adc69554c0fe7741`, **25 tests, rc=0**.
- Полная регрессия `Local-Workspace-Extensions` после последних source изменений: job `25b3360f37a042479babbf57ccbe3e9f`, **2638 tests, 46 skipped, rc=0**.
- Фактическая read-only Windows-проверка: `d97cc2372f7d481ebb444eb793750005`, rc=0, `is_elevated_administrator=false`; пять principal по-прежнему отсутствуют (`d5308fdfc0484a768ceff5fd8ebef421`), service не установлен и `release_authorized=false` (`ef32f295f09f4463af64d6d16934e4cb`). Матрица `0ecf1b4722a94fb9a65d26fc14fed102`: `ok=true/status=UNTRUSTED`. Нет доказательства реальной отдельной host identity.

**Финальная версия SHA для owner-документов:** `Setup-P085WindowsPrincipals.ps1` = `9e84499bfffbfc64263c9841983613400187e008fdb417953111e91469017b56`, `p085_accounts_readonly_check.py` = `50af23dc7caf740a80ddef50971f8968abe373944f4c1f449801e9c3ffcbfb73`, `p085_readiness_matrix.py` = `23b66dae966beb5487b529636ef021c7207c7140860e65c4f083110909cfba79`.

**Hard blocker:** OS user account creation/protected runtime/UAC cannot be performed by this non-elevated, agent-editable MCP. Do not invoke arbitrary PowerShell as administrator via Python subprocess or grant self-review. Only independent owner-controlled foreground trust deployment can enable protected P085 E2E.

## Финальная QA после исправлений

- Целевые Windows isolation/installer/preflight тесты, job `50e9c3f756d745a78adf0d1c8e2a5207`: 31 tests, 30 PASS / 1 SKIP, rc=0.
- Полная регрессия **после обоих source-fix**, job `977183becbaf47ebaa9012853f0d5330`: 2635 tests, 2589 PASS / 46 SKIP, rc=0.
- Код: `p085_cross_principal_probe.py`, SHA256 `79abedb650b2d834e1e6ed3e661d2a79c312fc44a4c4d102a5cee6b22246bb9f`; тест: `test_p085_cross_principal_probe.py`, SHA256 `58bd32aba06175cd514c03be3d790bd01d60497f17f0af37651d16eded568dba`.
- Полный автономный P085 аудит после первого path-fix и до финального self-attestation-fix, job `29711b4bb9ea478ab9e4824942a57390`: 7/7 suites PASS, `p085_release_ready=false`, live tool_count=28, `verified_host_identity=false`. Следовательно, PASS относится к offline suite, не к защищённой Windows установке.

**Следующий неавтоматизируемый через данный MCP шаг:** owner-controlled Windows UAC + trusted copy + 5 отдельных локальных Windows users. После его выполнения снова снять preflight; не считать Python-only bypass устранением P085.
