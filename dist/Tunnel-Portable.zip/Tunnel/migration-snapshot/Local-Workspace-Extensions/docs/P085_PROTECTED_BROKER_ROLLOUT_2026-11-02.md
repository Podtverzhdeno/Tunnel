# P085 — protected Windows reviewer broker: implementation & rollout

**Status 2026-11-02: source implemented and tested OFFLINE; NOT DEPLOYED; P085 NOT CLOSED.**

> **Update 2026-11-07:** protected source now includes an owner-gated SCM-dispatched `p085_reviewer_service.py --serve-service` reservation-only loop with STOP/SHUTDOWN handling, plus stop-aware `review_pipe_server.py`; real same-user Windows pipe connect and cancel tests PASS. **No Windows service, separate principal, private keys, privileged accept/merge or owner cutover is deployed.** The SCM-only reservation worker now selects the SHA-staged overlapped transport; `PIPE_NOWAIT` remains only for legacy one-shot compatibility. Bounded connect/read/write and CancelIoEx have passed disposable same-user Win32 smoke tests; real two-SID/QA E2E and owner-controlled runtime install are still mandatory before activation. Source-only `Install-P085ProtectedService.ps1` DOES NOT create a Windows service. Evidence: `docs/P085_OWNER_UNBLOCK_EVIDENCE_20261107.md`.

The actual live Local Workspace MCP continues to expose unrestricted `run_script` and file writes. It must NOT be treated as authenticated reviewer identity.

## Measured blocking evidence

Run from the scheduled-chat Local Workspace OS account:

```powershell
python p085_windows_isolation_probe.py
```

The read-only WinAPI effective-access probe returned `UNTRUSTED_WRITE_ALLOWED` for **all four** live targets: `.agent-team/team.sqlite3`, `.agent-team/`, `agent_team.py`, and the project root. This means any Python-only role check is bypassable by the same OS principal. The probe uses CreateFileW OPEN_EXISTING and closes the handle; it does not change file data or ACLs.

## New isolated components

- `p085_windows_isolation_probe.py` (repository root): read-only, fail-closed effective access diagnostic for Windows. `test_p085_windows_isolation_probe.py` verifies it using temporary files.
- `mcp-host-source/workspace_mcp/host_pipe_peer.py`: native WinAPI `ImpersonateNamedPipeClient` / `OpenThreadToken` / `GetTokenInformation(TokenUser)` / `RevertToSelf`. Retrieves the real OS SID of the pipe client AFTER a read. Includes an actual Windows named-pipe peer identity test, not just mocked role strings.
- `mcp-host-source/workspace_mcp/review_grant_broker.py`: only allows a preconfigured dedicated reviewer SID and rejects the agent SID, wrong service process SID, forged request fields/roles, stale SHA+lease grants, replay and self-review. Client can only submit `{task_id,signed_grant}`. **No acceptance or merge operation is exposed.**
- `mcp-host-source/workspace_mcp/review_pipe_server.py`: Windows-only first-instance local named pipe with protected DACL (SYSTEM + service full control; reviewer client has only read/write DATA, not FILE_CREATE_PIPE_INSTANCE). Remote clients rejected. Bounded 8KiB frames, nonblocking reads with deadlines, bounded ACK handshake (no unbounded `FlushFileBuffers`). The client protocol is binary `uint32-big-endian length | JSON`, response same format, then client sends one-byte `0x06` ACK. **No production client is installed or connected.**
- `mcp-host-source/p085_reviewer_service.py`: fail-closed protected installation loader. Requires external service installation **outside all of IdeaProjects**, 3 distinct Windows SIDs, a service-owned `p085_private/config.json`, `p085_private/review-key.bin` and **separate** `p085_private/qa-verify-key.bin` (each >=32 bytes, must differ). `--doctor` never starts IPC or creates keys; `--serve-one` handles only one post-QA one-shot reservation, never a merge. Current source-tree `--doctor` returned `PROTECTED_BROKER_NOT_READY` as expected.
- `mcp-host-source/workspace_mcp/review_qa_attestation.py`: strict signature and task/spec/lease/bundle SHA verifier for independent supervisor QA. Its six required checks are `unittest`, `spec_check`, `openspec_strict`, `reuse_guard`, `architecture_guard`, `negative_qa`; all must have successful exit codes and signed evidence SHA. Missing, forged, stale or different runner-environment evidence fails closed. The QA signer is **not** implemented or exposed through MCP because launching untrusted tests under the privileged signing identity would defeat the security boundary.
- `review_grant_broker.py.reserve_with_independent_qa` verifies a protected Windows peer SID, current SQLite/source state, signed QA evidence **and** owner-granted authorization before atomically reserving the nonce. `review_pipe_server.serve_one` now strictly requires independent QA policy/key and uses this path. It cannot return `done` or merge code.

## Operator-controlled OS isolation migration (do not run unattended)

1. **Prepare accounts:** under an actual elevated local Windows Terminal, provision distinct non-administrator principals for the untrusted agent MCP, the reviewer client, and the protected service. Record their *real* SIDs with `whoami /user` from each principal (not the names supplied by an MCP client). If scheduled web chats cannot map to distinct OS principals, their actor identities remain unverified; use a local reviewer process or owner-mediated review instead.
2. **Build a protected installation outside** `C:\Users\user\IdeaProjects` (e.g. a service-owned directory under ProgramData). Install a reviewed, pinned copy of `mcp-host-source/` in that directory. Apply Windows DACLs: SYSTEM and dedicated service read/write; Administrators recovery; reviewer client must have **no filesystem access to service code, key, config or ledger**; untrusted agent must have none. Verify by actually trying reads/writes under each OS principal. Code stored in the shared Git working tree is NOT an acceptable privileged installation.
3. **Protect main tree and coordinator:** the service principal owns canonical source files, review merge journal and `.agent-team/team.sqlite3`. Untrusted agents get only scoped sandbox permissions and authenticated narrow gateway operations; they must NOT retain general `run_script` or direct write/SQLite access. Current scheduled chat workflows will need a narrow MCP agent profile to preserve development without a privileged bypass. **Do not apply ACLs to live files until that alternative path passes E2E**, or the current 5-agent workload may stop.
4. **Install private configuration** (owner action only), shape:
```json
{
  "version": 1,
  "service_sid": "S-1-5-21-REPLACE-WITH-SERVICE-SID",
  "reviewer_client_sid": "S-1-5-21-REPLACE-WITH-REVIEWER-SID",
  "untrusted_mcp_sid": "S-1-5-21-REPLACE-WITH-WORKER-SID",
  "reviewer_actor": "reviewer:local-windows",
  "qa_runner_actor": "qa:isolated-supervisor",
  "qa_runner_environment_sha256": "REPLACE_WITH_REAL_PINNED_QA_RUNTIME_SHA256",
  "trusted_journal_sha256": "REPLACE_WITH_VERIFIED_REVIEW_MERGE_PY_SHA256",
  "workspace": "projects",
  "owner_principals": {
    "developer-1": "developer:principal-1",
    "developer-2": "developer:principal-2",
    "developer-3": "developer:principal-3",
    "developer-4": "developer:principal-4"
  },
  "project_root": "C:\\Users\\user\\IdeaProjects\\Local-Workspace-Extensions"
}
```
  Config and **two distinct** 32+ byte cryptographically random keys (`review-key.bin`, `qa-verify-key.bin`) must be stored **only** in `p085_private` of the protected installation, not in Git, chat, project root, logs, or public MCP. The QA supervisor's corresponding signing secret must also be restricted to its independently protected supervisor process and inaccessible to the subprocess that executes untrusted candidate tests. The placeholders above are NOT real SIDs or QA-environment hashes. Do not let any chat-facing tool issue/sign grants or QA receipts.
5. **Run separate-principal acceptance tests BEFORE network access:** run `p085_reviewer_service.py --doctor` as the service account. Run `p085_windows_isolation_probe.py` as the untrusted MCP account and require all protected write attempts to be OS-denied rather than merely sharing-locked/inconclusive. Test that the reviewer SID can open the named pipe but the worker SID cannot; grant SID cannot create a second pipe instance. Verify no service code/config/key readable by worker.
6. **Complete formal finalizer:** the service currently supports only authenticated one-time **reservation**, not `agent_team.review(...accept)`. To close P085, independent sandbox QA must run under a separate low-privilege identity (existing review tests execute candidate Python, so must NOT run inside the privileged broker). The finalizer must recheck lease/revision/spec/source+test SHA, exact independent QA receipt, author != reviewer, live MergeIntent, and emit canonical acceptance record atomically. Test crash after partial merge, replay, expired grant, simultaneous accept/reject, source drift. Keep all existing owner/foreground approvals for normative OpenSpec changes.
7. **Cutover/rollback:** install as a parallel service on the named-pipe local transport. Do not restart the current tunnel or replace its profile until both a canary restricted developer and reviewer flow pass. Keep an operator-approved rollback plan restoring the previous host profile **without exposing privileged reviewer operations via the tunnel**. Fail closed on an unknown merge intent or reserved grant; owner reconciliation only.

## Automated evidence & limitations

- The WinAPI effective access probe has already proven current shared OS principal can modify all protected files. Consequently, P085's deployment gate must report **NOT READY**.
- Windows named-pipe impersonation was exercised against a real local pipe and matched the actual process SID. The server DACL was parsed by Windows Advapi32 during tests, and frame fuzz / timeout / forged-role tests are included.
- Client-to-service real two-principal E2E, OS account creation, grant issuance, actual key custody, isolated QA execution, GitHub remote CI and protected release installation are **not verified**.
- The local `--serve-one` API is deliberately incomplete. Do not point a browser tunnel at it or claim autonomous accepting/merging is enabled.

Authoritative references: Microsoft Learn *Named Pipe Security and Access Rights* (use per-bit rights because FILE_GENERIC_WRITE enables FILE_CREATE_PIPE_INSTANCE); *Impersonating a Named Pipe Client* (impersonate only after reading a client message; revert immediately). The Windows PIPE_NOWAIT compatibility mode is a staging transport mechanism; for production prefer a fully reviewed overlapped-I/O implementation with hard timeouts.
