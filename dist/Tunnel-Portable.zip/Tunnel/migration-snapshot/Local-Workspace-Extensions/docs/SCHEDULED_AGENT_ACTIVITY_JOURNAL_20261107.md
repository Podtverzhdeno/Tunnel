# Журнал запланированных агентов — 07.11.2026

Реализация: `scheduler_activity_journal.py` (stdlib, без API, сетевых запросов, новых зависимостей и изменения live SQLite/leases).

## Два независимых источника данных

- **Scheduler metadata:** `.agent-team/reports/scheduler_run_history.json`, пополняется только при отдельном получении реального `Automation.peek(last_run)` и сохранении его числового snapshot через `scheduler_run_history.py --snapshot ... --save`. Ранее пропущенные записи не восстанавливаются автоматически; этот источник может быть неполным.
- **Agent self-report:** `.agent-team/reports/scheduler_activity_journal.json`, создаётся при начале/завершении работы через Local Workspace MCP. Его интервал измеряет **только время между вызовами двух инструментов**. Это не непрерывная генерация GPT, не длительность ChatGPT Scheduled Tasks, не billing и не основание считать агентскую работу проверенной.

Не суммировать эти два показателя между собой. Совместная карточка Developers 3+4 — одна ChatGPT-сессия, а не два параллельных запуска.

## Вызовы из запланированного чата

1. После `list_workspaces` и подтверждения `projects` выполнить:

```text
Local Workspace run_script:
  workspace=projects
  path=Local-Workspace-Extensions/scheduler_activity_journal.py
  cwd=Local-Workspace-Extensions
  args=["start","--role","developer-1"]
```

Получить `job_id`, проверить `job_status=completed`, `returncode=0`, в `job_output` проверить `ok=true`. **Сохранить точный `session_id`** в контексте текущей сессии. Менять role на developer-2 / scheduler-developer-3+4 / architect-reviewer, как соответствует расписанию.

2. После реальной работы и проверки тестов запустить:

```text
Local Workspace run_script:
  workspace=projects
  path=Local-Workspace-Extensions/scheduler_activity_journal.py
  cwd=Local-Workspace-Extensions
  args=["finish","--session","activity-<id>","--outcome","CODE_CHANGED_TESTED",
        "--reason","COMPLETED","--passed","45",
        "--changed-file","Tunnel-release-staging/scripts/test_chain2_triage.py",
        "--job-id","<real-job-uuid>","--task-id","P085"]
```

Сюда передавать **только фактически подтверждённые** тесты, файлы и job IDs, без выдуманных цифр. Пример выше иллюстративный. Для отсутствия новых задач используйте `--outcome NO_SAFE_WORK --reason NO_NEW_SAFE_WORK`; для заблокированного P085 `--outcome BLOCKED --reason P085_BLOCKED`; для изучения без изменений `--outcome DIAGNOSTIC_ONLY --reason COMPLETED`. Другие перечисления см. `python scheduler_activity_journal.py finish --help`. Поля `--passed`, `--failed`, `--skipped` и `--changed-file` необязательны. Проверить `job_status` и `job_output ok=true`.

Двойной успешный `finish` идемпотентен при совпадении параметров, конфликтующие повторы отвергаются. Если завершение ChatGPT прервётся до `finish`, запись останется открытой с UNKNOWN временем: **не закрывать её фиктивной длительностью**.

## Отчёт по суткам и неделе

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python scheduler_activity_journal.py report --from-date 2026-11-06 --through-date 2026-11-07 --tz Europe/Warsaw
python scheduler_activity_journal.py report --from-date 2026-11-02 --through-date 2026-11-08 --tz Europe/Warsaw
```

Отчёт включает `totals`, `by_role`, `sessions`, `scheduler_metadata_separate` и `caveats`. При назначении события календарному дню используется **локальная дата начала**; сессии через полночь не делятся. Для `Europe/Warsaw` и `UTC` не требуется установленный `tzdata`; для произвольного другого IANA timezone база может потребоваться.

## Автоматический контроль пропусков и ежедневная/недельная сводка — 07.11.2026

Добавлен read-only `health` и `report-recent`. В существующем расписании **Architect Reviewer** сохранены инструкции вызывать их каждый час и, когда реально доступна панель Automations, получать свежий snapshot карточек. Новых расписаний не создано.

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python scheduler_activity_journal.py health --threshold-minutes 120
python scheduler_activity_journal.py report-recent --days 1 --tz Europe/Warsaw
python scheduler_activity_journal.py report-recent --days 7 --tz Europe/Warsaw
```

Если `Automations.peek` был реально вызван в том же рабочем ходе и сохранён свежий снимок, можно выполнить:

```powershell
python scheduler_activity_journal.py health --threshold-minutes 120 --card-snapshot .agent-team/reports/scheduler_card_status_latest.json
```

Снимок: `schema=scheduled-card-observation-v1`, `observed_at` (ISO UTC), `cards` (ровно четыре роли, по одной на расписание), у каждой `role`, `automation_id`, `enabled`, `last_started_at`, `last_completed_at`, `last_run_id`, `last_status`. Роль Developers 3+4 общая. Только фактически наблюдавшиеся значения; не копировать секреты и тела бесед. `health` использует включённость карточек только если snapshot не старше 15 минут; устаревший снимок игнорируется.

Сигналы:

- `RECENT_SCHEDULER_OBSERVATION`: сведения о запуске получены достаточно недавно;
- `STALE_CAPTURE_NOT_PROVEN_MISSED`: локальная история давно не обновлялась; реальное отсутствие запусков **не доказано**;
- `POSSIBLE_GAP_ENABLED_CARD`: в свежем снимке карточка включена, но последняя зарегистрированная активность старше порога; требуется проверка в ChatGPT;
- `KNOWN_DISABLED`: карточка была выключена на момент наблюдения;
- `LAST_OBSERVED_RUN_FAILED`: последний известный запуск отмечен неуспешным;
- `NO_SCHEDULER_OBSERVATION`: нет подтверждённых сведений о запуске.

`suspected_missing_activity_receipt` показывает эвристическую нехватку записи `start` после завершённого запуска начиная с 7 ноября 00:00 UTC. Это **не независимая верификация**, а сравнение приблизительных временных окон без общего неизменяемого scheduler run ID; поле `null` означает, что проверка не применима. `open_receipts_over_threshold` отдельно подсчитывает незакрытые самоотчёты, но не объявляет их неудачными или нулевыми.

Периоды `report-recent --days 1|7` включают текущий календарный день в `Europe/Warsaw`, проверены переходы через полночь и DST. Сводка является снимком доступных данных, а не полной статистикой ChatGPT по аккаунту.

## Ограничения и защита

- Журнал не получает сам доступ к истории ChatGPT: без внешних `Automations.peek` снимков суммарное время планировщика за старые дни **неизвестно**.
- Переносимые самоотчёты не позволяют удостоверить личность агента — P085 не закрыт.
- Нет доступа к защищённой живой очереди, отправки сообщений, автоматической приёмки или Git.
- На запись используется атомарная замена JSON и эксклюзивный каталог-блокировка; после аварийного падения lock не удаляется автоматически, чтобы избежать потери данных.
- Нельзя включать ключи, промпты, ответы, персональные данные или секреты в `--note`; журнал принимает только короткие заметки, относительные пути и идентификаторы.
- Учет тестов и файлов в activity-journal самоотчётный, а не независимо верифицированный; фактические job IDs и SHA проверять отдельно.

## Проверка

```powershell
python -m unittest -v test_scheduler_activity_journal
python -m unittest -v test_scheduler_run_history test_scheduler_history_persistence test_scheduler_report_period
```
