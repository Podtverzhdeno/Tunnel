# Scheduled OpenSpec + SDD team — 4 developers + 1 architect-reviewer

**Project:** `C:\Users\user\IdeaProjects\Local-Workspace-Extensions`
**State:** `.agent-team/team.sqlite3` (not source code, never commit)
**Entrypoint:** `agent_team.py` via existing Local Workspace `run_script`, cwd `Local-Workspace-Extensions`.
**Canonical requirements:** `openspec/changes/local-pc-agent-tooling/specs/*/spec.md`.
**Planning:** `openspec/changes/local-pc-agent-tooling/tasks.md`, `specs/001-local-pc-agent-tooling/spec.md`, `specs/001-local-pc-agent-tooling/tasks.md`.

## Scheduled execution — confirmed 2026-11-01

The scheduling platform allows at most **5 active automations** under the current plan. One existing active daily job is `IT/AI сертификаты`, which was left unchanged. Thus the five team ROLES occupy **four hourly automation cards**:

| Active automation | Cadence | Agent role(s) |
| --- | --- | --- |
| OpenSpec — Developer 1 | Hourly, at minute :10 UTC | developer-1 |
| OpenSpec — Developers 3+4 | Hourly, at minute :20 UTC | developer-3 then developer-4 (separate SQLite owners, sandboxes and leases) |
| OpenSpec — Developer 2 | Hourly, at minute :30 UTC | developer-2 |
| OpenSpec — Architect Reviewer | Hourly, at minute :50 UTC | architect-reviewer |

The two roles in the combined :20 job run **sequentially**, not as two independent ChatGPT processes. This preserves the unrelated certificate automation without exceeding the platform limit. A fifth independent hourly automation requires disabling or completing another currently active automation; do not silently disable unrelated schedules.

The old three Scheduled-Agent-Harness automations were **updated in place**, keeping their IDs. The old Scheduled-Agent-Harness repository and database were not overwritten. The single new hourly job has the ID `6ae74da5c4548191b605d0566bfa56cf`.

## Current backlog — always read live SQLite

The initial four tasks P009/P010/P015/P016 were accepted. Second-wave P018 and P034 were accepted; P033 was returned to developer-3 for scoped media hash safety rework. P092 is a follow-up security review of P010; P021 remains a separate offline dependency task. P095 adds a scene dependency handoff plan with a **new** `scene-dispatch` capability, priority 30, and two new non-overlapping Python deliverables. See `docs/SCENE_HANDOFF_PLAN.md`.

**These are observations from 2026-11-01, not a static source of truth.** Every scheduled run MUST check `agent_team.py overview`, `status` and `history TASK_ID` first; priority and assignments can change. Resolve owned `rework` before starting unclaimed tasks. For any scene work, caller-declared checkpoint/verified flags are NOT trusted external approvals.

## Five roles and execution windows

- `developer-1`: project discovery, assigned independent P009 code.
- `developer-2`: code search, assigned P010.
- `developer-3`: diagnostics parser, assigned P015.
- `developer-4`: Git root mapper, assigned P016.
- `architect-reviewer`: independent verification, architecture and OpenSpec/SDD alignment, rejection/acceptance and authoring new scoped tasks when all previous work has been cleared.

Scheduled tasks are configured to execute **hourly**; each role performs one independent turn per scheduled invocation. There is no continuous background execution between launches. Do not claim otherwise.

## Avoid task-local stalls

Follow `docs/ANTI_IDLE_AGENT_POLICY.md`. A stale/expired task does not block unrelated task work for the same role when that other task is separately assigned, spec-backed, and lease-fenced. P096 is high-risk and must remain unmerged; P106 has disjoint deliverables and no P096 dependency, so developer-3 must make progress on P106 under its own valid lease rather than repeatedly analyze P096. If no active lease token is held, only read-only preflight is permitted until legitimate reacquisition. The reviewer handles P096 coordination and P107 fixture repair independently; do not bypass full-suite tests.

## On every invocation (mandatory)

1. Call Local Workspace `list_workspaces` to confirm alias `projects`, read/write/execute availability.
2. Call `run_script` on `Local-Workspace-Extensions/agent_team.py` with `args=["status","--role",ROLE]`; poll `job_status(job_id)` and `job_output(job_id)` until final result. Read the current `tasks[]`, `agents[]`, `recent_activity[]`: owner, status, last activity `activity_at`, `submitted_at`, `reviewed_at` and `lease_until`.
3. Read `AGENTS.md`, `README.md`, this file, the actual OpenSpec requirement under `openspec/changes/local-pc-agent-tooling/specs`, corresponding task `Pxxx`, SDD user stories and prior review notes. Current specifications have priority over historical conversation context.
4. Generate one request ID using `run_script(..., args=["new-request",ROLE])`, then `acquire ROLE REQUEST_ID`. If response is lost, retry the **same request_id**. NEVER create another request ID merely to bypass a live lease.
5. If no task, return an explicit no-work status. For a developer, do not invent edits. For reviewer, audit architecture/spec, provide meaningful gap report and optionally add one new spec-backed, safe task through reviewed `team_seed.json` followed by `init`.
6. For a developer task, read the assigned sandbox and implement **only** files named in `deliverables`. If it is a resumed task, inspect existing files and `review_notes` before starting new work. Never overwrite unrelated project files.
7. Run `unittest discover` and `spec_check.py` in sandbox via Local Workspace `run_tests` / `run_script`; report actual exit code and test failures, do not claim false PASS. Use `heartbeat ROLE TASK_ID LEASE_TOKEN` during long work, before current lease deadline. Submit only after all required files exist using `submit ROLE TASK_ID LEASE_TOKEN NOTES` (notes >30 chars, includes test evidence).
8. Reviewer obtains `review` lease, inspects the submitted changed Python files and test evidence, checks architecture/quality/security and the current OpenSpec/SDD. `review TASK_ID LEASE_TOKEN reject NOTES` returns to previous owner with persistent sandbox. `review ... accept NOTES` runs sandbox unittest + structural SDD validation and copies only explicitly allowlisted files into the project if base hashes still match. Reviewer **does not** commit/push Git, change Docker/Postgres or run arbitrary admin tools.
9. Finish by reading `status` or `history TASK_ID`, and report concrete file names, tests, task state, owner and last-activity timestamp. If a tool returns an error or MCP is inaccessible, report the blocker; no invented work.

## Operational overview and stalled-task detection

For a large review backlog, the Architect Reviewer first runs read-only `python review_readiness_matrix.py` and inspects its task-by-task source preflight classifications before spending time on QA. `READY_FOR_INDEPENDENT_QA` is only a prioritization signal: the reviewer still needs a fresh legitimate review lease, independent sandbox tests, current source SHA checks, and host-side reviewer authorization. `EXPIRED_LEASE_REACQUISITION_REQUIRED` never permits direct SQLite resets, reused tokens, or self-acceptance. Details and measurements: `docs/QA_REVIEW_READINESS_2026-11-02.md`.

Use `python agent_team.py overview` for a concise, read-only current snapshot: each developer's last session and last activity UTC, each task's owner and status, minutes since activity, time remaining on the lease, the last checkpoint's next steps, and attention flags for expired developer leases, review waiting over an hour, or required rework. This is an observation of actual SQLite state, not a promise that a scheduled job ran or that a developer wrote code.

The Local Workspace tool path under `.agent-team` was tested with an isolated fixture: `write_file` + `run_tests(unittest)` succeeded, 1/1 test. The fixture was moved to reversible private trash.

## Persistent progress checkpoints

The coordinator stores structured durable task checkpoints in SQLite rather than relying only on chat history or sandbox files. Any role holding an active lease may report:
- `done`: verified work already performed
- `next`: concrete continuation steps for the next hourly run
- `tests`: actual executed tests and results, not assumptions
- `blockers`: specific issues preventing completion

**Recommended Local Workspace-compatible flow (P089):** The Local Workspace bridge rejects JSON metacharacters inside run_script arguments. Write UTF-8 JSON directly to the assigned sandbox file `agent_progress.json` using `write_file` (or `replace_text` with optimistic SHA when updating an existing file), then call:

```text
python agent_team.py checkpoint-file developer-1 P009 LEASE_TOKEN CHECKPOINT_REQUEST_ID
```

The CLI uses a fixed `SANDBOX/agent_progress.json` path, not an arbitrary caller-provided filename; it requires an active lease, disallows symlinks/junctions, rejects >4096 bytes and malformed UTF-8, and applies the same idempotent request-ID logic as the original `checkpoint`. Example file content:

```json
{"done":["Read current spec"],"next":["Implement file scanner"],"tests":[],"blockers":[]}
```

**Never pass the JSON as a run_script argument.** Each task has its own file. A successful `write_file` by itself does not update the SQLite checkpoint; verify `checkpoint-file` success and `history TASK_ID`.

Obtain CHECKPOINT_REQUEST_ID using `new-request developer-1` separately from acquisition. If the response is lost, retry with exactly the same ID and JSON: the result is idempotent. Different content under a used request ID is rejected. The role and lease are checked against SQLite; an expired token cannot write a fresh checkpoint. Payload is limited to 4096 UTF-8 bytes and short text arrays; never include passwords or private file contents.

At the start of each turn call `status` and `history TASK_ID`: the latest checkpoint is included in each status task as `latest_checkpoint`; `history` returns the last 20 checkpoint records with UTC timestamps. A recovered task keeps its prior checkpoint history while receiving a fresh lease. Source files are still authoritative; a checkpoint is a progress claim, not proof that tests ran.

A real Local Workspace sandbox compatibility check successfully used `write_file` and `run_tests(unittest)` under `.agent-team/_integration_probe` (1/1 PASS); the disposable test directory was moved to reversible trash.

## Reviewer/spec-change continuity

When an architect changes the canonical OpenSpec while a task is in progress, the developer's old sandbox specification is invalidated. The reviewer must not silently approve it. After the active lease expires or the task has returned, the reviewer can call `python agent_team.py rebase-spec P009 "reason with at least 25 characters"` to refresh reference documents (not Python deliverables), preserve user code and return the task to `rework` with notes. Accepted `done` tasks cannot be silently reopened. Reviewer final acceptance invokes three actual quality gates: sandbox unittest, `spec_check.py`, and installed `openspec validate local-pc-agent-tooling --strict`.

The task seeder refuses duplicate task IDs, redefinition of existing output scopes and overlapping Python deliverable paths across different tasks. Code snapshots and approved deliverables are root-level Python files only; changes to unrelated sandbox modules block submission.

## Per-agent token usage accounting (FR-042 / FR-043)

To inspect recorded LLM input and output tokens separately for all five agents, run `python agent_team.py usage-report`, optionally filter by `--role` or `--task-id`. `python agent_team.py usage-export` creates `.agent-team/reports/token_usage_latest.html` and `.csv` for offline viewing. Agents can import exact provider-returned counts only while holding an active task lease, via a fixed sandbox `agent_token_usage.json` and `usage-import ROLE TASK_ID TOKEN`. Never fabricate ChatGPT Automations token usage: no actual per-run prompt/completion token telemetry is exposed by the connected scheduler; historical usage remains unknown. Full instructions in `docs/AGENT_TOKEN_USAGE.md`.

## Safe refresh of stale Python test/runtime snapshots (FR-041)

Long-running tasks retain their original test/runtime Python snapshot. If other developers merge new coordinator files while the current developer is still coding, the task's old full `unittest discover` may fail for reasons unrelated to its allowlisted deliverables. Never manually replace snapshot-owned non-deliverable modules, and never bypass `UNSCOPED_CHANGE` or main-source CAS checks.

Only the **currently leased developer role** may call:

```text
python agent_team.py sync-sandbox developer-2 P021 ACTIVE_LEASE_TOKEN
```

This refreshes root Python files **not** in the task's declared deliverables from approved main sources, after checking their old and new hashes. It detects new, changed and removed non-deliverable files. The task's own source/test deliverables, `agent_progress.json`, checkpoint history, canonical spec baseline and unrelated project files are preserved. If a non-deliverable file was manually edited, the command refuses without overwriting it; wrong/expired leases are refused. A repeat with unchanged main returns `refreshed=[]`.

A partial snapshot refresh caused by a hard interruption can be retried with the active lease **only if** files still have the previous or currently expected main hash. Unexpected third-party edits block the refresh. In-process mid-copy failure attempts rollback and has deterministic negative tests. This operation is a **logical file/workflow integrity control**, not an OS permission sandbox or host-authenticated identity; it is not atomic with concurrent filesystem modifications outside the project.

After successful refresh, run **full sandbox** unittest discover, spec_check and strict OpenSpec. Only submit if the task's own deliverables pass the usual independent review gate. Document source hashes and actual test results in `agent_progress.json` and persist via `checkpoint-file`.

## Durable acceptance evidence audit

The reviewer stores full structured QA evidence in `acceptance_records` in the same SQLite commit as task `done`. Run `python team_acceptance_audit.py` for an **independent read-only** inspection of accepted file hashes, required QA exit codes, legacy tasks lacking records, and production authorization limitations. It never claims to validate host identity or OS sandbox. See `docs/ACCEPTANCE_EVIDENCE.md`. A completed task with no modern structured acceptance record remains `legacy_unverifiable` — do not invent historical proof.

## Durable review merge and manual crash recovery

**Important:** task snapshots and CLI role strings are not OS isolation or authenticated reviewer identity. The original MCP host still exposes broad actions and this cannot be fixed by a Python guard inside the project.

The reviewer uses `agent_team.py merge-status P009` before any `review ... accept`. If `intent` is non-null, the integration journal is unfinished. Do **not** retry `accept` or edit files. Each accepted multi-file change now prepares an on-disk intent at `.agent-team/merge-intents/Pxxx/` with fsynced backups, staged outputs, expected pre/post SHA-256 and task revision, before replacing the first source file. The reviewer still runs sandbox unittest + spec_check + OpenSpec strict. A completed SQLite transaction is recorded before journal cleanup.

When a simulated crash interrupts after the first replacement or before SQLite commit, this durable journal survives. The next attempted review returns `MERGE_PENDING`; a subsequent reviewer acquisition skips tasks with pending merge intent. The `overview` command reports `merge_intent_requires_owner_review`. Read-only `merge-status` shows whether each target is original, applied or diverged. The journal does not automatically overwrite potentially concurrent user changes.

For an actual recovery, the owner must inspect the task in an **interactive Windows Terminal** (only when the prior review lease has expired):

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
.venv\Scripts\python.exe owner_review_recover.py P009
```

- If task status was **not committed**, inspect filenames/hashes and enter `RESTORE P009` to restore only files still matching the exact recorded new hash; returns task to `review`.
- If task is already `done`, enter `ACK P009` to acknowledge a leftover journal after verifying all new hashes; no source-file rollback.
- If any target is modified independently, a lease remains active, or the journal is corrupt, the operation **fails closed**. Do not delete the journal or manually force success; escalate to owner-driven inspection.
- Do not invoke this recovery from a scheduled agent; the successful unit tests simulate a TTY but do not attest a real owner's identity.

This makes interrupted file changes **detectable and conservatively recoverable**, not multi-file atomic in the OS/database transaction sense. True trusted reviewer identity is still blocked pending host-side authentication and grants (P081). A power-loss durability guarantee and hard OS process termination test are not yet established.

## Read-only review preview (before any accept)

For submitted tasks the reviewer can run `python agent_team.py review-preview P009`. The command:
- Shows the canonical OpenSpec requirement reference, task owner, last submission time and original task notes.
- Verifies the actual allowlisted output files, original/main/sandbox SHA-256 hashes and whether the canonical specification changed after acquisition.
- Parses Python syntax without executing sandbox modules; rejects malformed UTF-8 and unexpected Python files or modifications to snapshot-owned Python modules.
- Marks `ready_for_review: true` only for an unblocked task in `review` or `reviewing`. For completed tasks `already_accepted: true` is returned instead. A pending merge journal returns `MERGE_PENDING` and prevents a new acceptance.
- Does **not** replace independent source review, real sandbox tests, `spec_check.py`, `openspec --strict`, or a trusted MCP host authorization grant. Treat submitted `review_notes` as untrusted developer claims.

If any blocker is returned, do not accept. Send precise corrective feedback and maintain the task's existing sandbox. This command performs no code execution, Git operations or file merges.

## Follow-up revisions and priority

Tasks carry a bounded `priority` integer (0–100) in SQLite. Schema upgrades preserve existing task rows, checkpoints and accepted history. The scheduler always continues an owned `rework` task first; among unclaimed `available` tasks it prefers higher priority. Do not use higher priority to seize a file currently held by another active task.

A newly seeded task MAY reuse Python deliverables from a prior `done` task to implement the next reviewed revision. This permits continuous improvement without silently reopening the previously accepted task. The owner receives a new sandbox snapshot, baseline source hashes, fresh lease, separate review notes and full test gate. Unfinished tasks still reserve their deliverable names, and a new task with overlapping active outputs is rejected.

The seeder may revise **metadata only** (title, role hint, canonical spec reference, instructions and priority) for an `available`, unclaimed task that has no sandbox, recording `seed_revision` in the SQLite audit trail. It cannot change deliverable scope, already accepted work, acquired tasks or another agent's sandbox. Repeat `init` returns `revised=0` if there are no changes.

Current example: priority=100 `P092` follows already accepted `P010` with the same search-module deliverables. It is a **security assurance task, not a verified exploit report**. Current `_safe_regex` already rejects the sample additional-quantifier pattern; stdlib `re` lacks a hard per-match timeout. The reviewer must demand actual evidence, preserve safe regex cases and never accept unsupported vulnerability claims. The read-only four-capability E2E tests verify workspace metadata discovery, Git markers, literal/regex search, diagnostics parsing, Unicode, redaction and no source mutations.

## CLI commands

```text
python agent_team.py init
python agent_team.py status --role developer-1
python agent_team.py overview
python agent_team.py new-request developer-1
python agent_team.py acquire developer-1 REQUEST_ID
python agent_team.py heartbeat developer-1 P009 LEASE_TOKEN
python agent_team.py submit developer-1 P009 LEASE_TOKEN "Implemented and verified ..."
python agent_team.py acquire architect-reviewer REQUEST_ID
python agent_team.py review P009 REVIEW_TOKEN accept "Reviewed tests, specs, security, ... "
python agent_team.py review P009 REVIEW_TOKEN reject "Fix the following missing cases ..."
python agent_team.py history P009
python agent_team.py gate-check
python agent_team.py rebase-spec P009 "Canonical spec changed; preserve developer code"
```

## Isolation, ownership and recovery

- Each claimed task receives `.agent-team/workspaces/developer-N/Pxxx`, a bounded snapshot of project Python, OpenSpec and SDD files. It is **logical file conflict isolation, not a Windows OS sandbox**.
- Only that role's task with an active lease may submit. Lease TTL is 50 minutes and is renewed explicitly with `heartbeat`. A later scheduled turn reacquires its expired own task with a new token, keeping its original sandbox and review notes.
- Atomic SQLite task acquisition prevents two roles taking one task. New `request_id` is one per genuine invocation. Replaying a lost acquisition must reuse the same ID.
- Review integrates only Python files from the fixed allowlist in the task; all source hashes must match the original snapshot. Tests run in sandbox before integration. If tests fail or files conflict, reviewer must reject/request rework.
- Completed tasks remain in history; their deliverables are not silently reassigned. `status` provides last activity and per-role session counters. SQLite records all lease, submit, accept/reject and heartbeat events.
- The older `Scheduled-Agent-Harness` and its SQLite data are preserved unmodified. The new code/team/ledger live exclusively under Local-Workspace-Extensions.

## Security notes

Existing broad Local Workspace `run_script` and `write_file` have OS-user privileges. Prompts and SQLite checks do **not** enforce an OS isolation boundary. These agents are trusted to obey scoped prompts. A future MCP-host policy broker is needed for enforceable per-agent capabilities and restrictions. Don't run arbitrary shell, Docker, Postgres migrations, credentials, global Git operations, package installations or browser profile access during scheduled coding turns.
