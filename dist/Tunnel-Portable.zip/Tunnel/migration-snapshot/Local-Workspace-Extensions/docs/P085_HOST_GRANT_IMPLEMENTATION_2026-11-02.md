# P085 — trusted reviewer grant foundation (2026-11-02)

**IMPLEMENTED OFFLINE, NOT DEPLOYED. P085 REMAINS OPEN.** No authenticated ChatGPT actor or formal reviewer acceptance is claimed.

## Implemented
- `mcp-host-source/workspace_mcp/review_grants.py`: stdlib canonical HMAC-SHA256 verification of bounded one-time grant, bound to issuer, audience, externally authenticated actor ID, workspace, task ID, action (accept/reject), revision, exact spec SHA, full candidate source/test bundle SHA, expiry and nonce. Contains NO grant issuer or signing tool.
- `mcp-host-source/tests/test_review_grants.py`: negative suite for signature forgery, role spoofing, cross-task/cross-workspace/cross-revision/SHA, expiry, self-review, invalid lease, pending merge, malformed payload, concurrent duplicate claims, restart/replay, two different nonces for the same task+revision, a legitimately new revision and RESERVED crash state.
- Durable SQLite claim uniqueness: primary-key nonce AND UNIQUE(workspace, task_id, revision). `reserve` returns RESERVED before effects and **never** performs QA, formal accept/reject or source merges. A crash leaves RESERVED requiring owner reconciliation; there is no automatic reset or bypass.
- CI workflow includes mirrored host tests on Windows/Linux, but remote GitHub execution is NOT verified.

## Trust boundary — still not met on live host
1. `authenticated_actor` and `ReviewTarget` are parameters, not credentials. An externally protected host must create these from authenticated transport identity and live trusted coordinator state; NEVER accept caller-supplied JSON for these fields.
2. The signing key and grant ledger MUST live under a separate OS principal and ACL, unreachable by scheduled agents even when they have arbitrary Python execution. No signing, approval or secret-custody feature belongs in the chat-facing `run_script` tool.
3. The current connected Local Workspace MCP advertises script/file write capabilities. Thus its `legacy` endpoint is NOT a trusted reviewer plane. The mirror's `observer` profile default is a source change, not evidence the current local tunnel uses it. Switching the live server to observer immediately would interrupt developers and is NOT done.
4. A separate authorized finalizer must check source/spec SHA and source+test bundle, authenticated author != reviewer (including shared D3+D4 session), legitimate review lease, exact revision, independent QA, existing MergeIntent and atomic acceptance record. This module intentionally does not implement such a finalizer.
5. Source mirror `mcp-host-source` is not the running host installation, which was previously located outside this project's authorized directory. No host restart, key creation, OS account/ACL change, queue mutation, acceptance, Git staging or Git push occurred.

## Incremental implementation — trusted task snapshot + lease binding (2026-11-02)

- New `mcp-host-source/workspace_mcp/review_target_snapshot.py` reconstructs a REVIEWING task's current scoped facts **read-only** from SQLite and actual filesystem bytes: task revision, canonical spec digest, entire declared source+test bundle digest, active reviewer lease hash, author role mapped to a separately configured principal, and canonical merge-intent directory presence. Rejects absent/expired reviewer leases, spec drift, changed main baseline, unsafe paths and symlinks, missing tests, unknown owners. It **does not expose the raw review token** or modify live queue.
- `review_grants.py` signed payload was intentionally upgraded from `p085-review-grant-v1` to **v2** and now binds `review_lease_sha256`: rotating/revoking a reviewer lease makes prior signed grants invalid even when the source and task revision did not change. Older schema fails closed.
- `tests/test_review_target_snapshot.py`: 17 checks including current test+source SHA drift, lease rotation/expiry, Windows linked-path rejection, pending `MergeIntent`, SQLite no-mutation and baseline conflict; 1 Windows symlink privilege skip. `tests/test_review_authorization_flow.py`: 25 discovered tests including imported fixtures (1 skip); direct scenario tests prove SHA-bound signed grant/one-use ledger interoperation and deny stale signatures. All tests operate in disposable workspaces.
- Final mirrored host suite: **101 tests, 3 skipped, exit code 0** (includes shared imported test classes). Main coordinator gate: **1477 tests, 37 skipped, exit code 0**, `spec_check` exit 0 and strict OpenSpec validation exit 0. This is verification of the **offline code**, not a deployed OS-authenticated gateway.
- No running MCP server, tunnel, active developer lease, task status, signing key, Windows principal/ACL, remote CI or production merge was changed. Direct `run_script` remains a privileged bypass in current connected `legacy` MCP, so P085 cannot yet be closed.

## Next-stage implementation: Windows OS isolation, private pipe and deployment gate

An additional independent trust-boundary stage was implemented in `p085_windows_isolation_probe.py`, `mcp-host-source/workspace_mcp/host_pipe_peer.py`, `review_grant_broker.py`, `review_pipe_server.py`, and the protected bootstrap `mcp-host-source/p085_reviewer_service.py`. The real agent-side Windows file-access probe returned **UNTRUSTED_WRITE_ALLOWED** for coordinator DB, state directory, canonical `agent_team.py`, and project root: no production isolation exists. The stage was tested with actual Windows named-pipe impersonation, bounded framing and Windows DACL parsing, but **no live service was started and no Windows ACL was modified**. The broker is reservation-only, never merge-enabled, and refuses startup without a protected installation outside the entire `IdeaProjects` workspace and distinct Windows service/reviewer/worker SIDs.

Full runbook, code paths, concrete negative results and approval-safe migration procedure: `docs/P085_PROTECTED_BROKER_ROLLOUT_2026-11-02.md`. This is NOT a completed P085 signoff. A real owner-provisioned OS process and independent low-privilege QA are still mandatory.

## Finalization implementation — later verified state (2026-11-02)

The code now includes:
- `review_qa_attestation.py`: independent SHA/lease-scoped six-check signed QA proof, distinct key from owner grant;
- `review_finalizer.py`: transactionally guarded acceptance with verified QA+grant, pinned canonical `MergeIntent`, exact staged byte digest and durable owner crash recovery;
- `trusted_journal_loader.py`: hash-pinned merge module loaded from a protected copy, never from mutable live source;
- `owner_cutover_gate.py`: owner-installed short-lived cutover assertion, never generated by chat;
- `p085_reviewer_service.py --accept-one`: separate protected-service-only mode, unavailable until real operator preparation and OS ACL cutover.

Host suite: **226 tests, 6 SKIP**, main gate: **1658 tests, 41 SKIP**, OpenSpec strict/spec_check/reuse CI PASS. Real linked transport-to-finalizer E2E runs only on disposable project files, with a mocked Windows pipe kernel and real SQLite/journal. Source complete for staging does NOT mean deployed. On the connected local host, `p085_windows_isolation_probe.py` still reports all four critical targets writable by the untrusted MCP process; `--doctor` fails with `PROTECTED_BROKER_NOT_READY`. **P085 remains OPEN until separately protected Windows principal, file ACLs and low-privilege QA signer runtime are actually deployed and tested.**

Exact operator runbook: `docs/P085_FINALIZATION_RELEASE_GATE_2026-11-02.md`.

## Production completion gates
- Create an OS-protected reviewer service with isolated identity, signing key and ledger. Expose only narrowly scoped authenticated operations; remove general-purpose execution and direct SQLite/main-tree writes from untrusted scheduled agent principal.
- Implement trusted grant issuance via actual owner/authenticated transport, and a privileged review finalizer reusing canonical quality, CAS and merge-journal protections.
- Execute two-principal end-to-end negatives: forged role, replay and double-spend after restart, wrong task/action/revision, concurrent accept/reject, lease expiration during QA, source/spec drift, crash after first file replacement, ambiguous journal, missing test receipt, direct Python/SQLite/ACL bypass.
- No P085 completion claim until actual OS access-denial tests and live bridge test pass.

## Verification
Verified after source/profile edits: `python -m unittest discover -s tests` from `mcp-host-source` ran 54 tests (53 passed, 1 OS-conditional skip), exit 0. Main `python agent_team.py gate-check`: 1476 tests (37 skipped), `spec_check` exit 0, OpenSpec strict exit 0. Existing `agent_reuse_ci_gate.py` passed all checks; 0 canonical hard clone groups. CI config is present; remote GitHub runner evidence unknown.
