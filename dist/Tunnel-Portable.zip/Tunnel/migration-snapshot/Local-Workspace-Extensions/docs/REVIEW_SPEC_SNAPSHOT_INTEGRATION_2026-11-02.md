# Implementation checkpoint — OpenSpec source snapshot in reviewer QA matrix

Date: 2026-11-02.
State: code implemented and locally tested, not independently reviewer-accepted, not privileged release approved.
Project: Local-Workspace-Extensions.

## What changed

- review_readiness_matrix.py now optionally consumes one source provenance snapshot supplied by the existing spec_traceability.audit_traceability function.
- Uses the existing compare_source_snapshots() manifest validation: no second hash/snapshot authority, database or independent coordinator.
- Read-only per-task QA preflight compares canonical_spec_sha256 returned by the real agent_team.review_preview with the independently captured current manifest hash for that exact OpenSpec requirement file.
- A mismatch becomes SPEC_FILE_SHA_CHANGED_DURING_REVIEW and SPEC_SNAPSHOT_REVERIFICATION_REQUIRED; a missing or malformed reference is a blocker, not a successful unknown.
- Existing spec_matches_task_snapshot must be exactly True for a covered file; otherwise SPEC_TASK_BASELINE_UNVERIFIED.
- If a preview includes a task's earlier spec_snapshot_sha256, it is compared with the captured aggregate snapshot. Stale or invalid pins become blockers.
- Legacy tasks without stored aggregate snapshot remain FILE_MATCHED_UNPINNED_LEGACY in the nonstrict mode, with no claim of full evidence validity.
- The explicit --require-spec-pin mode denies advisory QA-ready status for unpinned legacy tasks. It is NOT enabled by default, since this would strand legitimate historical reviews without an approved rollout/migration.
- Existing confirmed independent negative QA keeps higher-priority BLOCKED_KNOWN_NEGATIVE_QA state even when spec drift is also present; both blocker codes are included.
- Active or unknown reviewer leases are not inspected or taken over. No leases, queue states, task records, host permissions, tests, reviewer acceptances, or merges are mutated.
- Every report says ADVISORY_ONLY and review_authority_verified=false. Passing these checks grants neither review acceptance nor release.

## Local usage

Read-only default (historical behavior, no expensive full spec audit):
    python review_readiness_matrix.py --limit 5

Opt-in source freshness check, preserves legacy reviewers:
    python review_readiness_matrix.py --with-spec-snapshot --limit 5

Strict forward-looking pin check (not appropriate for pre-migration legacy queue):
    python review_readiness_matrix.py --with-spec-snapshot --require-spec-pin --limit 5

The new options use the existing local OpenSpec and SDD sources; no external network or dependencies are installed.

## Actual live read-only smoke test

Normal snapshot mode on the then-current queue: 16 pending reviews inspected, 13 READY_FOR_INDEPENDENT_QA, 3 BLOCKED_KNOWN_NEGATIVE_QA; 12 spec source files rechecked, current aggregate SHA256 = 51b5df759bfaa4689eee65ba861fa77fc8021f50d5a58cb5c582c63a348c8825. The SHA is a point-in-time observation, not immutable across concurrent agent edits.

Strict aggregate-pin mode on the same then-current queue: 13 SPEC_SNAPSHOT_REVERIFICATION_REQUIRED (missing previous aggregate pin), 3 BLOCKED_KNOWN_NEGATIVE_QA; zero falsely QA-ready. No task records were modified.

## Tested code and hashes

- review_readiness_matrix.py: eb9f0ca8499969ed45cb7ba9ae3e77d5e2b0707f58498ca4bdc12f4beecd778f
- test_review_readiness_matrix.py: 6e76b9ee010acca1cb55fd44abdd4fbbbaaf28c82a5bef8885306816a693697c
- Reused unchanged spec_traceability.py: 0f68abb3b6a3603a401ac4669ba9c0f5d4fc8533960e2a484711ef2fc37dc739

Executed verification (all exit 0):
- python test_review_readiness_matrix.py: 28 tests, no failures or skips.
- python -m unittest discover -p test_review*.py: 83 tests, 2 skipped, 0 failures.
- python -m unittest discover -p test_spec*.py: 113 tests, 4 skipped, 0 failures.
- python test_agent_team.py: 54 tests, 1 skipped, 0 failures.
- python sdd_roadmap_check.py: 58 mapped roadmap tasks, no structural errors.
- python spec_check.py: 11 OpenSpec capabilities, 99 requirements, 128 scenarios, 43 SDD FR mappings; no structural errors.
- python ops.py spec_report Local-Workspace-Extensions local-pc-agent-tooling --strict: upstream validation valid; separate custom report still finds 56 unmapped OpenSpec requirements.

Unique suites (the focused 28 overlap the review suite): 83 + 113 + 54 = 250 test invocations, 7 skipped, no failures.

## Explicit limits and next actions

1. A source fingerprint binds a point-in-time read-only snapshot of 12 specs, but is not an atomic cross-filesystem/SQLite snapshot or host-authenticated identity.
2. New aggregate pins are not yet persisted by the existing authoritative coordinator. Add such fields only through owner-approved schema/contract migration; do NOT write task SQLite directly or silently retrofit historical QA.
3. Default existing review jobs do not run --with-spec-snapshot; it is opt-in until workload, legacy migration and owner-admission policy are separately reviewed.
4. P085 actual host principal security and broad run_script bypass remain separate, unverified production gates.
5. The 56 missing explicit FR mappings still require owner-reviewed disposition; no checkboxes or fake FRs were created to hide them.
6. Future reviewer adoption should measure latency and false-stale rate, then explicitly decide whether --with-spec-snapshot can become default; strict pinning must be canaried with backward-compatibility evidence.
7. Runtime QA, independent reviewer receipts and production release have NOT been granted by these read-only tests.

This is an advisory reviewer-queue integrity enhancement, not a second reviewer or owner-approval mechanism.
