# P085 — доступ к реальному MCP-host и staged observer hardening

Дата: 2026-11-02. **Status: source accessed; staged restricted-profile implementation tested. Live host NOT modified. P085 NOT accepted.**

## Подтверждённые исходники

- Владелец выполнил `python .\mcp_host_source_import.py` в собственном PowerShell.
- Скопированы **12** Python файлов из `%USERPROFILE%\Downloads\local-workspace-mcp` в `mcp-host-source/`.
- SHA исходного импорта сохранены в `mcp-host-source/SOURCE_MANIFEST.json`; настройки, ключи, журналы, состояние и `.env` не импортированы.
- `mcp-host-source/` остаётся в `.gitignore`: не публиковать полный случайный host state.
- Отличие от старого `host_snapshot/`: реальный `manage.py` содержит интеграцию `TOKEN_FORENSICS_BRIDGE_V1`. Сохранили её в legacy mode; в observer mode эта добавочная функциональность не загружается.

## Внесённые изменения только в копии

| Код | Изменение | Новый SHA-256 |
|---|---|---|
| `mcp-host-source/manage.py` | `serve --profile observer` по умолчанию, `--profile legacy` только для отдельного контролируемого процесса; bridge extensions исключены из observer | `7b0363bbd51993b3824bd51664f6ab017090e4816444519ce11a862d84e84869` |
| `mcp-host-source/workspace_mcp/tools.py` | Ровно 6 allowlisted read-only tools; запрет прямого вызова скрытых инструментов; санитизация отображаемых `write/execute/git` разрешений | `dc61caa40e86f54be42b3b07d2808bf570c79f9c7e2575372386cc1ba2f3f733` |
| `mcp-host-source/workspace_mcp/http_server.py` | `tools/list` показывает только разрешённое; `tools/call` скрытых инструментов даёт indistinguishable `Unknown tool` до исполняемого callback | `753a1be77bb9f5db9410aeffe1aaa9850b9b32a0d9d99c15cdc3ab9c92d5620a` |
| `mcp-host-source/tests/test_capability_profiles.py` | Негативные unit + real ephemeral-loopback HTTP tests, прямой `run_script` и `write_file`, попытки подставить role, extension registry bypass | `1c7cafca3564ed933e4c22d4c3b2ce67785bccd87bbc5540f37754910967d096` |

Source-verified review patch (tracked, no live installer):
`host_patches/P085_observer_profile_review.patch` — baseline сверена по `SOURCE_MANIFEST.json`. Исходные `http_server.py` и `tools.py` совпадали по SHA с `host_snapshot/`. Review patch существует для независимого ревью и переноса через явный owner-controlled план, **не выполнять автоматически**.

Тестовый интерфейс observer показывает только `list_workspaces`, `list_directory`, `directory_tree`, `file_info`, `read_file`, `search_text`. Универсальные `run_script`, `run_command`, `run_tests`, запись, Git, job status/logs и новые extension tools запрещены. Даже read-only git tools намеренно исключены из-за возможных внешних Git drivers.

## Проверки

- `python -m unittest discover -s tests -q` в `mcp-host-source/`: **34 tests OK, 1 skipped**.
- `python -m unittest test_mcp_host_mirror_profiles test_mcp_host_source_import -q` из корня: **8 tests OK, 1 skipped**.
- Полный тестовый набор проекта `python -m unittest discover -q`: **1476 tests OK, 37 skipped**.
- `openspec validate add-agent-foundation-hardening --strict` плюс SDD: **12 FR, 36 scenarios, 12 mappings, valid**.

## Границы безопасности

1. **P085 не решена полностью:** observer profile — только статическое сужение набора инструментов процесса, **не аутентификация 5 разных ChatGPT ролей**. Клиентские строки `role`, `actor_id`, заголовки и `host_claim` не становятся доверенными.
2. Принудительное применение observer к **текущему** scheduled MCP отключит у разработчиков исполнение и запись, поэтому **не разворачивать вместо действующего MCP с 28 инструментами** без новой двухконтурной схемы.
3. Для корректной автономности нужен отдельный защищённый Windows service SID/account, ACL к исполняемому коду/SQLite/ключам, а также authenticated broker с revocable one-use scoped grants. Уже имеется эксперимент `experiments/foundation_kernel/` (signed policy, native named pipe, negative tests). Его нельзя считать подключённым к host.
4. В частности, один legacy HTTP сервер с `run_script` и `run_command` на том же Windows OS account может обойти любую локальную Python проверку роли. `--profile legacy` — **не** доверенный owner/reviewer и не должен быть доступен scheduled agents.
5. Observer читает разрешённые roots; без отдельной ограниченной копии конфигурации и OS-пользователя даже read-only доступ может раскрыть непредусмотренные файлы. Не разворачивать наружу без scope/auth.
6. Для production gate необходимы отрицательные **реальные Windows межпользовательские** тесты ACL/SID, spoofed reviewer, replay, grant expiry, direct SQLite/file write, source/spec SHA drift, сбоев между merge intent/receipt, persistent revocation.

## Укрепление профиля v2 — 2026-11-02 (отдельный review patch)

После импорта появились параллельные работы над `workspace_mcp/review_grants.py`, поэтому
правки host registry/HTTP отделены от работы другого агента. Старый патч v1 **не
перезаписывался**. Новый точный baseline-verified патч:
`host_patches/P085_observer_profile_sealed_v2.patch`,
SHA-256 `5c0359d4f10ac773a4d100d33f8c8845b27e59994859692cbfb304a107a61d21`.

- `manage.py`: `serve --profile legacy` теперь **отказывается запускаться**
  (`LEGACY_HTTP_PROFILE_DISABLED_WITHOUT_TRUSTED_HOST_BROKER`); обычное
  автономное созидание требует отдельного изолированного канала, а не
  ослабления этого запрета. SHA `b8744ad0f524cbcfa8f06973ea7c746c40bab512d01162184964e4600f906c5a`.
- `workspace_mcp/tools.py`: default registry = `observer`; регистрации
  после создания запрещены, существующие имена нельзя перезаписать,
  runtime-dispatch mapping и callbacks заморожены через `MappingProxyType`.
  Это защищает от непреднамеренной подмены `read_file` внутри обычных
  расширений; не защищает против вредоносного кода с тем же OS SID.
  SHA `c2b791c0a5f5f66b85c4b9c9282630147a78ccb17ee2b5ccda3141a7275f7705`.
- `workspace_mcp/http_server.py`: `make_handler()` валидирует
  `observer` ещё до создания HTTP listener и блокирует любой `legacy`;
  `/healthz.tools` показывает разрешённые инструменты, а не полный
  внутренний реестр. SHA `b08b96676268a5bcb3e7b84987e4a0a0b8e0975266b77e8e628b16594824d6b7`.
- `assert_safe_http_profile`: ровно ожидаемый реестр из 28 исходных
  инструментов с шестью опубликованными read-only tools; все объявленные
  `roots` должны иметь `read=true` и `write=execute=git=false`;
  конфигурация и state_dir находятся вне опубликованных roots. Это
  **проверка заявленных config-флагов**, не OS ACL/SID attestation.
- Тесты: попытка подмены `read_file` даже с `readOnlyHint=true`,
  прямой legacy HTTP, unsafe writable root, control path inside root,
  off-profile `run_script`, HTTP spoof, и подсчёт опубликованных tools.
  Результат прицельного набора **13/13 OK**.

**Остаточный P0:** реальный host-process работает по исходному legacy
исполняемому коду; патч **не применялся** к нему. Реально доверенная
идентификация архитектора, выдача одноразового grant, OS-принципалы,
revocation и безопасная интеграция trusted broker остаются не завершены.
Отдельная разработка `review_grants.py` учитывается только после
независимого ревью и проверенных тестов.

## Следующее усиление: HTTP authentication и предсказуемый отказ (v4)

**Статус:** staged code only; действующий host с 28 privileged tools всё
ещё работает по старым исходникам, даже если staged suite зелёный.

- В копии observer `/mcp` требует Bearer credential из
  `LOCAL_MCP_OBSERVER_BEARER` (длина 43–128, URL-safe ASCII).
  Параметры MCP, JSON-поле `role`, URL и произвольные заголовки
  не являются доверенным источником principal. Ключ **не** записывается
  в репозиторий, CLI, журнал или тестовый отчёт. Доступ к `/healthz`
  остаётся локальным и не даёт вызовов `tools/call`.
- Без credential observer listener отказывается запускаться. Такую
  проверку **нельзя считать authenticated reviewer role**: общий bearer
  различает только обладающих транспортным секретом, не пять агентов.
  Отдельная запись/review потребует trusted OS SID + scoped grant.
- Исправлен стабильный Windows `WinError 10053` на неавторизованных
  POST: bounded тело (до `MAX_BODY`) читается с таймаутом до ответа
  `401`/`403`, но JSON не разбирается до проверки bearer; Origin
  и Host проверяются до dispatch. При таймауте соединение закрывается,
  не выполняя инструменты. Утечки тела/token в журнал исключены.
  `413`/rate limit могут прерывать нечитанный поток — это отдельное
  поведение ограничения ресурса, не доказательство полного HTTP hardening.
- Для реального observer rollout нужно отдельное ограниченное
  `config.json` с `write=execute=git=false`, конфиг/state вне
  разрешённых roots и OS read-only principal. Текущие root flags
  `projects` (read+write+execute+git) для такого запуска **не подходят**.
- Ревью-патч `host_patches/P085_observer_bearer_http_v4.patch`,
  SHA-256 `6e88bbde4676a34baa1ab6aac8ff3761f6f75712a2c3dadd4a7c4a26039122e0`.
  v1/v2/v3 оставлены неизменными для traceability.
- Independent host suite: `python -m unittest discover -s tests -q`:
  **76 тестов OK, 2 skipped** после исправления HTTP post-drain.
  Финальная приёмка требует ещё полных тестов основного проекта и
  реального Windows multi-SID/ACL E2E.

## Мультиагентный QA и изоляция работ

`test_mcp_host_mirror_profiles.py` запускает **только собственные**
`test_capability_profiles.py` и `test_http.py`, потому что
игнорируемый `mcp-host-source/` одновременно изменяют другие агенты.
Это устраняет систематическую зависимость root unit-тестов от
незавершённых чужих фич. **Полный** mirror-suite остаётся обязательным
отдельным strict quality gate перед P085 release и не может быть подменён
частичным прогоном. Дефекты `review_grants.py` /
`review_target_snapshot.py` были найдены при такой полной проверке;
чужие исходники не перезаписывались, окончательная проверка выполняется
на фактической текущей версии после их исправления.

## Следующий безопасный этап

- На основе доступных исходников подготовить изолированный **agent read-only endpoint** и отдельный **trusted broker/owner plane**, не заменяющий живую систему до допуска.
- Доработать реальный broker host identity/permissions используя уже существующий foundation kernel вместо параллельной реализации.
- Сделать независимый predeployment review, owner-approved backup/rollback, отдельный OS principal и E2E. Только после этого формально закрывать P085 и менять очередь ревью.
- Нынешний real MCP на `127.0.0.1:8765`, туннель и SQLite очереди не перезапускались и не изменялись данной операцией.
