# Owner-directed manual integration of 16 corrected modules (2026-11-04)

**Status:** SOURCE FILES CREATED IN CANONICAL PROJECT ROOT; full tests passed. This is **not** formal reviewer acceptance, a host identity/ACL attestation, release approval, or an agent queue merge.

## Scope

The user explicitly requested that previously corrected source files be applied. The Local Workspace MCP confirmed `projects` writable. Before applying, `.agent-team/owner-review-fixes/20261104/integrate_corrected_modules_into_main.py` ran a dry-run, checked the exact SHA-pinned source manifest and verification evidence, and confirmed 33 destination filenames absent, with zero conflicts.

The create-only script then wrote all 33 files **directly into `Local-Workspace-Extensions/`**, not merely staging:
- **16 corrected implementation modules:** `task_dag_schema.py`, `agent_metrics_series.py`, `media_rights_schema.py`, `lease_continuity_policy.py`, `mcp_trace_coverage_audit.py`, `usage_calibration_evidence.py`, `mcp_trace_failure_cases.py`, `mcp_trace_retention_plan.py`, `lease_restart_audit.py`, `usage_coverage_dashboard.py`, `workspace_boundary_evidence.py`, `job_poll_reconciliation.py`, `checkpoint_recovery_audit.py`, `agent_budget_guardrails.py`, `tool_risk_contract_audit.py`, and `rollback_preview_audit.py`.
- **17 test modules:** one `test_<module>.py` for each module plus `test_fixed_defect_regressions.py` with 18 additional independent regression scenarios.

The source and test files were previously tested in isolated candidate source tree (`507` tests PASS). Manual integration evidence was written under `.agent-team/owner-review-fixes/20261104/manual_main_integration_receipt.json` with SHA-256 `8d062804e2de7fdb55b0167ff2c95680335c408ddd32e5565aebca068872d24c`.

**Idempotence verification:** Job `c8c92e134bd54e69a7af560432170ad6` completed rc=0 with `to_create=0`, `already_identical=33`, `conflict_count=0`. Every canonical destination's SHA matched the pinned original candidate bytes.

## Test fixture repair after canonical integration

Unmodified production queue supply planner rightly denies new task proposals when their output filenames already exist in main (`SOURCE_EXISTS_*`). Five old test assertions erroneously assumed this root directory would forever be free of the planned files. We did **not** modify the planner's source-existence denial:
- Created `experiments/chat_only_run/supply_plan_fixture.py` to copy canonical spec input files into a disposable empty project tree and execute the **same real** `plan(..., project=temporary_dir)` function.
- Updated `test_next_wave_supply.py` (4 PASS) and `test_queue_supply_plan.py` (11 PASS) to use this isolated fixture. The source-exists negative test creates a real file in the temporary fixture and expects the blocker, preserving the safety contract.
- Updated only a deterministic test in `test_p085_windows_deploy_preflight.py` to exercise mocked system-only ACLs on a plain temporary file instead of `sys.executable`, which on some installations is inside a junction/symlink; no `os_protected` or host security logic was relaxed. Its 12 targeted tests passed.

## Final verification

| Check | Job ID | Result |
|---|---|---|
| Manual code integration | `e320b968ec0b4c37b4acc328b7ff9a05` | completed rc=0, 16 source + 17 test files created and SHA checked |
| Full unittest discover from canonical root | `4f18249af12c439ebab9d3dc30e7ffb4` | completed rc=0, **2305 tests OK (43 skipped)** |
| OpenSpec/SDD structural checker | `35ad87d26baa45599b81aa06b2523903` | completed rc=0; 99 requirements, 128 scenarios, 58 SDD tasks, errors=[] |
| SDD roadmap checker | `c0c4de4aceea4f4e80f39a4793ea31f7` | completed rc=0, errors=[] |
| Architecture/reuse CI | `0cd7cc43a98242549460cc104e3ec34c` | completed rc=0, no duplicate groups detected |
| 33 SHA-identical files on rerun | `c8c92e134bd54e69a7af560432170ad6` | completed rc=0, all 33 identical, zero writes needed |
| Strict live review matrix | `16a4488e240a4875bf401055b80ce592` | completed rc=0; 16 inspected, 0 QA-ready, 15 known negative QA findings, 1 source-preflight blocker |

## Governance and unresolved risks

- `.agent-team/team.sqlite3`, reviewer leases, tasks, old acceptance receipts, host ACLs and Windows principals were **not altered**. No privileged agent actor identity or trusted broker grant was claimed. No Git operations performed.
- **Important:** the files now exist in canonical root *before* task review. The ordinary agent reviewer may therefore report `SOURCE_EXISTS_*` or other source conflicts for these Pxxx tasks. The 16 original task submissions remain unaccepted; **a future authorized owner/reviewer must reconcile this manual publication with each task's SHA-fenced evidence**. Never mark the original task as accepted merely because an identical source file exists, and never rewrite the old acceptance ledger.
- Existing P085 host actor authentication/broker/OS protection, P096 expired lease, P104 accepted SHA drift, and P108/P111/P148 rework remain separate issues.
- No deployment, running-service reload, or trusted Windows end-to-end validation was done. Passing unit tests verifies code behavior, **not** actual host authorization or use of these newly published APIs by a running agent.

## Reproduction

From `Local-Workspace-Extensions`:

```powershell
python -m unittest discover -q
python spec_check.py
python sdd_roadmap_check.py
python agent_reuse_ci_gate.py
python .agent-team/owner-review-fixes/20261104/integrate_corrected_modules_into_main.py
```

The final command is the **read-only SHA/idempotence preview** unless `--apply` is explicitly provided.
