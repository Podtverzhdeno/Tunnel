# Контроль пятиагентной команды и структурированных доказательств приёмки

Дата: 2026-11-01, 17:19 UTC.
Проект: C:\Users\user\IdeaProjects\Local-Workspace-Extensions.

## Фактическое состояние

По `agent_team.py overview`: **8 done / 1 working / 1 review**.
- P009/P010/P015/P016/P018/P033/P034/P092: done.
- P021: developer-2, working (offline dependency review).
- P095: developer-1, review (scene dependency release plan).
Все роли продолжают использовать действующую SQLite-очередь; отдельного заявления о пяти одновременно работающих процессах нет. Developer-3 и Developer-4 используют одну часовую автоматизацию последовательно.

## Реализованное изменение FR-040 / P097

Проблема: прежний `event(action=accept)` имел жёсткое ограничение `detail[:1600]`. При наличии трёх команд с логами тестов JSON о QA получался обрезанным, и старые события нельзя строго перепроверить.

Изменения:
1. `agent_team.py` при инициализации создаёт `acceptance_records` без удаления истории. Для новых операций `review accept` в **одной SQLite-транзакции** с переходом в `done` сохраняются task ID, reviewer role label, timestamp, QA command names, exit codes, SHA-256 stdout/stderr tails, SHA-256 новых файлов, checksum актуальной canonical OpenSpec.
2. В `events` теперь фиксируется короткая машинно-читаемая ссылка `acceptance_evidence_sha256`, а не усечённый QA JSON. Логи тестов не копируются в долгосрочную новую таблицу — только их хеши.
3. `team_acceptance_audit.py` анализирует SQLite в режиме `query_only`, закрывает соединение для Windows и не изменяет файлы. Классы: `recorded_pass`, `legacy_unverifiable`, `invalid_evidence`, `not_accepted`. Последующие принятые ревизии корректно заменяют более старые хеши файлов, а не маркируют их подменой.
4. `test_team_acceptance_audit.py` проверяет правильные/неполные QA записи, malformed JSON, недопустимые артефакты, несовпадение SHA, legacy records, superseded revisions и отсутствие side effects.
5. Дополнены тесты `test_agent_team.py` на **настоящую** приёмку после unittest + SDD + OpenSpec и на атомарный rollback acceptance_record при SQL-ошибке, и сохранение при прерванной post-commit очистке журнала.
6. Текст OpenSpec и SDD дополнен `Durable acceptance evidence and conservative audit`, FR-040, T045/T046, P097/P098. Документация: `docs/ACCEPTANCE_EVIDENCE.md` и `docs/FIVE_AGENT_TEAM.md`.
7. Prompt scheduled `OpenSpec — Architect Reviewer` обновлён: после будущих `accept` обязан запускать auditor и проверять новую запись, не принимать старые `legacy_unverifiable` за доказанную подлинность.

## Результаты проверок

- `python -m unittest discover`: **340 tests, 321 PASS, 19 SKIP**, return code 0.
- `python spec_check.py`: **11 capabilities, 96 normative requirements, 116 scenarios, 40 SDD FR mappings, 46 SDD tasks, 99 OpenSpec tasks**, errors=[].
- `validate_upstream.py`: OpenSpec CLI 1.14.3, strict PASS.
- `agent_team.py gate-check`: unittest, spec_check, real OpenSpec strict — all PASS.
- `run_mcp_wire.py`: 16/16 standalone stdio MCP checks PASS; не означает регистрацию нативных инструментов в действующем Local Workspace backend.
- `team_acceptance_audit.py`: recorded_pass=1 (P033), legacy_unverifiable=7, invalid_evidence=0, not_accepted=2. Реальные исторические события не подменялись вымышленными QA.
- `agent_team.py overview`: done=8, working=1, review=1 на 17:19 UTC.

## Критические ограничения

**Host-level reviewer identity P085/P098 остаётся неподтверждённой.** Доверенным доказательством являются только значения локальной SQLite, которые сами по себе не защищены от процесса с общими OS-полномочиями. Поэтому аудит намеренно возвращает `host_actor_authenticated=false`, `os_sandbox_enforced=false`, `production_authorization_ready=false` даже при recorded_pass.

Нельзя выдавать `recorded_pass` за подтверждённое исполнение тестов независимым сервером или за готовность выполнять привилегированные операции. Старые 7 accepted tasks помечены `legacy_unverifiable`; требуется отдельная переоценка, а не слепое заполнение таблицы.

`P095` только на ревью, а `P021` в работе. Эти задачи не отмечались готовыми в этой итерации. Новые исправления не затрагивали их allowlisted deliverables.
