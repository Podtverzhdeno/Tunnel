# Полный backlog функций для 5-агентного проекта

**Статус: план, НЕ согласованное изменение OpenSpec и НЕ задачи в live SQLite.** Канонические изменения проходят owner approval, OpenSpec strict, SDD dependency gate и независимый Reviewer.

**Проверено:** 72 идеи; 45 отдельных implementation tracks, 20 объединены без дублирования, 4 отложены, 3 отвергнуты.

## Выпуск по зависимостям (отличается от рейтинга)

| Волна | Количество идей | Контроль допуска |
|---|---:|---|
| W0 | 31 | Owner-approved canonical OpenSpec/SDD, independent QA receipts, no lease conflicts |
| W1 | 11 | W0 execution correctness baseline and original regression tests green |
| W2 | 13 | Approved source/media rights and a safe real preview render pipeline |
| W3 | 10 | Measured W2 footage/scene test fixture, reviewer quality rubric and render QC |
| W4 | 0 | Holdout evaluation or observed scaling pressure; not part of first rollout |
| DEFER | 4 | Only if new architecture/workload makes it cost-effective |
| REJECT | 3 | Not authorized; design would weaken safety or add overhead without demonstrated benefit |

W0: восстановление сессий, память, безопасные sandbox/leases и независимая проверка. W1: повышение стабильности и качества. W2: работающий монтажный pipeline. W3: профессиональное качество изображения и звука. W4: масштабирование и эксперименты.

## Все идеи, строго по исходному рейтингу

| № | Score | Фича | Волна | Решение | Зависит от |
|---:|---:|---|---|---|---|
| 1 | 99 | Безопасный sync-sandbox при изменениях core | W0 | adopt_after_canonical_approval | — |
| 2 | 98 | Контекстный пакет при каждом запуске | W0 | adopt_after_canonical_approval | — |
| 3 | 97 | Транзакционная парковка и переключение задач | W0 | adopt_after_canonical_approval | MF-007 |
| 4 | 97 | Память решений с доказательствами и TTL | W0 | adopt_after_canonical_approval | — |
| 5 | 97 | Контроль устаревших спек и контекста | W0 | merge_into → MF-002 | — |
| 6 | 95 | Durable step journal + replay | W0 | adopt_after_canonical_approval | MF-002 |
| 7 | 95 | Диспетчер DAG на основании acceptance | W0 | adopt_after_canonical_approval | — |
| 8 | 95 | Управление таймкодами на уровне кадров | W2 | adopt_after_canonical_approval | MF-020, MF-028 |
| 9 | 95 | Чёткий следующий исполнимый шаг | W0 | merge_into → MF-002 | — |
| 10 | 94 | Реестр проверенных артефактов по SHA | W0 | adopt_after_canonical_approval | MF-002 |
| 11 | 94 | Пайплайн reviewer preflight с доказательствами | W0 | adopt_after_canonical_approval | MF-022 |
| 12 | 94 | Watchdog зависших задач + recovery hints | W0 | merge_into → MF-003 | — |
| 13 | 94 | Автоматический audio QC | W3 | adopt_after_canonical_approval | MF-015 |
| 14 | 92 | Семантика восстановления после непонятного tool timeout | W0 | merge_into → MF-006 | — |
| 15 | 92 | Метрически проверяемый рендер-превью | W2 | adopt_after_canonical_approval | MF-020 |
| 16 | 92 | Финальная сборка по accepted scene DAG | W2 | adopt_after_canonical_approval | MF-010, MF-015, MF-020 |
| 17 | 92 | Тесты на рестарт/crash injection | W0 | merge_into → MF-006 | — |
| 18 | 92 | Проверка источников видео и лицензий | W2 | adopt_after_canonical_approval | — |
| 19 | 92 | Самоисправление по красным тестам | W0 | adopt_after_canonical_approval | MF-011 |
| 20 | 92 | Стабильные пакетные сценовые контракты | W2 | adopt_after_canonical_approval | MF-002 |
| 21 | 92 | Структурированный mailbox + ACK между ролями | W0 | adopt_after_canonical_approval | MF-004 |
| 22 | 92 | Матрица требования→тест→артефакт | W0 | adopt_after_canonical_approval | MF-007 |
| 23 | 92 | Честный классификатор тестовых сбоев | W0 | merge_into → MF-019 | — |
| 24 | 91 | Автопроверка кода в независимом runner | W0 | merge_into → MF-011 | — |
| 25 | 91 | Продуктивность по accepted throughput | W0 | adopt_after_canonical_approval | MF-011 |
| 26 | 90 | Сценовая память визуальной непрерывности | W3 | adopt_after_canonical_approval | MF-004, MF-020 |
| 27 | 89 | Субтитры с контролем читаемости | W3 | adopt_after_canonical_approval | MF-015 |
| 28 | 89 | Редакторская timeline в OpenTimelineIO | W2 | adopt_after_canonical_approval | MF-020 |
| 29 | 89 | Кросс-сценовый контроль continuity | W3 | adopt_after_canonical_approval | MF-026, MF-028 |
| 30 | 88 | Безопасная изоляция процессов у host | W0 | adopt_after_canonical_approval | — |
| 31 | 87 | Сцено-кадровый анализ видеоматериала | W2 | adopt_after_canonical_approval | MF-020 |
| 32 | 86 | Автоматическая нарезка задачи на проверяемые slices | W1 | adopt_after_canonical_approval | MF-007 |
| 33 | 86 | Визуальный Director/critic по превью | W3 | adopt_after_canonical_approval | MF-015, MF-011 |
| 34 | 86 | Preview render profiles и proxy media | W2 | adopt_after_canonical_approval | MF-015 |
| 35 | 85 | Трассировка всех tool calls с causal IDs | W1 | adopt_after_canonical_approval | MF-006 |
| 36 | 84 | Речевой и музыкальный rhythm map | W3 | adopt_after_canonical_approval | MF-020 |
| 37 | 83 | Шаговый журнал изменений по source SHA | W0 | merge_into → MF-006 | — |
| 38 | 83 | Собственный benchmark непрерывных задач | W1 | adopt_after_canonical_approval | MF-011 |
| 39 | 83 | Снимки восстановления SQLite и проверка restore | W0 | merge_into → MF-006 | — |
| 40 | 83 | Семантический поиск по локальным решениям | W0 | merge_into → MF-004 | — |
| 41 | 83 | Versioned reusable agent skills | W1 | adopt_after_canonical_approval | MF-004 |
| 42 | 83 | Выбор tools по принципу минимального набора | W0 | merge_into → MF-030 | — |
| 43 | 83 | Смысловой storyboard из сценария | W2 | adopt_after_canonical_approval | MF-020 |
| 44 | 82 | Глобальная music rights / provenance карта | W2 | merge_into → MF-018 | — |
| 45 | 80 | Mutation/property-based тестирование | W1 | adopt_after_canonical_approval | MF-011 |
| 46 | 80 | Распределение нагрузки по ожидаемой сложности | W1 | adopt_after_canonical_approval | MF-007 |
| 47 | 80 | Планирование бюджетоёмких запусков | W1 | adopt_after_canonical_approval | MF-003 |
| 48 | 80 | A/B тестирование workflow-промптов | W1 | merge_into → MF-038 | — |
| 49 | 80 | Кэширование подтверждённых тестов по SHA | W0 | merge_into → MF-011 | — |
| 50 | 80 | Контроль цветов и shot matching | W3 | adopt_after_canonical_approval | MF-026 |
| 51 | 80 | Автоматическая подсветка неуместного B-roll | W3 | adopt_after_canonical_approval | MF-031 |
| 52 | 80 | Мониторинг сломанных dependencies/packages | W1 | adopt_after_canonical_approval | MF-011 |
| 53 | 80 | Снимки сцен с редактируемой историей | W2 | adopt_after_canonical_approval | MF-028 |
| 54 | 80 | Scene style templates и проверка соответствия | W2 | adopt_after_canonical_approval | MF-020 |
| 55 | 80 | Система обратной связи по ошибкам ревью | W0 | merge_into → MF-004 | — |
| 56 | 80 | Контроль частых повторов модели/вызовов | W0 | merge_into → MF-019 | — |
| 57 | 80 | Audio ducking и баланс диалогов/музыки | W3 | adopt_after_canonical_approval | MF-013 |
| 58 | 79 | Git PR auto-draft с reviewer gate | W1 | adopt_after_canonical_approval | MF-011 |
| 59 | 78 | Параллельные альтернативы монтажа A/B | W3 | adopt_after_canonical_approval | MF-015 |
| 60 | 78 | Карта решений архитектуры (ADR graph) | W0 | merge_into → MF-004 | — |
| 61 | 77 | Human escalation SLA по инцидентам | W0 | merge_into → MF-003 | — |
| 62 | 75 | Сравнение качества LLM-агентов по заданиям | W1 | adopt_after_canonical_approval | MF-038 |
| 63 | 75 | Захват неизменяемого контекста тестовой среды | W0 | merge_into → MF-011 | — |
| 64 | 75 | Динамическое перераспределение времени агентов | W0 | merge_into → MF-003 | — |
| 65 | 74 | Адаптер экспорта под NLE редакторы | W2 | adopt_after_canonical_approval | MF-028 |
| 66 | 64 | Восстановление после split-brain нескольких машин | DEFER | defer | — |
| 67 | 64 | Распределённый оркестратор Temporal | DEFER | defer | — |
| 68 | 54 | Векторная память всего рабочего чата | DEFER | defer | — |
| 69 | 43 | Платный vector DB/RAG до качественного индексирования | DEFER | defer | — |
| 70 | 40 | Автоматическая публикация и merge без участия человека | REJECT | reject_now | — |
| 71 | 40 | Десять новых агентов без увеличения независимых окон | REJECT | reject_now | — |
| 72 | 37 | Самоизменяющиеся промпты без eval/approval | REJECT | reject_now | — |

## Definition of Done по каждой функциональности

### MF-001 · Безопасный sync-sandbox при изменениях core — 99/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Автоматический preflight: stale test/runtime; sync только snapshot-owned под lease.
**Критерий приёмки:** Preflight reports stale owner snapshot and permits sync only with a valid current lease; fails closed on modified agent deliverable..
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-002 · Контекстный пакет при каждом запуске — 98/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Достоверные spec, lease, checkpoint, замечания и SHA; пакет собирается заново, ограничен по размеру.
**Критерий приёмки:** A role with no earlier chat restores task/spec/reviewer context from a bounded source-hashed packet; no stale spec may be accepted..
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-003 · Транзакционная парковка и переключение задач — 97/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** пока политика.
**Результат:** P096 блокирует только себя; другая безопасная задача под отдельным lease доступна.
**Критерий приёмки:** P096-style blocked work is parked by authorized event; developer obtains independently ready P110 under separate legitimate lease..
**Зависимости:** MF-007.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-004 · Память решений с доказательствами и TTL — 97/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** нет.
**Результат:** Хранит принятые ADR, неудачные попытки и источники; отзывается при изменении SHA.
**Критерий приёмки:** Reviewed facts survive restart, while stale, self-generated or out-of-scope memories cannot elevate authority..
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-005 · Контроль устаревших спек и контекста — 97/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** SHA текущего OpenSpec/SDD и исходников перед продолжением, rebase только по процедуре.
**Критерий приёмки:** Ноль принятых результатов со старой спецификацией.
**Включить в:** MF-002, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-006 · Durable step journal + replay — 95/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Персистентные шаги с idempotency key, digest, state и проверкой внешних эффектов.
**Критерий приёмки:** Crash before/after a write preserves exactly the verified ledger state; ambiguous external effect is not retried automatically..
**Зависимости:** MF-002.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-007 · Диспетчер DAG на основании acceptance — 95/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Dependency-ready tasks с проверенными reviewer receipts и непересекающимися write sets.
**Критерий приёмки:** DAG scheduling uses actual accepted QA evidence; unapproved predecessors never unlock tasks..
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-008 · Управление таймкодами на уровне кадров — 95/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** частично.
**Результат:** Рациональная fps/timebase, кадро-точные стыки, проверки накопления ошибки.
**Критерий приёмки:** Frame-accurate composition maintains exact rational fps/timebase and avoids drift at six-scene boundaries..
**Зависимости:** MF-020, MF-028.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-009 · Чёткий следующий исполнимый шаг — 95/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Каждый checkpoint содержит проверенную команду/файл/результат и предпосылки.
**Критерий приёмки:** Новая сессия не тратит запуск на общий разбор.
**Включить в:** MF-002, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-010 · Реестр проверенных артефактов по SHA — 94/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Использовать только принятый код/превью с хешем и QA, не случайный путь.
**Критерий приёмки:** A consumer may use only a matching hash and independent accepted QA receipt; changed assets invalidate dependent results..
**Зависимости:** MF-002.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-011 · Пайплайн reviewer preflight с доказательствами — 94/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Синтаксис, дифф, scope, spec SHA, тесты, секреты, source hash до приёмки.
**Критерий приёмки:** Untrusted worker-produced test output cannot satisfy the independent reviewer and host gate..
**Зависимости:** MF-022.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-012 · Watchdog зависших задач + recovery hints — 94/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Выявление истёкшего lease, stale review, незавершённого merge intent, без обхода ACL.
**Критерий приёмки:** Ни одна блокировка не остаётся без причины и владельца.
**Включить в:** MF-003, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-013 · Автоматический audio QC — 94/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** LUFS/LRA/true peak, провалы, клиппинг, пульсации.
**Критерий приёмки:** Экспорт соответствует выбранному измеримому аудиопрофилю.
**Зависимости:** MF-015.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-014 · Семантика восстановления после непонятного tool timeout — 92/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Различать NOT_APPLIED, CONFIRMED, UNKNOWN и NEEDS_RECONCILIATION.
**Критерий приёмки:** Нет повторного опасного вызова при потерянном ответе.
**Включить в:** MF-006, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-015 · Метрически проверяемый рендер-превью — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** не реализован.
**Результат:** Временные превью, измерение duration/fps/audio/resolution, хеш оригинала.
**Критерий приёмки:** Generate real read-only previews and inspect fps, duration, resolution, errors using installed renderer; source files remain immutable..
**Зависимости:** MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-016 · Финальная сборка по accepted scene DAG — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** частично.
**Результат:** Timeline only from approved scene receipts, not declared completion.
**Критерий приёмки:** Финальный ролик из 6 сцен получается воспроизводимо.
**Зависимости:** MF-010, MF-015, MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-017 · Тесты на рестарт/crash injection — 92/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Kill before/after write, replay, rollback, concurrent readers.
**Критерий приёмки:** Нулевой silent duplicate effects в fault-injection.
**Включить в:** MF-006, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-018 · Проверка источников видео и лицензий — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** частично.
**Результат:** Rights policy на входе, оригиналы immutable, usage rights per shot.
**Критерий приёмки:** Each sourced clip has rights provenance; unknown usage rights block publish/export decisions..
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-019 · Самоисправление по красным тестам — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Bounded execute→diagnose→patch→test, запрещён auto-merge.
**Критерий приёмки:** Bounded red-test repair loop stops safely, does not self-merge, and always performs unchanged independent regression..
**Зависимости:** MF-011.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-020 · Стабильные пакетные сценовые контракты — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** частично.
**Результат:** Каждой сцене — шоты, длительности, задачи, зависимости, входные материалы, критерии QA.
**Критерий приёмки:** An agent that knows only the README and scene contract can generate one scene with verifiable input/output/checkpoints..
**Зависимости:** MF-002.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-021 · Структурированный mailbox + ACK между ролями — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** нет.
**Результат:** Сообщения с message_id, task, artifact SHA, TTL и ACK, только данные не grants.
**Критерий приёмки:** Нет потерянных review notes после часового интервала.
**Зависимости:** MF-004.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-022 · Матрица требования→тест→артефакт — 92/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Шаг не done пока canonical SHALL не подтверждён тестом и review.
**Критерий приёмки:** В принятом PR 0 нетрассируемых требований.
**Зависимости:** MF-007.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-023 · Честный классификатор тестовых сбоев — 92/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Кодовый дефект / stale sandbox / инфраструктура / flake / policy.
**Критерий приёмки:** Снижение бессмысленных rework циклов.
**Включить в:** MF-019, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-024 · Автопроверка кода в независимом runner — 91/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** QA runner отделён от агента и его изменяемых тестов.
**Критерий приёмки:** Невозможно принять патч с поддельным stdout.
**Включить в:** MF-011, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-025 · Продуктивность по accepted throughput — 91/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** частично.
**Результат:** Accepted code/tasks per week, blocked time, rework, QA regressions.
**Критерий приёмки:** Дешёвая модель не выбирается ценой падения качества.
**Зависимости:** MF-011.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-026 · Сценовая память визуальной непрерывности — 90/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** Стиль, цвет, движение, шрифты, персонажи, переходы, зависимости соседних сцен.
**Критерий приёмки:** Сцена 4 согласована с принятыми 3 и 5.
**Зависимости:** MF-004, MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-027 · Субтитры с контролем читаемости — 89/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** SRT/ASS, тайминг, число символов, safe areas, контраст и коллизии.
**Критерий приёмки:** Субтитры не перекрывают объект и попадают в речь.
**Зависимости:** MF-015.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-028 · Редакторская timeline в OpenTimelineIO — 89/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** нет.
**Результат:** Редактируемые треки, клипы, transition, markers, source refs.
**Критерий приёмки:** Export actual readable OTIO timeline with clips/markers/roles and stable asset refs; do not claim OTIO renders frames..
**Зависимости:** MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-029 · Кросс-сценовый контроль continuity — 89/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** Сравнение цветового тона, движения, масштабов, направления, звука.
**Критерий приёмки:** Межсценовые скачки выявлены до финального экспорта.
**Зависимости:** MF-026, MF-028.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-030 · Безопасная изоляция процессов у host — 88/100
**Решение:** adopt_after_canonical_approval; **волна:** W0; **сейчас:** не реализована.
**Результат:** Реальные tool grants, ACL, работа в ограниченных процессах; prompt не является полномочием.
**Критерий приёмки:** Host auth cannot be impersonated by prompt strings or local role fields; R2/R3 effects require actual permission boundaries..
**Гейт:** HOST_AUTH_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-031 · Сцено-кадровый анализ видеоматериала — 87/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** частично.
**Результат:** Кадры/планы, движение, лица/объекты без идентификации личности; индекс таймкодов.
**Критерий приёмки:** Видеоредактор знает, какой план где находится.
**Зависимости:** MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-032 · Автоматическая нарезка задачи на проверяемые slices — 86/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** частично.
**Результат:** Максимум 1–2 файла и воспроизводимые negative tests на slice.
**Критерий приёмки:** Средний цикл review уменьшается без потери качества.
**Зависимости:** MF-007.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-033 · Визуальный Director/critic по превью — 86/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** Контекстные оценки 2–3 кандидатов сцен по рубрике+человек.
**Критерий приёмки:** Blind human rubric comparison determines whether critic selects professionally better scene variants..
**Зависимости:** MF-015, MF-011.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-034 · Preview render profiles и proxy media — 86/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** нет.
**Результат:** Low-res fast previews, финал в оригинальном качестве.
**Критерий приёмки:** Быстрее цикл preview→QA, исходник не изменён.
**Зависимости:** MF-015.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-035 · Трассировка всех tool calls с causal IDs — 85/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** частично.
**Результат:** run→step→tool→artifact→review chain без секретов.
**Критерий приёмки:** Можно объяснить любую регрессию и потерю времени.
**Зависимости:** MF-006.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-036 · Речевой и музыкальный rhythm map — 84/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** Точки пауз/смысловых акцентов/долей для плотного монтажа.
**Критерий приёмки:** Переходы привязаны к смыслу, а не случайным тактам.
**Зависимости:** MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-037 · Шаговый журнал изменений по source SHA — 83/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Proof each patch/file SHA and result revision.
**Критерий приёмки:** Различимы пользовательские изменения и изменения агентов.
**Включить в:** MF-006, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-038 · Собственный benchmark непрерывных задач — 83/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** нет.
**Результат:** Новые unseen баги + scene fixtures; не SWE-bench Verified alone.
**Критерий приёмки:** Измеряем accepted outcomes на holdout.
**Зависимости:** MF-011.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-039 · Снимки восстановления SQLite и проверка restore — 83/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Atomic backup, integrity, restore-to-fixture.
**Критерий приёмки:** После повреждения DB доказуемо восстанавливается состояние.
**Включить в:** MF-006, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-040 · Семантический поиск по локальным решениям — 83/100
**Решение:** merge_into; **волна:** W0; **сейчас:** нет.
**Результат:** FTS/SQLite сначала, provenance-filtered; embeddings только если надо.
**Критерий приёмки:** Агент находит прошлый ADR за пару запросов.
**Включить в:** MF-004, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-041 · Versioned reusable agent skills — 83/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** нет.
**Результат:** Навыки под domain with tests and versions, read-only untrusted data.
**Критерий приёмки:** Повторяемость задач без разбухания промптов.
**Зависимости:** MF-004.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-042 · Выбор tools по принципу минимального набора — 83/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Подбор разрешённых инструментов на основании risk и этапа.
**Критерий приёмки:** Меньше ошибочных и запрещённых вызовов.
**Включить в:** MF-030, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-043 · Смысловой storyboard из сценария — 83/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** нет.
**Результат:** Нарратив→beat-sheet→раскадровка→shot manifest.
**Критерий приёмки:** Есть схема монтажа до затратного рендера.
**Зависимости:** MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-044 · Глобальная music rights / provenance карта — 82/100
**Решение:** merge_into; **волна:** W2; **сейчас:** частично.
**Результат:** License registry at source/segment level.
**Критерий приёмки:** Не используется трек с неизвестным правом публикации.
**Включить в:** MF-018, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-045 · Mutation/property-based тестирование — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** нет.
**Результат:** Генерация adversarial fixtures, не только happy path.
**Критерий приёмки:** Ложноположительные PASS на regression снижаются.
**Зависимости:** MF-011.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-046 · Распределение нагрузки по ожидаемой сложности — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** нет.
**Результат:** Оценка сложности и WIP limit вместо равномерной раздачи.
**Критерий приёмки:** Меньше idle при той же доле принятых задач.
**Зависимости:** MF-007.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-047 · Планирование бюджетоёмких запусков — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** частично.
**Результат:** Длительность/LLM/tool limits, остановка по бюджету с checkpoint.
**Критерий приёмки:** Агент всегда завершает с полезным следующим шагом.
**Зависимости:** MF-003.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-048 · A/B тестирование workflow-промптов — 80/100
**Решение:** merge_into; **волна:** W1; **сейчас:** нет.
**Результат:** Одинаковые задачи, слепые тесты, контрольные выборки.
**Критерий приёмки:** Изменение промпта признаём лучше только по eval.
**Включить в:** MF-038, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-049 · Кэширование подтверждённых тестов по SHA — 80/100
**Решение:** merge_into; **волна:** W0; **сейчас:** нет.
**Результат:** Матрица source/deps/environment digest, избегать повторов.
**Критерий приёмки:** Запускаются только необходимые тесты, full QA не пропускается.
**Включить в:** MF-011, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-050 · Контроль цветов и shot matching — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** LUT/white balance/shot references без бессмысленных пресетов.
**Критерий приёмки:** Меньше заметных скачков цвета.
**Зависимости:** MF-026.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-051 · Автоматическая подсветка неуместного B-roll — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** B-roll mapping к смысловым единицам и разрешённым исходникам.
**Критерий приёмки:** Не возникает случайных кадров, не соответствующих истории.
**Зависимости:** MF-031.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-052 · Мониторинг сломанных dependencies/packages — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** частично.
**Результат:** Offline SBOM/dependency drift, licenses, pinned versions.
**Критерий приёмки:** Фиксируются версии и доказательства изменений.
**Зависимости:** MF-011.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-053 · Снимки сцен с редактируемой историей — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** нет.
**Результат:** Каждый preview+timeline reversible, source untouched.
**Критерий приёмки:** Можно откатить плохой монтаж без восстановления вручную.
**Зависимости:** MF-028.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-054 · Scene style templates и проверка соответствия — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** нет.
**Результат:** Типографика, safe-zone, темп, ограничение переходов.
**Критерий приёмки:** Сцены не разваливаются визуально.
**Зависимости:** MF-020.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-055 · Система обратной связи по ошибкам ревью — 80/100
**Решение:** merge_into; **волна:** W0; **сейчас:** нет.
**Результат:** Memory of failure pattern by role and capability, updated after QA.
**Критерий приёмки:** Повторяемость одних и тех же ревью-ошибок снижается.
**Включить в:** MF-004, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-056 · Контроль частых повторов модели/вызовов — 80/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** Detect same command/test attempts without new evidence.
**Критерий приёмки:** Уменьшение бессмысленных итераций.
**Включить в:** MF-019, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-057 · Audio ducking и баланс диалогов/музыки — 80/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** Автомикс по речевым фрагментам с peak guards.
**Критерий приёмки:** Речь разборчива, музыка не мешает.
**Зависимости:** MF-013.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-058 · Git PR auto-draft с reviewer gate — 79/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** нет.
**Результат:** Только предложение/дифф; push/merge под отдельным подтверждением.
**Критерий приёмки:** Ни одного auto-merge без reviewer.
**Зависимости:** MF-011.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-059 · Параллельные альтернативы монтажа A/B — 78/100
**Решение:** adopt_after_canonical_approval; **волна:** W3; **сейчас:** нет.
**Результат:** Генерация двух разных ритмов/стилей и сравнительный QA.
**Критерий приёмки:** Разные версии выбираются по заданной рубрике.
**Зависимости:** MF-015.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-060 · Карта решений архитектуры (ADR graph) — 78/100
**Решение:** merge_into; **волна:** W0; **сейчас:** нет.
**Результат:** Почему выбрали конкретный контракт, кто утвердил, что заменяет.
**Критерий приёмки:** Неизвестный агент не предлагает отвергнутую архитектуру.
**Включить в:** MF-004, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-061 · Human escalation SLA по инцидентам — 77/100
**Решение:** merge_into; **волна:** W0; **сейчас:** нет.
**Результат:** Типы блокировок и кто/когда принимает решение.
**Критерий приёмки:** Важные блокировки не забыты.
**Включить в:** MF-003, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-062 · Сравнение качества LLM-агентов по заданиям — 75/100
**Решение:** adopt_after_canonical_approval; **волна:** W1; **сейчас:** нет.
**Результат:** Counterfactual eval of model/effort on reproducible tasks.
**Критерий приёмки:** Меняем модель только при подтверждённой выгоде.
**Зависимости:** MF-038.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-063 · Захват неизменяемого контекста тестовой среды — 75/100
**Решение:** merge_into; **волна:** W0; **сейчас:** частично.
**Результат:** OS/tool version, dependencies, seed, locale and test result SHA.
**Критерий приёмки:** Флейки воспроизводятся в точной среде.
**Включить в:** MF-011, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-064 · Динамическое перераспределение времени агентов — 75/100
**Решение:** merge_into; **волна:** W0; **сейчас:** нет.
**Результат:** Agent idle? pick legal independent ready work; no lease bypass.
**Критерий приёмки:** Меньше пустых часов планировщика.
**Включить в:** MF-003, не создавать отдельный дублирующий сервис или штат агента.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-065 · Адаптер экспорта под NLE редакторы — 74/100
**Решение:** adopt_after_canonical_approval; **волна:** W2; **сейчас:** нет.
**Результат:** Resolve/Premiere/FCPXL where verified adapters support.
**Критерий приёмки:** Человек открывает настоящую редактируемую timeline.
**Зависимости:** MF-028.
**Гейт:** SOURCE_AND_MEDIA_RIGHTS_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-066 · Восстановление после split-brain нескольких машин — 64/100
**Решение:** defer; **волна:** DEFER; **сейчас:** нет.
**Результат:** PostgreSQL leader lease, distributed fencing, reconcile.
**Критерий приёмки:** Не теряются заявки при multi-host (нужно только при масштабе).
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-067 · Распределённый оркестратор Temporal — 64/100
**Решение:** defer; **волна:** DEFER; **сейчас:** нет.
**Результат:** Миграция с SQLite только при настоящих always-on workers.
**Критерий приёмки:** Нет двойного исполнения при мультихосте; большой TCO.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-068 · Векторная память всего рабочего чата — 54/100
**Решение:** defer; **волна:** DEFER; **сейчас:** нет.
**Результат:** Embeddings всех чатов риск утечки/шума; только после bounded reviewed memory.
**Критерий приёмки:** Острые запросы лучше baseline FTS, нет stale privilege.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-069 · Платный vector DB/RAG до качественного индексирования — 43/100
**Решение:** defer; **волна:** DEFER; **сейчас:** нежелательно.
**Результат:** TCO и утечка контекста без оснований.
**Критерий приёмки:** Вернуться если FTS провалился.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-070 · Автоматическая публикация и merge без участия человека — 40/100
**Решение:** reject_now; **волна:** REJECT; **сейчас:** нежелательно.
**Результат:** Избыточные полномочия на нынешнем host; do not implement now.
**Критерий приёмки:** Не допускать до доверенной границы хоста.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-071 · Десять новых агентов без увеличения независимых окон — 40/100
**Решение:** reject_now; **волна:** REJECT; **сейчас:** нежелательно.
**Результат:** Расширение списка ролей без concurrency и задач не даёт throughput.
**Критерий приёмки:** Сначала измерить пользу текущих ролей.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

### MF-072 · Самоизменяющиеся промпты без eval/approval — 37/100
**Решение:** reject_now; **волна:** REJECT; **сейчас:** нежелательно.
**Результат:** Риск деградации и обхода политики.
**Критерий приёмки:** Не выполнять в production.
**Гейт:** REVIEWER_INDEPENDENT_QA_REQUIRED; owner-approved canonical OpenSpec/SDD; regression tests; независимое ревью.

## Измерение полезности, а не количества функций

Baseline и holdout: accepted outputs/week, time-to-resume, % first-review acceptance, blocked agent-hours, duplicate side effects, real six-scene preview errors, frame drift and rights-check violations. Новая функция принимается только после независимого QA и улучшения релевантной метрики без падения baseline.

Не использовать этот Markdown как полномочие. Для новых OpenSpec changes нужен установленный workflow запроса подтверждения: `spec_preview` → `spec_request_prepare` → реальное `owner_approve.py` в локальном терминале → `spec_request_execute`.
