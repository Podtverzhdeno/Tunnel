# P085 protected-stage read/execute scope QA — 2026-11-04

## Defect
The staged package auditor `p085_stage_audit._acl_sane()` previously ensured only the protected service SID had an explicit Read+Execute ACE and that writes were SYSTEM-scoped. It did not reject **additional** Read+Execute ACEs granted to the untrusted worker or reviewer. The audit could therefore report `STRUCTURE_AND_ACL_OBSERVED` despite a visibly exposed code/private-state directory. That classification is advisory and never grants OS-backed authorization.

## Implemented
- `p085_stage_audit.py`: fail closed with `STAGE_ACL_READ_EXECUTE_SCOPE_VIOLATION` if an explicitly enumerated Read+Execute principal is not the service or SYSTEM SID.
- `test_p085_stage_audit.py`: added a regression test with 4 subcases: untrusted worker vs reviewer SID, and `review_grants.py` vs `private_state`. Tests check denied classification and no trusted deployment claim.
- `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py`: updated only the SHA-pinned, directly imported stage-auditor dependency following source inspection and tests. This pinning is **agent-writable advisory metadata**, never owner approval or cryptographic trust.
- Exact SHA256:
  - `p085_stage_audit.py`: `b67d7a25d3931034654968da2317c0131ed1389051fb84faefbe5fb4cd4a1ef4`
  - `test_p085_stage_audit.py`: `887802237b0f4161cd74ddd1fea9014c6dfcd5cbe3e74e5d705c4757cfdbbd24`
  - `p085_readiness_matrix.py`: `e516e902fbdd85b38d80cda7f5100ae1328ba16bbf3496ffb334d0ce2e410ad7`

## Verified MCP execution
- Focused stage auditor `ae4db43b03aa4160837f554da4009bb2`: completed rc=0, 21 tests, 19 PASS / 2 SKIP.
- Before updating the dependency SHA, the monitor `47ad9c6854ff4d7f8bf61741ad28d9dc` correctly returned `SOURCE_DEPENDENCY_SHA_DRIFT`, `status=UNKNOWN`, no operation authorized.
- P085-wide `fa13d1a83f214f7c8fa9eea4ab997c87`: completed rc=0, 98 tests, 92 PASS / 6 SKIP.
- Web companion matrix-focused `e08a883d802d424daea5ab880a92d067`: completed rc=0, 15/15 PASS.
- Web companion full suite `2fb5dc2890d34ee0b0019088aab78b93`: completed rc=0, 204 tests, 203 PASS / 1 SKIP.
- Live read-only matrix `da24262b59744d489f290f53f72173ff`: completed rc=0, `ok=true`, `status=UNTRUSTED`, `accounts_configured=0`, `accounts_missing=5`, `stage_status=NOT_STAGED`, `can_activate_chain3=false`, `can_complete_chain2=false`.
- Previous diagnostic preflight hardening is separately checkpointed in `docs/P085_PREFLIGHT_FAIL_CLOSED_QA_20261104.md`.

## Unresolved critical boundary
The existing WinAPI ACL inspector exposes `read_execute_allowed_sids`, not the complete set of SIDs with **read-only** permissions. This new check detects additional R+X ACEs but cannot prove the absence of a read-only ACE. The real effective-access checks must be performed under distinct actual Windows SIDs. ACL ownership, broad group membership, ancestor replacement, mutable source, credential custody, signer isolation and true owner control are not established by these unit tests.

No Windows UAC, SID creation, ACL changes, host restart, broker installation, protected key access, queue mutation, reviewer acceptance, Git, ChatGPT browser send or Chain3 activation occurred.

## Next lawful operation
In a separate owner-controlled interactive Windows session: verify immutable staged release outside `IdeaProjects`, provision genuinely distinct worker/reviewer/service principals, check deny/allow effective access including **read-only** key access, deploy isolated signer and broker, and run two-principal negative E2E before any cutover. Existing Chain2 ambiguous sends must be reconciled with original browser receipts, not replayed automatically.
