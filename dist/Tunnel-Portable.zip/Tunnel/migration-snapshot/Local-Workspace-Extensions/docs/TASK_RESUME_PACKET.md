# Read-only task resume packet — W0 (implemented)

**Scope:** `task_resume_packet.py` is a real, **read-only** command with bounded outputs. It operationalizes already-canonical OpenSpec requirements `Project onboarding bundle`, `Spec-first task pickup`, `Checkpoint persistence` (metadata only), and `Stalled work is visible`. This is not the separately proposed/unapproved durable step engine or long-term semantic memory.

At the beginning of a **new hourly session**, after reading `AGENTS.md`:

```powershell
cd Local-Workspace-Extensions
python task_resume_packet.py --task P108
python task_resume_packet.py --task P125
python task_resume_packet.py --task P111
python task_resume_packet.py --task P110
```

The tool reads current `team_seed.json`, the exact canonical OpenSpec requirement and its SHA-256, the machine-readable SDD roadmap, and existing **read-only SQLite reviewer acceptance evidence** via `team_productivity.report`. For an unowned available task not included in productivity's per-owner task summaries, it queries only three public task status columns using SQLite `mode=ro`.

It outputs: task ID, role hint (NOT authenticated), status, canonical specification path/requirement/hash, predecessor QA receipts, source-file SHA for available task sandbox artifacts, a safe advisory next-action enum and explicit trust flags. Does **not** output task prompts, checkpoint free text, raw leases, secrets, privileged grants, unknown provider usage or hidden model reasoning.

## Safety rules

- `REACQUIRE_OR_WAIT_FOR_EXISTING_LEASE`: an active task can have a lease from a *previous* scheduler invocation. Do **not** reuse or guess its token. Only the coordinator/host can legitimately issue a fresh one when permitted.
- `REQUEST_FRESH_HOST_AUTHORIZED_ACQUIRE`: a task is available with accepted dependencies. Still requires a new independent valid lease and host actor authentication; the packet does not grant either.
- `WAIT_INDEPENDENT_REVIEW`: only the reviewer/host can accept a submitted task after verifying source SHA and actual QA evidence.
- `STOP_AWAIT_ACCEPTED_DEPENDENCIES` / `STOP_UNVERIFIED_DEPENDENCIES`: do not mutate state or infer completion from another agent's chat messages.
- An expired/unknown `spec_ref`, missing accepted dependency or user-change SHA mismatch is **not** auto-fixed.
- A `queue_snapshot` supplied by a caller is clearly marked `caller_supplied_untrusted_snapshot`; it is useful for unit tests, never proof of trusted QA.
- Symlinks and junctions are refused for spec files, JSON source files and database. No network, subprocess, file mutation, Git, publish or key creation.

The system still does **not** persist model hidden thinking, full retry-safe tool effects, or verified cross-session semantic decisions. Those are separate proposed capabilities, requiring the normal owner-approved OpenSpec/SDD workflow before production rollout.

## Checked evidence

`test_task_resume_packet.py`: 13 unit tests: task continuation without reusing a token, dependency QA and missing QA, changed canonical requirement, traversal and symlinks, role mismatch, missing queue task, unowned available SQLite `mode=ro`, malformed SHA, no disk writes. Windows systems without symlink creation privileges mark only that platform-specific test skipped.

Main project standard gates: `python -m unittest discover`, `python spec_check.py`, and `python ops.py spec_validate Local-Workspace-Extensions local-pc-agent-tooling`.

Do not call a printed `safe_next_action` an executed operation. It is an instruction for the authorized **next** step.
