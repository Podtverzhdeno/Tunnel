# Доверенная делегация допуска задач — архитектурное решение (не включено)

**Мотивация.** Владелец хочет не вводить `ADMIT <plan_id>` для каждой волны. Текущий `owner_queue_admit.py` преднамеренно требует foreground Windows Terminal и проверяет точный SHA256 snapshot + независимую QA зависимостей. Текущий Local Workspace MCP содержит `host_authenticated_mcp_actor=false`; текст из ChatGPT и CLI `--role` не являются подтверждением владельца.

## Что уже автоматизировано без повышения привилегий
- MCP `run_script` читает SQLite read-only, выполняет preview, QA, планирование, отчёты.
- Architect Reviewer по расписанию проверяет `queue_supply_watch.py`, готовит новые дискретные задачи.
- Developer-1, Developer-2, Developer-3+4 читают `plan-work`, получают разрешённую ролью lease и реализуют задачи; после submit возвращаются к очереди.
- 2026-11-02 владельцем лично допущены P154–P161; 12 доступных задач (по 3 на роль) на момент последнего read-only snapshot.

## Требуемая новая граница доверия (пока отсутствует)

Для исключения *каждого нового* ручного подтверждения потребуется один раз локально доверенно настроить делегацию на уровне **MCP-хоста**. Простое переписывание `owner_queue_admit.py`, подставление `input()`, прямое `seed()`, правка SQLite или создание `.applied` receipts под видом владельца — не решение: любой удалённый scheduled agent смог бы сам повышать себе права.

1. **Native owner enrollment.** Владелец один раз в доверенном UI/локальном foreground подтверждает конкретный **полис** со сроком действия и nonce. Секреты подписи и полномочий хранятся вне `projects` под отдельным процессом/идентификатором, недоступным `run_script`/универсальному Python. При невозможности такой изоляции автоматическая выдача должна быть запрещена.
2. **Bounded delegation grant.** Точный проект `Local-Workspace-Extensions`, конкретный action `queue.admit.qa_backed_candidate`, allowlist canonical OpenSpec capabilities, лимит **8 задач на волну**, максимум **3 ready на роль**, ежедневный лимит и короткий TTL (например 24 часа). Отсутствует право reviewer accept/reject, изменение root/host config, run_command, OS ACL, платежи, Git push, выпуск в прод.
3. **Authenticated actor.** Хост получает не редактируемую агентом идентичность/проверяемый user authorization из **доверенного канала**, не из пользовательского role аргумента, текста ChatGPT или файла `projects`. Привязать scope к issuer и audience; защита от replay и просрочки.
4. **Transactional preflight.** Проверить текущие SHA256 seed/candidate, все задачи из canonical OpenSpec SHALL, 100% QA receipts предшественников, отсутствие пересечений, свежесть lease, ownership per role, отсутствие `.pending` receipt; отдельный reviewer не может быть автором.
5. **Immutable action receipt.** Host-side append-only WAL/SQLite transaction: grant_digest, approved scope hash, actor attestation, task IDs, before/after SHA, transaction id, monotonic sequence, trusted timestamp, rejection causes. Запись только атомарно; crash-safe reconciliation. Никаких токенов в публичных логах.
6. **Safe stop + revocation.** Владелец может отключить все делегированные действия; отказ при расхождении хеша/истечении TTL/недоступности trusted host; доказанная блокировка дублей и rate-limit. Не делегировать формальную независимую приёмку.

## Критерии приёмки новой архитектуры
- При неподтверждённом user actor, чужом role или недоверенном Python CLI: `DENY`, без mutations.
- При отсутствии защищённого host broker: `DENY`, даже если `projects` содержит JSON с `enabled=true`.
- При изменении любого из SHA: `DENY_STALE_PREVIEW`.
- При единственной разрешённой операции и валидном grant: ровно одна транзакция, максимум 8 QA-backed disjoint задач, `seed_total` обновлён, audit receipt подписан доверенным компонентом.
- Повторная доставка того же request id: idempotent replay без дубликатов.
- При обрыве после `seed`: `RECONCILIATION_REQUIRED`; не повторять вслепую.
- За пределами TTL/лимита/набора capabilities — `DENY`.
- Отключение на стороне владельца мгновенно блокирует новые действия.
- Дополнительный негативный E2E: scheduled agent может писать в собственный sandbox, но **не может** создать действующий owner grant, изменить host policy или заставить broker принять произвольные новые задачи.

## Порядок реализации
1. Дополнить OpenSpec/SDD через установленный `spec_preview → spec_request_prepare → owner_approve → spec_request_execute`, не менять действующий canonical spec напрямую.
2. Реализовать отдельный trusted host component/connector с реальной actor attestation и раздельными OS privileges.
3. Создать offline policy evaluator и негативный property-based/fuzz-style корпус; затем E2E на isolated dev host.
4. После явной первоначальной владельческой регистрации заменить `owner_queue_admit.py` для **только** делегированных, явно ограниченных QA-backed операций; старый интерактивный путь оставить как fallback.

## Офлайн-контракт (реализован, не является выдачей полномочий)

Создан `queue_delegation_contract.py` и `test_queue_delegation_contract.py`. Модуль `assess()` независимо проверяет структуры owner-grant, план seed SHA, TTL ≤24ч, максимум восемь заданий на волну, максимум три ready на роль, область действия, уникальность ID и deliverables, существующие QA-зависимости, точность хешей, предотвращение логического replay и строгие UTC timestamps. Любой успех возвращает строго **PASS_PREVIEW_ONLY**, `execution_authorized=false`, `host_actor_attested=false`, `queue_mutated=false`; все 15 локальных тестов PASS. Передаваемые записи `canonical_spec_checked=true` и `independent_qa_checked=true` являются **только тестовыми данными**, не проверенными подписями. Это вспомогательный будущий контракт, который НЕ делает возможным автоматический реальный допуск из ChatGPT.

Исправлен watchdog `experiments/chat_only_run/queue_supply_watch.py`: после owner admission он больше не называет уже зачисленные ID новым резервом. Отличает `already_admitted_in_candidate_manifest` и `future_proposals_pending_capacity_or_qa`. Добавлены негативные тесты; 9 тестов PASS.

**Критическое условие следующей волны:** официальный owner_queue_admit.py теперь проверяет соответствие каждой новой ready-задачи точной записи roadmap. P162+ ещё должны пройти SDD-согласование; отсутствие записи — `SDD_ROADMAP_UNMAPPED`, это не разрешается флагом или поддельным подтверждением. Изолированные тесты `test_owner_queue_admit.py` используют подстановку только для НЕ относящихся к SDD проверок, а отдельный негативный тест подтверждает отказ при unmapped. 7 тестов PASS. Полный набор: 1175 tests, 31 skipped, 0 failures. OpenSpec strict valid.

**Текущий статус: DESIGN ONLY.** Доверенной роли на MCP-хосте нет. Никаких автоматических admissions помимо реального owner-approved batch не выполнялось. Все обычные операции разработки/анализа можно и нужно проводить без PowerShell со стороны владельца.
