# Multi-agent system 2.0 — durable execution and evidence-backed memory
Status: **PROPOSAL / NOT CANONICAL OpenSpec**, 2026-11-02
Project: Local-Workspace-Extensions. Priority: software development and media editing outputs; token/cost dashboards are secondary.

## 0. Current implementation — verified from repo, not inferred
- Existing: `.agent-team/team.sqlite3` with queued/working/review/rework/done tasks, role-specific sandboxes, leases/fencing/heartbeat, bounded `agent_progress.json` + append-only checkpoints, task events, reviewer-accepted QA records, hash-checked merge intent, manual crash reconciliation; separate `scheduler_run_history.json` for numeric run metadata.
- Not done: cross-session **semantic project/agent memory**, authoritative resumable per-step execution log for all tool calls, dependency-aware parking/supersession, safe automatic post-crash continuation, trusted host role authentication, true OS isolation, real scene renderer and final measured media outputs.
- A scheduled ChatGPT run is a distinct invocation. Its hidden internal reasoning cannot be restored from SQLite, and an hourly schedule is **not** a continuously running worker. Durable continuation reconstructs *task context and saved operation outputs*, not private model state.
- Never fold unverified model-produced notes into canonical OpenSpec or privileged grants. Main project currently has four roles doing P108/P125/P111 and P096 rework; P110 is available. Never change their assigned deliverables or live queue/leases as part of this proposal.

## 1. Top 10 features (impact / implementation complexity: 1–5, design assessment)

| # | Capability | Outcome for real code/media work | Impact | Complexity | Priority |
|---|---|---|---:|---:|---|
| 1 | **Durable step engine + replay** | Resume a multi-hour plan after a crash without repeating accepted steps or destructive tool operations | 5 | 5 | P0 |
| 2 | **Hierarchical persistent memory** | New run knows project constraints, task decisions, scene style, errors and reviewer feedback without reading entire chat | 5 | 3 | P0 |
| 3 | **Evidence-based context packet** | Every role gets compact fresh spec/checkpoints/artifacts with source hashes and trust labels | 5 | 3 | P0 |
| 4 | **Dependency-aware DAG + safe park/unpark** | P096-like blocked work does not monopolize D3 while P110 is independent | 5 | 4 | P0 |
| 5 | **Durable agent mailbox/handoff** | Reviewer feedback and cross-scene contracts delivered exactly to the appropriate recipient role | 5 | 3 | P1 |
| 6 | **Artifact registry + SHA-addressed reuse** | No duplicate tests/render; other agents consume reviewer-accepted code/previews, not random workspace files | 5 | 4 | P1 |
| 7 | **Automatic evidence-driven QA/repair loops** | Agent fixes failing test cases within bounded attempts before reviewer, not repeated superficial analysis | 5 | 4 | P1 |
| 8 | **Risk-aware supervisor and anti-idle planning** | Real coding hours go to ready high-value tasks, with WIP caps and measurable progress | 4 | 3 | P1 |
| 9 | **Media continuity memory + shot-level scene contracts** | Consistent pace, color, motion graphics, music licensing, typography and transitions over 6+ scenes | 5 | 4 | P1 |
| 10 | **Operator cockpit + time-travel diagnosis** | Explain why task stalled, which checkpoint is authoritative, changed hashes, ETA as uncertainty, and recover safely | 4 | 4 | P2 |

**The core of the improvement is 1+2+3+4 as ONE controlled system**, not a vector DB for every sentence. First ensure correctness, then optimize retrieval and costs.

## 2. Three independent forms of persistence

**Execution persistence (authoritative)**: tasks, leases, attempts, step status, tool intent, tool response receipt/hash, QA decision, idempotency key, errors. Must be replay-safe and transactionally recorded.

**Knowledge persistence (advisory)**: facts/decisions learned during work, scoped to project/task/role/scene. Each memory has source link, provenance, confidence, valid-until, spec/content SHA; stale or contradicted memory cannot override current specs, owner or reviewer.

**Artifact persistence (authoritative only after acceptance)**: content hashes, producer task/scene, dependency hashes, QA receipt, review status, exact file paths. Large binaries and footage remain filesystem/object-store artifacts, **not SQLite BLOBs**.

Recommended authority order: owner/host security policy > current canonical OpenSpec/SDD > independently accepted QA/asset receipt > live task state > bounded agent checkpoints > unverified retrieved notes / previous chat. Do not equate memory with authorization.

## 3. Proposed storage contracts — separate migrations, NOT live schema

All tables below are design contracts, **not existing production tables**. Introduce through opt-in versioned migrations with `PRAGMA user_version`, foreign keys, backup/restore checks and rollback tests. Never modify `.agent-team/team.sqlite3` directly from a chat.

- `agent_runs`: run_id, task_id, role, attempt, spec_sha256, snapshot_revision, lease_fence_hash (never raw lease token), status, started_utc, ended_utc, last_heartbeat_utc, error_code.
- `run_steps`: run_id, step_id, ordinal, input_digest, tool_name, idempotency_key UNIQUE, side_effect_class, status (`PLANNED|STARTED|APPLIED|VERIFIED|FAILED|UNKNOWN`), result_digest, verified_evidence_id, retry_count, last_updated_utc. Only `VERIFIED` may be reused as done on replay.
- `memory_records`: record_id, scope_kind (`project|task|role|scene`), scope_id, memory_kind (`decision|constraint|failure|solution|style|observation`), bounded_json_payload, source_ref, source_sha256, spec_sha256, created_utc, valid_until_utc, status (`proposed|reviewed|stale|retracted`), sensitivity (`public|internal`), superseded_by, version. Index by scope/validity; optional FTS only for approved safe text.
- `artifact_receipts`: artifact_id, producer_task_id, content_sha256, media_type, relative_path, spec_sha256, qa_receipt_id, reviewer_acceptance_id, created_utc, immutable_version. No accepted receipt solely from the producer.
- `agent_mailbox`: message_id, from_role, to_role, task_id, artifact_id, message_kind, payload_sha256, created_utc, delivered_utc, acked_utc, correlation_id UNIQUE; incoming messages are data, not grants.
- `operation_outbox`: operation_id, kind, input_digest, target_resource, expected_state_hash, state `PREPARED|CONFIRMED|NEEDS_RECONCILIATION`, recorded_utc. Use host-provided idempotency or reconcile; **do not** promise exactly-once external side effects.

Recommended source of truth for local MVP: same-host SQLite in WAL mode + short transactions, busy_timeout, controlled migrations and periodic atomic backups. WAL supports simultaneous readers with a single concurrent writer, **not** distributed/multihost writes. PostgreSQL is a future move if workers physically split across machines. Time-travel/replay is bounded and deterministic only for explicitly logged state and completed activities.

## 4. Resume protocol for the hourly ChatGPT agent

1. Read `AGENTS.md`, current canonical OpenSpec/SDD and project configuration. Compute hashes; do not trust last run's saved interpretation.
2. Obtain authenticated run/role evidence from the **host** if available. Existing scheduler identity remains UNVERIFIED; do not turn a model-chosen string into a credential.
3. Read live queue and own `history Pxxx`; use legitimate `acquire`/fencing token and `sync-sandbox` only under the current lease. When owned work is blocked, use legal independent ready task. Do not let P096 block unrelated P110.
4. Build a bounded *context packet* from up-to-date specs + task state + review notes + verified artifact refs + relevant reviewed memories. Include `source_sha256`, `evidence_kind`, `trust_class`, `captured_utc`. If spec/hash changed, mark old memories stale and trigger controlled rebase or human review.
5. Resume next **not verified** step, checking journal and filesystem/current service state. Never reissue a state-changing command just because the LLM lost its last reply.
6. For read-only operations, retry with budgets; for file writes, use compare-and-swap and a durable intent; for R2/R3, require independently verified host/owner approval. External ambiguous writes go to `NEEDS_RECONCILIATION`, not automatic retry.
7. After a meaningful step, record atomic action status/evidence, checkpoint `done/next/tests/blockers`, refresh heartbeat, then continue until run limits.
8. Before scheduled turn ends, write a bounded handoff. The next hourly invocation reads it and the verified evidence, not full untrusted model chat.
9. Submit only after actual focused + full unittest, SDD + OpenSpec strict, scoped artifacts, reviewer checks. No model self-acceptance.

**Important:** user cannot obtain or serialize private reasoning tokens/hidden ChatGPT thinking state. The result is *persistent work state* and an exact restart boundary, not indefinite continuation of one ChatGPT inference.

## 5. Memory retrieval policy to avoid nonsense and cost blowups

For each resume, 3-level retrieval:
- **Hot, required** (always): exact task, spec digest, active lease/state, latest verified checkpoint, blockers, next action, 5–10 latest reviewer notes.
- **Warm, filtered**: 5–15 facts by project/task/scene ID + matching current spec SHA, approved QA receipts, artifact dependencies. Do not pull unrelated files or secrets.
- **Cold, on-demand**: versioned decision log, old failed approaches, rejected review, scene continuity and larger technical references. Must be retrieved with reason and labels.

Memory extraction is a candidate, never directly an instruction: store `fact/decision/why/source/evidence/expiry`; every contradiction is resolved against canonical specs and independently accepted artifacts. Introduce per-record TTL, compact summaries, deduplication by content SHA, and bounded total retrieval tokens. Semantic vector search is an optional **later** optimization, not required for the first 5 agents.

Illustrative packet skeleton (NOT an access token):
```json
{
  "project_id":"local-workspace-extensions",
  "task_id":"P108",
  "spec_sha256":"actual_current_source_sha",
  "checkpoint":{"done":[],"next":[],"blockers":[]},
  "review_notes_refs":[],
  "verified_artifact_receipts":[],
  "relevant_memories":[{"kind":"decision","source_ref":"...","trust":"reviewed"}],
  "current_lease_status":"must_read_live",
  "stale_context_detected":false
}
```

## 6. Testing / Definition of Done

Minimum tests (use independent temporary database, never user's live queue):
1. Process killed after `STARTED`, before write: resume determines operation not applied; no duplicate output.
2. Kill after real external effect but before completion receipt: mark `NEEDS_RECONCILIATION`; do not blindly retry.
3. Same step/idempotency key repeated 3x: one accepted event, identical durable result; different payload for same key -> reject.
4. Expired lease, wrong role, forged reviewer, missing host approval -> state-changing operation rejected.
5. Spec SHA or scene source SHA changed after checkpoint: stale memory and artifact references quarantined; no silent acceptance.
6. Human edits a target file during pause: CAS fails, both original and user edit preserved.
7. New fresh agent, no chat history: resumes from packet/checkpoint and exact snapshot within bounded retrieval; does not reread entire repository.
8. Concurrent 4 dev readers / reviewers / one writer: no duplicate claims, no writer starvation beyond measured budget; lock contention tests.
9. Backup + simulated damaged DB + restore into separate fixture: no invented `done` or lost accepted QA chain.
10. Prompt injection in README or shared memory: no privilege escalation; candidate memory cannot create security grant.
11. Scene 03 resume after restart: correct shot dependencies, rights status, timecodes and accepted visual continuity; no overwrite of footage.
12. D3's blocked P096 with independent P110 available: scheduler safely chooses P110 under a separate legitimate lease without bypass or starved workers.

Recommended MVP KPI: recovered task with zero duplicated accepted operations; resume packet build <2 s for 100-task fixture; no loss of completed steps after injected crashes; every accepted artifact linked to spec SHA and independent QA; reduced percentage of repeated repository rereads; bounded prompt bytes. Metrics are test targets, not measured current results.

## 7. Implementation slices suitable for four developers + reviewer

**Slice A (first, 2–4 isolated tasks)**
- D1: `run_step_contract.py` + tests; typed resumable step states and idempotency semantics, pure/offline, no filesystem effects.
- D2: `scoped_memory_contract.py` + tests; scope/TTL/provenance/version validation, bounded records, redaction.
- D3: `context_packet_builder.py` + tests; deterministic read-only task/spec/memory packet, SHA freshness and explicit stale flags. Requires safe P096 resolution before assigning to D3 in live queue.
- D4: `durable_handoff_contract.py` + tests; mailbox message validation, ACK and replay-resistant IDs, no authority escalation.
- Reviewer: approve SDD/OpenSpec changes, verify DAG dependencies, scope non-overlap, host trust limitations, accept verified tests. **Do not seed until canonical spec/owner approvals are satisfied.**

**Slice B**: versioned SQLite migration, atomic step journal, restore-after-crash fixtures, and context packet CLI on top of accepted v1 contracts. Prioritize these before optional embedding search, multi-PC workers or Studio.

**Slice C**: scene memory + render metadata persistence + cross-scene continuity + content-addressed approved preview registry; measured FFmpeg/ffprobe E2E only after safe host/render prerequisites.

**Explicit blockers:** protected operations need trusted host authentication & actual OS isolation; existing scheduled tasks P108/P125/P111/P096/P110 remain unaffected by this proposal. This document is not approval to create new canonical OpenSpec, enqueue tasks, write to main SQLite or call privileged tools.

## 8. What NOT to build first

- A giant RAG/vector database over every chat and source file: noise, leakage and stale instructions; low ROI before bounded summaries and correctness.
- Automatic self-merge or auto-modification of host access policy before verified actor identity and independent QA.
- A new heavy Temporal cluster for four hourly scheduled agents. Borrow durable-event/idempotency design first; evaluate Temporal only after reliable always-on worker execution and real infrastructure demand.
- Memory that stores secrets, raw lease tokens, unreconciled outputs or synthetic provider token estimates as factual receipts.
