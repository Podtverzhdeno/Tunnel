# GPT-6 API pricing: отдельная условная метрика

**Основной тариф по решению владельца — `gpt-6-sol`, а НЕ `gpt-6.1-sol`.** В обычном Standard/short-context API: $2 за 1 млн входных, $0.20 за 1 млн cached input, $10 за 1 млн выходных токенов. Тариф применяется **к каждому наблюдаемому запуску scheduled-задачи отдельно**, после чего суммы агрегируются. Единица «1 млн токенов» — лишь знаменатель в прайс-листе, а не минимальный платёж или размер задачи.

В ChatGPT пользовательский режим GPT-6 High обычно соответствует семейству Sol, но подключённый планировщик **не раскрывает фактическую модель и `thinking_effort` каждого запуска**. Проверено по всем четырём включённым автоматизациям 1 ноября 2026. Поэтому в API-калькуляторе `gpt-6-sol` — выбранный **тарифный ориентир**, `scheduler_model_verified=false`, `scheduler_thinking_effort_verified=false`; утверждать «в планировщике High подтверждён» нельзя.

Дата проверки тарифов: **2026-11-01**. Официальный источник:
https://developers.openai.com/api/docs/pricing

**Важно:** API-ключ сам по себе не является отдельным тарифом $20. В обычном API счёт зависит от использования модели и дополнительных услуг. Подписка ChatGPT и API — **разные модели оплаты**. Наша метрика моделирует, сколько стоили бы уже наблюдаемые scheduled-запуски *при исполнении через конкретную модель API*; фактически те ChatGPT-сеансы не становились платными API-вызовами.

## Тарифы — Standard, short context, USD за 1 млн токенов

| Модель | Input | Cached input | Output |
|---|---:|---:|---:|
| `gpt-6-astra` | 10.00 | 1.00 | 50.00 |
| `gpt-6-sol` | 2.00 | 0.20 | 10.00 |
| `gpt-6.1-sol` | 2.00 | 0.10 | 10.00 |
| `gpt-6.1-terra` | 1.00 | 0.05 | 5.00 |
| `gpt-6-luna` | 0.10 | 0.01 | 0.50 |

Это **пять альтернативных моделей**, а не пять одновременных услуг. В GPT-6 Sol и GPT-6.1 Sol базовые ставки совпадают, но скидка на cached input отличается (0.20 и 0.10 соответственно). ChatGPT GPT-6 High не обязательно соответствует одному из этих API SKU; подмена их имен не допускается. Тарифы меняются: после обновления официального прайс-листа нужно отдельно обновить версионированный снимок ставок в `api_token_pricing.py` и тесты.

## Формула

```text
api_cost_usd =
  (input_tokens - cached_input_tokens) * input_usd_per_1m / 1_000_000
  + cached_input_tokens * cached_input_usd_per_1m / 1_000_000
  + output_tokens * output_usd_per_1m / 1_000_000
```

По умолчанию `cached_input_tokens=0`: вся оценка input считается некешированной. Неизвестная доля кеширования — отдельный сценарный параметр, **не измеренная скидка**. Выходная оценка должна включать скрытые reasoning tokens, но у наших ChatGPT Automations они недоступны: `token_spend_estimator.py` строит лишь грубую эвристику. Не учитываем дополнительные tool fees, cache writes, long context, региональные надбавки, Batch/Flex/Fast и прочее. В некоторых сценариях и тарифах реальные расценки могут отличаться.

## Пример: четыре последних завершённых запуска

Для сохранённого эксперимента `token_spend_scenarios_latest.json` input ≈ **128 170**, output ≈ **24 423**. Это числа эвристики, **не провайдерские показания**.

| API модель | Input USD | Output USD | Итог API USD |
|---|---:|---:|---:|
| GPT-6 Astra | 1.281700 | 1.221150 | **2.502850** |
| GPT-6 Sol | 0.256340 | 0.244230 | **0.500570** |
| GPT-6.1 Sol | 0.256340 | 0.244230 | **0.500570** |
| GPT-6.1 Terra | 0.128170 | 0.122115 | **0.250285** |
| GPT-6 Luna | 0.012817 | 0.012212 | **0.025029** |

Оценочный допуск ×0.5..×2 — чувствительность, **не гарантированный доверительный интервал**. Не считайте гипотетическую API-цену фактическими списаниями ChatGPT, не прибавляйте её к `subscription_cost_allocation_latest.json`. При смене модели стоимость нужно пересчитать по актуальному официальному прайсу.

## Команды на ПК

Из `Local-Workspace-Extensions`:

```powershell
# API цена только от уже сохранённого token сценария
python api_token_pricing.py --token-scenarios .agent-team/reports/token_spend_scenarios_latest.json --save-report

# Для конкретной модели
python api_token_pricing.py --token-scenarios .agent-team/reports/token_spend_scenarios_latest.json --model gpt-6-astra

# Сценарий 50% cached input (не фактический cache hit rate)
python api_token_pricing.py --token-scenarios .agent-team/reports/token_spend_scenarios_latest.json --model gpt-6.1-sol --cached-input-fraction 0.5

# Общий отчёт: токены, тариф API, доля подписки — ТРИ отдельных секции
python team_run_metrics.py --observations .agent-team/reports/scheduler_visible_usage_completed_rough_20261101.json --estimate --api-pricing --subscription-observations .agent-team/reports/subscription_completed_run_observations_20261101.json
```

`api_token_pricing.py --save-report` создаёт только числовой файл `.agent-team/reports/api_token_cost_latest.json` с атомарной заменой. Текущие роли Developer-3 и Developer-4 остаются **одним общим scheduler run**: произвольно разделять API-счёт между ними нельзя.

**Отличать три величины**: `token_spend_scenarios` — грубые input/output, `api_token_pricing` — hypothetical API bill по конкретной модельной ставке, `subscription_cost_allocation` — доля фиксированных $20. Они связаны только как входные оценки токенов → условная API стоимость, но подписка от токенов не зависит.
