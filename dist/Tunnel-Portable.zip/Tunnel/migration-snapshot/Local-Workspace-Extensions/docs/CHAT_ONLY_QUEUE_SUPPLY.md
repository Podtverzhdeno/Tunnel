# Queue supply for chat-only five-agent team (2026-11-02)

**Scope:** ChatGPT Scheduled chats + Local Workspace MCP, no Codex, no Work, no browser automation, no LLM API.

## Outcome

The current authorized specifications and real reviewer QA evidence allow these **five independent, testable work items** as a short reserve, not an infinite fabricated backlog:

| ID | Role | Deliverables | Already accepted prerequisite |
|---|---|---|---|
| P116 | developer-1 | task_dag_schema.py, test_task_dag_schema.py | P104, P107 |
| P148 | developer-2 | queue_starvation_diagnostics.py, test_queue_starvation_diagnostics.py | P105 |
| P149 | developer-3 | lease_continuity_policy.py, test_lease_continuity_policy.py | P106 |
| P127 | developer-4 | agent_metrics_series.py, test_agent_metrics_series.py | P105 |
| P131 | developer-4 (reserve) | media_rights_schema.py, test_media_rights_schema.py | P107 |

P116, P127 and P131 originate in the existing IMPLEMENTATION_BACKLOG.md. P148 and P149 are useful narrowly scoped offline follow-ups to existing canonical requirements ('Durable task activity and checkpoint history', 'Lease and heartbeat') for the user's measured idle/continuity problem, with distinct modules and tests.

**Evidence:** acceptance audit finds P104/P105/P106/P107 all `recorded_pass`. P108/P110/P111/P125 are still pending reviewer acceptance: their results do **not** satisfy future dependent ticket gates. Existing P096 is a separate stale-coordinator blocker and does not authorize modifying its lease or files.

## Preview (read-only)

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\chat_only_run
python queue_supply_plan.py
python owner_queue_admit.py
```

The planner validates exact canonical requirement, QA receipt category, all dependencies, unique output scope, main-file collisions, and per-role ready buffers (max 2). It does **not** modify the task database. A full local suite passed: 40 tests, 1 skipped; isolated temporary copy of the **real SQLite** accepted all five candidates and idempotent re-seeding inserted 0 on second run.

## Actual admission: OWNER IN FOREGROUND TERMINAL ONLY

The current reviewed preview reported plan ID `705343afee3f9a15` and five ready tasks. The owner must review this precise plan. In their **real local Windows Terminal**, not MCP and not a scheduled agent, execute:

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions\experiments\chat_only_run
python owner_queue_admit.py
python owner_queue_admit.py --apply --plan-id 705343afee3f9a15
```

Then explicitly type `ADMIT 705343afee3f9a15` when prompted, after reviewing the printed scope and SHA-256. If the plan/seed changed since this check, the script refuses: re-preview and use the **new** plan ID; never bypass the verification. `--apply` explicitly requires interactive terminal stdin/stdout; via MCP it refuses with `FOREGROUND_INTERACTIVE_OWNER_TERMINAL_REQUIRED`. No attempt should be made to simulate TTY or owner input.

On success it writes a backup of the existing manifest in `.agent-team/reports`, atomically updates the allowlisted `team_seed.json`, then calls the existing transactional `agent_team.seed()`. If interrupted, a pending receipt remains for manual reconciliation; no automatic blind replay. No task acceptance/QA approval or merge happens as a result of seeding.

**Verify only after actual owner-confirmed success:**

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python agent_team.py overview
python agent_team.py plan-work developer-1
python agent_team.py plan-work developer-2
python agent_team.py plan-work developer-3
python agent_team.py plan-work developer-4
```

Expected: newly admitted task IDs appear `available` until legitimately acquired under new task-specific leases. Scheduled ChatGPT agents already read these plans. The reviewer scheduled chat was updated to run `queue_supply_plan.py` read-only when backlog is low, and request the next explicit owner admission when appropriate. It must never call `owner_queue_admit.py --apply`.

## Fundamental limitation and safety

This **does not** guarantee permanently infinite useful tasks. New work is finite and must be genuinely spec-backed, non-overlapping and independently reviewed. With source/owner policy changes, dependency failures or exhausted backlog, agents correctly stop rather than invent tasks or circumvent limits. Reviewer P085 / trusted host actor is not repaired by Python role strings or a foreground TTY check. True authenticated host enforcement and approved future OpenSpec waves are still prerequisites for autonomous production queue/merge operations.

Daily KPI: ready task buffer per role, ratio of productive-to-idle ChatGPT launches, accepted code artifacts, negative QA results, and queue wait/review latency. Do not use total session length or fabricated hidden token counts as a success KPI.
