# PC Toolbox — terminal and development diagnostics through Local Workspace MCP

**Implemented:** `pc_toolbox.py`, `test_pc_toolbox.py`, and 12 additional read-only tool declarations in `mcp_adapter.py`.
**Security boundary:** existing connected Local Workspace host, not the Python wrapper. The adapter functions are **NOT yet registered with the running MCP server** because the server source is outside the permitted project. They can be invoked immediately through the existing connected **Local Workspace `run_script` tool**. The original `run_command` is already available for explicitly authorized actions; it executes with the Windows user's privileges and must not be treated as a restricted shell.

## How to run from this ChatGPT chat

Use the already connected Local Workspace plugin:

```text
run_script(
  workspace="projects",
  path="Local-Workspace-Extensions/pc_toolbox.py",
  cwd="Local-Workspace-Extensions",
  args=["terminal", "python_version"]
)
```

The tool returns `job_id`; use `job_status(job_id)` until completed and `job_output(job_id)` for the actual JSON `ok/data/error`. A job starting is **not** success; check the real return code. All paths below are relative to `Local-Workspace-Extensions` (not to the PC root).

## Implemented CLI actions

| Action | Example `args` | Effect |
|---|---|---|
| Capability discovery | `["capabilities"]` | Lists tool status/limits |
| Terminal presets | `["terminal","python_version"]` | Runs exactly one allowlisted binary with fixed arguments |
| System resources | `["system"]` | CPU, RAM and project-volume disk space; no identifiers |
| Process list | `["processes","--limit","20"]` | Process names + PIDs; no command-line args |
| Local TCP port | `["port","8765"]` | Checks `127.0.0.1` only |
| Project directory | `["tree","--path","docs","--limit","30"]` | Bounded one-level file list |
| Literal source search | `["search","checkpoint","--path","docs","--limit","20"]` | Bounded matching files and lines |
| File checksum | `["fingerprint","pc_toolbox.py"]` | SHA256, file size, no file content |
| Syntax check | `["syntax","pc_toolbox.py"]` | AST parse only; no source execution |
| Git repository map | `["git_map"]` | Nested roots; never follow parent IdeaProjects repo |
| Test-run preview | `["test_preview"]` | Returns command and R2 warning; does not run tests |
| Media metadata | `["media_probe","assets/scene01.mp4"]` | ffprobe video/audio metadata only; file must exist inside project |

Allowed terminal presets: `python_version`, `git_version`, `node_version`, `ffmpeg_version`, `ffprobe_version`, `git_status`, `git_diff_stat`. Git project-status/diff requires the current project directory itself to be a Git root; otherwise return `PROJECT_NOT_GIT_ROOT` rather than reading the global dirty parent Git repository. No `cmd.exe`, `powershell`, `-c`, shell concatenation, arbitrary `subprocess` arguments or Git push in this toolbox.

## MCP native adapter integration (not yet deployed)

The existing `mcp_adapter.register_tools(mcp)` declares 12 new functions:

`pc_tool_capabilities`, `pc_terminal_preset`, `pc_system_resources`, `pc_process_names`, `pc_local_port`, `pc_project_tree`, `pc_project_code_search`, `pc_file_fingerprint`, `pc_python_syntax`, `pc_git_repo_map`, `pc_test_run_preview`, `pc_media_metadata`.

The adapter now prepares **30** tools in total (18 existing + 12 new). These declarations are tested with a fake FastMCP registry, **not an actual host deployment**. To make separate first-class tools appear in ChatGPT, the real Local Workspace MCP host must import/register the module, apply its independent tool/actor policies, restart, and prove the real `tools/list` response. A Python module in a project cannot dynamically add commands to a previously connected MCP host.

## Safety and limitations

- Read-only project diagnostics, no network outside `127.0.0.1`, symlink/junction and protected folders excluded, capped stdout/lines/bytes.
- Git status is refused if it would implicitly act in a parent repository.
- Source searches redact common obvious secret patterns best effort; not an exhaustive secret scanner.
- Executing Python tests or arbitrary scripts **is R2**, not a read-only operation. The preview remains R0 and does not execute.
- No token, user account, browser profile, clipboard, screen, `.env`, arbitrary filesystem drive or credential dumps.
- All new tools have the existing MCP process's OS-user privileges unless the real host enforces stronger isolation. The adapter is not a host-side identity grant, owner approval or permissions boundary. Restrict the older general `run_command` / `run_script` at the same host boundary before granting low-trust agents access.
- For actual PC terminal operations already supported by connected MCP, use `run_command` with an explicitly chosen allowlisted executable and argument array; for arbitrary Windows shell/system-wide effects, a separate verified operator approval and server-side policy is required.

## Native MCP verification and live-host install

An additional integration path is now implemented:
- `pc_host_extension.py` registers **only 12 PC tool names** into an existing FastMCP/MCPServer object, without registering or replacing any of its existing tools.
- `native_pc_extension_mcp.py` is an isolated stdio server used to independently verify this exact 12-tool registration.
- `native_pc_mcp.py` is a separate optional 30-tool stdio server (18 existing adapter declarations + 12 PC tools).
- `python run_pc_mcp_wire.py --extension-only` completed true MCP protocol `tools/list` (12) and 7 `tools/call` checks (including negative shell/traversal) with exit code 0; the standard command passed with 30 tools.
- **The running ChatGPT Local Workspace App still exposes its original 28 tools; no live host modification or tunnel restart has occurred.**

Full registration, rollback and trusted host verification steps are in [MCP_PC_ACTIVATION.md](MCP_PC_ACTIVATION.md). The host source is outside the current allowed workspace; registering natively in this already-running server requires making that source available to Local Workspace or modifying it in the operator's own Windows terminal.

## Live smoke checks

On the connected Windows PC, `python_version` returned Python 3.13.5, `system` returned CPU/RAM/disk metrics, `search` found the expected source line, `syntax` succeeded, local TCP 8765 accepted a connection, `processes` returned bounded names/PIDs, and installed `ffprobe` reported version 8.1.1. `git_status` correctly denied acting on the parent Git repository. No actual user video was probed; media metadata has fixture tests only until a suitable project-scoped clip is available.
