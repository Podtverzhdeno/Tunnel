# Implementation checkpoint — review snapshot recheck after queue inspection

Date: 2026-11-02
Scope: Local-Workspace-Extensions; optional, read-only QA review matrix.
Status: local code + negative tests implemented. Not an independent reviewer acceptance, canonical change approval, or host permission change.

## Defect / motivation

The previous optional source SHA-256 QA check captured an OpenSpec/SDD snapshot BEFORE inspecting potentially dozens of submitted tasks. If a spec changed during expensive per-task preflights, the matrix could still emit an advisory READY_FOR_INDEPENDENT_QA, even though the earlier snapshot was stale.

## Implemented

1. `review_readiness_matrix.build_matrix(..., spec_recheck=None)` accepts an opt-in, dependency-injected callback that obtains a fresh source provenance snapshot at the END of all task preflights, BEFORE sorting and displaying any ready task.
2. The before/after comparison REUSES `spec_traceability.compare_source_snapshots` and its existing SHA-256 manifest validation and deterministic added/removed/modified path calculation. No duplicate parser, mutable DB, or second coordinator has been created.
3. If source digests or included paths change, the report marks `spec_source.recheck_state=DRIFT`, appends `SPEC_SNAPSHOT_DRIFT_AFTER_PREFLIGHT`, and downgrades all would-be ready tasks to `SPEC_SNAPSHOT_REVERIFICATION_REQUIRED`. Hidden tasks beyond the display limit are included in the downgrade.
4. If the second read fails, is malformed or cannot be trusted, the report marks `recheck_state=FAILED` and appends `SPEC_SNAPSHOT_RECHECK_FAILED`, without leaking exception text.
5. Existing negative-QA blocks remain higher priority and active/unknown reviewer leases are not inspected or taken over.
6. The initial validated manifest is deep-copied before running caller callbacks, so in-memory changes to the original manifest cannot erase proof of drift.
7. The CLI runs both independent source snapshots automatically when explicitly invoked with `--with-spec-snapshot`. It returns exit code 1 on drift/recheck failure, code 2 on initial source-read failure; regular clean advisory audits keep exit code 0. The no-snapshot legacy CLI remains unchanged and makes no claim to have checked these SHA values.
8. This is bounded, best-effort filesystem consistency, NOT atomic filesystem+SQLite snapshot isolation, host-authenticated identity, or a merge/accept grant.

## Actual verification

| Check | Result |
| --- | --- |
| python test_review_readiness_matrix.py | 36 run; zero failed |
| python test_review_snapshot_recheck.py | 5 run; zero failed |
| python -m unittest discover -p test_review*.py | 96 run; 2 skipped; zero failed |
| python -m unittest discover -p test_spec*.py | 113 run; 4 skipped; zero failed |
| python test_agent_team.py | 54 run; 1 skipped; zero failed |
| python spec_check.py | exit 0; 11 OpenSpec capabilities, 99 requirements, 128 scenarios, 43 SDD FR mappings |
| python sdd_roadmap_check.py | exit 0; 58 roadmap tasks, no structural errors |
| python ops.py spec_report Local-Workspace-Extensions local-pc-agent-tooling --strict | exit 0; upstream syntax valid; independent audit still reports 56 requirements missing explicit FR links |
| python review_readiness_matrix.py --limit 3 --with-spec-snapshot | exit 0; recheck_state=MATCH; 13 advisory QA-ready tasks, 3 tasks blocked by known negative QA; 12 source files in snapshot |

Distinct regression suite totals 96 + 113 + 54 = 263 tests; 7 skipped; zero failures. Focused 36 and 5 tests are already included in the 96 review-suite tests and must not be counted twice.

## Local source SHA-256 after implementation

- review_readiness_matrix.py: ddfcda34d2ded99ba09d52450beba8e622183f7bb39f3cf8da39c303d2325fce
- test_review_readiness_matrix.py: d62b9700d6924a7229b5c2100e08bcba6799fc06dff7e0f020e2a355c1624a18
- test_review_snapshot_recheck.py: 107cfd9ba5838ba94afaf17644eebd9579d14e46525d11e2d1d15b1a8d10e062

## Commands

`python review_readiness_matrix.py --with-spec-snapshot --limit 5` — opt-in two-pass read-only snapshot.
`python review_readiness_matrix.py --with-spec-snapshot --require-spec-pin --limit 5` — strict old-queue migration diagnostic, deliberately blocks legacy entries without stored aggregate pins.

## Remaining work / boundaries

- This mechanism DOES NOT persist new full source-snapshot pins when tasks are created. That requires coordinated, owner-reviewed changes to the canonical task/evidence schema and task-admission flow, with backward-compatible migration; no direct edits to live SQLite.
- Existing exact per-requirement SHA in authoritative coordinator preflight is retained. Full aggregate snapshot comparison is additional evidence only and cannot substitute for it.
- P085 MCP host-enforced actor/permission grants, independent reviewer acceptance and 56 unmapped OpenSpec-to-SDD relationships remain open.
- The check does not guarantee the filesystem cannot change again immediately AFTER its final read. Correct authorization/merge must independently revalidate current SHA under its own trusted workflow.
- No queue mutation, reviewer lease, owner approval, host policy or third-party files were changed by this implementation.
