# Проверенные офлайн-прототипы F02/F08 — рабочий цикл 2026-11-02

## Граница и результат

Пользователь запросил непрерывную полезную работу: задача → реализация → негативные тесты → проверка → следующий разрешённый шаг. В рамках существующей команды из пяти логических ролей **НЕ** создан новый автономный ChatGPT-процесс, не повышены права, не выполнены merge/admission и не обещан час единого platform turn. Планировщик `verified_work_cycle.py` остаётся read-only: настоящий агент после завершения работы запрашивает новый snapshot, сохраняет QA evidence и корректно останавливается при отсутствии законных задач.

Живой `agent_team.py overview` (2026-11-02T20:09:05Z) показывал: 16 done, 16 review, 3 rework, 1 working с истёкшей арендой. `queue_supply_watch.py`: live_ready=0, пять будущих задач требуют отдельного owner admission. P085 trusted host/reviewer gate не закрыт. Из этих наблюдений **не следует**, что ChatGPT может работать один час, что 16 задач прошли независимую приёмку или что следующий планировочный вызов имеет lease.

## F02 — offline critical-SKIP ledger

Код: `experiments/chat_only_run/critical_skip_ledger.py`. Тесты: `test_critical_skip_ledger.py`.

Функция `assess_critical_skips(expected, receipts, target_os, source_sha256)` проверяет bounded test inventory и наблюдения по ОС и SHA. Типы `PASS/FAIL/SKIP`, exit code, обязательные проверки и skip reason оцениваются отдельно.

- Критический `SKIP`, отсутствующий mandatory тест, несоответствие OS/SHA, неизвестный exit, пропущенное поле, дублирующее или чужое observation: `INCOMPLETE`/`INVALID_INPUT`, не false PASS.
- Реальный `FAIL` или ненулевой job exit: `FAIL`.
- Полный непротиворечивый набор от вызывающей стороны: только `ADVISORY_PASS`, **не** host-certified PASS и не release.
- Неизвестный Windows SID, ACL/junction, MCP actor или provenance не подтверждается данными Python; `advisory_only=true`, `host_attested=false` и `release_authorized=false` неизменны.
- Тестовая матрица содержит 40 уникальных негативных комбинаций: 8 исходных дефектов × 5 независимых форм tamper/coverage. Плюс edge cases для не-хешируемых объектов, отсутствия mandatory, noncritical skips, duplicate source SHA.

**Наблюдение:** `test_critical_skip_ledger.py`, job `cf78c5a4cf61401abbe5641ff9fbc4c4`, rc=0, 13 tests OK. Исходные файлы зафиксированы SHA; это offline unit evidence, не производственное E2E.

## F08 — offline negative-effect envelope

Код: `experiments/chat_only_run/negative_effect_envelope.py`. Тесты: `test_negative_effect_envelope.py`.

`assess_effect_absence(expected_observers, reports, scope_id, source_sha256)` требует не меньше двух явно перечисленных observers и сравнивает `coverage_scope`, `coverage_complete`, `event_count`, source SHA и наличие записей. Недостающий/дублирующий/stale/malformed observer ⇒ `UNVERIFIED`, положительные сообщения о событиях ⇒ `REPORTED_EFFECT`, полный caller-supplied набор нулей ⇒ **только** `ADVISORY_ZERO_OBSERVED`. В коде нет `ABSENCE_PROVEN` или выдачи доверенной идентичности из JSON. Ни одна ветвь не разрешает публикацию или операции.

**Наблюдение:** `test_negative_effect_envelope.py`, job `b754e9150fa64d18bc1f990aebfe0351`, rc=0, 8 tests OK.

## Побочная независимая находка: журнал длительности

Полная регрессия первоначально дала RED в `test_automation_duration_analysis`: три `duration_seconds` были записаны как `696083 / 443626 / 507731` (масштаб миллисекунд), тогда как timestamps задают примерно `696.082 / 443.626 / 507.730` секунд. В локальном observational report изменены только эти три *derived* поля; scheduler start/end/status/run ID сохранены. Предыдущее состояние и точные run IDs записаны в append-only:
`.agent-team/reports/automation_duration_corrections_20261102T2015Z.json`, с SHA исходного отчёта. Нет исправления данных, которое подменяет реальную длительность модели, и нет вывода о платформенном 25-минутном SLA.

После исправления `automation_duration_analysis.py` rc=0 и `spec_check.py` rc=0 (11 capabilities, 99 requirements, 128 scenarios). Полный `python -m unittest discover -q` job `f6209df16b9944449766642c7e9b48b2`: **1774 tests OK, 43 skipped**, rc=0. Повторный полный прогон **после добавления F08**: job `b46991e3dff743848c1f9714951fbcaf`, rc=0, **1782 tests OK, 43 skipped**. Этот результат охватывает оба новых тестовых модуля; независимый host E2E и P085 ACL/grant по-прежнему не проверены.

## Перед производственным внедрением

1. Сверить F02/F08 со строго каноническими OpenSpec/SDD и актуальным responsibility registry; сейчас это эксперименты, не owner-admitted developer tasks.
2. Требовать независимых actual-host receipts и Windows two-SID E2E: `critical`, `coverage_complete`, `event_count` и `observer_id` в недоверенном JSON не становятся правами или доказательствами.
3. Только после P085 host principal/grant gate и независимой приёмки подключать полученные выводы к release/readiness gates; по умолчанию fail closed.
4. При следующей итерации сначала проверить реальный review backlog и scope leases через `verified_work_cycle.py`, не повторять старые QA по неизменённому SHA. Следующие F07/F03 исследования должны использовать существующие реализации и проходить code-reuse/dedup preflight.

**Никакие фичи здесь не объявлены production-ready, owner-approved или accepted reviewer.**
