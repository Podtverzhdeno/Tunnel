# Проверка пятиагентной команды и read-only review preview

Дата: 1 ноября 2026 года, 15:39:52 UTC.

## Фактический прогресс

| Task | Owner | Status |
| --- | --- | --- |
| P009 — Workspace inventory | developer-1 | done |
| P010 — Literal/regex search | developer-2 | working, lease до 16:25:08 UTC |
| P015 — Diagnostics parser | developer-3 | done |
| P016 — Git repo mapping | developer-4 | done |

Reviewer записал 4 сеанса и принял 3 задачи; они реально находятся в основном проекте. Developer-2 действительно запустился и получил P010; результат ещё не принят.

## Новый контроль приёмки

Добавлена команда agent_team.py review-preview TASK_ID. Это только чтение, без исполнения developer-кода: полный allowlist файлов, SHA-256 исходников и эталонов, свежесть OpenSpec, строгая UTF-8-проверка, AST Python, конфликты основной директории и незавершённый merge journal. Возвращает ready_for_review, blockers и already_accepted. Принятый task не предлагается к повторной приёмке.

Автоматизация Architect Reviewer обновлена: перед каждым accept она обязана вызывать review-preview и останавливаться при блокерах. Требование включено в каноническую OpenSpec-спеку, задача P088 записана в трекер, инструкции — в docs/FIVE_AGENT_TEAM.md.

Этот контроль **не заменяет** независимую проверку кода, реальные тесты, проверку безопасности и host-level reviewer authentication.

## Фактические тесты

- Основной unittest: **224 теста, 214 PASS, 10 SKIP**, exit 0.
- agent_team.py gate-check: unittest / spec_check / OpenSpec strict — PASS.
- spec_check.py: 10 capability, 91 requirement, 101 scenario, 37 FR mappings, 37 SDD tasks, 89 P tasks, 0 errors.
- OpenSpec CLI 1.14.3: local-pc-agent-tooling strict PASS.
- Real standalone MCP wire E2E: 16 из 16 проверок PASS.
- Ранее проверено в песочницах: P009 — 164 теста, 7 пропущено; P015 — 175 тестов, 4 пропущено. Обе задачи позднее приняты ревьюером.

## Открытые блокеры

- P085: реальный Local Workspace MCP-бэкенд не подтверждает личность reviewer на уровне инструментов. Строка architect-reviewer в CLI не является доверенным удостоверением.
- Неограниченные run_script/run_command сохраняют OS-права текущего пользователя. Изолированные копии файлов — не OS sandbox; unit-тесты из developer sandbox могут выполнять Python.
- Отдельный stdio MCP-сервер не зарегистрирован в уже подключённом MCP-бэкенде.
- Merge intent обеспечивает выявление и консервативное восстановление частичного переноса, но не транзакционную атомарность filesystem+SQLite.
- P010 всё ещё выполняется.

Команды мониторинга: agent_team.py overview, status, review-preview P010, merge-status P010, gate-check. Никаких Git push, изменений туннеля и отключений других автоматизаций не выполнялось.
