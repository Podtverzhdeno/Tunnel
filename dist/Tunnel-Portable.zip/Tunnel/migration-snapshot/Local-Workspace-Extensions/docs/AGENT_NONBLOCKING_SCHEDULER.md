# Non-blocking agent scheduling: task-local blockers must not stall a role

**Implementation:** `agent_team.py` (main project), 2026-11-02.
**Canonical basis:** `openspec/changes/local-pc-agent-tooling/specs/agent-orchestration/spec.md` — Task decomposition; Spec-first task pickup; Checkpoint persistence; Lease and heartbeat. This change does **not** grant any new OS/tool permissions and does not change canonical specs.

## Root cause

The old `acquire(role, request_id)` query always preferred an owned `rework` task or expired owned `working` lease before a distinct `available` task. It never checked whether the older task's original source/specification baseline still matched main. The stale P096 coordinator patch was therefore repeatedly selected, while P110 had a different write set and a completed P106 prerequisite. A run without the prior P096 lease token then became unable to make useful progress.

## What has changed

1. `_candidate_block_reason`: before *reacquiring* an owned task, verify its saved baseline against the live canonical spec SHA and all intended main deliverable SHA values; reject missing/reparse-point sandbox and pending merge intents. **No token is revoked, no task status is fabricated and no source is overwritten.**
2. `acquire` scans up to 5,000 eligible tasks under one `BEGIN IMMEDIATE` transaction, skips candidates with stale/unsafe sources, and obtains a fresh scoped lease on the next ready independent task. Existing priority/rework preferences apply only among safe candidates.
3. `acquire ROLE REQUEST_ID --task Pxxx`: select a specifically designated eligible task owned by that role or unowned and assigned to that role. Reject foreign role, non-ready, stale source, pending merge, malformed ID, and reuse of the same idempotency request ID for a different target. Never use the P096 lease for P110.
4. `plan-work ROLE`: a **read-only** query displays ordered candidate tasks and exact `blocked_reason` values plus `recommended_task_id`; it cannot grant a lease or perform work. The race between plan and acquire is closed by the transactional recheck.
5. Two distinct tasks may remain `working` for the same logical role **only when** the coordinator legitimately issued separate task-specific leases. The prior lease remains fenced by its own task ID, token and expiry. This is scheduling independence, not multi-model parallelism.

## Demonstration

```powershell
cd Local-Workspace-Extensions

# No lease, no source mutation:
python agent_team.py plan-work developer-3

# It currently reports P110 AVAILABLE; this command is a suggestion only.
# In an ACTUAL authenticated developer-3 agent invocation, generate one fresh
# safe request ID and call acquire for the allowed independent task:
python agent_team.py acquire developer-3 role3-p110-20261102-001 --task P110

# Then use only the new P110 token with P110 checkpoint/submit commands.
```

**Important:** The example command is illustrative. Do not run a state-changing `acquire` as an unauthenticated outside reader, do not reuse the sample request ID, and do not claim P110 is acquired without a returned actual lease. `role` is currently a caller-supplied string, not proven host identity; P085 trusted host authentication and OS isolation remain a separate hard security blocker.

A new hourly scheduled invocation must generate a **new request ID for a new intended acquire**; reuse a prior ID only for retrying *that same incomplete request* and target. Never reuse a no-work idempotency request across hours. Read `AGENTS.md`, fresh canonical OpenSpec/SDD and current task history. Call `plan-work` once; if the former task cannot be safely reacquired, select its independent ready candidate and use `--task`. Do not try to steal an active task from an inaccessible prior lease.

## Verified safety scenarios

`test_agent_task_selection.py` covers:
- Actual P096-style source SHA drift while P110 remains ready; automatic fallback and unchanged P096 lease/token/status.
- Fresh P096 lease while P110 is ready; P110 is independently claimable immediately.
- Explicit P110 target without changing P096; reject wrong-role or unavailable target.
- Different target under reused request ID rejected.
- Canonical spec change triggers fail-closed on old candidate.
- Read-only planning does not change the task rows.
- **Concurrent** competing P110 claims: one successful acquisition, one `TARGET_NOT_READY`; no double lease.
- Normal `test_agent_team.py` regression: no change to owner fencing or independent review.

**Remaining non-automatable blocker:** recovering a lost *active* lease token from a previous invocation still requires trusted host identity or waiting for expiry; deliberately no role-string-based takeover. This is a host authentication problem (P085), not a reason to idle if another independent task is available. A durable step/memory spec is separately awaiting owner's approval.

## Definition of Done

- Stale owned task does not monopolize a developer role.
- A separate ready task gets a new valid independent lease, with full transactional idempotency and no source overlap.
- Old lease never authorizes operations in the new task and is never revoked to accelerate scheduling.
- Read-only plan and full isolated regression tests pass.
- Main OpenSpec strict and SDD validation pass.
- Only independent reviewer may accept the new coding artifacts; this doc is not an acceptance receipt.
