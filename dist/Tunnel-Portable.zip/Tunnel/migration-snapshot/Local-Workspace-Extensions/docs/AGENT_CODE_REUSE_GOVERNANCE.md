# Architecture ownership and code reuse in the five-agent team

**Implementation status (2026-11-02):** local code-reuse preflight and exact-clone reviewer veto are implemented and tested, including intra-module duplication and annotation-safe fingerprints. The owner approved OpenSpec `add-agent-code-reuse-governance` (6 requirements, 12 scenarios). `agent_team.py` now enforces **newly admitted** explicit responsibility contracts, transactional uniqueness, validated acceptance handoffs, pre-submit reuse disposition, and contract-scoped static import-cycle/API checks during reviewer preview and direct acceptance. Pre-cutover tasks are grandfathered, new tasks without contracts cannot be admitted; the guards cannot establish semantic equivalence, dynamic import safety or MCP host actor identity (P085).

## Root cause of Denis's reported class of issue

The coordinator already enforces disjoint **output filenames**, but two independent agents can implement the same capability in `alpha.py` and `beta.py`. An explicit source-hash snapshot, full test suite, and self-declared architecture PASS do not prove that the new function is unique or needed. Prompt reminders alone cannot prevent this; a guard must execute **before publication**.

The uploaded academic-paper review is not an engineering diff illustrating the reported duplicate; this design addresses the observed structural hole in the local coordinator, not an asserted reproduction of Denis's specific code.

## Measured main-tree baseline (2026-11-02)

Read-only `python code_duplication_baseline.py` scanned **83 top-level production Python modules** containing **374 eligible substantial functions**. It found **0 exact normalized cross-module clones** and **0 near matches at the intentionally strict 0.91 token-similarity threshold**. This is a *narrow current-main baseline*, not proof Denis's report was mistaken: developer task sandboxes, other repositories, near-semantic duplication with different control-flow, and small helpers are not included. In-progress agent deliverables remain subject to a fresh reviewer comparison before merge. A clean structural baseline does not imply scalable or semantically unique responsibilities.

The test suite `test_code_duplication_baseline.py` uses synthetic duplicate modules to verify that a real cross-module clone is reported, and checks that changes to a source SHA invalidate the inventory. The actual main-tree source inventory hash is generated per run; do not cache it as an approval.

## Immediate mandatory agent workflow (existing approved tasks)

1. **Before writing:** run `python task_reuse_preflight.py Pxxx` from `Local-Workspace-Extensions` (or through Local Workspace `run_script`). Confirm exact live task ID, canonical spec reference and SHA-hashed code inventory. Open the top relevant modules/functions and inspect their actual APIs. Check `same_spec_tasks`: sharing a spec is **not** proof of duplicate responsibility, but demands careful coordination.
2. Write a short re-use decision to the task checkpoint: `REUSE_EXISTING module.symbol`, `EXTEND_CANONICAL_OWNER`, or `PROPOSE_NEW_RESPONSIBILITY` with actual reasons, imports, type/exception contracts and scaling budget. This checkpoint note is advisory, not host attestation or approved architecture owner transfer.
3. **Do not create a competing implementation:** if the needed function already exists, call its stable public interface. If its API must change, ask Architect Reviewer for a single owning developer task and make dependent tasks consume the newly accepted interface. Do not silently modify a second owner's files.
4. **Before submit:** run focused/negative tests and the existing `experiments/chat_only_run/agent_quality_gate.py audit Pxxx developer-N`. This now cross-checks **all source deliverables against canonical main** with `code_reuse_guard.py`, and hard structural copies fail `DUPLICATE_IMPLEMENTATION`. The supported `quality_submit.py` refuses such submissions; direct raw coordinator submission is still technically possible under the current privileged MCP tool model and is not an authenticated authorization gate.
5. **Independent review:** `agent_team.py review-preview Pxxx` reports `reuse_guard` with exact hard blockers and *heuristic* near duplicates. The actual `agent_team.review(...,accept,...)` independently repeats the hard-code comparison just before `_check_quality` and before merge intent/source writes. A direct accept call cannot bypass a newly detected exact clone.
6. **If blocked:** do not introduce a skip flag. Refactor the candidate to reuse the existing module; or have the architect explicitly propose a canonical shared component in a new owner-reviewed scope, and re-run tests and source SHA checks. Heuristic near similarities must be independently inspected and recorded; do not claim the detector proves semantic equivalence.

## Evidence and non-goals

- `code_reuse_guard.py`: stdlib AST parser; normalizes local identifiers (including exception handler names and explicit import aliases) and docstrings, retains imported modules, exception types and called APIs, literal constants, control flow, async semantics, parameter kinds/defaults, type annotations and decorators. Substantial exact clones are checked both **across distinct production modules** and **between functions in the same submitted production module**. Different type annotations are not a hard clone, because they can define a distinct API contract; high-similarity code remains advisory. Tests/boilerplate excluded from hard clone checks. Root-level only, limited to 350 production source modules, 2 MiB each, 8,000 eligible functions and 500,000 candidate-to-existing comparisons per audit. Exceeding any budget raises a typed error and **fails the submission/review gate closed**, never silently skips unchecked functions. Reports expose `indexed_production_functions` and `compared_function_pairs` for measurement; bounded diagnostic output with no source snippets/secrets. A substantial matching function fingerprint is a deterministic *structural* duplicate, not a proof that all contracts are interchangeable.
- `task_reuse_preflight.py`: read-only SQLite + bounded canonical code index; returns task's likely reusable symbols and SHA-256 source-inventory fingerprint, does not execute imported modules. Similarity search is lexical/discovery only; read the files to judge whether the design actually matches.
- `test_code_reuse_guard.py`: exact-clone and intra-module clone regressions, local/exception/import alias renames, imported-module and exception-type negatives, docstring, divergent defaults and annotations, async, malformed source, symlink and boilerplate cases.
- `test_agent_reuse_integration.py`: real coordinator reviewer preview and **direct accept veto before any main write**, even when quality checks are bypassed.
- `test_task_reuse_preflight.py`: source SHA changes, repository indexing, exclusion of test files, parallel same-spec task visibility, bad IDs and Windows unsafe paths.
- Full legacy suite remains mandatory. Review findings from heuristic similarity may be missed or false positive. There is no guarantee that a sufficiently altered algorithm is detected; deeper semantic validation needs independent design review, testing and eventually a vetted cross-language contract graph.
- Tasks may legitimately share a `spec_ref`; **do not reject same-spec alone**. New seed entries instead declare an explicit `responsibility.id`, canonical module/API, role and allowed extensions. Old accepted task IDs are not retroactively mapped, so the registry does not automatically detect all semantic overlaps with grandfathered code.

## Architecture enforcement and remaining future work

1. **Implemented for post-cutover tasks:** each owner-ready task carries a typed, immutable `responsibility` object containing ID, canonical module, public API, dependency IDs, extension scope, error/input/output/scaling contract, owner/consumer role and reuse disposition. `seed()` rejects absent/invalid fields and duplicate active owners under a single SQLite `BEGIN IMMEDIATE`; old tasks are grandfathered and remain unmapped until separately reviewed.
2. **Implemented:** handoff to a completed owner requires the exact predecessor task ID and a recorded architect acceptance receipt. The `acquire()` response includes the task's contract. A new developer's `submit` must cite the exact reuse decision and canonical module; `review-preview` and direct `review accept` independently block static import cycles, undeclared imports between registered modules, and missing declared public API.
3. **Remaining:** deeper semantic similarity, cross-language contracts, dynamic import/runtime module hooks, import-graph source SHA journaling, complexity trend, side-effect compatibility and rigorous mapping of legacy tasks. Existing root-level static import analysis detects cycles involving changed modules but cannot prove all runtime dependencies. Human architecture review and the separate structural clone veto remain necessary.
4. **Tests and rollout:** `test_agent_responsibility_integration.py` uses disposable SQLite and real coordinator calls to verify duplicate ownership rollback, no unverified handoff, grandfathered tasks, submission evidence, direct reviewer-cycle veto and accepted publication. The owner-admission preview now withholds candidate tickets lacking contracts before asking for a typed owner confirmation. P085 host actor identity remains unverified; do not simulate owner approval, rewrite unrelated code or silently migrate live leases.

## Reproducible commands

```powershell
cd C:\Users\user\IdeaProjects\Local-Workspace-Extensions
python task_reuse_preflight.py P154
python test_code_reuse_guard.py
python test_agent_reuse_integration.py
python test_task_reuse_preflight.py
python -m unittest discover -q
```

If active sandboxes contain older snapshots after canonical coordinator code changes, each **current leased owner** may use the existing `sync-sandbox` CAS workflow for unchanged **non-deliverable** code. Do not force-refresh unrelated agents or touch their in-progress deliverables.
