# Проверка пятиагентной системы и новой scene-dispatch capability

Дата: 2026-11-01, 17:02:56 UTC.
Основной проект: C:\Users\user\IdeaProjects\Local-Workspace-Extensions.

## Реальные результаты расписания

SQLite queue после нескольких независимых scheduled-вызовов:

| Задача | Роль | Статус | Что установлено |
| --- | --- | --- | --- |
| P009 | developer-1 | done | Workspace inventory принят |
| P010 | developer-2 | done | Scoped code search принят |
| P015 | developer-3 | done | Diagnostics parser принят |
| P016 | developer-4 | done | Read-only Git repo map принят |
| P018 | developer-1 | done | OpenSpec-to-SDD/test traceability принят |
| P021 | developer-2 | available | Offline dependency manifest audit ещё не начат |
| P033 | developer-3 | rework | Ревью обнаружило нарушение byte budget при изменяющемся медиафайле, TOCTOU и неподтверждённую ffprobe provenance |
| P034 | developer-4 | done | Валидатор задач шести сцен принят |
| P092 | developer-2 | done | Независимое ревью завершено; regex безопасность доработана |
| P095 | developer-1 | available | Новая scene-dispatch задача со спецификацией, код не принят |

Итого: **7 done / 2 available / 1 rework**. Временные отметки, владельцы, чекпоинты и подробные замечания доступны только через актуальные `agent_team.py status`, `history TASK_ID` и `overview`; данный документ — снимок на указанное UTC.

## Новые артефакты в этой итерации

- `openspec/changes/local-pc-agent-tooling/specs/scene-dispatch/spec.md`: 3 новых нормативных требования, 6 тестируемых сценариев; отдельная capability не меняет canonical media-pipeline spec, используемую разработчиком P033 в rework.
- `openspec/changes/local-pc-agent-tooling/proposal.md`: декларация capability scene-dispatch, необходимая для структурного checker.
- `specs/001-local-pc-agent-tooling/spec.md`: новое FR-039, трассировка до сцено-ориентированного OpenSpec.
- `specs/001-local-pc-agent-tooling/tasks.md` и `openspec/changes/local-pc-agent-tooling/tasks.md`: P095/P096/T043/T044, реализацию P095 не отмечали готовой.
- `team_seed.json`: P095 priority=30, developer-1, **только** `scene_release_plan.py` и `test_scene_release_plan.py`. Добавлено через SQLite `agent_team.py init`: `added=1`, `seed_total=10`, повторное `init` — `added=0,revised=0`.
- `test_scene_manifest_e2e.py`: 8 дополнительных независимых тестов уже принятого P034: scene03 без истории чата, последовательность шести сцен, idempotent checkpoint replay, ошибка конфликтующего replay, проверка устаревших исходников/артефактов, цикл, caller-supplied verified и bounded malformed JSON. Никаких render процессов, внешней файловой системы, сети, FFmpeg и изменения пользовательских медиа.
- `docs/SCENE_HANDOFF_PLAN.md`: проектные примеры handoff, OpenSpec acceptance и граница доверия к caller-supplied approvals.
- `docs/FIVE_AGENT_TEAM.md`: обновлён устаревший статический бэклог, вместо него указаны `overview/status/history` как источник истины.
- Часовая автоматизация `OpenSpec — Developers 3+4`: добавлено актуальное review-поручение P033 (hard byte caps, descriptor checks, swap/growth tests), с приоритетом собственного rework.

## Фактические проверки

| Контроль | Результат |
| --- | --- |
| Main `python -m unittest discover` | **311 всего; 295 PASS; 16 SKIP; 0 FAIL**, exit 0 |
| `agent_team.py gate-check` | unittest, spec_check, реальный OpenSpec strict — PASS |
| `spec_check.py` | 11 capability specs, 95 требований, 111 сценариев, 39 FR mappings, 44 SDD tasks, 97 OpenSpec task items, errors=[] |
| OpenSpec 1.14.3 `validate local-pc-agent-tooling --strict` | PASS |
| `run_mcp_wire.py` | 9 отдельных stdio MCP-tools, 16/16 проверок PASS |
| `agent_team.py init` повтор | added=0, revised=0, seed_total=10 |

Сбой промежуточной регрессии `Undeclared spec capabilities: scene-dispatch` устранён добавлением capability в `proposal.md`. После исправления все проверки выше перепройдены; ошибку не скрывали.

## Границы надёжности

1. `P095` — **пока только спецификация и новая очередь**, реальной реализации `scene_release_plan.py` не выдали за принятую. Первый разработчик должен взять её с новым lease, написать модуль и тесты, пятый — провести независимое ревью.
2. `P033` не принята: исправление хеширования и дескрипторных/byte-budget race остаётся за developer-3. Нельзя объявлять полноценную безопасную media inventory.
3. `P021` не начата. Реальный пакет проверки зависимостей пока не существует.
4. P085 — MCP host-verified role authorization и OS permission isolation не реализованы. CLI роль developer/reviewer — логический идентификатор. Отдельный standalone stdio MCP E2E не равен установке девяти новых инструментов в живой backend Local Workspace.
5. В `scene-dispatch` входной approved_scene_ids — внешнее заявление, **не криптографически или серверно подтверждённое**. Появление статуса `done` в checkpoint или `verified=true` в manifest не должно автоматически открывать зависимые сцены без отдельного доверенного источника.
6. Четыре активные hourly автоматизации продолжают обеспечивать пять логических ролей (developer-3 и developer-4 последовательно в одной карточке) при сохранении отдельной пользовательской IT/AI-сертификатной автоматизации. Нельзя утверждать пять параллельных процессов.

Проверенная роль reviewer и policy gates, настоящие доказательства render media, автоматический lease по каждой scene и host-side OS sandbox остаются отдельными этапами.
