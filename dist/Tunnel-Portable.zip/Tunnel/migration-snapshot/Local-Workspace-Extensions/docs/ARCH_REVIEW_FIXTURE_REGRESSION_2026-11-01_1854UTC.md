# Architect-reviewer: snapshot fixture regression and queue triage
Date: 2026-11-01 18:54 UTC. Role: architect-reviewer. Scope: read-only architecture/QA audit; no review lease was acquired (acquire task=null).

## Verified results
- Canonical main `python -m unittest discover`: **FAILED**, 456 tests, 58 errors, 20 skipped, returncode 1. Job 6fb1f4fb35cb48c0a67bdf69d82d5aa0.
- Focused `test_snapshot_seed_contract.py`: 6 tests, 1 skipped, **PASS**, returncode 0. Job cc8c3e4b33294d1d83f7e7ce9a8cd96f.
- `spec_check.py`: PASS, 99 requirements, 128 scenarios, 43 FR mappings. Structural only; strict upstream OpenSpec CLI not executed this run.
- `sdd_roadmap_check.py`: PASS, 44 tasks, 4 seeded, 40 blocked, 88 distinct outputs, errors=[].
- `team_acceptance_audit.py`: 3 recorded_pass, 7 legacy_unverifiable, 0 invalid_evidence; host_actor_authenticated=false and os_sandbox_enforced=false.

## Proven regression: snapshot seed preflight breaks existing coordinator tests
Canonical `agent_team.py` `_copy_sandbox` (lines 225-255) requires `PROJECT/team_seed.json` to exist, be a regular bounded JSON array and be copied to each new sandbox. This addresses missing roadmap fixture in new task snapshots, but existing isolated test setup uses `seed.json` without creating `team_seed.json`:
- `test_agent_team.py` lines 15-46: patches `PROJECT` to temporary root and calls `seed(self.seedfile,...)` with `seed.json`.
- `test_agent_token_usage.py` lines 13-39: same fixture pattern, followed by `acquire`.
- `_snapshot -> _copy_sandbox` fails with `TeamError(UNSAFE_SEED, 'Canonical team seed is absent or unsafe')`. Reproduced 58 full-suite errors.
- New focused snapshot tests pass because they explicitly create `team_seed.json`; they do NOT prove compatibility with the old temporary-project fixture.

### Required safe correction
1. Update **only the authorized coordinator/test owner** and tests to provide a canonical bounded `team_seed.json` in temporary fixtures, preferably identical bytes to their fixture seed; preserve the production fail-closed check for missing/invalid seed. Do not bypass or disable full-suite gates.
2. Run full main unittest, targeted snapshot/negative tests, SDD structural check, strict OpenSpec validation, and test missing/oversized/symlink/malformed seed. Add regression proving isolated coordinator and token-usage tests still acquire normally.
3. For **existing** P104/P105/P107 sandboxes, simply changing `_copy_sandbox` does not backfill the already-created snapshots. An owner-reviewed, lease-fenced, SHA-checked, atomic *fixture-only* repair is needed; never overwrite deliverables, developer changes, canonical spec, or lease metadata. Avoid raw manual copying as a bypass. Re-run full sandbox QA before submit/review.
4. Review TOCTOU: `_copy_sandbox` reads and validates manifest before creating the target, then reads it again while copying. Use one validated immutable byte snapshot with safe source identity checks and verify target SHA; fail closed on intervening replacement.
5. No ACCEPT until independent review-preview, merge-status intent=null, source SHA, code/negative QA, SDD and strict OpenSpec are green. After ACCEPT verify acceptance audit recorded_pass.

## Task-by-task anti-idle disposition (live SQLite, ~18:53 UTC)
| Task | Owner / status | Blocker | Independent alternative / next action |
|---|---|---|---|
| P104 | developer-1 / rework | sandbox missing team_seed.json, full QA failed | Reviewer/owner repairs fixture via approved path; developer-1 reacquires and reruns gates. |
| P105 | developer-2 / working | same existing-snapshot fixture, full QA not green | Keep scoped telemetry tests; request owner-authorized fixture repair; no submit without full QA. |
| P107 | developer-4 / working | same existing-snapshot fixture, full QA not green | Keep scoped scene-readiness tests; repair fixture safely; no submit without full QA. |
| P096 | developer-3 / working | stale coordinator baseline and spec drift; root agent_team.py SHA c6dd768ffa068b44d5212c679fab38e434f971e551d45384e3f3c8bcc6b2cdb9 vs candidate ef09564998b2904525612a3310a84176f48cb2057b8c71b45037c1195d9d9a4d | Never merge stale candidate; independent reviewer/owner reconciles after valid lease lifecycle. |
| P106 | developer-3 / working | deliverable team_recovery_diagnostics.py absent at audit; its own lease token not held by reviewer | **Independent of P096**. Developer-3 should work on P106 immediately only in its own valid lease session; no prerequisite to finish P096. |

## Security / completion boundary
P085 host-authenticated reviewer grants and OS-level sandbox are unverified. Do not call S1 or production complete. No P108-P147 seeding: roadmap dependencies and canonical spec mapping are blocked. No provider LLM usage metadata observed; no fabricated token counts. No developer source, active lease, or canonical specification was modified by this audit.
