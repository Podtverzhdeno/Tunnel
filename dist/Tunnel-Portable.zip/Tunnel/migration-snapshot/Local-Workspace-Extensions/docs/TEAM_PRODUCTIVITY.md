# Multi-agent productivity and execution telemetry (operational)

Updated: 2026-11-01. This runbook supplements **existing** canonical OpenSpec/SDD; it does not grant host permissions, release approval or LLM token attestation.

## Read-only reports

From `Local-Workspace-Extensions`:

```powershell
python team_productivity.py
python agent_team.py overview
python agent_team.py usage-report
python team_run_metrics.py --observations .agent-team/reports/scheduler_visible_usage_latest.json --estimate
python token_spend_estimator.py --observations .agent-team/reports/scheduler_visible_usage_latest.json
```

`team_productivity.py` reads the live queue **without modifying SQLite**. Per role it reports: started coordinator sessions, checkpoint/submit event counts, accepted tasks with 3 recorded successful quality gates, older `done` tasks without such evidence, active task states, and allowed sandbox source file sizes, line counts and SHA-256 hashes. File size means current snapshot size, not lines added in a diff. A checkpoint is not test proof. QA facts are those recorded in SQLite, and are not independently host-attested.

`team_run_metrics.py` combines those facts with a separate **numeric-only observation** of scheduled runs, when an observation file is available. A single run's start/end timestamps determine elapsed seconds, not active coding time. The final visible ChatGPT answer can be approximately tokenized, but hidden system context, reasoning, tool calls, prompt growth, caches and repeat model calls are invisible. `actual_llm_input_tokens=null` and `actual_llm_output_tokens=null` are deliberately unknown. The current saved automation prompt is not assumed to have been its historical prompt at the time of execution. The shared developer-3+4 scheduled job cannot be split into two usage streams without a separately trusted provider receipt.

Observations from Automations must be gathered **from real returned run IDs and timestamps** and must never be invented. Never persist prompts, messages, tool responses, API tokens or secrets in numerical observability summaries. The existing `agent_team.py usage-report` remains the only authoritative ledger for provider-returned API usage, and it currently reports `no_token_usage_metadata` for ChatGPT scheduled runs.

## Explicitly unvalidated token-spend scenario forecasting

Read `docs/TOKEN_ESTIMATION_V1_SDD.md` before interpreting `--estimate`. The new `token_spend_estimator.py` uses observed run duration and visible final-answer size to calculate a **scenario prior** for input and output separately. This is NOT an estimate with proven accuracy. Its coefficients have no real ChatGPT provider-usage calibration yet; 90% accuracy **has not been demonstrated**. Any predicted figures are segregated from real `usage-report` entries and marked `uncalibrated_heuristic`.

A later separate dataset with genuine provider counters may calibrate model-/effort-specific errors and evaluate the fraction of independent held-out runs for which **both** input and output predictions are within ±10%; only then can a historical accuracy metric be discussed. A 90% conformal prediction *interval* is not the same as 90% accuracy at ±10%. An unknown model/effort or insufficient data prevents calibration.

## Useful-work loop on each scheduled run

1. Re-read current `AGENTS.md`, OpenSpec, SDD, `docs/ANTI_IDLE_AGENT_POLICY.md`, queue overview, own task history and recent reviewer notes. Treat saved instructions older than accepted changes as stale.
2. Acquire/continue the **actual fenced task** with its live per-task token. No proxy identity, guessed lease or writes into another task's sandbox.
3. Implement an accepted change inside allowlisted deliverables. Run focused positive and adversarial tests, static review, full sandbox unittest, `spec_check.py`, and strict OpenSpec validation; record real outcomes in SQLite checkpoint. Fix observed defects before submit.
4. Submit for independent reviewer when required gates pass. Do not self-approve. If another independent approved and scoped task is available **in the same run**, acquire it with a new request ID and work through it. If there is no permitted task, do a bounded, useful read-only audit rather than repeated idle narration.
5. Reviewer reads actual submitted candidates, verifies approved QA, inspects source+test hashes, accepts/rejects independently, fixes system-wide test fixtures only via owner-approved safe path, and creates the next admitted wave only after DAG/spec review.
6. Report `run_id` (when provided), work items, source hashes, tested commands/return codes, accepted/rejected status, blocker owner and next action, measured elapsed wall time (when provided by scheduler), and `actual_llm_input_tokens=UNKNOWN` / `actual_llm_output_tokens=UNKNOWN` unless provider receipts exist. Never invent token usage or claim a short run necessarily means low effectiveness.

There is **no guaranteed minimum session duration**. Working longer solely to appear busy wastes budget and can increase errors; the objective is productive task throughput and trustworthy gate evidence. Current scheduled automations run discretely and cannot continue between runs unless another scheduled invocation begins. A shorter run is acceptable when the queue is empty or blocked by genuine host security constraints.

## Fixture recovery already completed

Coordinator `_copy_sandbox` now includes the canonical bounded `team_seed.json`. Historical P104, P105, P106, P107 sandboxes had their **missing** seed fixture safely copied with a hash check. No developer deliverables or main SQLite entries were overwritten by fixture repair.

Observed full-suite unittest following repair: P104 488 PASS / 22 skipped, P105 480 PASS / 22 skipped, P107 465 PASS / 22 skipped, each exit 0. These are QA checks, **not** reviewer acceptances. Each owner must still obtain valid lease/reacquisition, submit and independently pass reviewer gates. The P096 candidate remains stale and may not replace canonical `agent_team.py`.

## Host snapshot test fixture repair — 2026-11-02

The full sandbox unittest suite includes tests that read four non-secret
project-owned `host_snapshot/*.py` fixtures. Previously `_copy_sandbox`
copied root `*.py`, OpenSpec and SDD, but omitted `host_snapshot`; new
tasks P150/P154/P158 could pass 101 focused tests yet fail full QA with 23
fixture errors. **Do not mark those tasks accepted or submit on focused tests
alone.**

The main coordinator now copies an allowlisted `host_snapshot` directory
for NEW sandboxes and preflights every file against
`(__init__.py,manage.py,http_server.py,tools.py)`, rejecting unexpected
files, symlinks and missing files. For EXISTING task sandboxes, the
task owner must run `python agent_team.py sync-sandbox ROLE TASK_ID
ITS_ORIGINAL_LIVE_LEASE_TOKEN` under its real active lease. This
only fills absent, exact-byte verified fixtures; existing divergent fixture
bytes fail closed with `HOST_FIXTURE_CONFLICT`, preserving user content.
The baseline now records fixture hashes and independent integration
rejects divergent project/sandbox hashes. A second sync is idempotent.

No change to `Downloads/local-workspace-mcp`, host grants, Git or
live model-token accounting is implied. Developer deliverables are
preserved. Main full QA passed 1181 tests (31 skipped) after the change;
individual P150/P154/P158 full sandbox QA must still be repeated
by their legitimate owners before guarded submit.

## Next capability-level improvements (not yet production implemented)

- Host-bound actor authentication and OS sandbox (P085) so agent roles are not only prompt strings.
- Transactional `park → reassign → unpark` on the coordinator, fenced by the task lease, with a durable reason, DAG checks and no starvation, replay or stale write.
- Versioned immutable scheduler run receipts with independently recorded tool events, timestamps, test outputs, code delta, run ID and model/provider usage metadata where actually exposed.
- Run-aware dashboards and alerts for repeated no-work runs, repeated blocker reports, stalled reviewer queues and test-fixture regressions; isolate shared scheduler roles rather than double counting.
- True usage metering only via an owner-controlled LLM gateway/API returning provider-verified input/output token counts per request. A ChatGPT saved prompt cannot force the platform to reveal unavailable internal usage telemetry.

**Safe command:** `python -m unittest discover` in project root. Never weaken the quality gates to make a dashboard look green.
