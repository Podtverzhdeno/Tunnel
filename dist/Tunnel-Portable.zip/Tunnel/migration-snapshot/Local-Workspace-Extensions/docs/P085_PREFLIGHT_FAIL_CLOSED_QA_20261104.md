# P085 Windows preflight fail-closed audit — 2026-11-04

## Scope and authority
Read-only diagnostic hardening in `Local-Workspace-Extensions/`. No Windows account creation, UAC, ACL edits, OS service installation, protected key read, owner grant, host/tunnel restart, SQLite queue modification, reviewer acceptance, or Git actions.

## Defect reproduced by source inspection
Previously `p085_windows_deploy_preflight.os_protected()` used `record.get("write_allowed_sids", [])`; a missing `write_allowed_sids` could therefore be interpreted as an empty, safe writer list. The check also did not require the ACL parser's `has_deny_aces=false` and `acl_interpretation=CONSERVATIVE_BASIC_ACES_ONLY` evidence. This could yield an optimistic **diagnostic** finding for incomplete or unrecognized access-control metadata; it was never a real authorization to activate P085.

## Applied changes
- `p085_windows_deploy_preflight.py` requires dict-shaped ACL records, explicit owner SID and writer SID list, known conservative basic ACL interpretation and an unambiguous negative deny-ACE result. Missing, malformed, unexpected or nontrusted data fails closed.
- The file and its direct parent are separately checked for symlink/Windows junction indicators before ACL inspection.
- `test_p085_windows_deploy_preflight.py` extends negative coverage: every required missing ACL field, DENY ACE, unknown/invalid ACL interpretation, malformed owner/writer fields, unsafe parent ACL, symlink/junction parent, with a positive complete SYSTEM-only ACL baseline.
- Source SHA256: `2cdf35922c6c256cba4539957d48716239d31086d976b543ba9e67f45cef1aa4`.
- Test SHA256 at first focused run: `005cf101061a302b03043ce674212c457048e0bf7adef5f802f58f46f23441e3`.
- A concurrent legitimate local edit later adjusted the positive fixture to run against an ordinary temporary file instead of a possibly junctioned Python installation; the updated test file SHA256 is `69d09ec3d383934e1339a01690f3209e7c1bcee7c8c17674f519253abc947377`. No unrelated file was overwritten.

## Actual tool receipts
- Focused unittest `26344902fe664796baf4f45cc226d14d`: completed rc=0, **12 tests PASS**.
- Related P085 unittest `81c0992a85044073a3736b989e54ff63`: completed rc=0, **97 run, 91 PASS, 6 SKIP**.
- Live read-only Windows deployment preflight `74fce0589c98409882b2b1253f28f91f`: completed rc=0; `safe_to_activate=false`, `current_process_elevated=false`, `python_runtime_os_protected=false`, `broker_code_tree_os_protected=false`, `service_installed=false`, `stage_health.status=NOT_STAGED`.
- Live read-only stage audit `7d11d699b47046e19213acca7161c362`: completed rc=0; `status=NOT_STAGED`, `blockers=[P085_STAGE_NOT_INSTALLED]`, `trusted_deployment_verified=false`.
- Live coordinator read-only overview `62f7d9ab594f44fb981145f5b2d47794`: completed rc=0; queue `done=16, working=1, rework=3, review=16`. These counters do not establish trusted reviewer authority or actual agent activity.

## Downstream diagnostic pin & integration verification
The web-companion readiness monitor `chat-launch-smoke-desktop-test/web-companion/p085_readiness_matrix.py` deliberately pins the SHA of every script it executes. The first post-edit diagnostic (`6a17b1e6abe647f0a47e8cbcb17f0ffb`) correctly failed closed with `SOURCE_DEPENDENCY_SHA_DRIFT` and `status=UNKNOWN`. After review of the tested preflight source, the non-authorizing diagnostic pin was updated to its exact SHA256 `2cdf35922c6c256cba4539957d48716239d31086d976b543ba9e67f45cef1aa4`; matrix source SHA256 `c22626c0dd87fd4b23bc9fed6ff22b1d40469e3997a9f3815b422259df3bd04b`. This local pin update is **not** trusted owner review, protected binary signing, or OS authorization.

- Matrix-focused tests `d047a79574bd4ebcb3605a7951bcd67f`: completed rc=0, 15/15 PASS.
- Post-pin live matrix `cd4d58863a4848248cd00d43ff81b632`: completed rc=0, `ok=true`, `status=UNTRUSTED`, `can_activate_chain3=false`, `can_complete_chain2=false`, `accounts_missing=5`, `stage_status=NOT_STAGED`.
- Post-concurrent-edit P085 test rerun `facbede0090341ad98271f13c81a74cf`: completed rc=0, `Ran 97 tests`, 91 PASS / 6 SKIP.
- Full web-companion unittest `70724e0f0de247c79e0659d3b38bf8f6`: completed rc=0, `Ran 204 tests`, 203 PASS / 1 SKIP.
- Local SDD structural check `efbee84e76674468898a523a095216d3`: completed rc=0, `ok=true`, 0 errors (structural only, not upstream OpenSpec CLI or E2E).

## Remaining security boundary
This local preflight is still an **advisory inspection**, not OS-authenticated evidence of effective access under five distinct principals or a race-proof check of the full path ancestry. It cannot authorize agent self-review, merge, owner approval, arbitrary privileged operations, or Channel/Chain3 activation. To complete P085, the owner must independently review and stage immutable code outside MCP-writable paths, provision separate OS principals and a protected issuer, verify true multi-principal negative E2E, and enable only a narrow host-authenticated interface. Do not treat this file or source-controlled hashes as a privileged trust anchor.

## Safe next step
Review the existing owner-only `Setup-P085WindowsPrincipals.ps1`, `Install-P085ProtectedService.ps1` and protected-service model **from owner-controlled, non-agent-writable media**. Run independent service/worker/reviewer negative access tests in an actual interactive Windows session. Preserve unresolved Chain2 UNKNOWN deliveries; no blind retries.
