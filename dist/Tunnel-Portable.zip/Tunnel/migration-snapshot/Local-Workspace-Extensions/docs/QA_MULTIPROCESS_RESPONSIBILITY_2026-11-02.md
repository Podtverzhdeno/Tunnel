# Multiprocess responsibility admission — QA evidence (2026-11-02)

## Scope
Strengthens the *existing* canonical `agent_team.py` / `agent_responsibility_guard.py` architecture. Does not install the alternative staged `agent_team_coordinator.py` or create a second production registry.

## Changes
- Added `test_agent_responsibility_multiprocess.py`: Windows-compatible `spawn` process tests against fresh disposable SQLite files.
- Included that test module in `agent_reuse_ci_gate.py`; the existing GitHub Actions workflow already executes this gate on Windows and Ubuntu.
- Test cases: conflicting canonical ownership (exactly one succeeds), four distinct developers (all succeed), and restart with an existing responsibility (new conflicting owner rejected).

## Reproduced evidence (local MCP)
- `python test_agent_responsibility_multiprocess.py`: 3 tests, PASS.
- `python agent_reuse_ci_gate.py`: PASS. Core 120 tests with 4 skipped; additional contract tests 19 with 1 skipped; import graph tests 10 with 1 skipped. Canonical structural clone baseline: 0 cross-module clone groups, scan complete.
- `python agent_responsibility_stress.py --rounds 30 --workers 4`: PASS; 90 distinct-owner admissions, 30 conflicting-owner rejections, 0 unexpected outcomes. This stress probe is thread-based; new tests provide OS-process coverage.

## Safety / remaining gates
- Tests use temporary SQLite state only; no active lease, production queue, pending review or owner approval was modified.
- This proves only the tested responsibility-ID concurrency properties, **not** semantic uniqueness under different IDs. Static duplicate checks and independent architect review remain mandatory.
- Live queue triage at the time: 20 waiting reviews, one expired reviewing lease and one expired working lease; 0 ready coding tasks. This report does not authorize resetting leases, accepting reviews, seeding candidates P162–P169 or bypassing host identity/owner approvals.
- `Local-Workspace-Extensions` is inside a highly dirty parent Git worktree. No global git staging/commit/push performed.
- GitHub branch-protection *required status check* configuration and real production schedule E2E were not verified.

## Next safe actions
1. Independent reviewer investigates stale review leases and 20 queued reviews using current SHA/QA evidence, without self-acceptance.
2. Owner reviews P162+ canonical SDD mapping and queue-admission plan in the approved foreground workflow.
3. Once a trusted actor boundary is available, execute real five-agent E2E with task transitions, checkpoints, and observed lease recovery.
