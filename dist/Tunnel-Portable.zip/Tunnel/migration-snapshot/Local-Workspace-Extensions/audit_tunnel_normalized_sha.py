import hashlib,json,zipfile
from pathlib import Path
r=Path(__file__).resolve().parent.parent/"Tunnel-release-staging"
def sha(b):return hashlib.sha1(b"blob "+str(len(b)).encode("ascii")+b"\x00"+b).hexdigest()
out={}
for fn in ("Tunnel-Complete-Windows.zip","Local-Workspace-MCP.zip","New-Chat-Smoke-Test.zip","Web-Companion-Extension.zip"):
 with zipfile.ZipFile(r/"dist"/fn) as z:
  out[fn]={name:{"normal_sha":sha(z.read(name).replace(b"\r\n",b"\n")),
                 "raw_sha":sha(z.read(name)),"crlf_count":z.read(name).count(b"\r\n")}
           for name in z.namelist()}
print(json.dumps(out,separators=(",",":")))
