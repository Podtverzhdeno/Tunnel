"""P110 / FR-023: bounded, offline crash-reconciliation *plan*, never an executor.

All evidence (including hashes, lease and claimed approvals) is caller-supplied and
unverified. No filesystem, SQLite, network, subprocess, or owner-terminal access.
A SAFE_TO_INSPECT result is not permission to restore, merge or accept anything.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import re
import unicodedata
from typing import Any

MAX_BYTES = 65536
MAX_FILES = 64
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")
TASK_ID = re.compile(r"P[0-9]{3,6}\Z")
JOURNAL_STATES = {"prepared", "applying", "applied", "committed", "reconcile_required"}
TASK_STATES = {"working", "review", "reviewing", "rework", "done"}
STAGE_STATES = {"missing", "staged", "applied"}
RESERVED = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"}
RESERVED.update("COM" + n for n in "123456789¹²³")
RESERVED.update("LPT" + n for n in "123456789¹²³")


class PlanEvidenceError(ValueError):
    """Invalid, ambiguous or unbounded caller evidence."""


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in items:
        if key in result:
            raise PlanEvidenceError("DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def _constant(_: str) -> None:
    raise PlanEvidenceError("NONFINITE_JSON")


def _bounded(value: object) -> None:
    """Preflight Python objects before JSON serialization, including cycles."""
    stack = [(value, 0)]
    seen: set[int] = set()
    nodes = 0
    text_size = 0
    while stack:
        node, depth = stack.pop()
        nodes += 1
        if nodes > 4096 or depth > 32:
            raise PlanEvidenceError("EVIDENCE_TOO_LARGE")
        if type(node) in (dict, list):
            if id(node) in seen:
                raise PlanEvidenceError("CYCLIC_OR_SHARED_OBJECT")
            seen.add(id(node))
            if len(node) > 4096:
                raise PlanEvidenceError("EVIDENCE_TOO_LARGE")
            if type(node) is dict:
                for key, item in node.items():
                    if type(key) is not str:
                        raise PlanEvidenceError("INVALID_JSON_KEY")
                    stack.append((key, depth + 1))
                    stack.append((item, depth + 1))
            else:
                stack.extend((item, depth + 1) for item in node)
        elif type(node) is str:
            try:
                text_size += len(node.encode("utf-8", "strict"))
            except UnicodeError as exc:
                raise PlanEvidenceError("INVALID_UTF8") from exc
            if text_size > MAX_BYTES:
                raise PlanEvidenceError("EVIDENCE_TOO_LARGE")
        elif type(node) is int:
            if node.bit_length() > 8192:
                raise PlanEvidenceError("EVIDENCE_TOO_LARGE")
        elif type(node) in (float, complex):
            raise PlanEvidenceError("INVALID_JSON_NUMBER")
        elif node is not None and type(node) is not bool:
            raise PlanEvidenceError("INVALID_JSON_TYPE")


def _load(evidence: object) -> dict[str, Any]:
    if type(evidence) is dict:
        _bounded(evidence)
        try:
            raw = json.dumps(evidence, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        except (ValueError, TypeError, UnicodeError, OverflowError, RecursionError) as exc:
            raise PlanEvidenceError("INVALID_JSON") from exc
    elif type(evidence) is bytes:
        if len(evidence) > MAX_BYTES:
            raise PlanEvidenceError("EVIDENCE_TOO_LARGE")
        try:
            raw = evidence.decode("utf-8", "strict")
        except UnicodeError as exc:
            raise PlanEvidenceError("INVALID_UTF8") from exc
    elif type(evidence) is str:
        raw = evidence
    else:
        raise PlanEvidenceError("INVALID_ROOT")
    try:
        if len(raw.encode("utf-8", "strict")) > MAX_BYTES:
            raise PlanEvidenceError("EVIDENCE_TOO_LARGE")
        data = json.loads(raw, object_pairs_hook=_pairs, parse_constant=_constant)
    except PlanEvidenceError:
        raise
    except (ValueError, UnicodeError, RecursionError, OverflowError) as exc:
        raise PlanEvidenceError("INVALID_JSON") from exc
    if type(data) is not dict:
        raise PlanEvidenceError("INVALID_ROOT")
    return data


def _fields(value: object, required: set[str], optional: set[str] = frozenset()) -> dict:
    if type(value) is not dict or not required <= value.keys() or value.keys() - required - optional:
        raise PlanEvidenceError("INVALID_FIELDS")
    return value


def _timestamp(value: object) -> datetime:
    if type(value) is not str or len(value) > 64 or not value:
        raise PlanEvidenceError("INVALID_TIMESTAMP")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None or dt.utcoffset() is None:
            raise ValueError("missing timezone")
        return dt.astimezone(timezone.utc)
    except (ValueError, OverflowError) as exc:
        raise PlanEvidenceError("INVALID_TIMESTAMP") from exc


def _safe_path(value: object) -> bool:
    if type(value) is not str or not 1 <= len(value) <= 240:
        return False
    if value.startswith("/") or "\\" in value or ":" in value or "\x00" in value:
        return False
    for part in value.split("/"):
        if (not part or part in {".", ".."} or part.startswith(".")
                or part.endswith((" ", "."))
                or part.split(".", 1)[0].upper() in RESERVED
                or unicodedata.normalize("NFKC", part) != part
                or any(unicodedata.category(c) in {"Cc", "Cf"} for c in part)):
            return False
    return True


def _hash(value: object) -> bool:
    return type(value) is str and SHA256.fullmatch(value) is not None


def _result(classification: str, codes: list[str], count: int) -> dict[str, Any]:
    actions = {
        "BLOCKED": ["Stop automated reconciliation; preserve all bytes and request independent owner review."],
        "MANUAL_REVIEW": ["Inspect exact hashes and journal in a trusted owner terminal; require independent QA and explicit approval."],
        "SAFE_TO_INSPECT": ["Inspect the unchanged source and staged plan; no restore or approval is authorized."],
        "UNKNOWN": ["Obtain well-formed bounded evidence; do not infer success or execute recovery."],
    }
    return {
        "classification": classification,
        "incident_codes": sorted(set(codes)),
        "file_count": count,
        "next_actions": actions[classification],
        "automatic_recovery_authorized": False,
        "owner_action_required": True,
        "host_actor_verified": False,
        "evidence_provenance": "caller_supplied_unverified",
    }


def plan_crash_reconciliation(evidence: object, *, now_utc: str) -> dict[str, Any]:
    """Classify a supplied crash journal; NEVER perform reconciliation.

    Exact input schema:
      task: task_id, status, lease_until (ISO UTC or null), acceptance_recorded
      journal: state, sqlite_committed, files
      files[]: path, before_sha256, target_sha256, current_sha256 (null if
        missing), staged_sha256 (null if missing), stage_state,
        cas_ok, is_symlink. SHA values are claims, not measured values.
      validation (optional): openspec_pass, sdd_pass (strict booleans).
    """
    try:
        now = _timestamp(now_utc)
        doc = _load(evidence)
        _fields(doc, {"task", "journal"}, {"validation"})
        task = _fields(doc["task"], {"task_id", "status", "lease_until", "acceptance_recorded"})
        journal = _fields(doc["journal"], {"state", "sqlite_committed", "files"})
        if (type(task["task_id"]) is not str or not TASK_ID.fullmatch(task["task_id"])
                or type(task["status"]) is not str or task["status"] not in TASK_STATES
                or type(task["acceptance_recorded"]) is not bool
                or type(journal["sqlite_committed"]) is not bool
                or type(journal["state"]) is not str
                or type(journal["files"]) is not list
                or len(journal["files"]) > MAX_FILES):
            raise PlanEvidenceError("INVALID_FIELDS")
        lease = _timestamp(task["lease_until"]) if task["lease_until"] is not None else None
        validation = doc.get("validation")
        if validation is not None:
            _fields(validation, {"openspec_pass", "sdd_pass"})
            if any(type(validation[k]) is not bool for k in ("openspec_pass", "sdd_pass")):
                raise PlanEvidenceError("INVALID_VALIDATION")
        codes: list[str] = []
        files = journal["files"]
        seen: set[str] = set()
        before_count = 0
        target_count = 0
        for entry in files:
            _fields(entry, {"path", "before_sha256", "target_sha256", "current_sha256",
                            "staged_sha256", "stage_state", "cas_ok", "is_symlink"})
            if type(entry["is_symlink"]) is not bool or type(entry["cas_ok"]) is not bool:
                raise PlanEvidenceError("INVALID_FIELDS")
            path = entry["path"]
            if not _safe_path(path) or entry["is_symlink"]:
                codes.append("UNSAFE_PATH")
            else:
                folded = path.casefold()
                if folded in seen:
                    codes.append("DUPLICATE_PATH")
                seen.add(folded)
            for key in ("before_sha256", "target_sha256"):
                if not _hash(entry[key]):
                    raise PlanEvidenceError("INVALID_HASH")
            for key in ("current_sha256", "staged_sha256"):
                if entry[key] is not None and not _hash(entry[key]):
                    raise PlanEvidenceError("INVALID_HASH")
            if type(entry["stage_state"]) is not str or entry["stage_state"] not in STAGE_STATES:
                raise PlanEvidenceError("INVALID_STAGE")
            before = entry["before_sha256"].lower()
            target = entry["target_sha256"].lower()
            current = entry["current_sha256"].lower() if entry["current_sha256"] else None
            staged = entry["staged_sha256"].lower() if entry["staged_sha256"] else None
            if current is None:
                codes.append("MISSING_FILE")
            elif current not in {before, target}:
                codes.append("DIVERGENT_USER_EDIT")
            if current == before:
                before_count += 1
            if current == target:
                target_count += 1
            if not entry["cas_ok"]:
                codes.append("CAS_FAILED")
            if entry["stage_state"] == "missing" and staged is not None:
                codes.append("INCONSISTENT_STAGE")
            if entry["stage_state"] in {"staged", "applied"} and staged != target:
                codes.append("STAGED_HASH_MISMATCH")
            if entry["stage_state"] == "applied" and current != target:
                codes.append("APPLIED_HASH_MISMATCH")
        if journal["state"] not in JOURNAL_STATES:
            codes.append("UNKNOWN_JOURNAL_STATE")
        if not files:
            codes.append("EMPTY_JOURNAL")
        if lease is not None and lease <= now and task["status"] in {"working", "review", "reviewing"}:
            codes.append("EXPIRED_LEASE")
        if task["status"] == "done" and not task["acceptance_recorded"]:
            codes.append("FORGED_DONE")
        if task["status"] == "done" and lease is not None:
            codes.append("DONE_WITH_LEASE")
        if journal["sqlite_committed"] and (journal["state"] != "committed"
                                             or task["status"] != "done"):
            codes.append("INCONSISTENT_COMMIT")
        if task["status"] == "done" and journal["state"] != "committed":
            codes.append("FORGED_DONE")
        if journal["state"] == "committed":
            if (not journal["sqlite_committed"] or task["status"] != "done"
                    or not task["acceptance_recorded"] or target_count != len(files)):
                codes.append("COMMITTED_HASH_MISMATCH")
            if validation is None or not all(validation.values()):
                codes.append("UNVERIFIED_VALIDATION")
            if any(e["stage_state"] != "applied" or
                   e["staged_sha256"].lower() != e["target_sha256"].lower()
                   for e in files if e["staged_sha256"] is not None) or any(
                   e["staged_sha256"] is None for e in files):
                codes.append("COMMITTED_STAGE_EVIDENCE_MISSING")
        if validation is not None and not all(validation.values()):
            codes.append("VALIDATION_FAILED")
        if journal["state"] == "prepared" and (target_count or any(
                e["stage_state"] == "applied" for e in files)):
            codes.append("INCONSISTENT_PREPARED")
        if journal["state"] == "applied" and target_count != len(files):
            codes.append("INCONSISTENT_APPLIED")
        if journal["state"] == "applying" and not (before_count or target_count):
            codes.append("INCONSISTENT_APPLYING")
        severe = {"UNSAFE_PATH", "DUPLICATE_PATH", "MISSING_FILE", "DIVERGENT_USER_EDIT",
                  "CAS_FAILED", "INCONSISTENT_STAGE", "STAGED_HASH_MISMATCH",
                  "APPLIED_HASH_MISMATCH", "FORGED_DONE", "DONE_WITH_LEASE",
                  "INCONSISTENT_COMMIT", "COMMITTED_HASH_MISMATCH",
                  "COMMITTED_STAGE_EVIDENCE_MISSING", "VALIDATION_FAILED",
                  "INCONSISTENT_PREPARED", "INCONSISTENT_APPLIED", "EMPTY_JOURNAL"}
        if any(c in severe for c in codes):
            return _result("BLOCKED", codes, len(files))
        if "UNKNOWN_JOURNAL_STATE" in codes:
            return _result("UNKNOWN", codes, len(files))
        if journal["state"] in {"applying", "applied", "reconcile_required", "committed"}:
            return _result("MANUAL_REVIEW", codes or ["OWNER_RECONCILIATION_REQUIRED"], len(files))
        if codes:
            return _result("MANUAL_REVIEW", codes, len(files))
        return _result("SAFE_TO_INSPECT", ["NO_MUTATION_VERIFIED_BY_CALLER_ONLY"], len(files))
    except PlanEvidenceError as exc:
        code = str(exc)
        return _result("UNKNOWN", [code], 0)
