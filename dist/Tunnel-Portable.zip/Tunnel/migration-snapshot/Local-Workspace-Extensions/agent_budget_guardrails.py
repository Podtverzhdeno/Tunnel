"""P159: deterministic offline provider-usage budget simulation.

All inputs are caller-supplied; no provider API, billing or production policy writes.
Never treat a scenario estimate as measured spend or an offline decision as a grant.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from decimal import Context, Decimal, InvalidOperation, ROUND_HALF_EVEN, localcontext

SCHEMA = "agent-budget-simulation-v1"
MAX_RECEIPTS = 256
MAX_SCENARIOS = 64
MAX_TOKENS = 1_000_000_000
MILLION = Decimal(1_000_000)
MONEY = Decimal("0.000001")
ROLES = frozenset(("developer-1", "developer-2", "developer-3",
                   "developer-4", "architect-reviewer"))
_TOP = frozenset(("schema", "role", "task_id", "utc_day", "tariffs",
                  "receipts", "scenarios", "expected_calls", "limits"))
_TARIFF = frozenset(("model", "input_per_million_usd",
                     "output_per_million_usd", "cached_input_per_million_usd"))
_RECEIPT = frozenset(("usage_id", "role", "task_id", "model", "recorded_at",
                      "source", "input_tokens", "output_tokens",
                      "cached_input_tokens", "reasoning_output_tokens"))
_REQUIRED_RECEIPT = _RECEIPT - {"cached_input_tokens", "reasoning_output_tokens"}
_SCENARIO = frozenset(("scenario_id", "model", "input_tokens_estimate",
                       "output_tokens_estimate", "cached_input_tokens_estimate",
                       "reasoning_output_tokens_estimate"))
_REQUIRED_SCENARIO = _SCENARIO - {"cached_input_tokens_estimate",
                                 "reasoning_output_tokens_estimate"}
_LIMITS = frozenset(("soft_daily_usd", "hard_daily_usd",
                     "soft_task_usd", "hard_task_usd"))
_LABEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/+-]{0,127}\Z")
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}\Z")
_PRICE = re.compile(r"(?:0|[1-9][0-9]{0,3})(?:\.[0-9]{1,6})?\Z")
_TASK = re.compile(r"P[0-9]{3}\Z")


class BudgetError(ValueError):
    """Bounded machine-readable error without untrusted content."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def _shape(value, allowed, required):
    if type(value) is not dict or not required.issubset(value):
        raise BudgetError("INVALID_FIELDS")
    if any(type(k) is not str for k in value) or not set(value).issubset(allowed):
        raise BudgetError("INVALID_FIELDS")


def _items(value, limit):
    if type(value) is not list or len(value) > limit:
        raise BudgetError("INVALID_COLLECTION")
    return value


def _label(value, pattern=_LABEL):
    if type(value) is not str or not pattern.fullmatch(value):
        raise BudgetError("INVALID_IDENTIFIER")
    if value.casefold() in {"unknown", "none", "unspecified"}:
        raise BudgetError("INVALID_IDENTIFIER")
    return value


def _count(value):
    if type(value) is not int or not 0 <= value <= MAX_TOKENS:
        raise BudgetError("INVALID_COUNT")
    return value


def _money(value):
    if type(value) is not str or not _PRICE.fullmatch(value):
        raise BudgetError("INVALID_MONEY")
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise BudgetError("INVALID_MONEY") from exc
    if not amount.is_finite() or amount > Decimal("1000"):
        raise BudgetError("INVALID_MONEY")
    return amount


def _utc_day(value):
    if type(value) is not str or not 20 <= len(value) <= 40:
        raise BudgetError("INVALID_TIMESTAMP")
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise BudgetError("INVALID_TIMESTAMP") from exc
    if stamp.tzinfo is None or stamp.utcoffset() is None:
        raise BudgetError("INVALID_TIMESTAMP")
    return stamp.astimezone(timezone.utc).date().isoformat()


def _tariffs(rows):
    result = {}
    for row in _items(rows, MAX_SCENARIOS):
        _shape(row, _TARIFF, _TARIFF)
        model = _label(row["model"])
        if model in result:
            raise BudgetError("DUPLICATE_MODEL")
        result[model] = {key:_money(row[key]) for key in _TARIFF if key != "model"}
    return result


def _limits(value):
    _shape(value, _LIMITS, _LIMITS)
    parsed = {key:_money(value[key]) for key in _LIMITS}
    if (parsed["soft_daily_usd"] > parsed["hard_daily_usd"] or
            parsed["soft_task_usd"] > parsed["hard_task_usd"]):
        raise BudgetError("INVALID_LIMIT_ORDER")
    return parsed


def _receipt(row, role, task, day):
    _shape(row, _RECEIPT, _REQUIRED_RECEIPT)
    usage_id, model = _label(row["usage_id"], _ID), _label(row["model"])
    if row["role"] != role:
        raise BudgetError("CROSS_ROLE_OR_TASK")
    if type(row["task_id"]) is not str or not _TASK.fullmatch(row["task_id"]):
        raise BudgetError("INVALID_TASK")
    if row["source"] != "provider_reported":
        raise BudgetError("UNVERIFIED_SOURCE")
    if _utc_day(row["recorded_at"]) != day:
        raise BudgetError("CROSS_DAY")
    inp, out = _count(row["input_tokens"]), _count(row["output_tokens"])
    cached = _count(row.get("cached_input_tokens", 0))
    reasoning = _count(row.get("reasoning_output_tokens", 0))
    if cached > inp or reasoning > out:
        raise BudgetError("IMPOSSIBLE_SUBSET")
    return usage_id, model, (inp, out, cached, reasoning), row["task_id"]


def _scenario(row):
    _shape(row, _SCENARIO, _REQUIRED_SCENARIO)
    sid, model = _label(row["scenario_id"], _ID), _label(row["model"])
    inp, out = _count(row["input_tokens_estimate"]), _count(row["output_tokens_estimate"])
    cached = _count(row.get("cached_input_tokens_estimate", 0))
    reasoning = _count(row.get("reasoning_output_tokens_estimate", 0))
    if cached > inp or reasoning > out:
        raise BudgetError("IMPOSSIBLE_SUBSET")
    return sid, model, (inp, out, cached, reasoning)


def _cost(counters, tariff):
    inp, out, cached, _reasoning = counters
    with localcontext(Context(prec=40, rounding=ROUND_HALF_EVEN)):
        return (((inp - cached) * tariff["input_per_million_usd"] +
                 cached * tariff["cached_input_per_million_usd"] +
                 out * tariff["output_per_million_usd"]) / MILLION)


def _format_money(value):
    if value is None:
        return None
    with localcontext(Context(prec=40, rounding=ROUND_HALF_EVEN)):
        return format(value.quantize(MONEY), "f")


def _decision(daily_cost, task_cost, limits, complete,
              daily_lower_bound, task_lower_bound):
    # Known-cost lower bounds are monotone even with missing receipts or
    # unknown tariffs. Crossing a hard limit is a stop, not UNKNOWN.
    if (daily_lower_bound >= limits["hard_daily_usd"] or
            task_lower_bound >= limits["hard_task_usd"]):
        return "STOP_HARD_LIMIT"
    if daily_cost is None or task_cost is None or not complete:
        return "UNKNOWN"
    if (daily_cost >= limits["soft_daily_usd"] or
            task_cost >= limits["soft_task_usd"]):
        return "WARN_SOFT_LIMIT"
    return "WITHIN_CALLER_REPORTED_LIMITS"


def _aggregate_receipts(rows, tariffs, role, task, day):
    seen, daily_cost, task_cost = {}, Decimal(0), Decimal(0)
    unknown_models, unknown_task, task_count = set(), False, 0
    for row in _items(rows, MAX_RECEIPTS):
        usage_id, model, counters, receipt_task = _receipt(row, role, task, day)
        if usage_id in seen:
            if seen[usage_id] != row:
                raise BudgetError("CONFLICTING_USAGE_ID")
            continue  # exact replay never double-counted
        seen[usage_id] = row
        is_task = receipt_task == task
        task_count += int(is_task)
        tariff = tariffs.get(model)
        if tariff is None:
            unknown_models.add(model)
            unknown_task = unknown_task or is_task
        else:
            with localcontext(Context(prec=40, rounding=ROUND_HALF_EVEN)):
                amount = _cost(counters, tariff)
                daily_cost += amount
                if is_task:
                    task_cost += amount
    return (seen, task_count, None if unknown_models else daily_cost,
            None if unknown_task else task_cost, sorted(unknown_models),
            daily_cost, task_cost)


def _evaluate_scenarios(rows, tariffs):
    seen, output = set(), []
    for row in _items(rows, MAX_SCENARIOS):
        sid, model, counters = _scenario(row)
        if sid in seen:
            raise BudgetError("DUPLICATE_SCENARIO")
        seen.add(sid)
        tariff = tariffs.get(model)
        output.append({"scenario_id":sid, "model":model,
                       "scenario_cost_usd":_format_money(_cost(counters, tariff))
                       if tariff is not None else None,
                       "provenance":"SCENARIO_ONLY_NOT_MEASURED"})
    return sorted(output, key=lambda row: row["scenario_id"])


def evaluate_budget(payload):
    """Conservative offline advisory for one role/task/UTC day."""
    _shape(payload, _TOP, _TOP)
    if payload["schema"] != SCHEMA:
        raise BudgetError("INVALID_SCHEMA")
    role, task, day = payload["role"], payload["task_id"], payload["utc_day"]
    if type(role) is not str or role not in ROLES:
        raise BudgetError("INVALID_ROLE")
    if type(task) is not str or not _TASK.fullmatch(task):
        raise BudgetError("INVALID_TASK")
    if type(day) is not str or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
        raise BudgetError("INVALID_DAY")
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError as exc:
        raise BudgetError("INVALID_DAY") from exc
    expected = payload["expected_calls"]
    if type(expected) is not int or not 0 <= expected <= MAX_RECEIPTS:
        raise BudgetError("INVALID_EXPECTED_CALLS")
    tariffs, limits = _tariffs(payload["tariffs"]), _limits(payload["limits"])
    (seen, task_count, daily_cost, task_cost, unknown_models,
     daily_floor, task_floor) = _aggregate_receipts(
        payload["receipts"], tariffs, role, task, day
    )
    if task_count > expected:
        raise BudgetError("MORE_RECEIPTS_THAN_EXPECTED")
    scenarios = _evaluate_scenarios(payload["scenarios"], tariffs)
    complete = expected > 0 and task_count == expected and not unknown_models
    return {
        "schema":"agent-budget-advisory-v1",
        "role":role, "task_id":task, "utc_day":day,
        "provenance":"CALLER_SUPPLIED_PROVIDER_LABELS_UNVERIFIED",
        "chatgpt_scheduled_usage":"UNKNOWN",
        "recorded_receipts":len(seen), "current_task_receipts":task_count,
        "expected_calls":expected, "missing_receipts":expected - task_count,
        "unknown_tariff_models":unknown_models,
        "reported_cost_usd":_format_money(task_cost),
        "reported_role_daily_cost_usd":_format_money(daily_cost),
        "cost_scope":"OBSERVED_PROVIDER_LABELLED_RECEIPTS_ONLY",
        "decision":_decision(daily_cost, task_cost, limits, complete,
                             daily_floor, task_floor),
        "known_daily_cost_lower_bound_usd":_format_money(daily_floor),
        "known_task_cost_lower_bound_usd":_format_money(task_floor),
        "hard_limit_usd":_format_money(min(limits["hard_daily_usd"],
                                          limits["hard_task_usd"])),
        "soft_limit_usd":_format_money(min(limits["soft_daily_usd"],
                                          limits["soft_task_usd"])),
        "scenarios":scenarios,
        "host_authorization_granted":False,
    }
