"""Fail-closed, read-only CI entrypoint for five-agent code reuse governance.

Run from the Local-Workspace-Extensions repository root:
    python agent_reuse_ci_gate.py

This is NOT an owner approval, reviewer acceptance, or MCP host identity check.
It never writes to the production SQLite coordinator or publishes sources.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODULES = (
    "test_code_reuse_guard",
    "test_code_duplication_baseline",
    "test_task_reuse_preflight",
    "test_agent_responsibility_integration",
    "test_agent_responsibility_concurrency",
    "test_agent_responsibility_multiprocess",
    "test_agent_reuse_integration",
    "test_review_queue_triage",
    "test_review_readiness_matrix",
    "test_review_findings_registry",
    "test_reuse_cache_invalidation",
)
EXTRA_TESTS = (
    "experiments/code_reuse_governance/test_contract_guard.py",
    "experiments/code_reuse_governance/test_import_graph_guard.py",
)
TIMEOUT_SECONDS = 180


def _run(args: list[str], timeout: int = TIMEOUT_SECONDS) -> dict:
    try:
        result = subprocess.run(
            [sys.executable, *args], cwd=ROOT, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout, check=False,
        )
        return {
            "passed": result.returncode == 0,
            "exit_code": result.returncode,
            "log_tail": (result.stdout + "\n" + result.stderr)[-3500:],
        }
    except (subprocess.TimeoutExpired, OSError) as exc:
        return {"passed": False, "error": type(exc).__name__, "log_tail": str(exc)[-350:]}


def _baseline() -> dict:
    try:
        raw = subprocess.run(
            [sys.executable, "code_duplication_baseline.py"], cwd=ROOT,
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=90, check=False,
        )
        payload = json.loads(raw.stdout)
        if raw.returncode != 0 or payload.get("ok") is not True:
            raise ValueError("invalid baseline exit/status")
        data = payload["data"]
        hard = data["cross_module_clone_groups"]
        complete = (data["no_source_mutations"] is True
                    and data["truncated"] is False)
        return {
            "passed": hard == 0 and complete,
            "cross_module_clone_groups": hard,
            "near_similarity_groups_advisory": data["near_similarity_groups"],
            "scanned_modules": data["scanned_modules"],
            "eligible_substantial_functions": data["eligible_substantial_functions"],
            "snapshot_sha256": data["canonical_snapshot_sha256"],
            "complete": complete,
        }
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as exc:
        return {"passed": False, "error": type(exc).__name__, "reason": str(exc)[:180]}


def main() -> int:
    checks = {
        "unittest": _run(["-m", "unittest", "-q", *MODULES]),
        "contract_guard": _run([EXTRA_TESTS[0]]),
        "import_graph_guard": _run([EXTRA_TESTS[1]]),
        "canonical_clone_baseline": _baseline(),
    }
    passed = all(item["passed"] for item in checks.values())
    print(json.dumps({
        "schema": "agent-reuse-ci-gate-v1",
        "passed": passed,
        "checks": checks,
        "advisory": "Semantic equivalence and runtime imports still require independent review",
    }, ensure_ascii=False))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
