"""Bounded, offline checkpoint recovery integrity audit (not an authorization).

RECOVERABLE describes metadata consistency only. This module never reads
SQLite, authenticates a host actor, resumes a task or mutates an artifact.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import re
from typing import Any

MAX_CHECKPOINTS = 2_000
MAX_BYTES = 2_000_000
MAX_ISSUES = 256
IDENT = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
SHA = re.compile(r"^[a-f0-9]{64}$")
ARTIFACT = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")
FIELDS = frozenset({
    "checkpoint_id", "task_id", "role", "generation", "predecessor_id",
    "recorded_at", "source_sha256", "artifacts", "next_steps",
    "author_authenticated", "request_id",
})
STOP_CODES = frozenset({
    "TASK_MISMATCH", "ROLE_MISMATCH", "SOURCE_DRIFT", "ARTIFACT_HASH_MISMATCH",
    "CONFLICTING_CHECKPOINT_REPLAY", "GENERATION_COLLISION",
    "GENERATION_REGRESSION", "BROKEN_PREDECESSOR", "INCOMPLETE_NEXT_STEPS",
    "REQUEST_ID_REUSE", "TIMESTAMP_REGRESSION", "GENERATION_GAP",
})


class CheckpointAuditError(ValueError):
    """Stable validation failure for untrusted input."""


def _pairs_unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise CheckpointAuditError("DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def _id(value: Any, optional: bool = False) -> str | None:
    if value is None and optional:
        return None
    if not isinstance(value, str) or not IDENT.fullmatch(value):
        raise CheckpointAuditError("INVALID_IDENTIFIER")
    return value


def _role(value: Any) -> str:
    if not isinstance(value, str) or not 1 <= len(value) <= 64:
        raise CheckpointAuditError("INVALID_ROLE")
    if not all(ch.isalnum() or ch in "_-" for ch in value):
        raise CheckpointAuditError("INVALID_ROLE")
    return value


def _sha(value: Any) -> str:
    if not isinstance(value, str) or not SHA.fullmatch(value):
        raise CheckpointAuditError("INVALID_SHA256")
    return value


def _time(value: Any) -> datetime:
    if not isinstance(value, str) or len(value) > 40:
        raise CheckpointAuditError("INVALID_TIMESTAMP")
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise CheckpointAuditError("INVALID_TIMESTAMP") from exc
    if stamp.tzinfo is None:
        raise CheckpointAuditError("NAIVE_TIMESTAMP")
    return stamp.astimezone(timezone.utc)


def _artifacts(value: Any) -> dict[str, str]:
    if not isinstance(value, dict) or len(value) > 20:
        raise CheckpointAuditError("INVALID_ARTIFACT_MAP")
    result: dict[str, str] = {}
    for name, digest in value.items():
        if not isinstance(name, str) or not ARTIFACT.fullmatch(name):
            raise CheckpointAuditError("INVALID_ARTIFACT_PATH")
        result[name] = _sha(digest)
    return result


def _steps(value: Any) -> list[str]:
    if not isinstance(value, list) or len(value) > 8:
        raise CheckpointAuditError("INVALID_NEXT_STEPS")
    for step in value:
        if not isinstance(step, str) or not 1 <= len(step.strip()) <= 160:
            raise CheckpointAuditError("INVALID_NEXT_STEPS")
        if any(ord(ch) < 32 for ch in step):
            raise CheckpointAuditError("INVALID_NEXT_STEPS")
    return value


def _clean(item: Any) -> dict[str, Any]:
    if not isinstance(item, dict) or any(not isinstance(k, str) for k in item):
        raise CheckpointAuditError("INVALID_CHECKPOINT")
    if set(item) - FIELDS:
        raise CheckpointAuditError("UNSANITIZED_OR_UNKNOWN_FIELD")
    gen = item.get("generation")
    if type(gen) is not int or not 1 <= gen <= 1_000_000:
        raise CheckpointAuditError("INVALID_GENERATION")
    auth = item.get("author_authenticated")
    if auth is not None and type(auth) is not bool:
        raise CheckpointAuditError("INVALID_AUTHOR_CLAIM")
    return {
        "checkpoint_id": _id(item.get("checkpoint_id")),
        "task_id": _id(item.get("task_id")),
        "role": _role(item.get("role")),
        "generation": gen,
        "predecessor_id": _id(item.get("predecessor_id"), optional=True),
        "recorded_at": _time(item.get("recorded_at")),
        "source_sha256": _sha(item.get("source_sha256")),
        "artifacts": _artifacts(item.get("artifacts")),
        "next_steps": _steps(item.get("next_steps")),
        "author_authenticated": auth,
        "request_id": _id(item.get("request_id"), optional=True),
    }


def _issue(issues: list[dict[str, str]], code: str, checkpoint_id: str) -> None:
    if len(issues) < MAX_ISSUES:
        issues.append({"code": code, "checkpoint_id": checkpoint_id})


def _dedupe(
    records: list[dict[str, Any]], issues: list[dict[str, str]]
) -> list[dict[str, Any]]:
    seen: dict[str, str] = {}
    requests: dict[str, str] = {}
    unique: list[dict[str, Any]] = []
    for record in records:
        cid = record["checkpoint_id"]
        # Canonical nested maps prevent false conflicting replays caused
        # solely by artifact insertion order in equivalent metadata.
        canonical = dict(record)
        canonical["recorded_at"] = record["recorded_at"].isoformat()
        signature = hashlib.sha256(json.dumps(
            canonical, sort_keys=True, ensure_ascii=True,
            separators=(",", ":"), allow_nan=False
        ).encode("utf-8")).hexdigest()
        if cid in seen:
            if seen[cid] != signature:
                _issue(issues, "CONFLICTING_CHECKPOINT_REPLAY", cid)
            continue
        seen[cid] = signature
        request = record["request_id"]
        if request is not None:
            if request in requests and requests[request] != signature:
                _issue(issues, "REQUEST_ID_REUSE", cid)
            requests.setdefault(request, signature)
        unique.append(record)
    return unique


def _check_chain(
    records: list[dict[str, Any]], issues: list[dict[str, str]]
) -> None:
    ordered = sorted(records, key=lambda x: (x["generation"], x["checkpoint_id"]))
    seen_gens: set[int] = set()
    previous: dict[str, Any] | None = None
    for record in ordered:
        cid, gen = record["checkpoint_id"], record["generation"]
        if gen in seen_gens:
            _issue(issues, "GENERATION_COLLISION", cid)
        if previous is not None:
            if gen <= previous["generation"]:
                _issue(issues, "GENERATION_REGRESSION", cid)
            if gen != previous["generation"] + 1:
                _issue(issues, "GENERATION_GAP", cid)
            if record["predecessor_id"] != previous["checkpoint_id"]:
                _issue(issues, "BROKEN_PREDECESSOR", cid)
            if record["recorded_at"] < previous["recorded_at"]:
                _issue(issues, "TIMESTAMP_REGRESSION", cid)
        elif record["predecessor_id"] is not None:
            _issue(issues, "BROKEN_PREDECESSOR", cid)
        if previous is None and gen != 1:
            _issue(issues, "GENERATION_GAP", cid)
        if not record["next_steps"]:
            _issue(issues, "INCOMPLETE_NEXT_STEPS", cid)
        seen_gens.add(gen)
        previous = record


def audit_checkpoints(
    records: Any, *, expected_task: str, expected_role: str,
    current_source_sha256: str | None,
    expected_artifacts: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Classify structural recovery evidence without granting task authority."""
    _id(expected_task)
    _role(expected_role)
    if current_source_sha256 is not None:
        _sha(current_source_sha256)
    if expected_artifacts is not None:
        expected_artifacts = _artifacts(expected_artifacts)
    if not isinstance(records, list) or len(records) > MAX_CHECKPOINTS:
        raise CheckpointAuditError("CHECKPOINT_LIMIT_OR_TYPE")
    clean = [_clean(item) for item in records]
    issues: list[dict[str, str]] = []
    unique = _dedupe(clean, issues)
    for item in unique:
        cid = item["checkpoint_id"]
        if item["task_id"] != expected_task:
            _issue(issues, "TASK_MISMATCH", cid)
        if item["role"] != expected_role:
            _issue(issues, "ROLE_MISMATCH", cid)
        if current_source_sha256 is not None:
            if item["source_sha256"] != current_source_sha256:
                _issue(issues, "SOURCE_DRIFT", cid)
        if expected_artifacts is not None:
            if item["artifacts"] != expected_artifacts:
                _issue(issues, "ARTIFACT_HASH_MISMATCH", cid)
        if item["author_authenticated"] is not True:
            _issue(issues, "UNTRUSTED_AUTHOR", cid)
    _check_chain(unique, issues)
    if not unique:
        _issue(issues, "NO_CHECKPOINTS", "<none>")
    if current_source_sha256 is None:
        _issue(issues, "UNKNOWN_CURRENT_SOURCE", "<none>")
    if expected_artifacts is None:
        _issue(issues, "UNKNOWN_ARTIFACT_BASELINE", "<none>")
    issues.sort(key=lambda item: (item["code"], item["checkpoint_id"]))
    has_stop = any(item["code"] in STOP_CODES for item in issues)
    status = "STOP" if has_stop else "UNKNOWN" if issues else "RECOVERABLE"
    return {
        "ok": True, "status": status, "advisory_only": True,
        "host_actor_authenticated": False, "may_resume": False,
        "coverage": "UNKNOWN", "checkpoint_count": len(clean),
        "unique_checkpoint_count": len(unique),
        "issues": issues, "issues_truncated": len(issues) >= MAX_ISSUES,
        "limitations": [
            "RECOVERABLE means structural consistency, not a valid lease.",
            "Caller-supplied author_authenticated is not host identity evidence.",
            "No SQLite state, external side effects or reviewer grant was inspected.",
        ],
    }


def audit_checkpoint_json(
    raw: str | bytes, *, expected_task: str, expected_role: str,
    current_source_sha256: str | None,
    expected_artifacts: dict[str, str] | None = None,
) -> dict[str, Any]:
    if not isinstance(raw, (str, bytes)):
        return {"ok": False, "error": {"code": "INVALID_INPUT_TYPE"}}
    try:
        size = len(raw.encode("utf-8")) if isinstance(raw, str) else len(raw)
        if size > MAX_BYTES:
            raise CheckpointAuditError("INPUT_TOO_LARGE")
        text = raw.decode("utf-8", "strict") if isinstance(raw, bytes) else raw
        return audit_checkpoints(
            json.loads(text, object_pairs_hook=_pairs_unique),
            expected_task=expected_task, expected_role=expected_role,
            current_source_sha256=current_source_sha256,
            expected_artifacts=expected_artifacts,
        )
    except UnicodeError:
        return {"ok": False, "error": {"code": "INVALID_UTF8"}}
    except (CheckpointAuditError, ValueError, TypeError) as exc:
        code = str(exc) if isinstance(exc, CheckpointAuditError) else "INVALID_JSON"
        return {"ok": False, "error": {"code": code}}
