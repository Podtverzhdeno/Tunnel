"""Honest observed-text token proxies for ChatGPT scheduled agent runs.

No ChatGPT Automation usage API is available through this tool. This module
reports counts/approximations for *visible* text only; it never inserts any
approximation into the authoritative provider token_usage ledger.
Stdlib only, no network and no persistence of prompt / response content.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path

ROLES = frozenset({"developer-1", "developer-2", "developer-3", "developer-4", "architect-reviewer", "scheduler-developer-3+4"})
# One automation hosts two logical roles: never divide a shared usage sample
# between developer-3 and developer-4 without separate provider receipts.
MAX_INPUT_BYTES = 2 * 1024 * 1024
MAX_RUNS = 100
MAX_TEXT_BYTES = 350_000
IDENT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{5,127}\Z")
_CYRILLIC = re.compile(r"[А-Яа-яЁё]")
_LATIN = re.compile(r"[A-Za-z]")
_DIGITS = re.compile(r"[0-9]")


class ObservationError(ValueError):
    pass


def _text_info(value: str) -> dict:
    if not isinstance(value, str):
        raise ObservationError("TEXT_INVALID")
    raw = value.encode("utf-8", "strict")
    if len(raw) > MAX_TEXT_BYTES:
        raise ObservationError("TEXT_TOO_LARGE")
    cyr = len(_CYRILLIC.findall(value))
    latin = len(_LATIN.findall(value))
    digits = len(_DIGITS.findall(value))
    other = max(0, len(value) - cyr - latin - digits)
    # Deliberately a rough cross-language *text proxy*, not a model tokenizer.
    # No asserted confidence interval: code, logs and Russian text vary widely.
    proxy = (cyr / 2.1) + (latin / 3.8) + (digits / 2.6) + (other / 1.8)
    return {
        "utf8_bytes": len(raw),
        "characters": len(value),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "estimated_visible_text_tokens": math.ceil(proxy) if value else 0,
        "method": "multiscript_character_ratio_v1_not_model_tokenizer",
    }


def _parse_time(value: str) -> datetime:
    if not isinstance(value, str) or len(value) > 64:
        raise ObservationError("TIME_INVALID")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError) as e:
        raise ObservationError("TIME_INVALID") from e
    if dt.tzinfo is None:
        raise ObservationError("TIMEZONE_REQUIRED")
    return dt


def observe_one(run: dict) -> dict:
    if not isinstance(run, dict):
        raise ObservationError("RUN_INVALID")
    allowed = {
        "role", "run_id", "scheduled_prompt", "visible_result",
        "started_at", "completed_at", "result_truncated", "prompt_same_run",
    }
    if set(run) - allowed:
        raise ObservationError("UNKNOWN_FIELDS")
    role = run.get("role")
    run_id = run.get("run_id")
    if role not in ROLES or not isinstance(run_id, str) or not IDENT.fullmatch(run_id):
        raise ObservationError("IDENTITY_INVALID")
    prompt = _text_info(run.get("scheduled_prompt"))
    text = run.get("visible_result")
    if text is None:
        output = None
    else:
        output = _text_info(text)
    started = _parse_time(run.get("started_at"))
    ended_raw = run.get("completed_at")
    ended = _parse_time(ended_raw) if ended_raw is not None else None
    if ended is not None and ended < started:
        raise ObservationError("TIME_ORDER_INVALID")
    if type(run.get("result_truncated", False)) is not bool:
        raise ObservationError("TRUNCATED_INVALID")
    if type(run.get("prompt_same_run", False)) is not bool:
        raise ObservationError("PROMPT_PROVENANCE_INVALID")
    return {
        "role": role,
        "run_id": run_id,
        "source": "scheduler_visible_saved_prompt_and_result",
        "started_at": started.isoformat(),
        "completed_at": ended.isoformat() if ended is not None else None,
        "duration_seconds": round((ended - started).total_seconds(), 3) if ended else None,
        "visible_prompt": prompt,
        "prompt_same_run": run.get("prompt_same_run", False),
        "visible_result": output,
        "result_truncated": run.get("result_truncated", False),
        "estimate_scope": "visible_text_only",
        "full_input_tokens": None,
        "full_output_tokens": None,
        "provider_reported_input_tokens": None,
        "provider_reported_output_tokens": None,
        "hidden_system_context_tools_reasoning_usage_included": False,
        "status": "in_progress" if ended is None else "completed",
        "notice": "VISIBLE TEXT PROXY ONLY: excludes hidden system text, tools, context and reasoning. Not billing usage.",
    }


def observe_many(obj: dict) -> dict:
    if not isinstance(obj, dict) or set(obj) != {"runs"}:
        raise ObservationError("DOCUMENT_INVALID")
    runs = obj["runs"]
    if not isinstance(runs, list) or len(runs) > MAX_RUNS:
        raise ObservationError("RUNS_INVALID")
    seen = set()
    result = []
    for row in runs:
        item = observe_one(row)
        key = (item["role"], item["run_id"])
        if key in seen:
            raise ObservationError("RUN_DUPLICATE")
        seen.add(key)
        result.append(item)
    by_agent = {}
    for role in sorted(ROLES):
        items = [r for r in result if r["role"] == role]
        in_est = sum(r["visible_prompt"]["estimated_visible_text_tokens"] for r in items)
        out_est = sum(r["visible_result"]["estimated_visible_text_tokens"]
                      for r in items if r["visible_result"] is not None)
        by_agent[role] = {
            "observed_runs": len(items),
            "completed_runs": sum(r["status"] == "completed" for r in items),
            "current_saved_prompt_proxy": in_est if items else None,
            "visible_prompt_estimate": in_est if items and all(r["prompt_same_run"] for r in items) else None,
            "visible_response_estimate": out_est if items and all(
                r["visible_result"] is not None and not r["result_truncated"] for r in items
            ) else None,
            "actual_input_tokens": None,
            "actual_output_tokens": None,
            "coverage": "visible_text_proxy_only" if items else "no_observed_runs",
        }
    return {
        "ok": True,
        "schema": "scheduled-run-observations-v1",
        "provenance": "unverified_scheduler_visible_text",
        "by_agent": by_agent,
        "runs": result,
        "usage_not_available_is_not_zero": True,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Local JSON document with visible run text")
    args = parser.parse_args(argv)
    path = Path(args.input)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_INPUT_BYTES:
        raise SystemExit("INPUT_UNSAFE")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        report = observe_many(data)
    except (OSError, UnicodeError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)[:120]}))
        return 1
    print(json.dumps(report, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
