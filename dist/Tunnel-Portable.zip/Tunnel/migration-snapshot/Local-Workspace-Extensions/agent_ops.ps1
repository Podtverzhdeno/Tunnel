#requires -Version 5.1
<#
.SYNOPSIS
  Safe PowerShell frontend for the Local-Workspace-Extensions agent team.
.DESCRIPTION
  Read-only queue/trace/spec diagnostics and explicit test commands.
  Does NOT seed SQLite, request leases, run owner approval, start agents,
  stop/restart the MCP host, or claim a user's interactive approval.
.EXAMPLE
  .\agent_ops.ps1 -Action All
.EXAMPLE
  .\agent_ops.ps1 -Action Queue
#>
[CmdletBinding()]
param(
    [ValidateSet('Queue', 'Trace', 'Plan', 'Tests', 'Spec', 'All')]
    [string]$Action = 'Queue',
    [ValidateSet('developer-1','developer-2','developer-3','developer-4')]
    [string]$Role
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root -PathType Container)) {
    throw 'PROJECT_ROOT_UNAVAILABLE'
}
$python = Get-Command python -CommandType Application -ErrorAction Stop

function Invoke-ProjectPython {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Script,
        [string[]]$ScriptArguments = @()
    )
    $full = Join-Path $root $Script
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        throw "PROJECT_SCRIPT_MISSING: $Script"
    }
    Write-Host ("--- python " + $Script + " " + ($ScriptArguments -join ' ')) -ForegroundColor Cyan
    & $python.Source $full @ScriptArguments
    if ($LASTEXITCODE -ne 0) {
        throw "PROJECT_STEP_FAILED: $Script (exit=$LASTEXITCODE)"
    }
}
function Invoke-Queue {
    Invoke-ProjectPython 'experiments\chat_only_run\queue_supply_watch.py'
    Invoke-ProjectPython 'experiments\chat_only_run\owner_queue_admit.py'
    Write-Host 'Admission is a read-only PREVIEW here. Only the owner can approve in an interactive terminal.' -ForegroundColor Yellow
}
function Invoke-Plan {
    $roles = @('developer-1','developer-2','developer-3','developer-4')
    if ($Role) { $roles = @($Role) }
    foreach ($member in $roles) {
        Invoke-ProjectPython 'agent_team.py' @('plan-work', $member)
    }
    Write-Host 'A plan is NOT a lease or an execution grant.' -ForegroundColor Yellow
}
function Invoke-Trace {
    Invoke-ProjectPython 'token_forensics_health.py'
    Invoke-ProjectPython 'token_forensics_mcp_canary.py'
    Write-Host 'MCP tool events do not measure internal ChatGPT LLM tokens.' -ForegroundColor Yellow
}
function Invoke-Tests {
    Push-Location -LiteralPath $root
    try {
        Write-Host '--- python -m unittest discover -q' -ForegroundColor Cyan
        & $python.Source -m unittest discover -q
        if ($LASTEXITCODE -ne 0) {
            throw "UNIT_TESTS_FAILED: exit=$LASTEXITCODE"
        }
    }
    finally {
        Pop-Location
    }
}
function Invoke-Spec {
    Push-Location -LiteralPath $root
    try {
        Invoke-ProjectPython 'ops.py' @('spec_validate','Local-Workspace-Extensions','local-pc-agent-tooling')
    }
    finally {
        Pop-Location
    }
}
switch ($Action) {
    'Queue' { Invoke-Queue }
    'Trace' { Invoke-Trace }
    'Plan'  { Invoke-Plan }
    'Tests' { Invoke-Tests }
    'Spec'  { Invoke-Spec }
    'All'   {
        Invoke-Queue
        Invoke-Plan
        Invoke-Trace
        Invoke-Spec
        Invoke-Tests
    }
    default { throw "UNKNOWN_ACTION" }
}
Write-Host 'Completed: no queue admission or host mutation performed.' -ForegroundColor Green
