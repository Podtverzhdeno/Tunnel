"use strict";
const assert=require("node:assert/strict"),fs=require("node:fs");
const vm=require("node:vm"),path=require("node:path");
const base=__dirname;
const read=name=>fs.readFileSync(path.join(base,name),"utf8");
const bg=read("same_chat_bg.js");
const popup=read("popup.js");
const html=read("popup.html");
new vm.Script(bg,{filename:"same_chat_bg.js"});
new vm.Script(popup,{filename:"popup.js"});
const roles=["developer-1","developer-2","developer-3","developer-4","architect-reviewer"];
assert.equal(roles.length,new Set(roles).size);
for(const role of roles){
 assert.ok(bg.includes('role:"'+role+'"'),"Role missing from team launcher: "+role);
}
assert.match(bg,/team_requires_five_roles/);
assert.match(bg,/team_already_running/);
assert.match(bg,/team_prompt_length_invalid/);
assert.match(bg,/confirmed_observers/);
assert.match(bg,/awaiting_observer/);
assert.match(bg,/teamRole/);
assert.match(bg,/isTeam\|\|m\.separateWindows===true/);
assert.match(bg,/teamId=isTeam\?crypto\.randomUUID\(\)/);
assert.match(html,/<button id="startTeam" type="button">/);
assert.match(popup,/\$\("startTeam"\)\.addEventListener\("click",\(\)=>batch\("team"\)\)/);
assert.match(popup,/mode==="team"\?5:Number/);
assert.match(popup,/mode==="team"\|\|\$\("separateWindows"\)\.checked/);
assert.match(popup,/confirmed_observers/);
console.log("PASS 5-role browser team: source parses, dedicated UI, distinct roles, popup-only batch, bounded admissions and observer evidence");
