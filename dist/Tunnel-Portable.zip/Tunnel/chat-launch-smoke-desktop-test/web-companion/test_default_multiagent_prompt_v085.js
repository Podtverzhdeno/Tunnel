"use strict";
const assert=require("node:assert/strict"),fs=require("node:fs"),vm=require("node:vm"),path=require("node:path");
(async()=>{
 const dir=__dirname;
 const source=fs.readFileSync(path.join(dir,"same_chat_bg.js"),"utf8");
 const html=fs.readFileSync(path.join(dir,"popup.html"),"utf8");
 const popup=fs.readFileSync(path.join(dir,"popup.js"),"utf8");
 const found=source.match(/const defaults=(\{[^\n]+\});/);
 assert.ok(found,"default prompt declaration");
 const defaults=vm.runInNewContext("("+found[1]+")");
 const prompt=defaults.prompt;
 assert.ok(prompt.length>=2200&&prompt.length<=5000,"detailed but accepted by UI");
 const expected=["Local-Workspace-Extensions","Local Workspace MCP","AGENTS.md","VERIFIED_WORK_CYCLE.md",
  "PEER_ROLE_SWITCH.md","ARCHITECT_SUPPORT_LOOP.md","task_reuse_preflight",
  "P085","peer-review","checkpoint","job_status","job_output","LOOP_STOP","LOOP_NEXT_CHAT"];
 for(const name of expected)assert.ok(prompt.includes(name),"missing contract: "+name);
 assert.ok(prompt.includes("не разрабатывал"),"no self-review");
 assert.ok(prompt.includes("не выдумывай успех"),"honest evidence");
 assert.ok(source.includes('const MAX_PROMPT_CHARS=5000;'));
 assert.ok(source.includes("prompt.length>MAX_PROMPT_CHARS"));
 assert.ok(source.includes("prompt.length<=MAX_PROMPT_CHARS"));
 assert.ok(html.includes('id="loopDefaultPrompt"'));
 assert.ok(html.includes('maxlength="5000"'));
 assert.ok(popup.includes('loopPrompt.value=defaultLoopPrompt'));
 const hooks=[];
 const storage=new Map();
 const chrome={storage:{local:{
  async get(k){if(k===null)return Object.fromEntries(storage);const result={};for(const key of Array.isArray(k)?k:[k])if(storage.has(key))result[key]=storage.get(key);return result;},
  async set(items){for(const [k,v] of Object.entries(items))storage.set(k,v)}
 }},tabs:{async get(id){return {id,url:"https://chatgpt.com/c/demo"}} ,
  async sendMessage(){return {ok:true,version:"0.8.5"}},
  onRemoved:{addListener(){}},onUpdated:{addListener(){}}},
  runtime:{onMessage:{addListener(fn){hooks.push(fn)}},onStartup:{addListener(){}},onInstalled:{addListener(){}}},
  alarms:{onAlarm:{addListener(){}}},
  scripting:{async executeScript(){}}};
 vm.runInNewContext(source,{chrome,URL,Promise,Date,console,
  crypto:{randomUUID:()=> "00000000-0000-4000-8000-000000000001"},setTimeout});
 assert.equal(hooks.length,1);
 const request=msg=>new Promise(resolve=>hooks[0](msg,{},resolve));
 const result=await request({type:"same-chat-control",action:"start",tabId:7,
  prompt,unlimited:true,rotateEvery:0});
 assert.equal(result.ok,true,"long default prompt accepted by state machine");
 const bad=await request({type:"same-chat-control",action:"stop",tabId:7});
 assert.equal(bad.ok,true);
 const rejected=await request({type:"same-chat-control",action:"start",tabId:7,
  prompt:"x".repeat(5001),unlimited:true,rotateEvery:0});
 assert.equal(rejected.reason,"prompt_length_invalid");
 console.log("PASS multiagent default: "+prompt.length+" chars; long prompt accepted, >5000 rejected, UI reset control present");
})().catch(e=>{console.error(e);process.exitCode=1;});