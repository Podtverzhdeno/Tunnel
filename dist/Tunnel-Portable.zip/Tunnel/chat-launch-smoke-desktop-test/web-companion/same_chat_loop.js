/* Same-chat Loop v0.8.0: per-tab user opt-in, no hidden ChatGPT APIs. */
(()=>{
"use strict";
if(window.top!==window||location.origin!=="https://chatgpt.com")return;
const core=globalThis.ChatLaunchSmoke;
if(!core||globalThis.__SameChatLoopV080)return;
globalThis.__SameChatLoopV080=true;
const CHAT=/^\/c\/[a-z0-9-]+$/;
const CONTENT_PROTOCOL="0.8.5";
const normalize=s=>String(s||"").replace(/\s+/g," ").trim();
const userSelector='[data-message-author-role="user"],[data-testid="user-message"]';
const assistantSelector='[data-message-author-role="assistant"],[data-testid="assistant-message"]';
const stopSelector='button[data-testid="stop-button"],button[aria-label="Stop generating"],button[aria-label="Stop"],button[aria-label="Остановить генерацию"]';
const alertSelector='[role="alert"],[role="status"],[data-sonner-toast],[data-testid*="toast"],[data-testid*="error"]';
const rateError=/limit reached|usage limit|too many requests|rate limit|unusual activity|try again later|достигнут.*лимит|слишком много запросов|попробуйте позже|подозрительн.*активност/i;
const connectionError=/connection (?:lost|interrupted|failed)|network (?:error|disconnected|unavailable)|reconnecting|failed to connect|соединени[ея] (?:потерян|прерван|разорван)|связь (?:пропала|потеряна|прервана)|ошибка сети|нет подключения|переподключени/i;
const contextError=/conversation (?:too long|limit reached|has reached its maximum length)|maximum conversation length|контекст.*(?:исчерпан|слишком длин)|диалог.*(?:слишком длин|превысил)/i;
const SLEEP=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const checkpointPath=id=>"chat-launch-smoke-desktop-test/loop-checkpoints/"+id+".md";
let busy=false,writing=false,sending=false,stableNode=null,stableText="",stableSince=0;
let lastPath=location.pathname,lastDiagnostic="",lastDiagnosticAt=0;
async function stage(data){
 try{return await chrome.runtime.sendMessage({type:"same-chat-stage",...data});}
 catch(_){return {ok:false,reason:"runtime_unavailable"};}
}
async function block(reason){return stage({action:"block",reason});}
function issue(){
 if(core.detectAccountConflict?.(document))return "account_conflict";
 if(navigator.onLine===false)return "connection_lost";
 for(const el of document.querySelectorAll(alertSelector)){
  const value=normalize(el.innerText||el.textContent).slice(0,600);
  if(rateError.test(value))return "rate_limited";
  if(contextError.test(value))return "conversation_full";
  if(connectionError.test(value))return "connection_lost";
 }
 return "";
}
const TURN_SELECTOR='section[data-turn],article[data-turn],[data-testid^="conversation-turn-"],[data-turn-id],[data-turn-key],[data-message-id],article';
const RENDERED_SELECTOR='[data-testid="message-content"],[data-testid="final-completion"],.markdown,[class*="markdown"],.prose';
const SCL_MARKER=/SCL-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
const ASSISTANT_ACTION=/read aloud|listen|regenerate|retry|good response|bad response|thumbs.up|thumbs.down|озвуч|прочитать вслух|повторить ответ|перегенерир|хороший ответ|плохой ответ/i;
function messageRole(node){
 const searchKey=node.getAttribute?.("data-content-search-unit-key")||"";
 const keyed=searchKey.match(/:(user|assistant)$/);
 if(keyed)return keyed[1];
 const fromAttr=node.getAttribute?.("data-message-author-role")||
  node.getAttribute?.("data-turn")||
  node.getAttribute?.("data-role")||
  node.getAttribute?.("data-message-author")||
  node.querySelector?.("[data-message-author-role]")?.getAttribute?.("data-message-author-role");
 if(fromAttr==="assistant"||fromAttr==="user")return fromAttr;
 if(node.querySelector?.('[data-user-message-bubble="true"]'))return "user";
 const testId=node.getAttribute?.("data-testid")||"";
 if(node.matches?.(assistantSelector)||/assistant-message/.test(testId)||
   node.querySelector?.('[data-testid="assistant-message"]'))return "assistant";
 if(node.matches?.(userSelector)||/user-message/.test(testId)||
   node.querySelector?.('[data-testid="user-message"]'))return "user";
 return "unknown";
}
function assistantEvidence(node){
 const rich=!!node.querySelector?.(RENDERED_SELECTOR);
 const buttons=[...(node.querySelectorAll?.('button,[role="button"]')||[])];
 const actions=buttons.map(btn=>[
  btn.getAttribute?.("aria-label"),btn.getAttribute?.("title"),
  btn.getAttribute?.("data-testid")
 ].filter(Boolean).join(" ")).filter(Boolean);
 // Toolbar evidence, not raw prose alone: user turns may also contain Markdown.
 const uniqueAction=actions.some(name=>ASSISTANT_ACTION.test(name));
 const copyAction=actions.some(name=>/copy|копир/i.test(name));
 return rich&&(uniqueAction||(copyAction&&buttons.length>=4));
}
function messages(){
 const root=document.querySelector('main,[role="main"]')||document;
 const explicit=[...root.querySelectorAll(userSelector+","+assistantSelector)];
 // New Chat/Work app shells label individual content units, not whole articles.
 const units=[...root.querySelectorAll("[data-content-search-unit-key]")]
  .filter(node=>/:(user|assistant)$/.test(node.getAttribute?.("data-content-search-unit-key")||""));
 const turns=[...root.querySelectorAll(TURN_SELECTOR)];
 const hasConversationTurns=turns.length&&(!explicit.length||
  turns.some(turn=>explicit.some(el=>turn===el||turn.contains?.(el))));
 const raw=units.length?units:hasConversationTurns?turns:explicit;
 const selected=raw.filter((x,i)=>!raw.some((y,j)=>i!==j&&y.contains?.(x)));
 return selected.map(node=>{
  const role=messageRole(node);
  return {node,role,text:normalize(node.textContent),
   assistantEvidence:role==="assistant"||role==="unknown"&&assistantEvidence(node)};
 });
}
function latest(){
 const all=messages();
 return {all,last:all[all.length-1]||null,
  lastUser:[...all].reverse().find(x=>x.role==="user"||
    x.role==="unknown"&&!x.assistantEvidence&&SCL_MARKER.test(x.text)),
  lastAssistant:[...all].reverse().find(x=>x.role==="assistant"||
    x.role==="unknown"&&x.assistantEvidence)};
}
function inspectDom(){
 const list=messages();
 const last=list[list.length-1];
 const root=document.querySelector('main,[role="main"]')||document;
 const count=selector=>root.querySelectorAll(selector).length;
 // Do not include conversation content, URLs, IDs, account or any DOM HTML.
 return {protocol:CONTENT_PROTOCOL,turns:list.length,
  knownUsers:list.filter(x=>x.role==="user").length,
  knownAssistants:list.filter(x=>x.role==="assistant").length,
  assistantToolbarCandidates:list.filter(x=>x.role==="unknown"&&x.assistantEvidence).length,
  formattedBlocks:count('.markdown,[class*="markdown"],.prose,[data-testid="message-content"],[data-testid="final-completion"]'),
  selectors:{classicRoles:count('[data-message-author-role]'),
   classicTurns:count('[data-testid^="conversation-turn-"]'),
   article:count('article'),sectionTurns:count('section[data-turn]'),
   turnKeys:count('[data-turn-key]'),
   assistantUnits:count('[data-content-search-unit-key$=":assistant"]'),
   userUnits:count('[data-content-search-unit-key$=":user"]'),
   userBubbles:count('[data-user-message-bubble="true"]'),
   newTestIds:count('[data-test-id]')},
  lastRole:last?.role||"none",
  lastTag:String(last?.node?.tagName||"none").toLowerCase(),
  lastAssistantEvidence:!!last?.assistantEvidence,
  assistantCandidate:!!observedAnswer(),
  stableForMs:stableSince?Math.max(0,Date.now()-stableSince):null,
  generating:generating(),
  editorPresent:editorText()!==null,editorEmpty:editorEmpty()};
}
function generating(){
 return !!document.querySelector(stopSelector+
  ',[data-testid="streaming-indicator"],[data-testid="thinking-indicator"]');
}
function stopButton(){
 for(const node of document.querySelectorAll(stopSelector)){
  if(node.disabled||node.getAttribute("aria-disabled")==="true")continue;
  const b=node.getBoundingClientRect?.();
  if(b&&(b.width<=1||b.height<=1))continue;
  return node;
 }
 return null;
}
function editorText(){
 const editor=core.findEditor(document);
 return editor?normalize(editor.value??editor.textContent):null;
}
function editorEmpty(){return editorText()==="";}
function resetStable(){stableNode=null;stableText="";stableSince=0;}
function observedAnswer(marker=""){
 const m=latest();
 let candidate=m.last?.text&&
  (m.last.role==="assistant"||m.last.role==="unknown"&&m.last.assistantEvidence)?
   m.last:null;
 // Never reuse an older assistant block if a subsequent user turn exists.
 if(!marker&&(m.last?.role==="user"||
    m.last?.role==="unknown"&&SCL_MARKER.test(m.last.text)))return null;
 // Old DOM fallback only when no discoverable conversation turns are present.
 if(!candidate&&!marker&&!m.last){
  const nodes=[...document.querySelectorAll(
   'main .markdown,main [class*="markdown"],main [data-testid="final-completion"],main .prose')];
  const visible=nodes.filter(n=>{
   const b=n.getBoundingClientRect?.();
   return (!b||b.width>1&&b.height>1)&&normalize(n.textContent).length>=5&&
    !n.closest?.('[data-message-author-role="user"],[data-testid="user-message"],[data-user-message-bubble="true"],[data-content-search-unit-key$=":user"]');
  });
  const node=visible[visible.length-1];
  if(node)candidate={node,text:normalize(node.textContent),role:"assistant"};
 }
 if(!candidate||generating())return null;
 if(marker){
  const user=m.lastUser;
  if(!user?.text.includes(marker)||m.all.indexOf(candidate)<=m.all.indexOf(user)||
     candidate.text.includes(marker))return null;
 }
 return candidate;
}
function stableAssistant(marker=""){
 const answer=observedAnswer(marker);
 if(!answer)return null;
 if(stableNode!==answer.node||stableText!==answer.text){
  stableNode=answer.node;stableText=answer.text;stableSince=Date.now();
  return null;
 }
 return Date.now()-stableSince>=5000?answer.text:null;
}
function stopRequested(s){return /(?:^|\s)LOOP_STOP(?:\s|:|$)/i.test(s);}
function newChatRequested(s){return /(?:^|\s)LOOP_(?:NEXT|NEW)_CHAT(?:\s|:|$)/i.test(s);}
function promptText(s,request,mode){
 const id=request.checkpointId||s.checkpointId||
  (s.url||"").slice("https://chatgpt.com/c/".length);
 const checkpoint=checkpointPath(id);
 let command=String(request.prompt||"Продолжай работу").trim();
 if(!/[.!?…]$/.test(command))command+=".";
 let guidance;
 if(mode==="rollover"){
  guidance="Это продолжение предыдущего чата. Сначала восстанови контекст из чекпоинта `"+
   checkpoint+"`, затем продолжай задачу. Если файла нет, сообщи LOOP_STOP и не выдумывай историю работы.";
 }else if(mode==="bootstrap"){
  guidance="Проверь состояние проекта, выполни задачу и веди чекпоинт `"+
   checkpoint+"`. Если файла нет, создай его после проверки.";
 }else{
  guidance="Сверь результаты предыдущего шага, сделай следующий и обнови чекпоинт `"+
   checkpoint+"`. Если файла ещё нет, создай его после проверки проекта.";
 }
 const recovery=request.recoveryNote?
  "После сбоя сначала проверь уже выполненные действия. "+request.recoveryNote.trim():"";
 // The marker must remain plain visible text for exact ACK binding.
 // Cycle counters belong in the popup, not in every user message.
 return [command,recovery,guidance,"["+request.marker+"]"].filter(Boolean).join("\n\n");
}
async function diagnostic(code){
 if(!code||code===lastDiagnostic&&Date.now()-lastDiagnosticAt<14000)return;
 lastDiagnostic=code;lastDiagnosticAt=Date.now();
 await stage({action:"diagnostic",code});
}
function readyCode(){
 if(issue())return "chat_not_ready";
 if(generating())return "generation_active";
 const value=editorText();
 if(value===null)return "editor_missing";
 if(value!=="")return "composer_has_text";
 const answer=observedAnswer();
 if(!answer)return "assistant_selector_missing";
 return stableAssistant()?"ready":"waiting_for_stability";
}
async function clickReserved(s,request,mode){
 if(sending)return;
 sending=true;
 try{
  if((mode==="rollover"||mode==="bootstrap")&&location.pathname!=="/"){
   await block("route_changed");return;
  }
  if(mode==="normal"&&location.origin+location.pathname!==s.url){
   await block("route_changed");return;
  }
  if(generating()||!editorEmpty()||issue()){
   await block("generation_conflict");return;
  }
  const editor=core.findEditor(document);
  if(!editor){await block("missing_editor");return;}
  const prompt=promptText(s,request,mode);
  writing=true;
  if(!core.fillEditor(editor.ownerDocument||document,editor,prompt)){
   await block("missing_editor");return;
  }
  await SLEEP(350);
  const button=core.findSendButton(document);
  if(!button||generating()||issue()){
   await block("missing_send");return;
  }
  // Pause/Stop may arrive while the editor is being filled. Re-check the
  // exact owned reservation before the non-idempotent UI click.
  const fresh=await stage({action:"read"});
  if(!fresh?.ok||fresh.state?.status!=="running"||
     fresh.state?.attemptId!==request.attemptId)return;
  if(editorText()!==normalize(prompt)){
   await block("manual_input");return;
  }
  // One click only. Stage reserve/unique marker already saved in local storage.
  button.click();
  const clicked=await stage({action:"clicked",attemptId:request.attemptId});
  if(!clicked.ok){await block("uncertain_send");return;}
  resetStable();
 }catch(_){await block("uncertain_send");}
 finally{writing=false;sending=false;}
}
async function startAttempt(s,result){
 const readiness=readyCode();
 await diagnostic(readiness);
 if(readiness!=="ready")return;
 const request=await stage({action:"reserve"});
 if(!request.ok)return;
 await clickReserved(s,request,"normal");
}
async function bootstrap(s,result){
 if(location.pathname!=="/"){
  // The browser navigated to a different conversation before the first send.
  await block("route_changed");return;
 }
 if(issue()||generating()||!editorEmpty()){
  await diagnostic("chat_not_ready");return;
 }
 await diagnostic("waiting_for_click");
 const request={attemptId:s.attemptId,marker:s.marker,sequence:1,
  maxCycles:s.maxCycles,prompt:result.prompt,checkpointId:result.checkpointId};
 await clickReserved(s,request,"bootstrap");
}
async function rotate(s,result){
 if(s.phase!=="ready_for_rollover"||generating()||!editorEmpty())return;
 await diagnostic("waiting_for_new_chat");
 await stage({action:"rollover"});
}
async function complete(s,answer){
 if(stopRequested(answer)){await block("assistant_requested_stop");return;}
 const nextChat=newChatRequested(answer);
 if(nextChat&&!s.allowNewChat){await block("new_chat_disabled");return;}
 const r=await stage({action:"completed",attemptId:s.attemptId,nextChat});
 if(r.ok)resetStable();
}
async function recovery(s){
 const last=latest();
 if(!last.lastUser?.text.includes(s.marker)){
  if(Date.now()-s.recoveryStartedAt>45000)await block("not_confirmed");
  return;
 }
 const problem=issue();
 if(problem==="rate_limited"||problem==="account_conflict"){
  await block(problem);return;
 }
 if(problem!=="connection_lost"&&problem!=="conversation_full"){
  const answer=stableAssistant(s.marker);
  if(answer){await complete(s,answer);return;}
 }
 const elapsed=Date.now()-s.recoveryStartedAt;
 const button=stopButton();
 if(button&&(elapsed>=90000||problem==="connection_lost"&&elapsed>=20000)){
  const reserved=await stage({action:"reserve_stop",attemptId:s.attemptId});
  if(!reserved.ok)return;
  button.click(); // at most once, only after reservation
  await stage({action:"stopped_generation",attemptId:s.attemptId});
  resetStable();return;
 }
 if(elapsed>=120000)await block("response_not_confirmed");
}
async function tick(){
 if(busy)return;
 busy=true;
 try{
  const result=await stage({action:"read"});
  const s=result?.state;
  if(!result?.ok||!s||s.status!=="running")return;
  const phase=s.phase;
  if(phase==="bootstrap"){
   await bootstrap(s,result);return;
  }
  if(phase==="bootstrap_awaiting_user"||phase==="rotating_awaiting_user"){
   await diagnostic("waiting_for_saved_message");
   const m=latest();
   if(CHAT.test(location.pathname)&&m.lastUser?.text.includes(s.marker)&&editorEmpty()){
    await stage({action:"saved",attemptId:s.attemptId,url:location.origin+location.pathname});
    resetStable();
   }else if(Date.now()-s.attemptStartedAt>90000)await block("not_confirmed");
   return;
  }
  if(phase==="rotating"){
   if(location.pathname!=="/"){
    await diagnostic("waiting_for_new_chat");return;
   }
   if(issue()||generating()||!editorEmpty()){await diagnostic("chat_not_ready");return;}
   const request={attemptId:s.attemptId,marker:s.marker,sequence:s.cycles+1,
    maxCycles:s.maxCycles,checkpointId:result.checkpointId,prompt:result.prompt,
    recoveryNote:result.recoveryNote||""};
   await clickReserved(s,request,"rollover");return;
  }
  if(!CHAT.test(location.pathname)||location.origin+location.pathname!==s.url){
   await block("route_changed");return;
  }
  const problem=issue();
  if(problem==="rate_limited"||problem==="account_conflict"){
   await block(problem);return;
  }
  if(phase==="recovering"){await diagnostic("recovering");await recovery(s);return;}
  if(phase==="recovering_send"){
   await diagnostic("recovering");
   if(latest().lastUser?.text.includes(s.marker)&&editorEmpty())
    await stage({action:"saved",attemptId:s.attemptId});
   else if(Date.now()-s.recoveryStartedAt>90000)await block("not_confirmed");
   return;
  }
  if(phase==="recovering_ready"){
   await diagnostic("recovering");
   if(problem==="connection_lost"){
    if(Date.now()-s.recoveryStartedAt>60000)await block("connection_unavailable");
    return;
   }
   if(!generating()&&editorEmpty())await stage({action:"recovered_ready"});
   return;
  }
  if(phase==="recover_stopping"){
   await block("recovery_stop_unknown");return;
  }
  if(problem==="connection_lost"){
   if(["ready","awaiting_user","awaiting_assistant"].includes(phase))
    await stage({action:"connection_lost",attemptId:s.attemptId});
   else await block("connection_unavailable");
   return;
  }
  if(problem==="conversation_full"){
   if(phase==="ready_for_rollover"){await rotate(s,result);return;}
   if(s.allowNewChat&&(phase==="ready"||
     phase==="awaiting_assistant"&&latest().lastUser?.text.includes(s.marker)))
    await stage({action:"context_exhausted",attemptId:s.attemptId});
   else await block("new_chat_disabled");
   return;
  }
  if(phase==="ready_for_rollover"){await rotate(s,result);return;}
  if(phase==="ready"){
   if(s.maxCycles!==null&&s.completed>=s.maxCycles)return;
   await startAttempt(s,result);return;
  }
  if(phase==="reserved"){
   await diagnostic("waiting_for_click");
   if(Date.now()-s.attemptStartedAt>20000)await block("uncertain_send");
   return;
  }
  if(phase==="awaiting_user"){
   await diagnostic("waiting_for_saved_message");
   if(latest().lastUser?.text.includes(s.marker)&&editorEmpty()){
    const ack=await stage({action:"saved",attemptId:s.attemptId});
    if(ack.ok)resetStable();
   }else if(Date.now()-s.attemptStartedAt>60000)await block("not_confirmed");
   return;
  }
  if(phase==="awaiting_assistant"){
   await diagnostic("waiting_for_assistant");
   const m=latest();
   if(m.lastUser&&!m.lastUser.text.includes(s.marker)){
    await block("user_message_changed");return;
   }
   if(Date.now()-s.attemptStartedAt>900000){
    await block("assistant_timeout");return;
   }
   const answer=stableAssistant(s.marker);
   if(answer)await complete(s,answer);
  }
 }catch(_){
  // Fail closed on uncertain UI; never infer a send from an exception.
 }finally{busy=false;}
}
document.addEventListener("input",event=>{
 if(!event.isTrusted||writing)return;
 const editor=core.findEditor(document);
 if(!editor||event.target!==editor&&!editor.contains?.(event.target))return;
 void block("manual_input");
},true);
document.addEventListener("click",event=>{
 if(!event.isTrusted)return;
 if(event.target?.closest?.(stopSelector))void block("manual_stop");
},true);
chrome.runtime.onMessage.addListener((msg,_sender,respond)=>{
 if(msg?.type!=="same-chat-wake"&&msg?.type!=="same-chat-inspect")return;
 if(msg.type==="same-chat-inspect"){
  respond({ok:true,version:CONTENT_PROTOCOL,route:location.pathname,reason:readyCode(),dom:inspectDom()});
  return;
 }
 resetStable();
 respond({ok:true,version:CONTENT_PROTOCOL});
 void tick();
});
setInterval(()=>{
 if(location.pathname!==lastPath){lastPath=location.pathname;resetStable();}
 void tick().catch(()=>{});
},1600);
})();