"use strict";
const assert=require("node:assert/strict"),fs=require("node:fs"),vm=require("node:vm"),path=require("node:path");
async function test(){
 const handlers=[],updated=[],removed=[],startup=[],installed=[],alarms=[];
 const local=new Map(),urls=new Map(),meta=new Map();
 let next=40,uuid=0,now=2000000,injected=0;
 for(let i=1;i<=6;i++){
  urls.set(i,"https://chatgpt.com/c/test-"+i);
  meta.set(i,{windowId:i,discarded:false});
 }
 urls.set(7,"https://chatgpt.com/c/test-1");meta.set(7,{windowId:7,discarded:false});
 urls.set(8,"https://chatgpt.com/");meta.set(8,{windowId:8,discarded:false});
 const injectedTabs=new Set();
 const chrome={
  storage:{
   local:{
    async get(k){if(k===null)return Object.fromEntries(local);
      return Object.fromEntries((Array.isArray(k)?k:[k]).filter(x=>local.has(x)).map(x=>[x,local.get(x)]));},
    async set(o){for(const [k,v] of Object.entries(o))local.set(k,v);}
   },
   session:{async get(){return {};}}
  },
  tabs:{
   async query(){return [...urls].map(([id,url])=>({id,url,...meta.get(id)}));},
   async get(id){if(!urls.has(id))throw Error("missing");return {id,url:urls.get(id)};},
   async create(cfg){assert.equal(cfg.url,"https://chatgpt.com/");const id=next++;
     urls.set(id,cfg.url);meta.set(id,{windowId:1,discarded:false});return {id,url:cfg.url};},
   async update(id,cfg){urls.set(id,cfg.url);return {id,url:cfg.url};},
   async reload(){},
   async sendMessage(id){if(id===2&&!injectedTabs.has(id))throw Error("not injected");return {ok:true,version:"0.8.5"};},
   onUpdated:{addListener(fn){updated.push(fn)}},
   onRemoved:{addListener(fn){removed.push(fn)}}
  },
  scripting:{async executeScript({target,files}){assert.deepEqual(Array.from(files),["core.js","same_chat_loop.js"]);
    injectedTabs.add(target.tabId);injected++;return [{result:true}];}},
  windows:{async create({url}){assert.equal(url,"https://chatgpt.com/");const id=next++;
     urls.set(id,url);meta.set(id,{windowId:100+id,discarded:false});
     return {tabs:[{id,url}]};}},
  alarms:{onAlarm:{addListener(fn){alarms.push(fn)}}},
  runtime:{
   onMessage:{addListener(fn){handlers.push(fn)}},
   onStartup:{addListener(fn){startup.push(fn)}},
   onInstalled:{addListener(fn){installed.push(fn)}}
  }
 };
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,"same_chat_bg.js"),"utf8"),
  {chrome,URL,Promise,Date:{now:()=>now},crypto:{randomUUID:()=>
    "00000000-0000-4000-8000-"+String(++uuid).padStart(12,"0")},console,setTimeout});
 assert.equal(handlers.length,1);
 const message=(m,tabId=null)=>new Promise((resolve,reject)=>{
  const accepted=handlers[0](m,tabId===null?{}:{tab:{id:tabId}},resolve);
  if(accepted!==true)reject(Error("unhandled"));
 });
 const opts={prompt:"Продолжай",unlimited:true,rotateEvery:10,allowNewChat:true,maxCycles:20};
 const batch=(mode,count,rest={})=>message({type:"same-chat-batch",mode,count,...opts,...rest});
 const stage=(id,action,extra={})=>message({type:"same-chat-stage",action,...extra},id);
 let r=await batch("existing",5);
 assert.equal(r.ok,true);assert.equal(r.count,5);
 assert.equal(r.started.length,5);
 assert.equal(injected,1); // one stale existing tab was safely instrumented
 assert.equal((await message({type:"same-chat-summary"})).running,5);
 let read=await stage(1,"read");
 assert.equal(read.state.status,"running");
 assert.equal(read.state.phase,"ready");
 await stage(1,"diagnostic",{code:"assistant_selector_missing"});
 read=await stage(1,"read");
 assert.equal(read.state.diagnostic,"assistant_selector_missing");
 assert.equal(read.state.observedAt,now);
 r=await batch("existing",7); // all 6 unique saved URLs, duplicates do not start twice
 assert.equal(r.count,1);
 assert.ok(r.skipped.some(x=>x.reason==="already_running"));
 assert.equal((await message({type:"same-chat-summary"})).running,6);
 r=await batch("new",5);
 assert.equal(r.count,5);
 const tabId=r.started[0].tabId;
 read=await stage(tabId,"read");
 assert.equal(read.state.phase,"bootstrap");
 assert.equal(read.state.url,"");
 const attempt=read.state.attemptId;
 assert.ok(read.state.marker.startsWith("SCL-"));
 assert.ok(read.checkpointId.length>0);
 assert.equal((await stage(tabId,"clicked",{attemptId:attempt})).state.phase,
   "bootstrap_awaiting_user");
 const newUrl="https://chatgpt.com/c/created-one";
 urls.set(tabId,newUrl);
 let saved=await stage(tabId,"saved",{attemptId:attempt,url:newUrl});
 assert.equal(saved.ok,true);
 assert.equal(saved.state.phase,"awaiting_assistant");
 assert.equal(saved.state.url,newUrl);
 assert.equal(saved.state.cycles,1);
 let completed=await stage(tabId,"completed",{attemptId:attempt});
 assert.equal(completed.ok,true);
 assert.equal(completed.state.completed,1);
 // New windows are explicitly created only on user request.
 r=await batch("new",3,{separateWindows:true});
 assert.equal(r.count,3);
 assert.equal((await message({type:"same-chat-summary"})).running,14);
 // Navigating an owned bootstrap tab before first send may not bind another dialog.
 const another=r.started[0].tabId;
 read=await stage(another,"read");
 assert.equal(read.state.phase,"bootstrap");
 urls.set(another,"https://chatgpt.com/c/nonowned");
 const attempted=await stage(another,"clicked",{attemptId:read.state.attemptId});
 assert.equal(attempted.ok,true); // only the local reservation was acknowledged
 const unsafe=await stage(another,"saved",
  {attemptId:read.state.attemptId,url:"https://chatgpt.com/c/other"});
 assert.equal(unsafe.ok,false);
 const paused=await message({type:"same-chat-batch",mode:"pause_all"});
 assert.equal(paused.ok,true);assert.equal(paused.count,14);
 assert.equal((await message({type:"same-chat-summary"})).running,0);
 const restart=await message({type:"same-chat-control",action:"start",tabId:1,...opts});
 assert.equal(restart.ok,true);
 const stopped=await message({type:"same-chat-batch",mode:"stop_all"});
 assert.equal(stopped.ok,true);assert.equal(stopped.count,1);
 assert.equal((await message({type:"same-chat-summary"})).running,0);
 // The owner can start five distinct disjoint roles, in five separate windows.
 // A created tab is NOT automatically counted as a confirmed live observer.
 const simultaneous=await Promise.all([
  batch("team",5,{separateWindows:false}),
  batch("team",5,{separateWindows:false})
 ]);
 assert.equal(simultaneous.filter(x=>x.ok).length,1,
              "concurrent team starts must admit exactly one owner batch");
 assert.equal(simultaneous.filter(x=>!x.ok)[0].reason,"batch_busy");
 r=simultaneous.find(x=>x.ok);
 assert.equal(r.ok,true);assert.equal(r.count,5);
 assert.equal(r.started.length,5);
 const roles=r.started.map(x=>x.role);
 assert.equal(roles.join("|"),"developer-1|developer-2|developer-3|developer-4|architect-reviewer");
 assert.equal(new Set(r.started.map(x=>meta.get(x.tabId).windowId)).size,5);
 let teamSummary=await message({type:"same-chat-summary"});
 assert.equal(teamSummary.running,5);
 assert.equal(teamSummary.confirmed_observers,0);
 assert.equal(teamSummary.awaiting_observer,5);
 assert.equal(teamSummary.team_roles.length,5);
 for(const item of r.started){
  const state=await stage(item.tabId,"read");
  assert.equal(state.state.teamRole,item.role);
  assert.ok(state.prompt.includes(item.role.startsWith("developer")?
      item.role.slice(-1).toUpperCase()+":" :"Reviewer:"));
  assert.ok(state.prompt.includes("Tunnel-release-staging"));
  assert.ok(state.prompt.includes("P085"));
 }
 const duplicated=await batch("team",5);
 assert.equal(duplicated.ok,false);
 assert.equal(duplicated.reason,"team_already_running");
 const wrongCount=await batch("team",4);
 assert.equal(wrongCount.ok,false);
 assert.equal(wrongCount.reason,"team_requires_five_roles");
 const oversizedTeam=await batch("team",5,{prompt:"x".repeat(4900)});
 assert.equal(oversizedTeam.ok,false);
 assert.equal(oversizedTeam.reason,"team_prompt_length_invalid");
 const contentScriptAttempt=await message({
  type:"same-chat-batch",mode:"team",count:5,...opts
 },r.started[0].tabId);
 assert.equal(contentScriptAttempt.ok,false);
 assert.equal(contentScriptAttempt.reason,"popup_only");
 await stage(r.started[0].tabId,"diagnostic",{code:"script_alive"});
 teamSummary=await message({type:"same-chat-summary"});
 assert.equal(teamSummary.confirmed_observers,1);
 assert.equal(teamSummary.awaiting_observer,4);
 const stoppedTeam=await message({type:"same-chat-batch",mode:"stop_all"});
 assert.equal(stoppedTeam.count,5);
 assert.equal((await message({type:"same-chat-summary"})).running,0);
 // A tab that never reports observer progress must not remain running forever.
 const stale=await message({type:"same-chat-control",tabId:1,action:"start",...opts});
 assert.equal(stale.ok,true);
 now+=400000;
 assert.ok(alarms.length,"watchdog must subscribe to extension alarm");
 for(const fn of alarms)fn({name:"chat-smoke-queue"});
 await new Promise(resolve=>setTimeout(resolve,80));
 const s=await message({type:"same-chat-status",tabId:1});
 assert.equal(s.state.status,"paused","stale observer must fail closed");
 assert.equal(s.state.reason,"observer_stale");
 // Tests use one action only: no duplicate second click is ever initiated by the state machine.
 const pendingBatch=batch("new",10);
 await new Promise(resolve=>setTimeout(resolve,1000));
 const urgentStop=await message({type:"same-chat-batch",mode:"stop_all"});
 assert.equal(urgentStop.ok,true,"emergency stop must work during a running batch");
 const afterStop=await pendingBatch;
 assert.ok(afterStop.count<10,"batch must stop admitting tabs after Stop all");
 assert.equal((await message({type:"same-chat-summary"})).running,0);
 const pauseBatch=batch("new",6);
 await new Promise(resolve=>setTimeout(resolve,1000));
 const urgentPause=await message({type:"same-chat-batch",mode:"pause_all"});
 assert.equal(urgentPause.ok,true,"pause-all must work during admission");
 const pausedBatch=await pauseBatch;
 assert.ok(pausedBatch.count<6,"pause all must cancel pending admissions");
 assert.equal((await message({type:"same-chat-summary"})).running,0);
 console.log("PASS 0.8.1: multitab, URL binding, stale watchdog, pause/stop-all interrupt batches");
}
test().catch(e=>{console.error(e);process.exitCode=1;});