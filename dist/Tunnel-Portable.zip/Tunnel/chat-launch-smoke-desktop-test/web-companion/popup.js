"use strict";
const $=id=>document.getElementById(id);
const state=$("state"),circuit=$("circuit"),resume=$("resume");
Promise.all([
 chrome.storage.local.get(["chatSmokeLast","chatSmokeAuthPaused"]),
 chrome.storage.session.get("chatSmokeCircuit")
]).then(([last,active])=>{
 const v=last.chatSmokeLast;
 state.textContent=v?"Задание: "+(v.id||"—")+"\nСтадия: "+v.stage:
   "Новых заданий пока нет.";
 const c=active.chatSmokeCircuit||{};
 const remaining=Math.max(0,Math.ceil(((c.cooldownUntil||0)-Date.now())/1000));
 circuit.textContent=last.chatSmokeAuthPaused?"Конфликт аккаунта, очередь остановлена.":
  c.paused?"Очередь остановлена: "+(c.stopReason||"нужна проверка"):
  remaining?"Пауза UI: "+remaining+" сек.":
  "Очередь активна; ошибок подряд: "+(c.failures||0);
 resume.disabled=!c.paused&&last.chatSmokeAuthPaused!==true;
}).catch(()=>{state.textContent="Диагностика очереди недоступна.";resume.disabled=true;});
resume.addEventListener("click",async()=>{
 resume.disabled=true;
 try{
  const r=await chrome.runtime.sendMessage({type:"chat-smoke-resume"});
  circuit.textContent=r?.ok?"Очередь возобновлена.":"Возобновление не подтверждено.";
 }catch(_){circuit.textContent="Связь с обработчиком не установлена.";}
});
const loopPrompt=$("loopPrompt"),loopMax=$("loopMax"),loopUnlimited=$("loopUnlimited");
let defaultLoopPrompt="";
const loopNewChat=$("loopNewChat"),loopRotateEvery=$("loopRotateEvery");
const loopState=$("loopState"),parallelState=$("parallelState");
const controls=Object.fromEntries(["Start","Pause","Resume","Stop"].map(
  n=>[n.toLowerCase(),$("loop"+n)]));
const parallelButtons=[$("startExisting"),$("startNew"),$("startTeam"),$("pauseAll"),$("stopAll")];
let currentTab=null,currentState=null,initialized=false,busy=false,lastNote="";
loopUnlimited.addEventListener("change",()=>loopMax.disabled=loopUnlimited.checked);
const saved=url=>{try{const u=new URL(url);return u.origin==="https://chatgpt.com"&&
 /^\/c\/[a-z0-9-]+$/.test(u.pathname);}catch(_){return false;}};
const eligible=url=>{try{const u=new URL(url);return u.origin==="https://chatgpt.com"&&
 (u.pathname==="/"||/^\/c\/[a-z0-9-]+$/.test(u.pathname));}catch(_){return false;}};
function settings(){
 return {prompt:loopPrompt.value,maxCycles:Number(loopMax.value),
  unlimited:loopUnlimited.checked,allowNewChat:loopNewChat.checked,
  rotateEvery:Number(loopRotateEvery.value)};
}
function labels(diag){
 const dict={
  ready:"Ответ завершён — отправка готовится",
  waiting_for_stability:"Жду стабилизации последнего ответа (≈5 секунд)",
  assistant_selector_missing:"Не найден текст ответа; проверь страницу и селекторы",
  editor_missing:"Поле ввода ChatGPT не найдено",
  composer_has_text:"В поле есть несохранённый текст — отправка запрещена",
  generation_active:"Ответ ещё генерируется",
  waiting_for_click:"Проверяю кнопку отправки",
  waiting_for_saved_message:"Ожидаю подтверждения отправленного сообщения",
  waiting_for_new_chat:"Создаю новый диалог",
  waiting_for_assistant:"Жду ответа ChatGPT",
  recovering:"Восстанавливаю соединение",
  chat_not_ready:"Интерфейс чата ещё не готов",
  content_script_missing:"Обработчик не подключён. Перезагрузи вкладку.",
  content_script_version_mismatch:"Версии скрипта и расширения не совпадают — перезагрузи саму вкладку ChatGPT.",
  unsupported_chat_dom:"Неизвестная структура ответов. Автоматическое продолжение приостановлено.",
  observer_stale:"Нет сигналов от наблюдателя более 6 минут; цикл приостановлен."
 };
 return dict[diag]||diag||"Нет данных от наблюдателя";
}
function render(){
 const s=currentState,status=s?.status||"stopped";
 controls.start.disabled=busy||!currentTab||!saved(currentTab.url)||status==="running";
 controls.pause.disabled=busy||!currentTab||status!=="running";
 controls.resume.disabled=busy||!currentTab||status!=="paused"||s?.phase!=="ready"||
  (s?.maxCycles!==null&&s?.cycles>=s?.maxCycles);
 controls.stop.disabled=busy||!currentTab||status==="stopped";
 $("loopInspect").disabled=busy||!currentTab;
 if(!currentTab){
  loopState.textContent="Открой сохранённый диалог /c/… в активной вкладке.";
  return;
 }
 if(!s){
  loopState.textContent="В этой вкладке цикл ещё не запущен."+(lastNote?"\n"+lastNote:"");
  return;
 }
 const elapsed=s.observedAt?Math.round((Date.now()-s.observedAt)/1000):null;
 loopState.textContent=
  (s.teamRole?"Роль команды: "+s.teamRole+"\n":"")+
  "Статус: "+s.status+" | этап: "+s.phase+
  "\nОтправки: "+s.cycles+"/"+(s.maxCycles===null?"∞":s.maxCycles)+
  " | ответы: "+s.completed+" | новых диалогов: "+(s.rollovers||0)+
  "\nНаблюдатель: "+labels(s.diagnostic)+
  (elapsed===null?" (ещё не ответил)":(" ("+elapsed+" сек. назад)"))+
  (s.reason?"\nПричина: "+s.reason:"")+
  (lastNote?"\n"+lastNote:"");
 loopState.classList.toggle("error",status==="paused");
}
async function refresh(){
 if(busy)return;
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  const next=tab?.id!=null&&eligible(tab.url)?tab:null;
  const changed=currentTab?.id!==next?.id;
  currentTab=next;
  if(currentTab){
   const r=await chrome.runtime.sendMessage({type:"same-chat-status",tabId:currentTab.id});
   currentState=r?.state||null;
   if((changed||!initialized)&&currentState){
    loopMax.value=currentState.maxCycles??20;
    loopUnlimited.checked=currentState.maxCycles===null;
    loopMax.disabled=loopUnlimited.checked;
    loopNewChat.checked=currentState.allowNewChat;
    loopRotateEvery.value=currentState.rotateEvery??0;
   }
   if(r?.defaults?.prompt)defaultLoopPrompt=r.defaults.prompt;
   if(!loopPrompt.value&&(r?.prompt||defaultLoopPrompt))
    loopPrompt.value=r.prompt||defaultLoopPrompt;
  }else currentState=null;
  initialized=true;
  render();
  const summary=await chrome.runtime.sendMessage({type:"same-chat-summary"});
  $("runningCount").textContent=summary?.ok?
   "Учтённых циклов: "+summary.running+
   "\nНаблюдателей подтверждено: "+(summary.confirmed_observers??0)+
   " | ожидают ответа: "+(summary.awaiting_observer??summary.running)+
   (summary.team_roles?.length?"\nРоли команды: "+summary.team_roles.join(", "):""):
   "Статистика окон недоступна";
 }catch(_){
  loopState.textContent="Не удалось получить статус. Проверь расширение и обнови страницу.";
 }
}
for(const [action,button] of Object.entries(controls)){
 button.addEventListener("click",async()=>{
  if(!currentTab||busy)return;
  busy=true;render();
  try{
   const reply=await chrome.runtime.sendMessage({
    type:"same-chat-control",tabId:currentTab.id,action,
    ...(action==="start"?settings():{})
   });
   lastNote=reply?.ok?"Команда "+action+" подтверждена.":
    "Команда отклонена: "+(reply?.reason||"неизвестная ошибка");
   currentState=reply?.state||currentState;
  }catch(_){lastNote="Отправка команды не подтверждена.";}
  busy=false;render();void refresh();
 });
}
$("loopDefaultPrompt").addEventListener("click",()=>{
 if(!defaultLoopPrompt){lastNote="Промпт по умолчанию пока не получен из расширения.";render();return;}
 loopPrompt.value=defaultLoopPrompt;
 lastNote="Загружен промпт для разработки и независимого ревью. Нажми Start для нового цикла.";
 render();
});
$("loopInspect").addEventListener("click",async()=>{
 if(!currentTab)return;
 try{
  const r=await chrome.tabs.sendMessage(currentTab.id,{type:"same-chat-inspect"});
  const d=r?.dom;
  lastNote=r?.ok?"Диагностика страницы: "+labels(r.reason)+
   (d?"\nПротокол скрипта: "+(d.protocol||"не определён")+
    "\nDOM: сообщений="+d.turns+
    ", явных ответов="+d.knownAssistants+
    ", ответов по кнопкам="+d.assistantToolbarCandidates+
    ", форматированных блоков="+d.formattedBlocks+
    "\nНовая разметка: turnKey="+(d.selectors?.turnKeys??"?")+
    ", assistantUnits="+(d.selectors?.assistantUnits??"?")+
    ", userUnits="+(d.selectors?.userUnits??"?")+
    ", userBubbles="+(d.selectors?.userBubbles??"?")+
    "\nСтарая: roles="+(d.selectors?.classicRoles??"?")+
    ", turns="+(d.selectors?.classicTurns??"?")+
    ", article="+(d.selectors?.article??"?")+
    ", section="+(d.selectors?.sectionTurns??"?")+
    "\nПоследнее: "+d.lastRole+"/"+d.lastTag+
    ", признаки ответа="+(d.lastAssistantEvidence?"да":"нет")+
    ", генерация="+(d.generating?"да":"нет")+
    ", редактор пуст="+(d.editorEmpty?"да":"нет"):""):
   "Наблюдатель не отвечает. Обнови страницу.";
 }catch(_){lastNote="Наблюдатель не установлен. Обнови страницу.";}
 render();
});
async function batch(mode){
 if(busy)return;
 const count=mode==="team"?5:Number($("parallelCount").value);
 if(!Number.isInteger(count)||count<1||count>25){
  parallelState.textContent="Укажи количество от 1 до 25.";return;
 }
 const config=settings();
 if(!config.prompt.trim()){parallelState.textContent="Сначала заполни сообщение.";return;}
 busy=true;parallelButtons.forEach(b=>b.disabled=true);render();
 parallelState.textContent="Подготавливаю выбранные чаты…";
 try{
  const outcome=await chrome.runtime.sendMessage({
   type:"same-chat-batch",mode,count,separateWindows:mode==="team"||$("separateWindows").checked,...config
  });
  parallelState.textContent=outcome?.ok?
   "Открыто/назначено: "+(outcome.count||0)+". Пропущено: "+(outcome.skipped?.length||0)+
    (mode==="team"?"\nПять ролей назначены. Дождись подтверждения наблюдателей.":"")+
    (outcome.skipped?.length?"\nПричины: "+outcome.skipped.slice(0,4).map(v=>v.reason).join(", "):""):
   "Ошибка: "+(outcome?.reason||"вызов не подтверждён");
 }catch(_){parallelState.textContent="Нет подтверждения запуска. Проверь открытые вкладки.";}
 busy=false;parallelButtons.forEach(b=>b.disabled=false);void refresh();
}
$("startExisting").addEventListener("click",()=>batch("existing"));
$("startNew").addEventListener("click",()=>batch("new"));
$("startTeam").addEventListener("click",()=>batch("team"));
async function allControl(mode){
 if(busy)return;
 busy=true;parallelButtons.forEach(x=>x.disabled=true);
 try{
  const result=await chrome.runtime.sendMessage({type:"same-chat-batch",mode});
  parallelState.textContent=result?.ok?
   (mode==="pause_all"?"Приостановлено: ":"Остановлено: ")+result.count+" циклов.":
   "Команда не подтверждена: "+(result?.reason||"unknown");
 }catch(_){parallelState.textContent="Команда не подтверждена. Проверь состояние.";}
 busy=false;parallelButtons.forEach(x=>x.disabled=false);void refresh();
}
$("pauseAll").addEventListener("click",()=>allControl("pause_all"));
$("stopAll").addEventListener("click",()=>allControl("stop_all"));
void refresh();
setInterval(()=>void refresh(),2500);
