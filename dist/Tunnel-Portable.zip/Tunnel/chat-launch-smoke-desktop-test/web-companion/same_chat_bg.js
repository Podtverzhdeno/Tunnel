/* Same-chat Loop v1. Explicit foreground opt-in; never bypass ChatGPT limits. */
(()=>{
"use strict";
const PREFIX="sameChatLoop_v1_tab_";
const PATH=/^\/c\/[a-z0-9-]+$/;
const MAX_SAFE_CYCLES=Number.MAX_SAFE_INTEGER;
const COOLDOWN_MS=15000;
const MAX_PARALLEL=25; // Max new tabs/windows per explicit user batch action.
const CONTENT_PROTOCOL="0.8.5"; // Hardcoded to detect stale content after extension upgrades.
const MAX_PROMPT_CHARS=5000;
const defaults={prompt:"Ты инженер мультиагентной системы Local-Workspace-Extensions. Продолжай реальную разработку и независимое ревью задач. Каждый цикл должен дать проверяемый результат, а не пересказ планов.\n\n1. Подключи Local Workspace MCP, проверь alias projects. Прочитай актуальные AGENTS.md, README.md, docs/VERIFIED_WORK_CYCLE.md, docs/PEER_ROLE_SWITCH.md, docs/ARCHITECT_SUPPORT_LOOP.md, docs/AGENT_CODE_REUSE_GOVERNANCE.md и относящиеся к задаче OpenSpec/SDD. Посмотри живую очередь, действующие leases, последние отчёты и checkpoint. Не доверяй устаревшим статусам из истории чата.\n\n2. Приоритет — самая важная разрешённая задача разработки, затем независимое peer-review чужой задачи, затем architect-support/новая негативная QA-проверка. После каждого завершённого действия снова проверь очередь и выбери следующий законный шаг. Не создавай фиктивные задачи, коммиты или отчёты ради активности.\n\n3. Разработка: работай только в пределах фактического task ID, роли, lease и ownership-контракта. До изменения кода сверь SHA, зависимости и уже существующие реализации; для Pxxx выполни предусмотренный task_reuse_preflight. Вноси минимальные изменения, дополняй негативные тесты, запускай соответствующие проверки. Получи job_status, returncode и job_output: «команда запущена» не значит PASS. При конфликте SHA или неясном результате — останови опасный повтор и проведи сверку.\n\n4. Ревью: выбирай только задачу другого автора, которую не разрабатывал и не проверял в той же общей роли. При необходимости получи отдельный peer lease. Независимо проверь diff, SHA, требования OpenSpec/SDD, корректность, отказоустойчивость, безопасность, конкуренцию, масштабируемость, наблюдаемость и тесты. Воспроизведи существенные дефекты, укажи severity, доказательства и конкретные исправления. Peer-review является advisory: не делай формальный accept/reject или merge без необходимых подтверждённых полномочий.\n\n5. Соблюдай ограничения AGENTS.md: P085 и ограничения доверенной идентичности не обходить; не менять права, живую очередь/SQLite, чужие sandbox, не выдавать себе одобрения владельца. Не делать push, release или разрушительные действия без разрешения. Для OpenSpec/SDD — только действующий процесс согласования. Если нет разрешённой разработки, переключись на реальное независимое ревью или architect-support, а не простаивай.\n\n6. После каждого полезного шага обновляй checkpoint через MCP: task ID, фактически сделанное, пути файлов, SHA, команды и результат тестов, найденные дефекты, блокеры и точное следующее действие. Не записывай токены, секреты и персональные данные. Не отмечай задачу завершённой без проверенных артефактов.\n\nВ ответе кратко фиксируй проверенный результат и следующий шаг. Если MCP недоступен или нет полномочий — сообщи BLOCKED и причину, не выдумывай успех. Если работа завершена или требуется решение человека — заверши строкой LOOP_STOP с причиной. Если контекст заканчивается, сначала сохрани checkpoint, затем заверши строкой LOOP_NEXT_CHAT. Не используй новые чаты для обхода лимитов платформы.",maxCycles:20,allowNewChat:true,rotateEvery:30};
// User-started, five distinct roles. These prompts are NOT OS-trusted grants.
const TEAM_SHARED="В команде 4 разработчика и независимый ревьюер. Через Local Workspace MCP проверь projects и актуальный SHA. Работай только в Tunnel-release-staging, не меняй живые очередь/SQLite/права/P085, не делай merge/push. Если нет доступа MCP, сообщи BLOCKED. В конце реальные тесты, SHA и checkpoint; не повторяй UNKNOWN-отправки и не обходи лимиты платформы. ";
const TEAM_ROLES=[
 {role:"developer-1",brief:"D1: исправляй и проверяй только scripts/chain2-triage.py и scripts/test_chain2_triage.py. Цель: безопасная сверка 9 ACTIVE и негативные тесты handoff без фиктивных ACK. "},
 {role:"developer-2",brief:"D2: исправляй и проверяй только scripts/status-stack.py и scripts/test_status_stack.py. Цель: точные статусы browser/MCP и сигнал о зависаниях без утечки секретов. "},
 {role:"developer-3",brief:"D3: дополняй только тесты chat-launch-smoke-desktop-test/web-companion/test_v066_ui_recovery.py и chat-launch-smoke-desktop-test/web-companion/test_recovery.js. Проверь смену URL, сеть, повторную отправку. Без реальных браузерных отправок. "},
 {role:"developer-4",brief:"D4: исправляй и проверяй только scripts/build-distribution.py и scripts/test-distribution.py. Цель: безопасные ZIP и офлайн-регрессия. Не публикуй релиз. "},
 {role:"architect-reviewer",brief:"Reviewer: только независимый read-only аудит изменений D1–D4 и live Chain2/Chain3/P085 preview. Сверяй SHA, test receipts и blockers. Без формального approve/merge, grants, повторных отправок. "}
];
const queue=new Map();
function serialized(tabId,fn){
 const prior=queue.get(tabId)||Promise.resolve();
 const task=prior.catch(()=>{}).then(fn);
 queue.set(tabId,task);
 task.finally(()=>{if(queue.get(tabId)===task)queue.delete(tabId);}).catch(()=>{});
 return task;
}
function normalize(url){
 try{
  const u=new URL(url);
  return u.origin==="https://chatgpt.com"&&PATH.test(u.pathname)&&!u.username&&!u.password?
   u.origin+u.pathname:"";
 }catch(_){return "";}
}
const key=id=>PREFIX+id;
async function get(id){return (await chrome.storage.local.get(key(id)))[key(id)]||null;}
async function put(s){const next={...s,updatedAt:Date.now()};await chrome.storage.local.set({[key(s.tabId)]:next});return next;}
const shape=s=>s?{tabId:s.tabId,url:s.url,status:s.status,phase:s.phase,
 reason:s.reason||"",cycles:s.cycles||0,completed:s.completed||0,
 maxCycles:s.maxCycles,allowNewChat:s.allowNewChat===true,rotateEvery:s.rotateEvery||0,
 attemptId:s.attemptId||"",checkpointId:s.checkpointId||"",
 recoveryStartedAt:s.recoveryStartedAt||0,
 rollovers:s.rollovers||0,recoveryCount:s.recoveryCount||0,
 teamRole:s.teamRole||"",
 updatedAt:s.updatedAt||0,startedAt:s.startedAt||0,
 attemptStartedAt:s.attemptStartedAt||0,marker:s.marker||"",
  lastSentAt:s.lastSentAt||0,diagnostic:s.diagnostic||"",
  observedAt:s.observedAt||0}:null;
async function tabUrl(id){
 try{const t=await chrome.tabs.get(id);return normalize(t?.url||"");}
 catch(_){return "";}
}
async function checked(id,s){
 let current=await tabUrl(id);
 if(["rotating","rotating_awaiting_user","bootstrap","bootstrap_awaiting_user"].includes(s.phase)){
  try{
   const tab=await chrome.tabs.get(id);
   const u=new URL(tab.url);
   if(u.origin==="https://chatgpt.com"&&(u.pathname==="/"||PATH.test(u.pathname)))
    return {ok:true,state:shape(s)};
  }catch(_){}
 }
 if(!current||current!==s.url){
  if(s.status==="running")s=await put({...s,status:"paused",reason:"conversation_changed"});
  return {ok:false,state:shape(s),reason:"conversation_changed"};
 }
 return {ok:true,state:shape(s)};
}
async function hasOtherOwner(tabId,url){
 if(!url)return false;
 const all=await chrome.storage.local.get(null);
 return Object.entries(all).some(([k,v])=>k.startsWith(PREFIX)&&v&&
  v.tabId!==tabId&&v.url===url&&v.status==="running");
}
async function wakeTab(tabId,inject=true){
 try{
  const reply=await chrome.tabs.sendMessage(tabId,{type:"same-chat-wake"});
  if(reply?.ok===true){
   return reply.version===CONTENT_PROTOCOL?
    {ok:true}:{ok:false,reason:"content_script_version_mismatch"};
  }
 }catch(_){}
 if(!inject||!chrome.scripting?.executeScript)
  return {ok:false,reason:"content_script_missing"};
 try{
  await chrome.scripting.executeScript({target:{tabId},
   files:["core.js","same_chat_loop.js"]});
  const reply=await chrome.tabs.sendMessage(tabId,{type:"same-chat-wake"});
  if(reply?.ok===true)return reply.version===CONTENT_PROTOCOL?
   {ok:true}:{ok:false,reason:"content_script_version_mismatch"};
  return {ok:false,reason:"content_script_missing"};
 }catch(_){return {ok:false,reason:"content_script_missing"};}
}
async function control(m){
 const tabId=m.tabId;
 if(!Number.isInteger(tabId)||tabId<0)return {ok:false,reason:"tab_id_invalid"};
 return serialized(tabId,async()=>{
  const url=await tabUrl(tabId);
  let s=await get(tabId);
  const action=m.action;
  if(action==="start"){
   if(!url)return {ok:false,reason:"open_saved_chat_first"};
   if(s?.status==="running"&&s.url===url)return {ok:false,reason:"already_running",state:shape(s)};
   if(s?.status==="paused"&&s.url===url&&s.phase!=="ready")
    return {ok:false,reason:"uncertain_attempt_requires_stop_and_new_start",state:shape(s)};
   if(await hasOtherOwner(tabId,url))return {ok:false,reason:"another_tab_is_running"};
   const prompt=typeof m.prompt==="string"?m.prompt.trim():"";
   if(!prompt||prompt.length>MAX_PROMPT_CHARS)return {ok:false,reason:"prompt_length_invalid"};
   const unlimited=m.unlimited===true;
   const maxCycles=unlimited?null:Number(m.maxCycles);
   if(!unlimited&&(!Number.isSafeInteger(maxCycles)||maxCycles<1||maxCycles>MAX_SAFE_CYCLES))
    return {ok:false,reason:"cycle_limit_invalid"};
   const allowNewChat=m.allowNewChat===true;
   const rotateEvery=Number(m.rotateEvery??0);
   if(!Number.isSafeInteger(rotateEvery)||rotateEvery<0)
    return {ok:false,reason:"rollover_interval_invalid"};
   s=await put({schema:2,tabId,url,status:"running",phase:"ready",reason:"",
    cycles:0,completed:0,maxCycles,prompt,allowNewChat,rotateEvery,
    checkpointId:url.slice("https://chatgpt.com/c/".length),rollovers:0,
    recoveryCount:0,recoveryNote:"",startedAt:Date.now(),
    lastSentAt:0,attemptId:"",marker:"",attemptStartedAt:0});
  }else{
   if(!s)return {ok:false,reason:"not_bound_to_this_chat"};
   const verification=await checked(tabId,s);
   if(!verification.ok)return verification;
   if(!["rotating","rotating_awaiting_user","bootstrap","bootstrap_awaiting_user"].includes(s.phase)&&s.url!==url)
    return {ok:false,reason:"not_bound_to_this_chat"};
   if(action==="pause"){
    s=await put({...s,status:"paused",reason:"manual_pause"});
   }else if(action==="stop"){
    s=await put({...s,status:"stopped",reason:"manual_stop"});
   }else if(action==="resume"){
    if(s.status!=="paused"||s.phase!=="ready")
     return {ok:false,reason:"uncertain_attempt_requires_stop_and_new_start",state:shape(s)};
    if(s.maxCycles!==null&&s.cycles>=s.maxCycles)
     return {ok:false,reason:"cycle_budget_reached_start_new",state:shape(s)};
    if(await hasOtherOwner(tabId,url))return {ok:false,reason:"another_tab_is_running"};
    s=await put({...s,status:"running",reason:""});
   }else return {ok:false,reason:"unknown_action"};
  }
   if(s.status==="running"){
    const awake=await wakeTab(tabId);
    if(!awake.ok){
     const reason=awake.reason||"content_script_missing";
     s=await put({...s,status:"paused",reason,diagnostic:reason});
     return {ok:false,reason,state:shape(s)};
    }
   }
   return {ok:true,state:shape(s)};
  });
}
async function stage(m,sender){
 const tabId=sender.tab?.id;
 if(!Number.isInteger(tabId))return {ok:false,reason:"sender_tab_required"};
 return serialized(tabId,async()=>{
  let s=await get(tabId);
   if(!s||![1,2,3].includes(s.schema)||s.tabId!==tabId)return {ok:false,reason:"no_state"};
  const check=await checked(tabId,s);
  if(!check.ok)return check;
  if(m.action==="read")return {ok:true,state:shape(s),prompt:s.status==="running"?s.prompt:"",
   checkpointId:s.checkpointId||s.url.slice("https://chatgpt.com/c/".length),
   recoveryNote:s.recoveryNote||""};
  if(s.status!=="running")return {ok:false,reason:"not_running",state:shape(s)};
  if(m.action==="diagnostic"){
   const allowed=new Set(["ready","waiting_for_answer","waiting_for_stability",
    "editor_missing","composer_has_text","generation_active","assistant_selector_missing",
    "waiting_for_click","waiting_for_saved_message","waiting_for_new_chat",
    "waiting_for_assistant","recovering","script_alive","chat_not_ready"]);
   const diagnostic=allowed.has(m.code)?m.code:"unknown";
   const diagnosticSince=s.diagnostic===diagnostic&&s.diagnosticSince?
    s.diagnosticSince:Date.now();
   // A visible completed answer with unsupported DOM must never stay
   // misleadingly "running / ready" indefinitely.
   if(s.phase==="ready"&&diagnostic==="assistant_selector_missing"&&
      Date.now()-diagnosticSince>=90000){
    s=await put({...s,status:"paused",reason:"unsupported_chat_dom",
     diagnostic,diagnosticSince,observedAt:Date.now()});
    return {ok:true,state:shape(s)};
   }
   if(s.diagnostic!==diagnostic||Date.now()-(s.observedAt||0)>14000)
    s=await put({...s,diagnostic,diagnosticSince,observedAt:Date.now()});
   return {ok:true};
  }
  if(m.action==="reserve"){
   if(s.phase!=="ready"||(s.maxCycles!==null&&s.cycles>=s.maxCycles))
    return {ok:false,reason:"not_ready",state:shape(s)};
   if(Date.now()-(s.lastSentAt||0)<COOLDOWN_MS)return {ok:false,reason:"cooldown",state:shape(s)};
   const attemptId=crypto.randomUUID();
   const marker="SCL-"+attemptId;
   const recoveryNote=s.recoveryNote||"";
   s=await put({...s,phase:"reserved",attemptId,marker,attemptStartedAt:Date.now(),
    recoveryNote:""});
   return {ok:true,marker,attemptId,sequence:s.cycles+1,maxCycles:s.maxCycles,
    prompt:s.prompt,checkpointId:s.checkpointId,recoveryNote};
  }
  if(m.action==="rollover"){
   if(!s.allowNewChat||s.phase!=="ready_for_rollover")
    return {ok:false,reason:"rollover_not_allowed"};
   if(s.maxCycles!==null&&s.cycles>=s.maxCycles)
    return {ok:false,reason:"cycle_budget_reached"};
   if(Date.now()-(s.lastSentAt||0)<COOLDOWN_MS)return {ok:false,reason:"cooldown"};
   const attemptId=crypto.randomUUID(),marker="SCL-"+attemptId;
   s=await put({...s,phase:"rotating",attemptId,marker,attemptStartedAt:Date.now(),
    previousUrl:s.url,rollovers:(s.rollovers||0)+1});
   try{
    await chrome.tabs.update(tabId,{url:"https://chatgpt.com/"});
   }catch(_){
    await put({...s,status:"paused",reason:"rollover_navigation_failed"});
    return {ok:false,reason:"rollover_navigation_failed"};
   }
   return {ok:true,state:shape(s)};
  }
  if(m.action==="context_exhausted"){
   if(!s.allowNewChat||!["awaiting_assistant","ready"].includes(s.phase)||
      (s.phase==="awaiting_assistant"&&s.attemptId!==m.attemptId))
    return {ok:false,reason:"context_rollover_not_allowed"};
   if(s.maxCycles!==null&&s.cycles>=s.maxCycles){
    s=await put({...s,status:"paused",reason:"cycle_budget_reached"});
    return {ok:false,reason:"cycle_budget_reached"};
   }
   s=await put({...s,phase:"ready_for_rollover",attemptId:"",marker:"",
    attemptStartedAt:0,
    recoveryNote:"Контекст предыдущего чата закончился до надёжного ответа. Сверь checkpoint и фактические результаты перед новым действием."});
   return {ok:true,state:shape(s)};
  }
  if(m.action==="connection_lost"){
   if(s.phase!=="ready"&&
      (!["awaiting_assistant","awaiting_user"].includes(s.phase)||
        s.attemptId!==m.attemptId))
    return {ok:false,reason:"recovery_not_allowed"};
   if((s.recoveryCount||0)>=2){
    s=await put({...s,status:"paused",reason:"connection_recovery_exhausted"});
    return {ok:false,reason:"connection_recovery_exhausted"};
   }
   const recoveryPhase=s.phase==="ready"?"recovering_ready":
    s.phase==="awaiting_user"?"recovering_send":"recovering";
   s=await put({...s,phase:recoveryPhase,
    recoveryCount:(s.recoveryCount||0)+1,recoveryStartedAt:Date.now()});
   try{await chrome.tabs.reload(tabId);}
   catch(_){
    await put({...s,status:"paused",reason:"reload_failed"});
    return {ok:false,reason:"reload_failed"};
   }
   return {ok:true,state:shape(s)};
  }
  if(m.action==="recovered_ready"){
   if(s.phase!=="recovering_ready")return {ok:false,reason:"recovery_not_ready"};
   s=await put({...s,phase:"ready",recoveryCount:0,recoveryStartedAt:0});
   return {ok:true,state:shape(s)};
  }
  if(m.action==="reserve_stop"){
   if(s.phase!=="recovering"||s.attemptId!==m.attemptId)
    return {ok:false,reason:"recovery_stop_not_allowed"};
   s=await put({...s,phase:"recover_stopping"});
   return {ok:true,state:shape(s)};
  }
  if(m.action==="stopped_generation"){
   if(s.phase!=="recover_stopping"||s.attemptId!==m.attemptId)
    return {ok:false,reason:"recovery_stop_unknown"};
   s=await put({...s,phase:"ready",reason:"",
    recoveryNote:"Предыдущий ответ прервался из-за потери соединения и был остановлен через интерфейс. Сначала проверь checkpoint, существующие файлы и статус действий. Ничего не повторяй без проверки идемпотентности.",
    attemptId:"",marker:"",attemptStartedAt:0,lastSentAt:Date.now()});
   return {ok:true,state:shape(s)};
  }
  if(m.action==="block"){
   const reasons=new Set(["manual_input","route_changed","rate_limited","account_conflict",
    "ui_error","missing_editor","missing_send","not_confirmed","assistant_timeout",
    "uncertain_send","no_reply","assistant_requested_stop","user_message_changed",
    "generation_conflict","session_reloaded","rollover_navigation_failed",
    "recovery_stop_unknown","connection_recovery_exhausted","new_chat_disabled",
    "checkpoint_missing","response_not_confirmed","manual_stop",
    "connection_unavailable"]);
   s=await put({...s,status:"paused",reason:reasons.has(m.reason)?m.reason:"unknown_error"});
   return {ok:true,state:shape(s)};
  }
  if(s.attemptId!==m.attemptId||!s.attemptId)return {ok:false,reason:"attempt_mismatch"};
  if(m.action==="clicked"&&["reserved","rotating","bootstrap"].includes(s.phase)){
   s=await put({...s,phase:s.phase==="rotating"?"rotating_awaiting_user":
      s.phase==="bootstrap"?"bootstrap_awaiting_user":"awaiting_user",
      lastSentAt:Date.now()});
  }else if(m.action==="saved"&&
      (s.phase==="awaiting_user"||s.phase==="recovering_send")){
   s=await put({...s,phase:"awaiting_assistant",cycles:s.cycles+1});
  }else if(m.action==="saved"&&
      (s.phase==="rotating_awaiting_user"||s.phase==="bootstrap_awaiting_user")){
   const next=normalize(m.url||"");
   if(!next||next===s.previousUrl||next!==await tabUrl(tabId))
    return {ok:false,reason:"new_chat_binding_unconfirmed"};
   s=await put({...s,url:next,phase:"awaiting_assistant",cycles:s.cycles+1,
    previousUrl:""});
  }else if(m.action==="completed"&&(s.phase==="awaiting_assistant"||
     s.phase==="recovering")){
   const finished=s.completed+1;
   const exhausted=s.maxCycles!==null&&s.cycles>=s.maxCycles;
   const wantsRollover=s.allowNewChat===true&&!exhausted&&(
    m.nextChat===true||
    (s.rotateEvery>0&&finished>0&&finished%s.rotateEvery===0));
   s=await put({...s,phase:wantsRollover?"ready_for_rollover":"ready",
     attemptId:"",marker:"",attemptStartedAt:0,completed:finished,
     recoveryCount:0,recoveryNote:"",recoveryStartedAt:0,
     status:exhausted?"paused":"running",
     reason:exhausted?"cycle_budget_reached":""});
  }else return {ok:false,reason:"invalid_transition",state:shape(s)};
  return {ok:true,state:shape(s)};
 });
}
let batchBusy=false, batchCancelled=false, batchCancelMode="stop_all";
function validSettings(m){
 const prompt=typeof m.prompt==="string"?m.prompt.trim():"";
 const unlimited=m.unlimited===true, maxCycles=unlimited?null:Number(m.maxCycles);
 const rotateEvery=Number(m.rotateEvery??0);
 return !!prompt&&prompt.length<=MAX_PROMPT_CHARS&&
  (unlimited||(Number.isSafeInteger(maxCycles)&&maxCycles>=1))&&
  Number.isSafeInteger(rotateEvery)&&rotateEvery>=0;
}
async function batchStart(m){
 if(m.mode==="pause_all"||m.mode==="stop_all"){
  batchCancelled=true;
  batchCancelMode=m.mode;
  try{
   const all=await chrome.storage.local.get(null);
   let changed=0;
   for(const [key,record] of Object.entries(all)){
    if(!key.startsWith(PREFIX)||record?.status!=="running"||
       !Number.isInteger(record.tabId))continue;
    await serialized(record.tabId,async()=>{
     const fresh=await get(record.tabId);
     if(fresh?.status!=="running")return;
     await put({...fresh,status:m.mode==="pause_all"?"paused":"stopped",
      reason:m.mode==="pause_all"?"manual_pause_all":"manual_stop_all"});
     changed++;
    });
   }
   return {ok:true,count:changed,mode:m.mode,started:[],skipped:[]};
  }finally{/* Stop/Pause are independent of the admission batch lock. */}
 }
 if(batchBusy)return {ok:false,reason:"batch_busy"};
 if(!validSettings(m))return {ok:false,reason:"invalid_settings"};
 const isTeam=m.mode==="team";
 const requested=Number(m.count||5);
 if(!Number.isInteger(requested)||requested<1||requested>MAX_PARALLEL||
    (isTeam&&requested!==TEAM_ROLES.length))
  return {ok:false,reason:isTeam?"team_requires_five_roles":"parallel_count_out_of_range"};
 const teamPrompts=isTeam?TEAM_ROLES.map(item=>
  TEAM_SHARED+item.brief+"Задание владельца: "+m.prompt.trim()):[];
 if(isTeam&&teamPrompts.some(prompt=>prompt.length>MAX_PROMPT_CHARS))
  return {ok:false,reason:"team_prompt_length_invalid"};
 batchBusy=true;
 batchCancelled=false;
 const teamId=isTeam?crypto.randomUUID():"";
 const result={ok:true,started:[],skipped:[],mode:m.mode};
 try{
  // Hold the admission lock before the first asynchronous storage read.
  // Otherwise two simultaneous user clicks could both launch a full team.
  if(isTeam){
   const all=await chrome.storage.local.get(null);
   if(Object.entries(all).some(([key,row])=>key.startsWith(PREFIX)&&
      row?.status==="running"&&row.teamRole))
    return {ok:false,reason:"team_already_running"};
  }
  const limit=Number(m.count||5);
  if(!Number.isInteger(limit)||limit<1||limit>MAX_PARALLEL)
   return {ok:false,reason:"parallel_count_out_of_range"};
  if(m.mode==="existing"){
   const tabs=await chrome.tabs.query({});
   const seen=new Set();
   const smoke=await chrome.storage.session.get(null).catch(()=>({}));
   const reserved=new Set(Object.entries(smoke).filter(([key])=>
     key.startsWith("chatSmokeTask_")).map(([,v])=>v?.tabId));
   const eligible=tabs.filter(t=>Number.isInteger(t.id)&&normalize(t.url)&&
     !reserved.has(t.id)&&!t.discarded);
   for(const tab of eligible){
    if(batchCancelled||result.started.length>=limit)break;
    const url=normalize(tab.url);
    if(seen.has(url)){result.skipped.push({tabId:tab.id,reason:"duplicate_chat"});continue;}
    seen.add(url);
    const outcome=await control({...m,tabId:tab.id,action:"start"});
    if(outcome.ok)result.started.push({tabId:tab.id,url});
    else result.skipped.push({tabId:tab.id,reason:outcome.reason||"error"});
    if(result.started.length<limit)await new Promise(resolve=>setTimeout(resolve,300));
   }
  }else if(m.mode==="new"||isTeam){
   for(let i=0;i<limit;i++){
    if(batchCancelled)break;
    let tab;
    try{
     if(isTeam||m.separateWindows===true){
      const win=await chrome.windows.create({url:"https://chatgpt.com/",focused:false});
      tab=win?.tabs?.[0];
     }else tab=await chrome.tabs.create({url:"https://chatgpt.com/",active:false});
     if(!Number.isInteger(tab?.id))throw Error("missing_tab_id");
     const id=crypto.randomUUID(),attemptId=crypto.randomUUID();
     const now=Date.now();
     const s={schema:3,tabId:tab.id,url:"",status:"running",phase:"bootstrap",
      reason:"",prompt:isTeam?teamPrompts[i]:m.prompt.trim(),
      teamRole:isTeam?TEAM_ROLES[i].role:"",teamId,
      maxCycles:m.unlimited===true?null:Number(m.maxCycles),
      allowNewChat:m.allowNewChat===true,rotateEvery:Number(m.rotateEvery||0),
      cycles:0,completed:0,checkpointId:id,rollovers:0,recoveryCount:0,
      recoveryNote:"",attemptId,marker:"SCL-"+attemptId,attemptStartedAt:now,
      startedAt:now,lastSentAt:0};
     const admitted=await serialized(tab.id,async()=>{
      if(batchCancelled)return false;
      await put(s);
      if(batchCancelled){await put({...s,status:batchCancelMode==="pause_all"?"paused":"stopped",reason:"manual_"+batchCancelMode});return false;}
      return true;
     });
     if(!admitted){result.skipped.push({index:i+1,reason:"batch_cancelled"});break;}
     result.started.push({tabId:tab.id,newChat:true,...(isTeam?{role:TEAM_ROLES[i].role}:{})});
     if(i+1<limit)await new Promise(resolve=>setTimeout(resolve,850));
    }catch(_){
     result.skipped.push({index:i+1,reason:"new_tab_unavailable"});
    }
   }
  }else return {ok:false,reason:"unknown_batch_mode"};
  result.count=result.started.length;
  return result;
 }finally{batchBusy=false;batchCancelled=false;}
}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
 if(!m||typeof m.type!=="string"||!m.type.startsWith("same-chat-"))return;
 (async()=>{
   if(m.type==="same-chat-control"){
    if(sender.tab)return {ok:false,reason:"popup_only"};
    return control(m);
   }
   if(m.type==="same-chat-batch"){
    if(sender.tab)return {ok:false,reason:"popup_only"};
    return batchStart(m);
   }
   if(m.type==="same-chat-summary"){
    if(sender.tab)return {ok:false,reason:"popup_only"};
    const all=await chrome.storage.local.get(null);
    const sessions=Object.entries(all).filter(([k,v])=>
      k.startsWith(PREFIX)&&v&&v.status==="running");
    const now=Date.now();
    const confirmed=sessions.filter(([,v])=>Number.isFinite(v.observedAt)&&
      v.observedAt>=v.startedAt&&v.observedAt>0&&
      now-v.observedAt>=0&&now-v.observedAt<=90000);
    const roles=sessions.map(([,v])=>v.teamRole||"").filter(Boolean);
    return {ok:true,running:sessions.length,
      confirmed_observers:confirmed.length,
      awaiting_observer:sessions.length-confirmed.length,
      team_roles:roles,
      ids:sessions.map(([,v])=>v.tabId)};
   }
  if(m.type==="same-chat-status"){
   if(sender.tab||!Number.isInteger(m.tabId))return {ok:false};
   const s=await get(m.tabId);
   if(!s)return {ok:true,state:null,defaults};
   const result=await checked(m.tabId,s);
   return {...result,defaults,prompt:s.prompt||""};
  }
  if(m.type==="same-chat-stage"){
   return stage(m,sender);
  }
  return {ok:false,reason:"unknown_type"};
 })().then(respond,()=>respond({ok:false,reason:"storage_or_runtime_error"}));
 return true;
});
chrome.tabs.onRemoved.addListener(id=>{
 void serialized(id,async()=>{
  const s=await get(id);
  if(s?.status==="running")await put({...s,status:"paused",reason:"tab_closed"});
 }).catch(()=>{});
});
chrome.tabs.onUpdated.addListener((tabId,changeInfo)=>{
 if(!changeInfo.url)return;
 void serialized(tabId,async()=>{
  const s=await get(tabId);
   if(s?.status==="running"&&
      !["rotating","rotating_awaiting_user","bootstrap",
        "bootstrap_awaiting_user"].includes(s.phase)&&
      normalize(changeInfo.url)!==s.url)
    await put({...s,status:"paused",reason:"conversation_changed"});
 }).catch(()=>{});
});
// A service-worker/browser restart can lose exact-send evidence.
// Never replay an uncertain user message or auto-run a stale checkpoint.
async function suspendOnRestart(){
 const all=await chrome.storage.local.get(null);
 for(const [k,s] of Object.entries(all)){
  if(k.startsWith(PREFIX)&&s?.status==="running")
   await put({...s,status:"paused",reason:"session_reloaded"});
 }
}
// Content scripts in discarded/background tabs can stop ticking entirely.
// Fail closed when no observer heartbeat has arrived for six minutes.
const OBSERVER_STALE_MS=360000;
async function sweepStaleLoops(){
 const all=await chrome.storage.local.get(null);
 const now=Date.now();
 for(const [storageKey,entry] of Object.entries(all)){
  if(!storageKey.startsWith(PREFIX)||entry?.status!=="running"||
     !Number.isInteger(entry.tabId))continue;
  const last=Math.max(entry.observedAt||0,entry.startedAt||0);
  if(!last||now-last<OBSERVER_STALE_MS)continue;
  await serialized(entry.tabId,async()=>{
   const current=await get(entry.tabId);
   const lastSeen=Math.max(current?.observedAt||0,current?.startedAt||0);
   if(current?.status==="running"&&lastSeen&&Date.now()-lastSeen>=OBSERVER_STALE_MS)
    await put({...current,status:"paused",reason:"observer_stale",
     diagnostic:"observer_stale"});
  });
 }
}
if(chrome.alarms?.onAlarm?.addListener){
 chrome.alarms.onAlarm.addListener(alarm=>{
  if(alarm?.name==="chat-smoke-queue")void sweepStaleLoops().catch(()=>{});
 });
}
chrome.runtime.onStartup.addListener(()=>{void suspendOnRestart();});
chrome.runtime.onInstalled.addListener(()=>{void suspendOnRestart();});
})();
