# Portable MCP migration (2026-11-11)

**START HERE:** [Complete Windows + existing Secure MCP Tunnel setup](docs/TRANSFER_TO_NEW_PC_RU.md)

This archive contains a verified base installer with Web Companion v0.8.5. Newer source snapshot v0.9.7 is stored separately under migration-snapshot/; it is not automatically installed or proven compatible.

Locally generated configuration, user authorizations, tokens, private keys, browser profiles and runtime session state are intentionally absent.
A restricted Platform runtime API key, a valid Tunnel ID and an account/workspace with custom-MCP permission are required for live remote ChatGPT use. Full MCP access is not automatically available on personal ChatGPT plans.
Use a **new target-local** profile/key; never reuse original secrets.
