# Portable MCP migration (2026-11-11)
A tested base archive was combined with an INACTIVE filtered current source snapshot under migration-snapshot/.
Runtime secrets, browser profiles, cookies, auth state, local databases, and .env files were excluded.
Do not treat this as an active tunnel binding: on the target machine configure its own local credentials and tunnel profile.
Use INSTALL_FROM_ARCHIVE.ps1 and docs/ARCHIVE_INSTALL_RU.md after extracting, then run scripts/status-stack.py.
The tested base browser extension is older than migration-snapshot (0.9.7). The newer source is NOT installed automatically.
Never import an existing personal browser profile or authorization store.
