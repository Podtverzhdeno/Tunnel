# New Chat Smoke Test

These files are the source of a custom MCP App. They do not carry any existing ChatGPT App ID, authorization or session. On another account, deploy a new stdio MCP server and configure a new Tunnel custom app; see the full Tunnel README for steps. Uploading this ZIP to ChatGPT does not guarantee automatic app registration.
